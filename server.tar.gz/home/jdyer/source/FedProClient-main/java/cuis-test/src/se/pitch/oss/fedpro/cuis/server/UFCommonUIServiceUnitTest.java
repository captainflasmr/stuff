package se.pitch.oss.fedpro.cuis.server;

import com.baesystems.mimesis.UfCuiHlaServer.RegisterRequest;
import com.baesystems.mimesis.UfCuiHlaServer.RegisterResponse;
import io.grpc.stub.StreamObserver;
import org.junit.Test;
import se.pitch.oss.fedpro.cuis.server.grpc.UFCommonUIServiceImpl;
import se.pitch.oss.fedpro.cuis.server.session.SessionRegistry;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/**
 * Unit test for {@link UFCommonUIServiceImpl#registerClient} that calls the
 * service directly (no gRPC transport) and verifies a session is minted.
 *
 * <p>Registration does not touch the RTI, so a null {@code RtiAdapter} is fine.
 */
public class UFCommonUIServiceUnitTest {

   private static class CapturingObserver implements StreamObserver<RegisterResponse> {
      private RegisterResponse resp;
      private Throwable error;

      @Override
      public void onNext(RegisterResponse registerResponse) {
         this.resp = registerResponse;
      }

      @Override
      public void onError(Throwable throwable) {
         this.error = throwable;
      }

      @Override
      public void onCompleted() { }
   }

   @Test
   public void register_directServiceCallRegistersSession() {
      SessionRegistry registry = new SessionRegistry();
      UFCommonUIServiceImpl svc = new UFCommonUIServiceImpl(registry, null);

      RegisterRequest req = RegisterRequest.newBuilder()
            .setClientAddr("localhost")
            .setClientPortNumber(0)
            .setLittleEndian(false)
            .build();

      CapturingObserver obs = new CapturingObserver();
      svc.registerClient(req, obs);

      assertNull(obs.error);
      assertTrue(obs.resp.getSuccessful().getSuccessful());
      int id = obs.resp.getTheClientId().getId();
      assertTrue("server-assigned id should be positive", id > 0);
      assertNotNull(registry.getSession(id));
   }
}
