package se.pitch.oss.fedpro.cuis.server;

import com.baesystems.mimesis.UFCommonUIServiceGrpc;
import com.baesystems.mimesis.UfCuiHlaServer.Client_Id;
import com.baesystems.mimesis.UfCuiHlaServer.PublishObjectRequest;
import com.baesystems.mimesis.UfCuiHlaServer.PublishObjectResponse;
import com.baesystems.mimesis.UfCuiHlaServer.RegisterRequest;
import com.baesystems.mimesis.UfCuiHlaServer.RegisterResponse;
import hla.rti1516_2025.RTIambassador;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.junit.Test;
import se.pitch.oss.fedpro.cuis.server.rti.CuisHandleFactory;

import java.lang.reflect.Proxy;

import static org.junit.Assert.assertTrue;

/**
 * Integration test that drives the CUIS gRPC service over a real channel
 * against a lightweight dynamic-proxy {@link RTIambassador}.
 *
 * <p>The proxy returns {@code null} for every call except object-class name
 * resolution, where it hands back a stub handle. That one value is needed
 * because the service now resolves object/interaction class names to HLA
 * handles through the RTI before publishing; a purely null RTI would make the
 * publish path fail. This keeps the test self-contained (no mock RTI module).
 */
public class IntegrationCuisTest {

   private static RTIambassador stubRti() {
      return (RTIambassador) Proxy.newProxyInstance(
            RTIambassador.class.getClassLoader(),
            new Class[]{RTIambassador.class},
            (proxy, method, args) -> {
               if (method.getName().equals("getObjectClassHandle")) {
                  return CuisHandleFactory.objectClassHandle(new byte[]{0, 0, 0, 1});
               }
               return null;
            }
      );
   }

   @Test
   public void registerClient_rpcSucceeds() throws Exception {
      CuisMain app = new CuisMain(stubRti(), 0);
      try {
         app.start("IntegrationFed", new String[0]);

         int port = app.getGrpcServer().getPort();
         ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", port).usePlaintext().build();
         try {
            UFCommonUIServiceGrpc.UFCommonUIServiceBlockingStub stub = UFCommonUIServiceGrpc.newBlockingStub(channel);
            RegisterResponse resp = stub.registerClient(RegisterRequest.newBuilder()
                  .setClientAddr("localhost")
                  .setClientPortNumber(12345)
                  .setLittleEndian(false)
                  .build());

            assertTrue(resp.getSuccessful().getSuccessful());
            assertTrue("server-assigned id should be positive", resp.getTheClientId().getId() > 0);
         } finally {
            channel.shutdownNow();
         }
      } finally {
         app.stop();
      }
   }

   @Test
   public void publishObjectAttributes_rpcRegistersPublication() throws Exception {
      CuisMain app = new CuisMain(stubRti(), 0);
      try {
         app.start("IntegrationFed", new String[0]);

         int port = app.getGrpcServer().getPort();
         ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", port).usePlaintext().build();
         try {
            UFCommonUIServiceGrpc.UFCommonUIServiceBlockingStub stub = UFCommonUIServiceGrpc.newBlockingStub(channel);

            // Register a client first
            RegisterResponse regResp = stub.registerClient(RegisterRequest.newBuilder()
                  .setClientAddr("localhost")
                  .setClientPortNumber(12345)
                  .setLittleEndian(false)
                  .build());
            int regId = regResp.getTheClientId().getId();
            assertTrue(regId > 0);

            // Publish an object class by name
            String objName = "TestObject";
            PublishObjectResponse pubResp = stub.publishObjectAttributes(PublishObjectRequest.newBuilder()
                  .setTheClientId(Client_Id.newBuilder().setId(regId).build())
                  .setName(objName)
                  .build());
            assertTrue("publish should succeed: " + pubResp.getSuccessful().getErrorText(),
                  pubResp.getSuccessful().getSuccessful());

            // Verify server-side session recorded the publication (keyed by class name)
            assertTrue(app.getSessionRegistry().getSession(regId).hasPublishedObject(objName));
         } finally {
            channel.shutdownNow();
         }
      } finally {
         app.stop();
      }
   }
}
