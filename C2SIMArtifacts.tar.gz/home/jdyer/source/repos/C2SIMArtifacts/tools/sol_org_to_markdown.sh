#!/usr/bin/env sh
set -eu

# Export the SOL Org document as GFM Markdown.
#
# The built-in Org Markdown exporter (ox-md) writes HTML <table> elements.
# VisualSVN Server renders GFM pipe tables but does not necessarily render
# raw HTML tables the same way, so use a GFM writer instead.
#
# Usage:
#   tools/sol_org_to_markdown.sh [input.org] [output.md]
#
# Defaults:
#   input  = Documents/SOL.org
#   output = Documents/SOL.md

repo_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
input=${1:-"$repo_root/Documents/SOL.org"}
output=${2:-"$repo_root/Documents/SOL.md"}

if ! command -v pandoc >/dev/null 2>&1; then
    echo "error: pandoc is required to export SOL.org as GFM Markdown" >&2
    exit 1
fi

pandoc "$input" -f org -t gfm --wrap=none -o "$output"
echo "Wrote $output"
