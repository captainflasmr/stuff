#!/usr/bin/env python3
"""Generate the SOL XML instance from the CSV source tables.

The SOL source of truth is a small set of CSV tables under
``libraries/sol-data``.  This script reads those tables, builds the SOL
XML document in the element order required by ``libraries/SOL.xsd``,
writes ``libraries/sol-minimal.xml`` and validates the result against
the schema with ``xmllint``.

Tables
------
library.csv
    One row with the SOL root attributes and the ``Metadata`` block.
objects.csv
    One row per SOL object.  Columns cover the object identity and the
    optional C2SIM identity/organisation slots that the current
    catalogue uses.
platform-details.csv
    One row per platform object, keyed by ``object_id``, with the
    physical, performance and complement measures.  Every measure is
    written as ``value unit`` (for example ``149.9 m``).
sensor-details.csv
    One row per sensor object, keyed by ``object_id``, with the broad
    sensor category, maximum detection range and field of view.  Measures
    are written as ``value unit`` (for example ``360 deg``).

The generated XML file is a build product; edit the CSV tables instead.
"""

from __future__ import annotations

import argparse
import csv
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

SOL_NS = "https://mimesis.org/library/sol/0.1"
C2SIM_NS = "http://www.sisostds.org/schemas/C2SIM/1.1"

ID_PATTERN = re.compile(r"^[a-z0-9]+([a-z0-9-]*[a-z0-9]+)?$")
KINDS = {"platform", "sensor", "weapon", "munition", "organisation", "behaviour"}

PHYSICAL_COLUMNS = {
    "length": "Length",
    "beam": "Beam",
    "draught": "Draught",
    "height": "Height",
    "mass": "Mass",
}

PERFORMANCE_COLUMNS = {
    "cruise_speed": "CruiseSpeed",
    "max_speed": "MaxSpeed",
    "range": "Range",
    "endurance": "Endurance",
    "max_depth": "MaxDepth",
    "service_ceiling": "ServiceCeiling",
    "climb_rate": "ClimbRate",
}

COMPLEMENT_COLUMNS = {
    "crew": "Crew",
    "passengers": "Passengers",
}

SENSOR_CATEGORIES = {
    "radar",
    "sonar",
    "electro-optical",
    "infrared",
    "laser",
    "electronic-support-measures",
    "magnetic-anomaly",
    "other",
}

SENSOR_COLUMNS = {
    "sensor_type": "Type",
    "range": "Range",
    "field_of_view": "FieldOfView",
}


def q(namespace: str, tag: str) -> str:
    """Return an ElementTree qualified name."""
    return f"{{{namespace}}}{tag}"


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    """Read a CSV file into a header and a list of stripped dictionaries."""
    if not path.is_file():
        raise ValueError(f"Missing CSV table: {path}")

    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle)
        try:
            header = [column.strip() for column in next(reader)]
        except StopIteration:
            raise ValueError(f"CSV table is empty: {path}") from None

        rows: list[dict[str, str]] = []
        for line_number, values in enumerate(reader, start=2):
            if not values or all(not value.strip() for value in values):
                continue
            if len(values) != len(header):
                raise ValueError(
                    f"{path}:{line_number}: expected {len(header)} columns, "
                    f"got {len(values)}"
                )
            rows.append(
                {
                    column: value.strip()
                    for column, value in zip(header, values, strict=True)
                }
            )
        return header, rows


def require_columns(header: list[str], path: Path, columns: list[str]) -> None:
    """Ensure every required column is present in a CSV table."""
    missing = [column for column in columns if column not in header]
    if missing:
        raise ValueError(f"CSV table {path} is missing columns: {', '.join(missing)}")


def index_details(
    rows: list[dict[str, str]],
    table_name: str,
) -> dict[str, dict[str, str]]:
    """Index detail rows by object_id, rejecting duplicate rows."""
    details: dict[str, dict[str, str]] = {}
    for row in rows:
        object_id = row["object_id"]
        if object_id in details:
            raise ValueError(
                f"{table_name} has more than one row for '{object_id}'"
            )
        details[object_id] = row
    return details


def parse_measure(value: str, column: str, object_id: str) -> tuple[str, str]:
    """Split a ``value unit`` cell into its value and unit parts."""
    if " " not in value:
        raise ValueError(
            f"Measure '{column}' for object '{object_id}' must be "
            f"'value unit' (for example '149.9 m'); got '{value}'"
        )

    number, unit = value.rsplit(" ", 1)
    if not number or not unit:
        raise ValueError(
            f"Measure '{column}' for object '{object_id}' has an empty "
            f"value or unit: '{value}'"
        )
    return number, unit


def add_text(parent: ET.Element, namespace: str, tag: str, text: str) -> ET.Element:
    """Append a simple text element."""
    element = ET.SubElement(parent, q(namespace, tag))
    element.text = text
    return element


def add_measure(
    parent: ET.Element,
    namespace: str,
    tag: str,
    value: str,
    column: str,
    object_id: str,
) -> ET.Element:
    """Append a MeasureType element with its required unit attribute."""
    number, unit = parse_measure(value, column, object_id)
    element = ET.SubElement(parent, q(namespace, tag))
    element.set("unit", unit)
    element.text = number
    return element


def build_metadata(library: dict[str, str]) -> ET.Element:
    """Build the SOL Metadata block from the library table row."""
    metadata = ET.Element(q(SOL_NS, "Metadata"))
    add_text(metadata, SOL_NS, "LibraryId", library["library_id"])
    add_text(metadata, SOL_NS, "Status", library["status"])

    classification = library.get("classification", "")
    if classification:
        add_text(metadata, C2SIM_NS, "SecurityClassificationCode", classification)

    return metadata


def build_platform(
    details: dict[str, str],
    object_id: str,
) -> ET.Element | None:
    """Build the Platform block for one platform object."""
    physical_values = {
        tag: details[column]
        for column, tag in PHYSICAL_COLUMNS.items()
        if details.get(column, "")
    }
    performance_values = {
        tag: details[column]
        for column, tag in PERFORMANCE_COLUMNS.items()
        if details.get(column, "")
    }
    complement_values = {
        tag: details[column]
        for column, tag in COMPLEMENT_COLUMNS.items()
        if details.get(column, "")
    }

    if not (physical_values or performance_values or complement_values):
        return None

    platform = ET.Element(q(SOL_NS, "Platform"))

    if physical_values:
        physical = ET.SubElement(platform, q(SOL_NS, "Physical"))
        for tag, value in physical_values.items():
            add_measure(physical, SOL_NS, tag, value, tag, object_id)

    if performance_values:
        performance = ET.SubElement(platform, q(SOL_NS, "Performance"))
        for tag, value in performance_values.items():
            add_measure(performance, SOL_NS, tag, value, tag, object_id)

    if complement_values:
        complement = ET.SubElement(platform, q(SOL_NS, "Complement"))
        for tag, value in complement_values.items():
            add_text(complement, SOL_NS, tag, value)

    return platform


def build_sensor(
    details: dict[str, str],
    object_id: str,
) -> ET.Element | None:
    """Build the Sensor block for one sensor object."""
    values = {
        tag: details[column]
        for column, tag in SENSOR_COLUMNS.items()
        if details.get(column, "")
    }

    if not values:
        return None

    category = values.get("Type", "")
    if category and category not in SENSOR_CATEGORIES:
        raise ValueError(
            f"Sensor '{object_id}' has unsupported sensor_type '{category}'; "
            f"expected one of: {', '.join(sorted(SENSOR_CATEGORIES))}"
        )

    sensor = ET.Element(q(SOL_NS, "Sensor"))
    for tag, value in values.items():
        if tag == "Type":
            add_text(sensor, SOL_NS, tag, value)
        else:
            add_measure(sensor, SOL_NS, tag, value, tag, object_id)

    return sensor


def build_object(
    row: dict[str, str],
    platform_details: dict[str, str] | None,
    sensor_details: dict[str, str] | None,
) -> ET.Element:
    """Build one SOL Object element in the order required by SOL.xsd."""
    object_id = row["id"]
    kind = row["kind"]

    if not ID_PATTERN.match(object_id):
        raise ValueError(f"Object id '{object_id}' does not match IdentifierType")
    if kind not in KINDS:
        raise ValueError(f"Object '{object_id}' has unsupported kind '{kind}'")
    if not row["version"]:
        raise ValueError(f"Object '{object_id}' is missing a version")
    if not row["name"]:
        raise ValueError(f"Object '{object_id}' is missing a name")

    entity_name = row.get("entity_type_name", "")
    entity_namespace = row.get("entity_type_namespace", "")
    if (entity_name or entity_namespace) and not (entity_name and entity_namespace):
        raise ValueError(
            f"Object '{object_id}' needs both entity_type_name and "
            f"entity_type_namespace when a NamedEntityType is supplied"
        )

    element = ET.Element(q(SOL_NS, "Object"))
    element.set("id", object_id)
    element.set("kind", kind)
    element.set("version", row["version"])

    add_text(element, SOL_NS, "Name", row["name"])

    if row.get("role", ""):
        add_text(element, SOL_NS, "Role", row["role"])

    if entity_name and entity_namespace:
        named_type = ET.SubElement(element, q(C2SIM_NS, "NamedEntityType"))
        add_text(named_type, C2SIM_NS, "EntityTypeName", entity_name)
        add_text(named_type, C2SIM_NS, "EntityTypeNamespace", entity_namespace)

    if row.get("organization_type_code", ""):
        add_text(
            element,
            C2SIM_NS,
            "OrganizationTypeCode",
            row["organization_type_code"],
        )

    if row.get("country_code", ""):
        add_text(element, C2SIM_NS, "CountryCode", row["country_code"])

    if row.get("echelon_code", ""):
        add_text(element, C2SIM_NS, "EchelonCode", row["echelon_code"])

    if platform_details is not None and kind == "platform":
        platform = build_platform(platform_details, object_id)
        if platform is not None:
            element.append(platform)

    if sensor_details is not None and kind == "sensor":
        sensor = build_sensor(sensor_details, object_id)
        if sensor is not None:
            element.append(sensor)

    return element


def build_xml(
    library: dict[str, str],
    objects: list[dict[str, str]],
    platform_details: dict[str, dict[str, str]],
    sensor_details: dict[str, dict[str, str]],
) -> ET.Element:
    """Build the complete SOL document."""
    ET.register_namespace("", SOL_NS)
    ET.register_namespace("c2sim", C2SIM_NS)

    if not library.get("authority"):
        raise ValueError("library.csv is missing the authority value")
    if not library.get("version"):
        raise ValueError("library.csv is missing the version value")

    seen_ids: set[str] = set()
    for row in objects:
        object_id = row["id"]
        if object_id in seen_ids:
            raise ValueError(f"Duplicate object id '{object_id}' in objects.csv")
        seen_ids.add(object_id)

    for object_id in platform_details:
        if object_id not in seen_ids:
            raise ValueError(
                f"platform-details.csv references unknown object '{object_id}'"
            )

    for object_id in sensor_details:
        if object_id not in seen_ids:
            raise ValueError(
                f"sensor-details.csv references unknown object '{object_id}'"
            )

    root = ET.Element(q(SOL_NS, "SOL"))
    root.set("authority", library["authority"])
    root.set("version", library["version"])

    root.append(build_metadata(library))

    objects_element = ET.SubElement(root, q(SOL_NS, "Objects"))
    for row in objects:
        platform_row = platform_details.get(row["id"])
        sensor_row = sensor_details.get(row["id"])

        if platform_row is not None and row["kind"] != "platform":
            print(
                f"warning: object '{row['id']}' has platform details but "
                f"kind '{row['kind']}'",
                file=sys.stderr,
            )
        if platform_row is None and row["kind"] == "platform":
            print(
                f"warning: platform object '{row['id']}' has no "
                f"platform-details row",
                file=sys.stderr,
            )

        if sensor_row is not None and row["kind"] != "sensor":
            print(
                f"warning: object '{row['id']}' has sensor details but "
                f"kind '{row['kind']}'",
                file=sys.stderr,
            )
        if sensor_row is None and row["kind"] == "sensor":
            print(
                f"warning: sensor object '{row['id']}' has no "
                f"sensor-details row",
                file=sys.stderr,
            )

        objects_element.append(build_object(row, platform_row, sensor_row))

    return root


def write_xml(root: ET.Element, output: Path) -> None:
    """Serialise the tree with the project's XML declaration style."""
    ET.indent(root, space="  ")
    body = ET.tostring(root, encoding="unicode")

    lines = body.splitlines(keepends=True)
    if lines and lines[0].startswith("<SOL "):
        lines[0] = (
            f'<SOL xmlns="{SOL_NS}"\n'
            f'     xmlns:c2sim="{C2SIM_NS}"\n'
            f'     authority="{root.attrib["authority"]}" '
            f'version="{root.attrib["version"]}">\n'
        )
        body = "".join(lines)

    if not body.endswith("\n"):
        body += "\n"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n' + body,
        encoding="utf-8",
    )


def validate_xml(schema: Path, output: Path) -> None:
    """Validate the generated XML against the SOL XSD with xmllint."""
    if shutil.which("xmllint") is None:
        raise RuntimeError("xmllint is required for schema validation")

    result = subprocess.run(
        ["xmllint", "--noout", "--schema", str(schema), str(output)],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(
            "Schema validation failed:\n"
            + (result.stderr.strip() or result.stdout.strip())
        )


def parse_args() -> argparse.Namespace:
    repo_root = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=repo_root / "libraries" / "sol-data",
        help="directory containing the SOL CSV tables",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=repo_root / "libraries" / "sol-minimal.xml",
        help="generated SOL XML file",
    )
    parser.add_argument(
        "--schema",
        type=Path,
        default=repo_root / "libraries" / "SOL.xsd",
        help="SOL XSD used for validation",
    )
    parser.add_argument(
        "--no-validate",
        action="store_true",
        help="generate the XML but skip xmllint schema validation",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    library_header, library_rows = read_csv(args.input_dir / "library.csv")
    object_header, object_rows = read_csv(args.input_dir / "objects.csv")
    platform_header, platform_rows = read_csv(
        args.input_dir / "platform-details.csv"
    )
    sensor_header, sensor_rows = read_csv(args.input_dir / "sensor-details.csv")

    require_columns(
        library_header,
        args.input_dir / "library.csv",
        ["authority", "version", "library_id", "status", "classification"],
    )
    require_columns(
        object_header,
        args.input_dir / "objects.csv",
        [
            "id",
            "kind",
            "version",
            "name",
            "role",
            "entity_type_name",
            "entity_type_namespace",
            "organization_type_code",
            "country_code",
            "echelon_code",
        ],
    )
    require_columns(
        platform_header,
        args.input_dir / "platform-details.csv",
        ["object_id"]
        + list(PHYSICAL_COLUMNS)
        + list(PERFORMANCE_COLUMNS)
        + list(COMPLEMENT_COLUMNS),
    )
    require_columns(
        sensor_header,
        args.input_dir / "sensor-details.csv",
        ["object_id"] + list(SENSOR_COLUMNS),
    )

    if len(library_rows) != 1:
        raise ValueError("library.csv must contain exactly one data row")
    if not object_rows:
        raise ValueError("objects.csv must contain at least one object row")

    platform_details = index_details(platform_rows, "platform-details.csv")
    sensor_details = index_details(sensor_rows, "sensor-details.csv")

    root = build_xml(
        library_rows[0],
        object_rows,
        platform_details,
        sensor_details,
    )
    write_xml(root, args.output)

    if not args.no_validate:
        validate_xml(args.schema, args.output)

    print(f"Generated {args.output}")
    if not args.no_validate:
        print(f"Validated against {args.schema}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, RuntimeError) as error:
        print(f"error: {error}", file=sys.stderr)
        raise SystemExit(1)
