# C2SIMArtifacts
This repository contains artifacts supporting the Command and Control Systems - Simulation Systems Interoperation (C2SIM) international standard produced by the Simulation Interoperability Standards Organization (SISO) C2SIM Product Development Group / Product Support Group. 

For information on the reference architecture (OpenC2SIM), please see: https://openc2sim.github.io/

## SOL data workflow

The SOL instance `libraries/sol-minimal.xml` is generated from the CSV tables in `libraries/sol-data/`:

- `library.csv` — library metadata and root attributes
- `objects.csv` — one row per SOL object
- `platform-details.csv` — one row per platform object
- `sensor-details.csv` — one row per sensor object

Edit the CSV tables, then regenerate and validate the XML with:

    python3 tools/sol_table_to_xml.py

The script writes `libraries/sol-minimal.xml` and validates it against `libraries/SOL.xsd` using `xmllint`.

See [`Documents/SOL.org`](Documents/SOL.org) for the full SOL data workflow, CSV column reference, validation rules and troubleshooting.

To export that document as a VisualSVN-friendly Markdown file with GFM pipe tables:

    tools/sol_org_to_markdown.sh Documents/SOL.org Documents/SOL.md

Upload the result as `README.md` on the VisualSVN server.
