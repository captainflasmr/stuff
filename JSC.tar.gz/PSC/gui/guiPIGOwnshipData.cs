//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiPIGOwnshipData.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Drawing;

namespace PSCGenericBuild
{
	
	//-----------------------------------------------------------------------
	//The PIG Ownship Data Page Class.
	//-----------------------------------------------------------------------
	public class C_guiPIGOwnshipData : C_guiTemplatePage
	{
		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		//protected C_guiDataItem [] dataItem;
		protected string     [] strDescription;
		public PIGOwnshipData   m_InData;

		public const int NUM_MASTS = 10;

		public C_guiDataItemByte  dataType;	
		public C_guiDataItemByte  dataSmoke;	
		public C_guiDataItemFloat dataLatitude;	
		public C_guiDataItemFloat dataLongitude;	
		public C_guiDataItemFloat dataX;	
		public C_guiDataItemFloat dataY;	
		public C_guiDataItemFloat dataDepth;
		public C_guiDataItemFloat dataHeading;	
		public C_guiDataItemFloat dataRoll;
		public C_guiDataItemFloat dataPitch;	
		public C_guiDataItemFloat dataSpeed;	

		public C_guiDataItemFloat [] dataMast;	

		//-----------------------------------------------------------------------
		//Class Properties
		//-----------------------------------------------------------------------
		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		/************************************************************************
		  FUNCTION      : C_guiOwnshipData()
		  DESCRIPTION   : The Constructor for Ownship Data Page. 
		  PARAMETERS    : parentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the Ownship Data Page.
		 ************************************************************************/
		public C_guiPIGOwnshipData (C_gui parentForm)
		{
			string [] strOnOff     = {"Off", "On"};
			string [] strType      = {"Swiftsure", "Trafalgar", "Vanguard", "Astute", "Victoria"};

			this.ptrGui   = parentForm;
			//this.ptrPSC    = parentForm.psc;

			this.Text     = "PIG Data - Ownship Data";

			//-----------------------------------------------------
			//Declare the data items.
			//-----------------------------------------------------
			m_dataItem    = new C_guiDataItem[21];
			this.pageType = C_gui.page.PIG_OWNSHIP;

			m_InData  = this.ptrGui.m_InPIGData.oPIGOwnship;


			strDescription = new String[12];

			strDescription[0]  = "Ownship type (Swiftsure/Trafalgar/Vanguard/Astute/Victoria";
			strDescription[1]  = "Diesel smoke (On/Off)";
			strDescription[2]  = "Current latitude ("            +  ")";
			strDescription[3]  = "Current longitude ("           +  ")";
			strDescription[4]  = "X position from reference ("   +  ") (m)";
			strDescription[5]  = "Y position from reference ("   +  ") (m)";
			strDescription[6]  = "Periscope (eyepoint) height (" +  ") (m)";
			strDescription[7]  = "True bearing ("                +  ")";
			strDescription[8]  = "Roll angle ("                  +  ")";
			strDescription[9]  = "Pitch angle ("                 +  ")";
			strDescription[10] = "Speed (m-per-s) ("             +  ")";
			strDescription[11] = "Mast Height ("                 +  ") (m)";


			//-----------------------------------------------------
			//Initialise each data item.
			//-----------------------------------------------------
			dataType      = new C_guiDataItemByte( "Type",     "PIG_OWNSHIP_TYPE",     50,  10, this, strDescription[0]);
			dataSmoke     = new C_guiDataItemByte( "Smoke",    "PIG_OWNSHIP_SMOKE",    50,  40, this, strDescription[1]);
			dataLatitude  = new C_guiDataItemFloat( "Latitude", "PIG_OWNSHIP_LATITUDE", 50,  70, this, strDescription[2]);
			dataLongitude = new C_guiDataItemFloat( "Longitude","PIG_OWNSHIP_LONGITUDE",50, 100, this, strDescription[3]);
			dataX         = new C_guiDataItemFloat( "X",        "PIG_OWNSHIP_X",        50, 130, this, strDescription[4]);
			dataY         = new C_guiDataItemFloat( "Y",        "PIG_OWNSHIP_Y",        50, 160, this, strDescription[5]);
			dataDepth     = new C_guiDataItemFloat( "Depth",    "PIG_OWNSHIP_DEPTH",    50, 190, this, strDescription[6]);
			dataHeading   = new C_guiDataItemFloat( "Heading",  "PIG_OWNSHIP_HEADING",  50, 220, this, strDescription[7]);
			dataRoll      = new C_guiDataItemFloat( "Roll",     "PIG_OWNSHIP_ROLL",     50, 250, this, strDescription[8]);
			dataPitch     = new C_guiDataItemFloat( "Pitch",    "PIG_OWNSHIP_PITCH",    50, 280, this, strDescription[9]);
			dataSpeed     = new C_guiDataItemFloat( "Speed",    "PIG_OWNSHIP_SPEED",    50, 310, this, strDescription[10]);

            dataMast      = new C_guiDataItemFloat[NUM_MASTS];

			for(int i = 0; i <  NUM_MASTS; i++)
			{
				string strMast = String.Format("Mast Height ({0})", i+1);
				string strHashTableKey = "PIG_OWNSHIP_MAST_" + i + "_HEIGHT";
				dataMast[i] = new C_guiDataItemFloat(strMast, strHashTableKey,  50, 340 + (i*30), this, strDescription[11]);
			}

			dataType.setListEntries(strType);			
			dataSmoke.setListEntries(strOnOff);

            this.Controls.Add(dataType);
            this.Controls.Add(dataSmoke);
            this.Controls.Add(dataLatitude);
            this.Controls.Add(dataLongitude);
            this.Controls.Add(dataX);
            this.Controls.Add(dataY);
            this.Controls.Add(dataDepth);
            this.Controls.Add(dataHeading);
            this.Controls.Add(dataRoll);
            this.Controls.Add(dataPitch);
            this.Controls.Add(dataSpeed);

			for(int i=0 ; i <NUM_MASTS; i++)
			  this.Controls.Add(dataMast[i]);

			this.Size = new Size(830, 670);

			this.MdiParent = parentForm;
			//this.WindowState = FormWindowState.Maximized;

			//
			//Declare the mast array in the packet structure.
			//
			//oPIGOwnshipPacket.mast = new float[/*C_Network.NUM_OWNSHIP_MASTS*/ 10];

			m_initialised = true;
		}

		public override void updateIncomingData()
		{
			if(!m_initialised)
				return;

			dataType.Value = m_InData.bType.Value;
			dataSmoke.Value = m_InData.bSmoke.Value;
			dataLatitude.Value = m_InData.fLatitude.Value;
			dataLongitude.Value = m_InData.fLogitude.Value;
			dataX.Value = m_InData.fX.Value;
			dataY.Value = m_InData.fY.Value;
			dataDepth.Value = m_InData.fDepth.Value;
			dataHeading.Value = m_InData.fHeading.Value;
			dataRoll.Value = m_InData.fRoll.Value;
			dataPitch.Value = m_InData.fPitch.Value;
			dataSpeed.Value = m_InData.fSpeed.Value;

			for(int i = 0 ; i < 10 ; i++)
			{
				dataMast[i].Value = m_InData.mast[i].Value;
			}
		}

		public override void updateOutgoingData()
		{
			int i;

			if(!m_initialised)
				return;

			this.ptrGui.m_OutPIGData.oPIGOwnship.bType.Value     = dataType.Value;
			this.ptrGui.m_OutPIGData.oPIGOwnship.bSmoke.Value    = dataSmoke.Value;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fLatitude.Value = dataLatitude.Value;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fLogitude.Value = dataLongitude.Value;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fX.Value        = dataX.Value;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fY.Value        = dataY.Value;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fDepth.Value    = dataDepth.Value;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fHeading.Value  = dataHeading.Value;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fRoll.Value     = dataRoll.Value;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fPitch.Value    = dataPitch.Value;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fSpeed.Value    = dataSpeed.Value;

			for (i = 0; i < 10; i++)
				this.ptrGui.m_OutPIGData.oPIGOwnship.mast[i].Value = dataMast[i].Value;

			this.ptrGui.m_OutPIGData.oPIGOwnship.bType.Flag     = dataType.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGOwnship.bSmoke.Flag    = dataSmoke.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fLatitude.Flag = dataLatitude.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fLogitude.Flag = dataLongitude.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fX.Flag        = dataX.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fY.Flag        = dataY.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fDepth.Flag    = dataDepth.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fHeading.Flag  = dataHeading.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fRoll.Flag     = dataRoll.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fPitch.Flag    = dataPitch.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGOwnship.fSpeed.Flag    = dataSpeed.overrideChecked;

			for (i = 0; i < 10; i++)
				this.ptrGui.m_OutPIGData.oPIGOwnship.mast[i].Flag = dataMast[i].overrideChecked;


			//this.ptrMain.ptrNetwork.send();
		}

		public override void setOverride(bool bEnabled)
		{
			if(!m_initialised) 
				return;

		        dataType.setOverride(bEnabled);	
				dataSmoke.setOverride(bEnabled);	
				dataLatitude.setOverride(bEnabled);	
				dataLongitude.setOverride(bEnabled);	
				dataX.setOverride(bEnabled);	
				dataY.setOverride(bEnabled);	
				dataDepth.setOverride(bEnabled);
				dataHeading.setOverride(bEnabled);
				dataRoll.setOverride(bEnabled);
				dataPitch.setOverride(bEnabled);
				dataSpeed.setOverride(bEnabled);
			  
				for(int i=0; i < NUM_MASTS; i++)
				{
					dataMast[i].setOverride(bEnabled);	
				}
		}

		public override void enableOverrides(bool bEnabled)
		{
			dataType.enableOverride(bEnabled);	
			dataSmoke.enableOverride(bEnabled);	
			dataLatitude.enableOverride(bEnabled);	
			dataLongitude.enableOverride(bEnabled);	
			dataX.enableOverride(bEnabled);	
			dataY.enableOverride(bEnabled);	
			dataDepth.enableOverride(bEnabled);
			dataHeading.enableOverride(bEnabled);
			dataRoll.enableOverride(bEnabled);
			dataPitch.enableOverride(bEnabled);
			dataSpeed.enableOverride(bEnabled);
			  
			for(int i=0; i < NUM_MASTS; i++)
			{
				dataMast[i].enableOverride(bEnabled);	
			}
		}
	}
}
