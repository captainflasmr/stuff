//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiPIPTargetData.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Windows.Forms;

namespace PSCGenericBuild
{

	public class TargetData
	{
		public C_DataStoreItemBool bVisible;	
		public C_DataStoreItemBool bExplosion;	
		public C_DataStoreItemBool bMissileExplosion;	
		public C_DataStoreItemBool bTorpedoExplosion;	
		public C_DataStoreItemBool bSinking;	
		public C_DataStoreItemBool bNavLights;	
		public C_DataStoreItemBool bSonarDunking;
		public C_DataStoreItemBool bTLAMLaunch;	

		public C_DataStoreItemByte iDunkingSonar;
		public C_DataStoreItemByte iLightConfig;	
		public C_DataStoreItemByte iSpotLightConfig;

		public C_DataStoreItemInt   iTargetNum;
		public C_DataStoreItemInt   iSlotID;
		public C_DataStoreItemFloat fX;
		public C_DataStoreItemFloat fY;
		public C_DataStoreItemFloat fDepth;
		public C_DataStoreItemFloat fClimbRate;
		public C_DataStoreItemFloat fTurnRate;
		public C_DataStoreItemFloat fPitch;
		public C_DataStoreItemFloat fHeading;
		public C_DataStoreItemFloat fDriftCourse;
		public C_DataStoreItemFloat fSpeed;
		public C_DataStoreItemFloat fDriftSpeed;

		public C_DataStoreItemBool  bDieselSmoke;	
		public C_DataStoreItemBool  bMissileLaunch;


		public TargetData()
		{
			bVisible = new C_DataStoreItemBool();	
			bExplosion = new C_DataStoreItemBool();	
			bMissileExplosion = new C_DataStoreItemBool();		
			bTorpedoExplosion = new C_DataStoreItemBool();		
			bSinking = new C_DataStoreItemBool();	
			bNavLights = new C_DataStoreItemBool();	
			bSonarDunking = new C_DataStoreItemBool();
			bTLAMLaunch = new C_DataStoreItemBool();	

			iDunkingSonar = new C_DataStoreItemByte();
			iLightConfig = new C_DataStoreItemByte();	
			iSpotLightConfig = new C_DataStoreItemByte();

			iTargetNum = new C_DataStoreItemInt();
			iSlotID = new C_DataStoreItemInt();
			fX = new C_DataStoreItemFloat();
			fY = new C_DataStoreItemFloat();
			fDepth = new C_DataStoreItemFloat();
			fClimbRate = new C_DataStoreItemFloat();
			fTurnRate = new C_DataStoreItemFloat();
			fPitch = new C_DataStoreItemFloat();
			fHeading = new C_DataStoreItemFloat();
			fDriftCourse = new C_DataStoreItemFloat();
			fSpeed = new C_DataStoreItemFloat(); 
			fDriftSpeed = new C_DataStoreItemFloat();

			bDieselSmoke = new C_DataStoreItemBool();	
			bMissileLaunch = new C_DataStoreItemBool();	
		}
	}

	
	//-----------------------------------------------------------------------
	//The PIP Target Data Page Class.
	//-----------------------------------------------------------------------
	public class C_guiPIPTargetData : C_guiTemplatePage
	{
		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		protected string     [] strDescription;
		public PIGTargetData oPIGTargetDataPacket;
		protected Label      ptrTargetLabel;
		protected ComboBox   ptrComboBox;

		protected PIPTargetData   m_InData;
		public TargetData [] m_targetData;

		public const int NUM_TARGETS = SIMControl.NUM_PERI_TARGETS;

		protected int iNumTargetType;

		protected int m_iTarget; //ComboBox which has been selected.

		public C_guiDataItemBoolean dataVisible;	
		public C_guiDataItemBoolean dataExplosion;	
		public C_guiDataItemBoolean dataMissileExplosion;	
		public C_guiDataItemBoolean dataTorpedoExplosion;	
		public C_guiDataItemBoolean dataSinking;	
		public C_guiDataItemBoolean dataNavLights;	
		public C_guiDataItemBoolean dataSonarDunking;
		public C_guiDataItemBoolean dataTLAMLaunch;	

		public C_guiDataItemByte dataDunkingSonar;
		public C_guiDataItemByte dataLightConfig;	
		public C_guiDataItemByte dataSpotLightConfig;

		public C_guiDataItemInt   dataTargetNum;
		public C_guiDataItemFloat dataX;
		public C_guiDataItemFloat dataY;
		public C_guiDataItemFloat dataDepth;
		public C_guiDataItemFloat dataClimbRate;
		public C_guiDataItemFloat dataTurnRate;
		public C_guiDataItemFloat dataPitch;
		public C_guiDataItemFloat dataHeading;
		public C_guiDataItemFloat dataDriftCourse;
		public C_guiDataItemFloat dataSpeed;
		public C_guiDataItemFloat dataDriftSpeed;
		public C_guiDataItemBoolean  dataDieselSmoke;	
		public C_guiDataItemBoolean  dataMissileLaunch;	

		public Label TargetNumLabel;
		public Label TargetNum;

		public int iTempCount;
		protected int m_modelID;
		//-----------------------------------------------------------------------
		//Class Properties
		//-----------------------------------------------------------------------

		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------
		public C_guiPIPTargetData()
		{
		}

		//
		//Property to retrieve the number of targets.
		//
		public int iNumberOfTargets
		{
			get
			{
				return iNumTargetType;
			}
		}


		/************************************************************************
		  FUNCTION      : C_guiPIPTargetData()
		  DESCRIPTION   : The Constructor for Target Data Page. 
		  PARAMETERS    : parentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the PIP Target Data Page.
		 ************************************************************************/
		public C_guiPIPTargetData (C_gui parentForm, String strLabel, int iNumTargets)
		{
			this.ptrGui = parentForm;
			//this.ptrPSC = parentForm.psc;

		    iNumTargetType = iNumTargets;

			//-----------------------------------------------------
			//Declare the data items.
			//-----------------------------------------------------
			m_dataItem = new C_guiDataItem[23];

			//this.pageType  = C_gui.page.PIP_T;

			string [] strOnOff     = {"Off", "On"};
			string [] strSetReset   = {"Reset", "Set"};
			string [] strLights     = {"Making Way", 
									   "Short Fishing", 
									   "Long Fishing", 
									   "Trawling", 
									   "Shooting Nets", 
									   "Hauling Nets", 
									   "Nets Snagged",
									   "Purse Seining",
									   "On Pilot Duty"};				           
			string [] strSpotlights = {"Off", "Port", "Starboard"};

			this.SuspendLayout();
			this.Text      = strLabel;

			strDescription = new String [24];

			m_InData = this.ptrGUI.m_InPIPData.oTarget[0];

			ptrTargetLabel          = new Label();
			ptrTargetLabel.Text     = "Target Selection";
			ptrTargetLabel.Location = new Point(50, 10);
			this.Controls.Add(ptrTargetLabel);

			ptrComboBox             = new ComboBox();
			ptrComboBox.Location    = new Point(180, 10);
			this.Controls .Add(ptrComboBox);
			ptrComboBox.KeyPress    += new KeyPressEventHandler(integerKeyPress);
			ptrComboBox.TextChanged += new EventHandler(targetNumberChanged);

			ptrComboBox.BeginUpdate();
			for(int i= 0 ; i < SIMControl.NUM_PERI_TARGETS; i++)
			{
				ptrComboBox.Items.Add((i+1).ToString());				
			}
			ptrComboBox.EndUpdate();

			ptrComboBox.Text = "1";
			ptrComboBox.TextChanged += new EventHandler(targetIndexChanged);

		    TargetNumLabel = new Label();
			TargetNumLabel.Text     = "Target Number";
			TargetNumLabel.Location = new Point(50, 50);
			this.Controls.Add(TargetNumLabel);

		    TargetNum          = new Label();
			TargetNum.Location = new Point(180, 50);
			TargetNum.Text     = (iNumTargets - 1).ToString();
			this.Controls.Add(TargetNum);


			strDescription[ 0] = "PIG Model ID ("                + ")";
			strDescription[ 1] = "X coord offset from own boat(" + ")";
			strDescription[ 2] = "Y coord offset from own boat(" + ")";
			strDescription[ 3] = "Depth (-ve)/ Height (+ve) ("   + ")";
			strDescription[ 4] = "Climb/Dive Rate ("             + ")";
			strDescription[ 5] = "Turn Rate ("                   + ")";
			strDescription[ 6] = "Target pitch ("                + ")";
			strDescription[ 7] = "Target heading ("              + ")";
			strDescription[ 8] = "Drift Course ("                + ")";
			strDescription[ 9] = "Target Speed ("                + ")";
			strDescription[10] = "Drift Speed ("                 + ")";

			strDescription[11] = "Target is visible in the scenario(On/Off)";
			strDescription[12] = "An Explosion is present in the scenario(On/Off)";
			strDescription[13] = "Missile impact on target(On/Off)";
			strDescription[14] = "Torpedo explosion on target(On/Off)";
			strDescription[15] = "Target Sinking(On/Off)";
			strDescription[16] = "Nav lights are illuminated(On/Off)";
			strDescription[17] = "Helicopter target has sonar dip(On/Off)";
			strDescription[18] = "TLAM Faulty launch(Reset/Set)";
			strDescription[19] = "Dunking Sonar";
			strDescription[20] = "(Making Way / Short Fishing / Long Fishing / Trawling /Shooting Nets\n" +
				                 " Hauling Nets / Nets Snagged / Purse Seining / On Pilot Duty";
			strDescription[21] = "Spotlight configuration (OFF/PORT/STARBOARD)";
			strDescription[22] = "Diesel smoke required(On/Off)";
			strDescription[23] = "Missile Launch(On/Off)";


			//-----------------------------------------------------
			//Initialise each data item.
			//-----------------------------------------------------
			dataTargetNum   = new C_guiDataItemInt( "PIG Model ID",            "PIP_TARGET_MODEL_ID",      50,  80, this, strDescription[0]);
			dataX           = new C_guiDataItemFloat( "X",                     "PIP_TARGET_X",             50, 110, this, strDescription[1]);
			dataY           = new C_guiDataItemFloat( "Y",                     "PIP_TARGET_Y",             50, 140, this, strDescription[2]);
			dataDepth       = new C_guiDataItemFloat( "Depth/Height",          "PIP_TARGET_HEIGHT",        50, 170, this, strDescription[3]);
			dataClimbRate   = new C_guiDataItemFloat( "Climb/Dive Rate",       "PIP_TARGET_CLIMB_RATE",    50, 200, this, strDescription[4]);
			dataTurnRate    = new C_guiDataItemFloat( "Turn Rate",             "PIP_TARGET_TURN_RATE",     50, 230, this, strDescription[5]);
			dataPitch       = new C_guiDataItemFloat( "Pitch",                 "PIP_TARGET_PITCH",         50, 260, this, strDescription[6]);
			dataHeading     = new C_guiDataItemFloat( "Heading",               "PIP_TARGET_HEADING",       50, 290, this, strDescription[7]);
			dataDriftCourse = new C_guiDataItemFloat( "Drift Course",          "PIP_TARGET_DRIFT_COURSE",  50, 320, this, strDescription[8]);
			dataSpeed       = new C_guiDataItemFloat( "Speed",                 "PIP_TARGET_SPEED",         50, 350, this, strDescription[9]);
			dataDriftSpeed  = new C_guiDataItemFloat( "Drift Speed",           "PIP_TARGET_DRIFT_SPEED",   50, 400, this, strDescription[10]);
			dataVisible     = new C_guiDataItemBoolean( "Visible",                "PIP_TARGET_VISIBLE",       50, 430, this, strDescription[11]);
			dataExplosion   = new C_guiDataItemBoolean( "Explosion",              "PIP_TARGET_EXPLOSION",     50, 460, this, strDescription[12]);
			dataMissileExplosion = new C_guiDataItemBoolean( "Missile Impact",    "PIP_TARGET_MISSILE_IMPACT",50, 490, this, strDescription[13]);
			dataTorpedoExplosion = new C_guiDataItemBoolean( "Torpedo Impact",    "PIP_TARGET_TORPEDO_IMPACT",50, 520, this, strDescription[14]);
			dataSinking         = new C_guiDataItemBoolean( "Sinking",            "PIP_TARGET_SINKING",       50, 550, this, strDescription[15]);
			dataNavLights       = new C_guiDataItemBoolean( "Nav Lights",         "PIP_TARGET_NAV_LIGHTS",    50, 580, this, strDescription[16]);
			dataSonarDunking    = new C_guiDataItemBoolean( "Sonar Dip",          "PIP_TARGET_SONAR_DIP",     50, 610, this, strDescription[17]);
			dataTLAMLaunch      = new C_guiDataItemBoolean( "TLAM Launch",        "PIP_TARGET_TLAM_LAUNCH",   50, 640, this, strDescription[18]);
			dataDunkingSonar    = new C_guiDataItemByte( "Dunking Sonar",       "PIP_TARGET_DUNKING_SONAR", 50, 670, this, strDescription[19]);
			dataLightConfig     = new C_guiDataItemByte( "Fising Vessel Lights","PIP_TARGET_FISHING_LIGHTS",50, 700, this, strDescription[20]);
			dataSpotLightConfig = new C_guiDataItemByte( "Fising Vessel SpotLights","PIP_TARGET_FISHING_SPOTS", 50, 730, this, strDescription[21]);
			dataDieselSmoke     = new C_guiDataItemBoolean( "Diesel Smoke",      "PIP_TARGET_DIESEL_SMOKE",  50, 760, this, strDescription[22]);
			dataMissileLaunch   = new C_guiDataItemBoolean( "Missile Launch",    "PIP_TARGET_MISSILE_LAUNCH", 50, 790, this, strDescription[23]);

			dataVisible.setListEntries(strOnOff);
			dataExplosion.setListEntries(strOnOff);
			dataMissileExplosion.setListEntries(strOnOff);
			dataTorpedoExplosion.setListEntries(strOnOff);
			dataSinking.setListEntries(strOnOff);
			dataNavLights.setListEntries(strOnOff);
			dataSonarDunking.setListEntries(strOnOff);
			dataTLAMLaunch.setListEntries(strSetReset);
			dataDunkingSonar.setListEntries(strOnOff);
			dataDieselSmoke.setListEntries(strOnOff);
			dataMissileLaunch.setListEntries(strOnOff);

			dataLightConfig.setListEntries(strLights);
			dataSpotLightConfig.setListEntries(strSpotlights);

			dataLightConfig.description.Height = 30;

			this.Controls.Add(dataVisible);	
			this.Controls.Add(dataExplosion);	
			this.Controls.Add(dataMissileExplosion);	
			this.Controls.Add(dataTorpedoExplosion);	
			this.Controls.Add(dataSinking);	
			this.Controls.Add(dataNavLights);	
			this.Controls.Add(dataSonarDunking);
			this.Controls.Add(dataTLAMLaunch);	

			this.Controls.Add(dataDunkingSonar);
			this.Controls.Add(dataLightConfig);	
			this.Controls.Add(dataSpotLightConfig);

			this.Controls.Add(dataTargetNum);
			this.Controls.Add(dataX);
			this.Controls.Add(dataY);
			this.Controls.Add(dataDepth);
			this.Controls.Add(dataClimbRate);
			this.Controls.Add(dataTurnRate);
			this.Controls.Add(dataPitch);
			this.Controls.Add(dataHeading);
			this.Controls.Add(dataDriftCourse);
			this.Controls.Add(dataSpeed);
			this.Controls.Add(dataDriftSpeed);
			this.Controls.Add(dataDieselSmoke);	
			this.Controls.Add(dataMissileLaunch);	

			this.MdiParent = parentForm;

			this.Size        = new Size(880, 870);
			this.MinimumSize = new Size(200, 200);

			this.ResumeLayout(false );

			m_targetData = new TargetData[SIMControl.NUM_PERI_TARGETS];

			for(int i=0; i < SIMControl.NUM_PERI_TARGETS ; i++)
			{
				m_targetData[i] = new TargetData();
			}

			dataVisible.comboBox.SelectedIndexChanged          += new EventHandler(targetDataChanged);
			dataExplosion.comboBox.SelectedIndexChanged        += new EventHandler(targetDataChanged);	
			dataMissileExplosion.comboBox.SelectedIndexChanged += new EventHandler(targetDataChanged);	
			dataTorpedoExplosion.comboBox.SelectedIndexChanged += new EventHandler(targetDataChanged);	
			dataSinking.comboBox.SelectedIndexChanged          += new EventHandler(targetDataChanged);	
			dataNavLights.comboBox.SelectedIndexChanged        += new EventHandler(targetDataChanged);	
			dataSonarDunking.comboBox.SelectedIndexChanged     += new EventHandler(targetDataChanged);
			dataTLAMLaunch.comboBox.SelectedIndexChanged       += new EventHandler(targetDataChanged);	
			dataDunkingSonar.comboBox.SelectedIndexChanged     += new EventHandler(targetDataChanged);
			dataLightConfig.comboBox.SelectedIndexChanged      += new EventHandler(targetDataChanged);	
			dataSpotLightConfig.comboBox.SelectedIndexChanged  += new EventHandler(targetDataChanged);
			dataMissileLaunch.comboBox.SelectedIndexChanged  += new EventHandler(targetDataChanged);

			dataTargetNum.numeric.ValueChanged           += new EventHandler(targetDataChanged);
			dataX.numeric.ValueChanged                   += new EventHandler(targetDataChanged);
			dataY.numeric.ValueChanged                   += new EventHandler(targetDataChanged);
			dataDepth.numeric.ValueChanged               += new EventHandler(targetDataChanged);
			dataClimbRate.numeric.ValueChanged           += new EventHandler(targetDataChanged);
			dataTurnRate.numeric.ValueChanged            += new EventHandler(targetDataChanged);
			dataPitch.numeric.ValueChanged               += new EventHandler(targetDataChanged);
			dataHeading.numeric.ValueChanged             += new EventHandler(targetDataChanged);
			dataDriftCourse.numeric.ValueChanged         += new EventHandler(targetDataChanged);
			dataSpeed.numeric.ValueChanged               += new EventHandler(targetDataChanged);
			dataDriftSpeed.numeric.ValueChanged          += new EventHandler(targetDataChanged);
			dataDieselSmoke.numeric.ValueChanged         += new EventHandler(targetDataChanged);

			dataVisible.checkBox.CheckedChanged          += new EventHandler(targetCheckChanged);
			dataExplosion.checkBox.CheckedChanged        += new EventHandler(targetCheckChanged);	
			dataMissileExplosion.checkBox.CheckedChanged += new EventHandler(targetCheckChanged);	
			dataTorpedoExplosion.checkBox.CheckedChanged += new EventHandler(targetCheckChanged);	
			dataSinking.checkBox.CheckedChanged          += new EventHandler(targetCheckChanged);	
			dataNavLights.checkBox.CheckedChanged        += new EventHandler(targetCheckChanged);	
			dataSonarDunking.checkBox.CheckedChanged     += new EventHandler(targetCheckChanged);
			dataTLAMLaunch.checkBox.CheckedChanged       += new EventHandler(targetCheckChanged);	
			dataDunkingSonar.checkBox.CheckedChanged     += new EventHandler(targetCheckChanged);
			dataLightConfig.checkBox.CheckedChanged      += new EventHandler(targetCheckChanged);	
			dataSpotLightConfig.checkBox.CheckedChanged  += new EventHandler(targetCheckChanged);
			dataTargetNum.checkBox.CheckedChanged        += new EventHandler(targetCheckChanged);
			dataX.checkBox.CheckedChanged                += new EventHandler(targetCheckChanged);
			dataY.checkBox.CheckedChanged                += new EventHandler(targetCheckChanged);
			dataDepth.checkBox.CheckedChanged            += new EventHandler(targetCheckChanged);
			dataClimbRate.checkBox.CheckedChanged        += new EventHandler(targetCheckChanged);
			dataTurnRate.checkBox.CheckedChanged         += new EventHandler(targetCheckChanged);
			dataPitch.checkBox.CheckedChanged            += new EventHandler(targetCheckChanged);
			dataHeading.checkBox.CheckedChanged          += new EventHandler(targetCheckChanged);
			dataDriftCourse.checkBox.CheckedChanged      += new EventHandler(targetCheckChanged);
			dataSpeed.checkBox.CheckedChanged            += new EventHandler(targetCheckChanged);
			dataDriftSpeed.checkBox.CheckedChanged       += new EventHandler(targetCheckChanged);
			dataDieselSmoke.checkBox.CheckedChanged      += new EventHandler(targetCheckChanged);
			dataMissileLaunch.checkBox.CheckedChanged    += new EventHandler(targetCheckChanged);

			m_initialised = true;
			m_modelID = -1;

			dataTargetNum.description.Width = 300;
			dataTargetNum.Width = 800;
		}

		public virtual TargetData getTargetData(int iTargetIndex)
		{
			if(iTargetIndex >= 0 && (iTargetIndex < NUM_TARGETS))
			{
				return m_targetData[iTargetIndex];
			}
			else
				return null;
		}
				 
		public virtual void setTargetData(int iTargetIndex, TargetData newtargetdata)
		{
			if(iTargetIndex >= 0 && (iTargetIndex < NUM_TARGETS))
			{
				m_targetData[iTargetIndex] = newtargetdata;
			}
		}
				 

		public void targetIndexChanged(object sender, EventArgs e)
		{
			int iTarget = Int32.Parse(ptrComboBox.Text) - 1;
			m_InData = ptrGUI.m_InPIPData.oTarget[iTarget];

			changePageContent(iTarget);

			//Refresh the content of the screen.
			//updateIncomingData();

			m_iTarget = iTarget;         

			TargetNum.Text = (m_iTarget).ToString();

			C_guiNetworkStatus.txtv = TargetNum.Text;
		}

		public void changePageContent(int iNewTarget)
		{

			//
			//Save the existing values...
			//
			m_targetData[m_iTarget].iTargetNum.Value = dataTargetNum.Value;
			// Slot has no diplay interface
			m_targetData[m_iTarget].fX.Value = dataX.Value;
			m_targetData[m_iTarget].fY.Value = dataY.Value;
            m_targetData[m_iTarget].fDepth.Value = dataDepth.Value;
			m_targetData[m_iTarget].fClimbRate.Value = dataClimbRate.Value;
			m_targetData[m_iTarget].fTurnRate.Value = dataTurnRate.Value;
			m_targetData[m_iTarget].fPitch.Value = dataPitch.Value;
			m_targetData[m_iTarget].fHeading.Value = dataHeading.Value;
			m_targetData[m_iTarget].fDriftCourse.Value = dataDriftCourse.Value;
			m_targetData[m_iTarget].fSpeed.Value = dataSpeed.Value;
			m_targetData[m_iTarget].fDriftSpeed.Value = dataDriftSpeed.Value;

			m_targetData[m_iTarget].bVisible.Value = dataVisible.Value;
			m_targetData[m_iTarget].bExplosion.Value = dataExplosion.Value;
			m_targetData[m_iTarget].bMissileExplosion.Value = dataMissileExplosion.Value;
			m_targetData[m_iTarget].bTorpedoExplosion.Value = dataTorpedoExplosion.Value;
			m_targetData[m_iTarget].bSinking.Value = dataSinking.Value;
			m_targetData[m_iTarget].bNavLights.Value = dataNavLights.Value;
			m_targetData[m_iTarget].bSonarDunking.Value = dataSonarDunking.Value;
			m_targetData[m_iTarget].bTLAMLaunch.Value = dataTLAMLaunch.Value;
			m_targetData[m_iTarget].iDunkingSonar.Value = dataDunkingSonar.Value;
			m_targetData[m_iTarget].iLightConfig.Value = dataLightConfig.Value;
			m_targetData[m_iTarget].iSpotLightConfig.Value = dataSpotLightConfig.Value;
			m_targetData[m_iTarget].bDieselSmoke.Value = dataDieselSmoke.Value;
			m_targetData[m_iTarget].bMissileLaunch.Value = dataMissileLaunch.Value;


			m_targetData[m_iTarget].iTargetNum.Flag = dataTargetNum.overrideChecked;
			m_targetData[m_iTarget].fX.Flag = dataX.overrideChecked;
			m_targetData[m_iTarget].fY.Flag = dataY.overrideChecked;
			m_targetData[m_iTarget].fDepth.Flag = dataDepth.overrideChecked;
			m_targetData[m_iTarget].fClimbRate.Flag = dataClimbRate.overrideChecked;
			m_targetData[m_iTarget].fTurnRate.Flag = dataTurnRate.overrideChecked;
			m_targetData[m_iTarget].fPitch.Flag = dataPitch.overrideChecked;
			m_targetData[m_iTarget].fHeading.Flag = dataHeading.overrideChecked;
			m_targetData[m_iTarget].fDriftCourse.Flag = dataDriftCourse.overrideChecked;
			m_targetData[m_iTarget].fSpeed.Flag = dataSpeed.overrideChecked;
			m_targetData[m_iTarget].fDriftSpeed.Flag = dataDriftSpeed.overrideChecked;

			m_targetData[m_iTarget].bVisible.Flag = dataVisible.overrideChecked;
			m_targetData[m_iTarget].bExplosion.Flag = dataExplosion.overrideChecked;
			m_targetData[m_iTarget].bMissileExplosion.Flag = dataMissileExplosion.overrideChecked;
			m_targetData[m_iTarget].bTorpedoExplosion.Flag = dataTorpedoExplosion.overrideChecked;
			m_targetData[m_iTarget].bSinking.Flag = dataSinking.overrideChecked;
			m_targetData[m_iTarget].bNavLights.Flag = dataNavLights.overrideChecked;
			m_targetData[m_iTarget].bSonarDunking.Flag = dataSonarDunking.overrideChecked;
			m_targetData[m_iTarget].bTLAMLaunch.Flag = dataTLAMLaunch.overrideChecked;
			m_targetData[m_iTarget].iDunkingSonar.Flag = dataDunkingSonar.overrideChecked;
			m_targetData[m_iTarget].iLightConfig.Flag = dataLightConfig.overrideChecked;
			m_targetData[m_iTarget].iSpotLightConfig.Flag = dataSpotLightConfig.overrideChecked;
			m_targetData[m_iTarget].bDieselSmoke.Flag = dataDieselSmoke.overrideChecked;
			m_targetData[m_iTarget].bMissileLaunch.Flag = dataMissileLaunch.overrideChecked;


			//
			//Display the values for the new target page.
			//
			this.dataTargetNum.OverrideValue = m_targetData[iNewTarget].iTargetNum.Value;
			this.dataX.OverrideValue = m_targetData[iNewTarget].fX.Value;
			this.dataY.OverrideValue = m_targetData[iNewTarget].fY.Value;
			this.dataDepth.OverrideValue = m_targetData[iNewTarget].fDepth.Value;
			this.dataClimbRate.OverrideValue = m_targetData[iNewTarget].fClimbRate.Value;
			this.dataTurnRate.OverrideValue = m_targetData[iNewTarget].fTurnRate.Value;
			this.dataPitch.OverrideValue = m_targetData[iNewTarget].fPitch.Value;
			this.dataHeading.OverrideValue = m_targetData[iNewTarget].fHeading.Value;
			this.dataDriftCourse.OverrideValue = m_targetData[iNewTarget].fDriftCourse.Value;
			this.dataSpeed.OverrideValue = m_targetData[iNewTarget].fSpeed.Value;
			this.dataDriftSpeed.OverrideValue = m_targetData[iNewTarget].fDriftSpeed.Value;

			this.dataVisible.OverrideValue = m_targetData[iNewTarget].bVisible.Value;
			this.dataExplosion.OverrideValue = m_targetData[iNewTarget].bExplosion.Value;
			this.dataMissileExplosion.OverrideValue = m_targetData[iNewTarget].bMissileExplosion.Value;
			this.dataTorpedoExplosion.OverrideValue = m_targetData[iNewTarget].bTorpedoExplosion.Value;
			this.dataSinking.OverrideValue = m_targetData[iNewTarget].bSinking.Value;
			this.dataNavLights.OverrideValue = m_targetData[iNewTarget].bNavLights.Value;
			this.dataSonarDunking.OverrideValue = m_targetData[iNewTarget].bSonarDunking.Value;
			this.dataTLAMLaunch.OverrideValue = m_targetData[iNewTarget].bTLAMLaunch.Value;

			this.dataDunkingSonar.OverrideValue = m_targetData[iNewTarget].iDunkingSonar.Value;
			this.dataLightConfig.OverrideValue = m_targetData[iNewTarget].iLightConfig.Value;
			this.dataSpotLightConfig.OverrideValue = m_targetData[iNewTarget].iSpotLightConfig.Value;
			this.dataDieselSmoke.OverrideValue = m_targetData[iNewTarget].bDieselSmoke.Value;
			this.dataMissileLaunch.OverrideValue = m_targetData[iNewTarget].bMissileLaunch.Value;
//
			this.dataTargetNum.setupOverride(m_targetData[iNewTarget].iTargetNum.Flag);
			this.dataX.setupOverride(m_targetData[iNewTarget].fX.Flag);
			this.dataY.setupOverride(m_targetData[iNewTarget].fY.Flag);
			this.dataDepth.setupOverride(m_targetData[iNewTarget].fDepth.Flag);
			this.dataClimbRate.setupOverride(m_targetData[iNewTarget].fClimbRate.Flag);
			this.dataTurnRate.setupOverride(m_targetData[iNewTarget].fTurnRate.Flag);
			this.dataPitch.setupOverride(m_targetData[iNewTarget].fPitch.Flag);
			this.dataHeading.setupOverride(m_targetData[iNewTarget].fHeading.Flag);
			this.dataDriftCourse.setupOverride(m_targetData[iNewTarget].fDriftCourse.Flag);
			this.dataSpeed.setupOverride(m_targetData[iNewTarget].fSpeed.Flag);
			this.dataDriftSpeed.setupOverride(m_targetData[iNewTarget].fDriftSpeed.Flag);

			this.dataVisible.setupOverride(m_targetData[iNewTarget].bVisible.Flag);
			this.dataExplosion.setupOverride(m_targetData[iNewTarget].bExplosion.Flag);
			this.dataMissileExplosion.setupOverride(m_targetData[iNewTarget].bMissileExplosion.Flag);
			this.dataTorpedoExplosion.setupOverride(m_targetData[iNewTarget].bTorpedoExplosion.Flag);
			this.dataSinking.setupOverride(m_targetData[iNewTarget].bSinking.Flag);
			this.dataNavLights.setupOverride(m_targetData[iNewTarget].bNavLights.Flag);
			this.dataSonarDunking.setupOverride(m_targetData[iNewTarget].bSonarDunking.Flag);
			this.dataTLAMLaunch.setupOverride(m_targetData[iNewTarget].bTLAMLaunch.Flag);

			this.dataDunkingSonar.setupOverride(m_targetData[iNewTarget].iDunkingSonar.Flag);
			this.dataLightConfig.setupOverride(m_targetData[iNewTarget].iLightConfig.Flag);
			this.dataSpotLightConfig.setupOverride(m_targetData[iNewTarget].iSpotLightConfig.Flag);
			this.dataDieselSmoke.setupOverride(m_targetData[iNewTarget].bDieselSmoke.Flag);
			this.dataMissileLaunch.setupOverride(m_targetData[iNewTarget].bMissileLaunch.Flag);
		}

		public override void updateIncomingData()
		{   
			if(!m_initialised)
				return;

			if(!this.Visible)
				return;

			this.dataTargetNum.Value = m_InData.iTargetNum.Value;

			//
			//Update the model name in the description field if the model id has changed.
			//
			if(dataTargetNum.Value != m_modelID)
			{
				if(dataTargetNum.Value >= 0 && dataTargetNum.Value < 1000)
				{
					dataTargetNum.description.Text = dataTargetNum.strDescription + " (" + ptrGui.m_modelNames[dataTargetNum.Value] + ")";
					m_modelID = dataTargetNum.Value;
				}
			}
			this.dataX.Value = m_InData.fX.Value;
			this.dataY.Value = m_InData.fY.Value;
			this.dataDepth.Value = m_InData.fDepth.Value;
			this.dataClimbRate.Value = m_InData.fClimbRate.Value;
			this.dataTurnRate.Value = m_InData.fTurnRate.Value;
			this.dataPitch.Value = m_InData.fPitch.Value;
			this.dataHeading.Value = m_InData.fHeading.Value;
		    this.dataDriftCourse.Value = m_InData.fDriftCourse.Value;
			this.dataSpeed.Value = m_InData.fSpeed.Value;
			this.dataDriftSpeed.Value = m_InData.fDriftSpeed.Value;

			this.dataVisible.Value = m_InData.bVisible.Value;
			this.dataExplosion.Value = m_InData.bExplosion.Value;
			this.dataMissileExplosion.Value = m_InData.bMissileExplosion.Value;
			this.dataTorpedoExplosion.Value = m_InData.bTorpedoExplosion.Value;
			this.dataSinking.Value = m_InData.bSinking.Value;
			this.dataNavLights.Value = m_InData.bNavLights.Value;
			this.dataSonarDunking.Value = m_InData.bSonarDunking.Value;
			this.dataTLAMLaunch.Value = m_InData.bTLAMLaunch.Value;

			this.dataDunkingSonar.Value = m_InData.bDunkingSonar.Value;
			this.dataLightConfig.Value = m_InData.bLightConfig.Value;
			this.dataSpotLightConfig.Value = m_InData.bSpotLightConfig.Value;
			this.dataDieselSmoke.Value = m_InData.bDieselSmoke.Value;
			this.dataMissileLaunch.Value = m_InData.bMissileLaunch.Value;


			//Update the page from the values.
			updatePage();

		}

		public override void updateOutgoingData()
		{
			if(!m_initialised)
				return;

			for(int i=0 ; i < SIMControl.NUM_PERI_TARGETS; i++)

			{
				int iIndex = i;

				this.ptrGui.m_OutPIPData.oTarget[iIndex].iTargetNum.Value   = m_targetData[i].iTargetNum.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fX.Value           = m_targetData[i].fX.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fY.Value           = m_targetData[i].fY.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fDepth.Value       = m_targetData[i].fDepth.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fClimbRate.Value   = m_targetData[i].fClimbRate.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fTurnRate.Value    = m_targetData[i].fTurnRate.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fPitch.Value       = m_targetData[i].fPitch.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fHeading.Value     = m_targetData[i].fHeading.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fDriftCourse.Value = m_targetData[i].fDriftCourse.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fSpeed.Value       = m_targetData[i].fSpeed.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fDriftSpeed.Value  = m_targetData[i].fDriftSpeed.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bLightConfig.Value = m_targetData[i].iLightConfig.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bSpotLightConfig.Value = m_targetData[i].iSpotLightConfig.Value;

				this.ptrGui.m_OutPIPData.oTarget[iIndex].bVisible.Value          = m_targetData[i].bVisible.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bExplosion.Value        = m_targetData[i].bExplosion.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bMissileExplosion.Value = m_targetData[i].bMissileExplosion.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bTorpedoExplosion.Value = m_targetData[i].bTorpedoExplosion.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bSinking.Value          = m_targetData[i].bSinking.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bNavLights.Value        = m_targetData[i].bNavLights.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bSonarDunking.Value     = m_targetData[i].bSonarDunking.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bTLAMLaunch.Value       = m_targetData[i].bTLAMLaunch.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bDunkingSonar.Value     = m_targetData[i].iDunkingSonar.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bLightConfig.Value      = m_targetData[i].iLightConfig.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bSpotLightConfig.Value  = m_targetData[i].iSpotLightConfig.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bDieselSmoke.Value      = m_targetData[i].bDieselSmoke.Value;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bMissileLaunch.Value    = m_targetData[i].bMissileLaunch.Value;

				//
				//Flags.
				//
				this.ptrGui.m_OutPIPData.oTarget[iIndex].iTargetNum.Flag   = m_targetData[i].iTargetNum.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fX.Flag           = m_targetData[i].fX.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fY.Flag           = m_targetData[i].fY.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fDepth.Flag       = m_targetData[i].fDepth.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fClimbRate.Flag   = m_targetData[i].fClimbRate.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fTurnRate.Flag    = m_targetData[i].fTurnRate.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fPitch.Flag       = m_targetData[i].fPitch.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fHeading.Flag     = m_targetData[i].fHeading.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fDriftCourse.Flag = m_targetData[i].fDriftCourse.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fSpeed.Flag       = m_targetData[i].fSpeed.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].fDriftSpeed.Flag  = m_targetData[i].fDriftSpeed.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bLightConfig.Flag = m_targetData[i].iLightConfig.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bSpotLightConfig.Flag = m_targetData[i].iSpotLightConfig.Flag;

				this.ptrGui.m_OutPIPData.oTarget[iIndex].bVisible.Flag          = m_targetData[i].bVisible.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bExplosion.Flag        = m_targetData[i].bExplosion.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bMissileExplosion.Flag = m_targetData[i].bMissileExplosion.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bTorpedoExplosion.Flag = m_targetData[i].bTorpedoExplosion.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bSinking.Flag          = m_targetData[i].bSinking.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bNavLights.Flag        = m_targetData[i].bNavLights.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bSonarDunking.Flag     = m_targetData[i].bSonarDunking.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bTLAMLaunch.Flag       = m_targetData[i].bTLAMLaunch.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bDunkingSonar.Flag     = m_targetData[i].iDunkingSonar.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bLightConfig.Flag      = m_targetData[i].iLightConfig.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bSpotLightConfig.Flag  = m_targetData[i].iSpotLightConfig.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bDieselSmoke.Flag      = m_targetData[i].bDieselSmoke.Flag;
				this.ptrGui.m_OutPIPData.oTarget[iIndex].bMissileLaunch.Flag      = m_targetData[i].bMissileLaunch.Flag;
			}
		}

		private void targetNumberChanged(object sender, EventArgs e)
		{
			if(ptrComboBox.Text.Length == 0)
		       ptrComboBox.Text = "1";

			if(Int32.Parse(ptrComboBox.Text) == 0)
			{
				ptrComboBox.Text = "1";
			}		   
			else if(Int32.Parse(ptrComboBox.Text) > NUM_TARGETS)
			{
				ptrComboBox.Text = NUM_TARGETS.ToString();
			}
		}

		private void targetDataChanged(object sender, EventArgs e)
		{
			//
			//The polynia values signal a change in value when the combo box index has changed. This is handled
			//by the 'polyniaNumberChanged' method.
			//
			if(! ptrComboBox.ContainsFocus)
			{
				if(sender == dataVisible.comboBox)
					m_targetData[m_iTarget].bVisible.Value = dataVisible.Value;

				if(sender == dataExplosion.comboBox)
					m_targetData[m_iTarget].bExplosion.Value = dataExplosion.Value;

				if(sender == dataMissileExplosion.comboBox)
					m_targetData[m_iTarget].bMissileExplosion.Value = dataMissileExplosion.Value;

				if(sender == dataTorpedoExplosion.comboBox)
					m_targetData[m_iTarget].bTorpedoExplosion.Value = dataTorpedoExplosion.Value;

				if(sender == dataSinking.comboBox)
					m_targetData[m_iTarget].bSinking.Value = dataSinking.Value;

				if(sender == dataNavLights.comboBox)
					m_targetData[m_iTarget].bNavLights.Value = dataNavLights.Value;

				if(sender == dataSonarDunking.comboBox)
					m_targetData[m_iTarget].bSonarDunking.Value = dataSonarDunking.Value;

				if(sender == dataTLAMLaunch.comboBox)
					m_targetData[m_iTarget].bTLAMLaunch.Value = dataTLAMLaunch.Value;

				if(sender == dataDunkingSonar.comboBox)
					m_targetData[m_iTarget].iDunkingSonar.Value = dataDunkingSonar.Value;

				if(sender == dataLightConfig.comboBox)
					m_targetData[m_iTarget].iLightConfig.Value = dataLightConfig.Value;

				if(sender == dataSpotLightConfig.comboBox)
					m_targetData[m_iTarget].iSpotLightConfig.Value = dataSpotLightConfig.Value;

				if(sender == dataTargetNum.numeric)
					m_targetData[m_iTarget].iTargetNum.Value = dataTargetNum.Value;

				if(sender == dataX.numeric)
					m_targetData[m_iTarget].fX.Value = dataX.Value;

				if(sender == dataY.numeric)
					m_targetData[m_iTarget].fY.Value = dataY.Value;

				if(sender == dataDepth.numeric)
					m_targetData[m_iTarget].fDepth.Value = dataDepth.Value;

				if(sender == dataClimbRate.numeric)
					m_targetData[m_iTarget].fClimbRate.Value = dataClimbRate.Value;

				if(sender == dataTurnRate.numeric)
					m_targetData[m_iTarget].fTurnRate.Value = dataTurnRate.Value;

				if(sender == dataPitch.numeric)
					m_targetData[m_iTarget].fPitch.Value = dataPitch.Value;

				if(sender == dataHeading.numeric)
					m_targetData[m_iTarget].fHeading.Value = dataHeading.Value;

				if(sender == dataDriftCourse.numeric)
					m_targetData[m_iTarget].fDriftCourse.Value = dataDriftCourse.Value;

				if(sender == dataSpeed.numeric)
					m_targetData[m_iTarget].fSpeed.Value = dataSpeed.Value;

				if(sender == dataDriftSpeed.numeric)
					m_targetData[m_iTarget].fDriftSpeed.Value = dataDriftSpeed.Value;

				if(sender == dataDieselSmoke.comboBox)
					m_targetData[m_iTarget].bDieselSmoke.Value = dataDieselSmoke.Value;

				if(sender == dataMissileLaunch.comboBox)
					m_targetData[m_iTarget].bMissileLaunch.Value = dataMissileLaunch.Value;

			}
		}

		private void targetCheckChanged(object sender, EventArgs e)
		{
			//
			//The polynia values signal a change in value when the combo box index has changed. This is handled
			//by the 'polyniaNumberChanged' method.
			//
			if(! ptrComboBox.ContainsFocus)
			{
				if(sender == dataVisible.checkBox)
				{
					m_targetData[m_iTarget].bVisible.Flag = dataVisible.overrideChecked;
					m_targetData[m_iTarget].bVisible.Value = dataVisible.Value;
				}

				if(sender == dataExplosion.checkBox)
				{
					m_targetData[m_iTarget].bExplosion.Flag = dataExplosion.overrideChecked;
					m_targetData[m_iTarget].bExplosion.Value = dataExplosion.Value;
				}

				if(sender == dataMissileExplosion.checkBox)
				{
					m_targetData[m_iTarget].bMissileExplosion.Flag = dataMissileExplosion.overrideChecked;
					m_targetData[m_iTarget].bMissileExplosion.Value = dataMissileExplosion.Value;
				}

				if(sender == dataTorpedoExplosion.checkBox)
				{
					m_targetData[m_iTarget].bTorpedoExplosion.Flag = dataTorpedoExplosion.overrideChecked;
					m_targetData[m_iTarget].bTorpedoExplosion.Value = dataTorpedoExplosion.Value;
				}

				if(sender == dataSinking.checkBox)
				{
					m_targetData[m_iTarget].bSinking.Flag = dataSinking.overrideChecked;
					m_targetData[m_iTarget].bSinking.Value = dataSinking.Value;
				}

				if(sender == dataNavLights.checkBox)
				{
					m_targetData[m_iTarget].bNavLights.Flag = dataNavLights.overrideChecked;
					m_targetData[m_iTarget].bNavLights.Value = dataNavLights.Value;
				}

				if(sender == dataSonarDunking.checkBox)
				{
					m_targetData[m_iTarget].bSonarDunking.Flag = dataSonarDunking.overrideChecked;
					m_targetData[m_iTarget].bSonarDunking.Value = dataSonarDunking.Value;
				}

				if(sender == dataTLAMLaunch.checkBox)
				{
					m_targetData[m_iTarget].bTLAMLaunch.Flag = dataTLAMLaunch.overrideChecked;
					m_targetData[m_iTarget].bTLAMLaunch.Value = dataTLAMLaunch.Value;
				}

				if(sender == dataDunkingSonar.checkBox)
				{
					m_targetData[m_iTarget].iDunkingSonar.Flag = dataDunkingSonar.overrideChecked;
					m_targetData[m_iTarget].iDunkingSonar.Value = dataDunkingSonar.Value;
				}

				if(sender == dataLightConfig.checkBox)
				{
					m_targetData[m_iTarget].iLightConfig.Flag = dataLightConfig.overrideChecked;
					m_targetData[m_iTarget].iLightConfig.Value = dataLightConfig.Value;
				}

				if(sender == dataSpotLightConfig.checkBox)
				{
					m_targetData[m_iTarget].iSpotLightConfig.Flag = dataSpotLightConfig.overrideChecked;
					m_targetData[m_iTarget].iSpotLightConfig.Value = dataSpotLightConfig.Value;
				}

				if(sender == dataTargetNum.checkBox)
				{
					m_targetData[m_iTarget].iTargetNum.Flag = dataTargetNum.overrideChecked;
					m_targetData[m_iTarget].iTargetNum.Value = dataTargetNum.Value;
				}

				if(sender == dataX.checkBox)
				{
					m_targetData[m_iTarget].fX.Flag = dataX.overrideChecked;
					m_targetData[m_iTarget].fX.Value = dataX.Value;
				}

				if(sender == dataY.checkBox)
				{
					m_targetData[m_iTarget].fY.Flag = dataY.overrideChecked;
					m_targetData[m_iTarget].fY.Value = dataY.Value;
				}

				if(sender == dataDepth.checkBox)
				{
					m_targetData[m_iTarget].fDepth.Flag = dataDepth.overrideChecked;
					m_targetData[m_iTarget].fDepth.Value = dataDepth.Value;
				}

				if(sender == dataClimbRate.checkBox)
				{
					m_targetData[m_iTarget].fClimbRate.Flag = dataClimbRate.overrideChecked;
					m_targetData[m_iTarget].fClimbRate.Value = dataClimbRate.Value;
				}

				if(sender == dataTurnRate.checkBox)
				{
					m_targetData[m_iTarget].fTurnRate.Flag = dataTurnRate.overrideChecked;
					m_targetData[m_iTarget].fTurnRate.Value = dataTurnRate.Value;
				}

				if(sender == dataPitch.checkBox)
				{
					m_targetData[m_iTarget].fPitch.Flag = dataPitch.overrideChecked;
					m_targetData[m_iTarget].fPitch.Value = dataPitch.Value;
				}

				if(sender == dataHeading.checkBox)
				{
					m_targetData[m_iTarget].fHeading.Flag = dataHeading.overrideChecked;
					m_targetData[m_iTarget].fHeading.Value = dataHeading.Value;
				}

				if(sender == dataDriftCourse.checkBox)
				{
					m_targetData[m_iTarget].fDriftCourse.Flag = dataDriftCourse.overrideChecked;
					m_targetData[m_iTarget].fDriftCourse.Value = dataDriftCourse.Value;
				}

				if(sender == dataSpeed.checkBox)
				{
					m_targetData[m_iTarget].fSpeed.Flag = dataSpeed.overrideChecked;
					m_targetData[m_iTarget].fSpeed.Value = dataSpeed.Value;
				}

				if(sender == dataDriftSpeed.checkBox)
				{
					m_targetData[m_iTarget].fDriftSpeed.Flag = dataDriftSpeed.overrideChecked;
					m_targetData[m_iTarget].fDriftSpeed.Value = dataDriftSpeed.Value;
				}

				if(sender == dataDieselSmoke.checkBox)
				{
					m_targetData[m_iTarget].bDieselSmoke.Flag = dataDieselSmoke.overrideChecked;
					m_targetData[m_iTarget].bDieselSmoke.Value = dataDieselSmoke.Value;
				}

				if(sender == dataMissileLaunch.checkBox)
				{
					m_targetData[m_iTarget].bMissileLaunch.Flag = dataMissileLaunch.overrideChecked;
					m_targetData[m_iTarget].bMissileLaunch.Value = dataMissileLaunch.Value;
				}

			}
		}

		public void updatePage()
		{
			iTempCount ++;

			if(this.ptrGUI.PIPEmulation)
			{
				if(m_iTarget >= 0 && m_iTarget < iNumTargetType)
				{
					if(dataVisible.OverrideValue != m_targetData[m_iTarget].bVisible.Value)
						dataVisible.OverrideValue = m_targetData[m_iTarget].bVisible.Value;

					if(dataExplosion.OverrideValue != m_targetData[m_iTarget].bExplosion.Value)
						dataExplosion.OverrideValue = m_targetData[m_iTarget].bExplosion.Value;

					if(dataMissileExplosion.OverrideValue != m_targetData[m_iTarget].bMissileExplosion.Value)
						dataMissileExplosion.OverrideValue = m_targetData[m_iTarget].bMissileExplosion.Value;

					if(dataTorpedoExplosion.OverrideValue != m_targetData[m_iTarget].bTorpedoExplosion.Value)
						dataTorpedoExplosion.OverrideValue = m_targetData[m_iTarget].bTorpedoExplosion.Value;

					if(dataSinking.OverrideValue != m_targetData[m_iTarget].bSinking.Value)
						dataSinking.OverrideValue = m_targetData[m_iTarget].bSinking.Value;

					if(dataNavLights.OverrideValue != m_targetData[m_iTarget].bNavLights.Value)
						dataNavLights.OverrideValue = m_targetData[m_iTarget].bNavLights.Value;

					if(dataSonarDunking.OverrideValue != m_targetData[m_iTarget].bSonarDunking.Value)
						dataSonarDunking.OverrideValue = m_targetData[m_iTarget].bSonarDunking.Value;

					if(dataTLAMLaunch.OverrideValue != m_targetData[m_iTarget].bTLAMLaunch.Value)
						dataTLAMLaunch.OverrideValue = m_targetData[m_iTarget].bTLAMLaunch.Value;

					if(dataDunkingSonar.OverrideValue != m_targetData[m_iTarget].iDunkingSonar.Value)
						dataDunkingSonar.OverrideValue = m_targetData[m_iTarget].iDunkingSonar.Value;

					if(dataLightConfig.OverrideValue != m_targetData[m_iTarget].iLightConfig.Value)
						dataLightConfig.OverrideValue = m_targetData[m_iTarget].iLightConfig.Value;

					if(dataSpotLightConfig.OverrideValue != m_targetData[m_iTarget].iSpotLightConfig.Value)
						dataSpotLightConfig.OverrideValue = m_targetData[m_iTarget].iSpotLightConfig.Value;

					if(dataTargetNum.OverrideValue != m_targetData[m_iTarget].iTargetNum.Value)
						dataTargetNum.OverrideValue = m_targetData[m_iTarget].iTargetNum.Value;

					if(dataX.OverrideValue != m_targetData[m_iTarget].fX.Value)
						dataX.OverrideValue = m_targetData[m_iTarget].fX.Value;

					if(dataY.OverrideValue != m_targetData[m_iTarget].fY.Value)
						dataY.OverrideValue = m_targetData[m_iTarget].fY.Value;

					if(dataDepth.OverrideValue != m_targetData[m_iTarget].fDepth.Value)
						dataDepth.OverrideValue = m_targetData[m_iTarget].fDepth.Value;

					if(dataClimbRate.OverrideValue != m_targetData[m_iTarget].fClimbRate.Value)
						dataClimbRate.OverrideValue = m_targetData[m_iTarget].fClimbRate.Value;

					if(dataTurnRate.OverrideValue != m_targetData[m_iTarget].fTurnRate.Value)
						dataTurnRate.OverrideValue = m_targetData[m_iTarget].fTurnRate.Value;

					if(dataPitch.OverrideValue != m_targetData[m_iTarget].fPitch.Value)
						dataPitch.OverrideValue = m_targetData[m_iTarget].fPitch.Value;

					if(dataHeading.OverrideValue != m_targetData[m_iTarget].fHeading.Value)
						dataHeading.OverrideValue = m_targetData[m_iTarget].fHeading.Value;

					if(dataDriftCourse.OverrideValue != m_targetData[m_iTarget].fDriftCourse.Value)
						dataDriftCourse.OverrideValue = m_targetData[m_iTarget].fDriftCourse.Value;

					if(dataSpeed.OverrideValue != m_targetData[m_iTarget].fSpeed.Value)
						dataSpeed.OverrideValue = m_targetData[m_iTarget].fSpeed.Value;

					if(dataDriftSpeed.OverrideValue != m_targetData[m_iTarget].fDriftSpeed.Value)
						dataDriftSpeed.OverrideValue = m_targetData[m_iTarget].fDriftSpeed.Value;

					if(dataDieselSmoke.OverrideValue != m_targetData[m_iTarget].bDieselSmoke.Value)
						dataDieselSmoke.OverrideValue = m_targetData[m_iTarget].bDieselSmoke.Value;

					if(dataMissileLaunch.OverrideValue != m_targetData[m_iTarget].bMissileLaunch.Value)
						dataMissileLaunch.OverrideValue = m_targetData[m_iTarget].bMissileLaunch.Value;

				}
			}
		}

		public override void enableOverrides(bool bOnOff)
		{
			dataVisible.enableOverride(bOnOff);
			dataExplosion.enableOverride(bOnOff);
			dataMissileExplosion.enableOverride(bOnOff);
			dataTorpedoExplosion.enableOverride(bOnOff);
			dataSinking.enableOverride(bOnOff);
			dataNavLights.enableOverride(bOnOff);
			dataSonarDunking.enableOverride(bOnOff);
			dataTLAMLaunch.enableOverride(bOnOff);
			dataDunkingSonar.enableOverride(bOnOff);
			dataLightConfig.enableOverride(bOnOff);
			dataSpotLightConfig.enableOverride(bOnOff);

			dataTargetNum.enableOverride(bOnOff);
			dataX.enableOverride(bOnOff);
			dataY.enableOverride(bOnOff);
			dataDepth.enableOverride(bOnOff);
			dataClimbRate.enableOverride(bOnOff);
			dataTurnRate.enableOverride(bOnOff);

			dataPitch.enableOverride(bOnOff);
			dataHeading.enableOverride(bOnOff);
			dataDriftCourse.enableOverride(bOnOff);
			dataSpeed.enableOverride(bOnOff);
			dataDriftSpeed.enableOverride(bOnOff);
			dataSpeed.enableOverride(bOnOff);
			dataDriftSpeed.enableOverride(bOnOff);
			dataDieselSmoke.enableOverride(bOnOff);
			dataMissileLaunch.enableOverride(bOnOff);

			//
			//Set the flags for each the target data.
			//
			for(int i=0; i < m_targetData.Length; i++)
			{
				m_targetData[i].bVisible.Flag = bOnOff;	
				m_targetData[i].bExplosion.Flag = bOnOff;	
				m_targetData[i].bMissileExplosion.Flag = bOnOff;	
				m_targetData[i].bTorpedoExplosion.Flag = bOnOff;	
				m_targetData[i].bSinking.Flag = bOnOff;	
				m_targetData[i].bNavLights.Flag = bOnOff;	
				m_targetData[i].bSonarDunking.Flag = bOnOff;	
				m_targetData[i].bTLAMLaunch.Flag = bOnOff;	
				m_targetData[i].iDunkingSonar.Flag = bOnOff;	
				m_targetData[i].iLightConfig.Flag = bOnOff;	
				m_targetData[i].iSpotLightConfig.Flag = bOnOff;	
				m_targetData[i].iTargetNum.Flag = bOnOff;	
				m_targetData[i].fX.Flag = bOnOff;	
				m_targetData[i].fY.Flag = bOnOff;	
				m_targetData[i].fDepth.Flag = bOnOff;	
				m_targetData[i].fClimbRate.Flag = bOnOff;	
				m_targetData[i].fTurnRate.Flag = bOnOff;	
				m_targetData[i].fPitch.Flag = bOnOff;	
				m_targetData[i].fHeading.Flag = bOnOff;	
				m_targetData[i].fDriftCourse.Flag = bOnOff;	
				m_targetData[i].fSpeed.Flag = bOnOff;	
				m_targetData[i].fDriftSpeed.Flag = bOnOff;	
				m_targetData[i].bDieselSmoke.Flag = bOnOff;	
				m_targetData[i].bMissileLaunch.Flag = bOnOff;	
			}
		}
	}
}
