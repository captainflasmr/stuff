//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiDataItem.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Drawing;


namespace PSCGenericBuild
{
	/// <summary>
	/// Summary description for guiDATAITEM.
	/// </summary>
	//-----------------------------------------------------------------------
	//The DataItem Class, a windows panel containing:
	//  o a label giving the name of the data item
	//  o a text box displaying the 'current' value
	//  o a Checkbox to override the current value
	//  o a numeric/combobox displaying the overriden value
	//  o a label giving the description of the data item
	//-----------------------------------------------------------------------
	public class C_guiDataItem : Panel
	{

		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		protected Label     m_Label;
		protected CheckBox  m_CheckBox;
		protected C_numeric m_Numeric;
		protected ComboBox  m_ComboBox;
		protected TextBox   m_TextBox;
		protected Label     m_Description;
		protected String    m_strDescription;
		protected Control   m_overrideControl;
		protected C_guiTemplatePage guiPage;

		//-----------------------------------------------------------------------
		//Class Properties
		//-----------------------------------------------------------------------

		/************************************************************************
		  PROPERTY      : description
		  TYPE          : Label
		  GET           : Returns the description label
		 ************************************************************************/
		public Label description
		{
			get
			{
				return m_Description;
			}
		}

		public C_numeric numeric
		{
			get
			{
				return m_Numeric;
			}
		}

		public ComboBox comboBox
		{
			get
			{
				return m_ComboBox;
			}
		}

		public CheckBox checkBox
		{
			get
			{
				return m_CheckBox;
			}
		}

		public String strDescription
		{
			get
			{
				return m_strDescription;
			}
		}


		/************************************************************************
		  PROPERTY      : overrideChecked
		  TYPE          : bool
		  GET           : Returns true if the override check has been checked
						  false otherwise.
		 ************************************************************************/
		public bool overrideChecked
		{
			get
			{
				if(m_CheckBox.Checked) 
					return true;
				else
					return false;
			}
		}

		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		public C_guiDataItem()
		{
		}

		/************************************************************************
		  FUNCTION      : C_guiDataItem()
		  DESCRIPTION   : The Constructor for a Data Item. 
		  PARAMETERS    : string strLabel: Label string
						  int iMinValue : Minimum Value
						  int iMaxValue : Maximum Value 						  
						  int iLeft     : Pixel position in from the left of the screen. 						  
						  int iTop      : Pixel position in from the top of the screen. 						  						  
						  Form parent   : Form to add the data item to.						  
						  string strDescription : Description string label.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the Data Item
		 ************************************************************************/
		public C_guiDataItem(string strLabel, string strHashTableKey, int iLeft, int iTop, C_guiTemplatePage parent, string strDescription)
		{
			//
			//Retrieve the data from the config hash table
			//
			if(strHashTableKey == null) return;

			//
			//Initialise the data item by creating the various components.
			//
			initDataItem(strLabel, strHashTableKey, iLeft, iTop, parent, strDescription);
		}

		protected virtual void initDataItem(string strLabel, string strHashTableKey, int iLeft, int iTop, C_guiTemplatePage parent, string strDescription)
		{
			this.Location = new Point(iLeft, iTop);
			this.guiPage    = parent;

			//
			//Create the Label.
			//
			m_Label       = new Label();
			m_Label.Text  = strLabel;
			m_Label.Left  = 0;
			m_Label.Top   = 0;
			m_Label.Width = 130;

			//
			//Create the Text Box. Make the text box read only. By default this will change the colour of the 
			//component background to grey, so set the colour manually to white.
			//
			m_TextBox           = new TextBox();
			m_TextBox.ReadOnly  = true;
			m_TextBox.ForeColor = Color.Black;
			m_TextBox.TabStop   = false;
			m_TextBox.BackColor = Color.White;	
				
			//
			//Create the Check Box.
			//
			m_CheckBox           = new CheckBox();
			m_CheckBox.Width     = 20;
			m_CheckBox.Click    += new EventHandler(ToggleOverrideActive);           

			//
			//Create the NumericUpDown.
			//
			m_Numeric                = new C_numeric();
			m_Numeric.Enabled        = false;
			//m_Numeric.Maximum        = m_iMaxValue;
			//m_Numeric.Minimum        = m_iMinValue;
			m_Numeric.DecimalPlaces  = 4;			
			m_Numeric.TabStop        = false;
			m_Numeric.GotFocus      += new EventHandler(override_GotFocus);
			m_Numeric.LostFocus     += new EventHandler(override_LostFocus);

			//Add an Event Handler when the override value is changed.
			m_Numeric.ValueChanged += new EventHandler(OverrideValueChanged);

			//
			//Create the ComboBox
			//
			m_ComboBox = new ComboBox();

			//By default the override control is a NumericUpDown.
			m_overrideControl = m_Numeric;

			//
			//Create the description label.
			//
			m_Description       = new Label();
			m_Description.Text  = strDescription;
			m_Description.Width = strDescription.Length * 8;

			//
			//Set the default values for the controls.
			//
			//this.CurrentValue  = (float) m_iDefaultValue;
			//this.OverrideValue = (float) m_iDefaultValue;

			//
			//Add the controls to the panel.
			//
			this.Controls.Add (m_Label);
			this.Controls.Add (m_TextBox);
			this.Controls.Add (m_CheckBox);
			this.Controls.Add (m_overrideControl);
			this.Controls.Add (m_Description);

			//Update the size of the panel.
			this.Size      = new Size(500, 30);

			//Set the underlying data
			if(parent.ptrGUI.hashtable != null)
			{
				DataFields data = (DataFields) parent.ptrGUI.hashtable[strHashTableKey];
				setData(data);
			}

			//
			//Position the data items.
			//
			positionDataItems(); 

			
		}

        delegate void setTextboxTextCallback(string text);

        public void setTextboxText(string text) {
            if (this.m_TextBox.InvokeRequired)
            {
                //Console.WriteLine("Invoked from other thread!");
                setTextboxTextCallback d = new setTextboxTextCallback(setTextboxText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                //Console.WriteLine("Invoked from this thread!");
                this.m_TextBox.Text = text;
            }
        }

        

		protected virtual void setData(DataFields data)
		{
			//Virtual Function is placeholder for derived classes.
		}	

		protected virtual void positionDataItems()
		{
			m_TextBox.Location     = new Point(130, 0);
			m_CheckBox.Location    = new Point(250, 0);
			m_Numeric.Location     = new Point(300, 0);
			m_Description.Location = new Point(450, 0);
		}

		public void positionDataItems(Point TextPos,Point CheckPos,	Point OverridePos,Point DescriptionPos)
		{
			m_TextBox.Location         = TextPos;
			m_CheckBox.Location        = CheckPos;
			m_overrideControl.Location = OverridePos;
			m_Description.Location     = DescriptionPos;
		}

		public void setListEntries(string [] stringEntries)
		{
			//Disable the text box.
			this.Controls.Remove(m_Numeric);

			//A ComboBox is to be used instead of the NumericUpDown.
			m_ComboBox = new ComboBox();
			m_ComboBox.BeginUpdate();
			for(int i=0; i< stringEntries.Length; i++)
			{
				m_ComboBox.Items.Add(stringEntries[i]);
			}
			m_ComboBox.EndUpdate();

			//Position the comboBox.
			m_ComboBox.Left = m_Numeric.Left;
			m_ComboBox.Top  = m_Numeric.Top;

			//By default the comboBox is disabled.
			m_ComboBox.Enabled       = false;
			m_ComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
			m_ComboBox.SelectedIndex = 0;

			//Switch the override control to be the comboBox.
			m_overrideControl = m_ComboBox;

			//
			//Add an Event Handler for when the override value is changed by altering the state.
			//of the combo box.
			//
			m_ComboBox.SelectedValueChanged += new EventHandler(OverrideValueChanged);

			this.Controls.Add(m_ComboBox);

			//
			//Set the default value.
			//
			//this.CurrentValue  = (float) m_iDefaultValue;
			//this.OverrideValue = (float) m_iDefaultValue;
			setDefaultValues();
		}

		public virtual void setDefaultValues()
		{
			//placeholder for the defaultValues
		}
	
		public void setDecimalPlaces(int iDecimalPlaces)
		{
			m_Numeric.DecimalPlaces = iDecimalPlaces;
		}

		public void setOverride(bool bEnabled)
		{
			if(bEnabled)
			{
				if(m_CheckBox.Checked)
				{
					m_overrideControl.Enabled = true;
					m_TextBox.BackColor      = Color.Empty;               
				}
			}
			else
			{
				if(m_CheckBox.Checked)
				{
					m_overrideControl.Enabled = false;
					m_TextBox.BackColor     = Color.White;
				}
			}
		}

		public virtual void enableOverride(bool bOnOff)
		{
			if(bOnOff)
			{
				m_overrideControl.Enabled = true;
				m_TextBox.BackColor = Color.Empty;
				m_CheckBox.Checked = true;
				//this.OverrideValue = (float) this.m_iDefaultValue;
				guiPage.OverrideSelect(true);
			}
			else
			{
				m_overrideControl.Enabled = false;
				m_TextBox.BackColor      = Color.White;
				m_CheckBox.Checked       = false;
				guiPage.OverrideSelect(false);
			}
		}

		public void setupOverride(bool bEnabled)
		{
			if(bEnabled)
			{
				m_CheckBox.Checked = true;
				m_overrideControl.Enabled = true;
				m_TextBox.BackColor = Color.Empty;               
			}
			else
			{
				m_CheckBox.Checked = false;
				m_overrideControl.Enabled = false;
				m_TextBox.BackColor = Color.White;
			}
		}


		/************************************************************************
		  FUNCTION      : ToggleOverrideActive(object sender, EventArgs e)
		  DESCRIPTION   : Event to toggle between text box entry and the override.
		  PARAMETERS    : None.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : As read.
		 ************************************************************************/
		protected void ToggleOverrideActive(object sender, EventArgs e)
		{
			//
			//Update the Appearance of the TextBox.
			//
			if(m_overrideControl.Enabled == true)
			{
				m_overrideControl.Enabled = false;
				m_TextBox.BackColor      = Color.White;
				guiPage.OverrideSelect(false);
			}
			else
			{
				m_overrideControl.Enabled = true;
				m_TextBox.BackColor      = Color.Empty;
				guiPage.OverrideSelect(true);
			}


			//
			//Update the PIG data and send the packet out.
			//
			//guiPage.updateOutgoingData();
		}

		/************************************************************************
		  FUNCTION      : numeric_Validating(object sender, CancelEventArgs e)
		  DESCRIPTION   : Event to validate the entry in a NumericUpDown.
		  PARAMETERS    : object sender       :
						  CancelEventArgs e   : Default Arguments.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : As read.
		 ************************************************************************/
		protected virtual void numeric_Validating(object sender, CancelEventArgs e)
		{

			//			NumericUpDown aNumeric  = (NumericUpDown) sender;  
			//			float fValidate = (float) aNumeric.Value;
			//
			//			//
			//			//A valid number in the numeric is less than the maximum and greater
			//			//than the minimum value.
			//			//
			//			if (aNumeric.Value > aNumeric.Maximum)
			//			{
			//				aNumeric.Value = aNumeric.Maximum;
			//				//Beep(1000, 1000);
			//			}
			//
			//			else if (aNumeric.Value < aNumeric.Minimum) 
			//			{
			//				aNumeric.Value = aNumeric.Minimum;
			//				//Beep(1000, 1000);
			//			}

		}

		/************************************************************************
		  FUNCTION      : override_GotFocus(object sender, CancelEventArgs e)
		  DESCRIPTION   : Event to set the override background colour when the object
						  has got focus.
		  PARAMETERS    : object sender       :
						  CancelEventArgs e   : Default Arguments.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : As read.
		 ************************************************************************/
		protected void override_GotFocus(object sender, EventArgs eArgs)
		{
			//
			//Alter the colour of the background.
			//

			if(sender == m_Numeric)
			{
				m_Numeric.BackColor = Color.PowderBlue; /*Color.RoyalBlue*/ 
				m_Numeric.ForeColor = Color.White;
			}
		}

		/************************************************************************
		  FUNCTION      : override_LostFocus(object sender, CancelEventArgs e)
		  DESCRIPTION   : Event to set the background colour when the override field
						  has lost focus.
		  PARAMETERS    : object sender       :
						  CancelEventArgs e   : Default Arguments.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : As read.
		 ************************************************************************/
		protected void override_LostFocus(object sender, EventArgs eArgs)
		{
			//
			//Alter the colour of the background.
			//
			if(sender == m_Numeric)
			{
				if(m_CheckBox.Checked)
					m_Numeric.BackColor = Color.Empty;               
				else
					m_Numeric.BackColor = Color.White;

				m_Numeric.ForeColor = Color.Black;
			}
		}

		protected virtual void OverrideValueChanged(object sender, EventArgs eArgs)
		{
			//			if(sender == m_Numeric)
			//			{
			//				OverrideValue = (float) m_Numeric.Value;
			//			}
			//			else
			//			{
			//				OverrideValue = this.m_ComboBox.Items.IndexOf(m_ComboBox.Text);					
			//			}
			
			//
			//Update the PIG Data (and send the packet to the PIG).
			//		
			//guiPage.updateOutgoingData();
		}
	}

	//-----------------------------------------------------------------------
	//The numeric Class, a refinement of the windows NumericUpDown control.
	//
	// o The numeric class has redefined the validation methods so that the system
	//   will beep if a value is entered which lies outside of the max/min bounds.
	//
	// o Value is validated when the 'Enter', 'Tab' and 'Escape' keys are pressed, or 
	//   if the control has lost focus on the form.
	//
	//-----------------------------------------------------------------------
	public class C_numeric : NumericUpDown
	{
		protected string strText;

		public enum MessageBeepType
		{
			Default     = -1,
			Ok          = 0x00000000,
			Error       = 0x00000010,
			Question    = 0x00000020,
			Warning     = 0x00000030,
			Information = 0x00000040,		    
		}

		[DllImport("user32.dll", SetLastError=true)]
		public static extern bool MessageBeep(MessageBeepType type);

		public C_numeric()
		{
			this.TabStop   = false;
			//this.AcceptsTab = true;
		}

		protected override void OnTextBoxKeyPress(object source, KeyPressEventArgs e)
		{ 
			if((e.KeyChar == (char) Keys.Enter) || 
				(e.KeyChar == (char) Keys.Tab )  || 
				(e.KeyChar == (char) Keys.Escape))
			{
				e.Handled = true;
				validateValue(true);
			}
			else
			{
				base.OnTextBoxKeyPress(source, e);
			}

		}

		protected override void ValidateEditText()
		{
			strText = this.Text;
			base.ValidateEditText ();
		}

		protected override void OnLostFocus(EventArgs e)
		{
			Form parent = this.FindForm();
			if(parent != null)
			{
				if(parent.ContainsFocus)
				{
					validateValue(true);
				}
				else
					validateValue(false);
			}

			base.OnLostFocus (e);
		}

		public void validateValue(bool bSoundsOn)
		{
			float fValue;

			try
			{
				if(strText == null) return;

				fValue = Single.Parse(strText);

				//
				//If the value entered is less than the  minimum or greater than
				//the maximum, play an error sound.
				//
				if(fValue > (float) this.Maximum)
				{
					if(bSoundsOn)
						MessageBeep(MessageBeepType.Ok);
				}
				else if(fValue < (float) this.Minimum)
				{
					if(bSoundsOn)
						MessageBeep(MessageBeepType.Ok);
				}
			}
			catch(FormatException)
			{	
				//
				//If no value is entered, play an error sound.
				//
				if(strText != "")
				{
					if(bSoundsOn)
						MessageBeep(MessageBeepType.Ok);
				}

				System.Console.WriteLine("Value entered was not a valid number");
			}

			//Reset the text.
			strText = this.Text;
		}
	}

}
