//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiPIPExerciseData.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Drawing;

namespace PSCGenericBuild
{
	//-----------------------------------------------------------------------
	//The PIP Exercise Data Page Class.
	//-----------------------------------------------------------------------
	public class C_guiPIPExerciseData : C_guiTemplatePage
	{
		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		string [] strMode = {"Freeze", "Run", "Target Freeze",  "Fast Run"};
		//public PIGExercisePacket oPIGExercisePacket;
		protected PIPExerciseData   m_InData;

		public C_guiDataItemByte  dataRunMode;
		public C_guiDataItemByte  dataHours;
		public C_guiDataItemByte  dataMinutes;
		public C_guiDataItemByte  dataSeconds;
		public C_guiDataItemByte  dataDay;
		public C_guiDataItemByte  dataMonth;
		public C_guiDataItemByte  dataYear;

		//protected bool m_intialised;


		//-----------------------------------------------------------------------
		//Class Properties
		//-----------------------------------------------------------------------

		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		/************************************************************************
		  FUNCTION      : C_guiPIPExerciseData()
		  DESCRIPTION   : The Constructor for PIP Exercise Data Page. 
		  PARAMETERS    : parentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the PIP Exercise Data Page.
		 ************************************************************************/
		public C_guiPIPExerciseData (C_gui parentForm)
		{

			this.ptrGui    = parentForm;
			//this.ptrPSC    = parentForm.psc;

			//-----------------------------------------------------
			//Declare the data items.
			//-----------------------------------------------------
			m_dataItem    = new C_guiDataItem[7];
			this.Text     = "PIP Data - Exercise Data";
			this.pageType = C_gui.page.PIP_EXERCISE;

			m_InData = this.ptrGui.m_InPIPData.oExercise;

			//-----------------------------------------------------
			//Initialise each data item.
			//-----------------------------------------------------

			string [] strDescription = new string[7];

			strDescription[ 0] = "Run Mode (Freeze/Run/Target Freeze/Fast Run" + ")";
			strDescription[ 1] = "Time of day, hours ";
			strDescription[ 2] = "Time of day, minutes";
			strDescription[ 3] = "Time of day, seconds";
			strDescription[ 4] = "Date, day ";
			strDescription[ 5] = "Date, month";
			strDescription[ 6] = "Date, year since 1990 ";

			dataRunMode = new C_guiDataItemByte( "Run Mode"     ,"PIP_EXERCISE_RUN_MODE",50, 10,  this, strDescription[0]);
			dataHours   = new C_guiDataItemByte( "Hours "       ,"PIP_EXERCISE_HOURS",   50, 40,  this, strDescription[1]);
			dataMinutes = new C_guiDataItemByte( "Minutes "     ,"PIP_EXERCISE_MINUTES", 50, 70,  this, strDescription[2]);
			dataSeconds = new C_guiDataItemByte( "Seconds "     ,"PIP_EXERCISE_SECONDS", 50, 100, this, strDescription[3]);
			dataDay     = new C_guiDataItemByte( "Day "         ,"PIP_EXERCISE_DAY",     50, 130, this, strDescription[4]);
			dataMonth   = new C_guiDataItemByte( "Month"        ,"PIP_EXERCISE_MONTH",   50, 160, this, strDescription[5]);
			dataYear    = new C_guiDataItemByte( "Year"         ,"PIP_EXERCISE_YEAR",    50, 190, this, strDescription[6]);

			dataRunMode	.setListEntries(strMode);

			//for(int i = 0; i < m_dataItem.Length; i++)
			//	this.Controls.Add(m_dataItem[i]);

		    this.Controls.Add(dataRunMode);
		    this.Controls.Add(dataHours);
			this.Controls.Add(dataMinutes);
			this.Controls.Add(dataSeconds);
			this.Controls.Add(dataDay);
			this.Controls.Add(dataMonth);
			this.Controls.Add(dataYear);


			this.MdiParent = parentForm;
			this.Size        = new Size(760, 260);

			m_initialised = true;
			//this.WindowState = FormWindowState.Maximized;
		}

		public override void updateIncomingData()
		{

			if(!m_initialised) 
				return;

			dataRunMode.Value = m_InData.bRunMode.Value;
			dataHours.Value =  m_InData.hours.Value;
			dataMinutes.Value =  m_InData.minutes.Value;
			dataSeconds.Value =  m_InData.seconds.Value;
			dataDay.Value =  m_InData.day.Value;
			dataMonth.Value =  m_InData.month.Value;
			dataYear.Value =  m_InData.year.Value;
		}

		public override void updateOutgoingData()
		{           
			if(!m_initialised) 
				return;

			this.ptrGui.m_OutPIPData.oExercise.bRunMode.Value = dataRunMode.Value;
			this.ptrGui.m_OutPIPData.oExercise.hours.Value  = dataHours.Value;
			this.ptrGui.m_OutPIPData.oExercise.minutes.Value = dataMinutes.Value;
			this.ptrGui.m_OutPIPData.oExercise.seconds.Value  = dataSeconds.Value;
			this.ptrGui.m_OutPIPData.oExercise.day.Value  = dataDay.Value;
			this.ptrGui.m_OutPIPData.oExercise.month.Value = dataMonth.Value;
			this.ptrGui.m_OutPIPData.oExercise.year.Value  = dataYear.Value;
		
			this.ptrGui.m_OutPIPData.oExercise.bRunMode.Flag = dataRunMode.overrideChecked;
			this.ptrGui.m_OutPIPData.oExercise.hours.Flag  = dataHours.overrideChecked;
			this.ptrGui.m_OutPIPData.oExercise.minutes.Flag = dataMinutes.overrideChecked;
			this.ptrGui.m_OutPIPData.oExercise.seconds.Flag  = dataSeconds.overrideChecked;
			this.ptrGui.m_OutPIPData.oExercise.day.Flag  = dataDay.overrideChecked;
			this.ptrGui.m_OutPIPData.oExercise.month.Flag = dataMonth.overrideChecked;
			this.ptrGui.m_OutPIPData.oExercise.year.Flag  = dataYear.overrideChecked;

			/*
						oPIGExercisePacket.iSystemID = Convert.ToInt32 (dataItem[0].Value);
						oPIGExercisePacket.iRunMode  = Convert.ToInt32 (dataItem[1].Value);
						this.ptrMain.ptrNetwork.send();
			*/			
		}

		public override void enableOverrides(bool bOnOff)
		{
			dataRunMode.enableOverride(bOnOff);
			dataHours.enableOverride(bOnOff);
			dataMinutes.enableOverride(bOnOff);
			dataSeconds.enableOverride(bOnOff);
			dataDay.enableOverride(bOnOff);
			dataMonth.enableOverride(bOnOff);
			dataYear.enableOverride(bOnOff);
		}
	}
}
