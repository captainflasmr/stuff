//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiPIPOwnshipData.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Drawing;

namespace PSCGenericBuild
{
	
	//-----------------------------------------------------------------------
	//The PIP Ownship Page Class.
	//-----------------------------------------------------------------------
	public class C_guiPIPOwnshipData : C_guiTemplatePage
	{
		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		protected string     [] strDescription;
		public PIGOwnshipData oPIGOwnshipPacket;
		public PIPOwnboatData m_InData;

		public const int NUM_MASTS = 10;

		public const int WHIP_AERIAL  = 0x0001;
		public const int EM_LIGHT     = 0x0002;
		public const int DIESEL_SMOKE = 0x0004;

		public C_guiDataItemDouble dataLatitude;
		public C_guiDataItemDouble dataLongitude;

		public C_guiDataItemFloat dataDepth;
		public C_guiDataItemFloat dataDiveRate;
		public C_guiDataItemFloat dataPitch;
		public C_guiDataItemFloat dataTurnRate;
		public C_guiDataItemFloat dataHeading;
		public C_guiDataItemFloat dataDriftCourse;
		public C_guiDataItemFloat dataSpeed;
		public C_guiDataItemFloat dataDriftSpeed;
		public C_guiDataItemBoolean  dataWhipAerial;
		public C_guiDataItemBoolean  dataEmLight;
		public C_guiDataItemBoolean dataDieselSmoke;
		public C_guiDataItemByte  dataRESM;
		public C_guiDataItemByte  dataWTComms;
		public C_guiDataItemByte  dataHFDF;
		public C_guiDataItemByte  dataAttackPeri;
		public C_guiDataItemByte  dataRadar;
		public C_guiDataItemByte  dataSnortInduction;
		public C_guiDataItemByte  dataSnortExhaust;
		public C_guiDataItemByte  dataOwnBoatType;

		//-----------------------------------------------------------------------
		//Class Properties
		//-----------------------------------------------------------------------
		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		/************************************************************************
		  FUNCTION      : C_guiPIPOwnshipData()
		  DESCRIPTION   : The Constructor for PIP Ownship Data Page. 
		  PARAMETERS    : parentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the PIP Ownship Data Page.
		 ************************************************************************/
		public C_guiPIPOwnshipData (C_gui parentForm)
		{
			string [] strOnOff     = {"Off", "On"};
			string [] strDownUp    = {"Down", "Up"};
			string [] strBoatType  = {"OS Subtest","Swiftsure", "Trafalgar"};

			this.ptrGui = parentForm;
			//this.ptrPSC = parentForm.psc;

			this.Text      = "PIP Data - Ownship Data";
			this.pageType  = C_gui.page.PIP_OWNSHIP;
			m_InData = this.ptrGUI.m_InPIPData.oOwnboat;

			//-----------------------------------------------------
			//Declare the data items.
			//-----------------------------------------------------
			m_dataItem = new C_guiDataItem[21];



			strDescription = new String[21];

			strDescription[ 0]  = "Current latitude ("            + ")";
			strDescription[ 1]  = "Current longitude ("           + ")";
			strDescription[ 2]  = "Depth             ("           + ")";
			strDescription[ 3]  = "Climb / Dive rate ("           + ")";
			strDescription[ 4]  = "Turn rate ("                   + ")";
			strDescription[ 5]  = "Pitch ("                       + ")";
			strDescription[ 6]  = "Heading ("                     + ")";
			strDescription[ 7]  = "Drift Course ("                + ")";
			strDescription[ 8]  = "Speed ("                       + ")";
			strDescription[ 9]  = "Drift Speed ("                 + ")";
			strDescription[10]  = "Whip Aerial ( Down / Up)";
			strDescription[11]  = "Emergency Light ( On / Off)";
			strDescription[12]  = "Diesel Smoke (On / Off)";
			strDescription[13]  = "RESM ("                        + "%)";
			strDescription[14]  = "WT Comms ("                    + "%)";
			strDescription[15]  = "CESM (HFDF) ("                 + "%)";
			strDescription[16]  = "Attack Periscope ("            + "%)";
			strDescription[17]  = "Radar ("                       + "%)";
			strDescription[18]  = "Snort Induction ("             + "%)";
			strDescription[19]  = "Snort Exhaust ("               + "%)";
			strDescription[20]  = "Own Boat Type ( OS Subtest / Swiftsure / Trafalgar)";


			//-----------------------------------------------------
			//Initialise each data item.
			//-----------------------------------------------------
			dataLatitude = new C_guiDataItemDouble( "Latitude",          "PIP_OWNSHIP_LATITUDE",      50,  10, this, strDescription[0]);
			dataLongitude = new C_guiDataItemDouble( "Longitude",         "PIP_OWNSHIP_LONGITUDE",     50,  40, this, strDescription[1]);
			dataDepth  = new C_guiDataItemFloat( "Depth",             "PIP_OWNSHIP_DEPTH",         50,  70, this, strDescription[2]);
			dataDiveRate = new C_guiDataItemFloat( "Climb / Dive Rate", "PIP_OWNSHIP_CLIMB_RATE",    50, 100, this, strDescription[3]);
			dataTurnRate = new C_guiDataItemFloat( "Turn Rate",         "PIP_OWNSHIP_TURN_RATE",     50, 130, this, strDescription[4]);
			dataPitch = new C_guiDataItemFloat( "Pitch",             "PIP_OWNSHIP_PITCH",         50, 160, this, strDescription[5]);
			dataHeading = new C_guiDataItemFloat( "Heading",           "PIP_OWNSHIP_HEADING",       50, 190, this, strDescription[6]);
			dataDriftCourse = new C_guiDataItemFloat( "Drift Course",      "PIP_OWNSHIP_DRIFT_COURSE",  50, 220, this, strDescription[7]);
			dataSpeed  = new C_guiDataItemFloat( "Speed",             "PIP_OWNSHIP_SPEED",         50, 250, this, strDescription[8]);
			dataDriftSpeed = new C_guiDataItemFloat( "Drift Speed",       "PIP_OWNSHIP_DRIFT_SPEED",   50, 280, this, strDescription[9]);
			dataWhipAerial = new C_guiDataItemBoolean( "Whip Aerial",        "PIP_OWNSHIP_WHIP_AERIAL",   50, 310, this, strDescription[10]);
			dataEmLight = new C_guiDataItemBoolean( "Emergency Light",    "PIP_OWNSHIP_EMERGENCY_LGT", 50, 340, this, strDescription[11]);
			dataDieselSmoke = new C_guiDataItemBoolean( "Diesel Smoke",       "PIP_OWNSHIP_DIESEL_SMOKE",  50, 370, this, strDescription[12]);
			dataRESM = new C_guiDataItemByte( "RESM",               "PIP_OWNSHIP_RESM",          50, 400, this, strDescription[13]);
			dataWTComms = new C_guiDataItemByte( "WT Comms",           "PIP_OWNSHIP_WT_COMMS",      50, 430, this, strDescription[14]);
			dataHFDF = new C_guiDataItemByte( "CESM (HFDF)",        "PIP_OWNSHIP_CESM",          50, 460, this, strDescription[15]);
			dataAttackPeri = new C_guiDataItemByte( "Attack Periscope",   "PIP_OWNSHIP_ATTACK_PERI",   50, 490, this, strDescription[16]);
			dataRadar = new C_guiDataItemByte( "Radar",              "PIP_OWNSHIP_RADAR",         50, 520, this, strDescription[17]);
			dataSnortInduction = new C_guiDataItemByte( "Snort Induction",    "PIP_OWNSHIP_SNORT_IND",     50, 550, this, strDescription[18]);
			dataSnortExhaust = new C_guiDataItemByte( "Snort Exhaust",      "PIP_OWNSHIP_SNORT_EX",      50, 580, this, strDescription[19]);
			dataOwnBoatType = new C_guiDataItemByte( "Own Boat Type",      "PIP_OWNSHIP_TYPE",          50, 610, this, strDescription[20]);

			dataWhipAerial.setListEntries(strDownUp);
			dataEmLight.setListEntries(strOnOff);
			dataDieselSmoke.setListEntries(strOnOff);
			dataOwnBoatType.setListEntries(strBoatType);

			this.Controls.Add(dataLatitude);
			this.Controls.Add(dataLongitude);
			this.Controls.Add(dataDepth);
			this.Controls.Add(dataDiveRate);
			this.Controls.Add(dataPitch);
			this.Controls.Add(dataTurnRate);
			this.Controls.Add(dataHeading);
			this.Controls.Add(dataDriftCourse);
			this.Controls.Add(dataSpeed);
			this.Controls.Add(dataDriftSpeed);
			this.Controls.Add(dataWhipAerial);
			this.Controls.Add(dataEmLight);
			this.Controls.Add(dataDieselSmoke);
			this.Controls.Add(dataRESM);
			this.Controls.Add(dataWTComms);
			this.Controls.Add(dataHFDF);
			this.Controls.Add(dataAttackPeri);
			this.Controls.Add(dataRadar);
			this.Controls.Add(dataSnortInduction);
			this.Controls.Add(dataSnortExhaust);
			this.Controls.Add(dataOwnBoatType);


			this.Size = new Size(830, 670);

			this.MdiParent = parentForm;
			//this.WindowState = FormWindowState.Maximized;

			//
			//Declare the mast array in the packet structure.
			//
			//oPIGOwnshipPacket.mast = new float[/*(C_Network.NUM_OWNSHIP_MASTS*/ 10 ];

			m_initialised = true;

		}

		public override void updateIncomingData()
		{
			if(!m_initialised)
				return;

			this.dataLatitude.Value =  m_InData.dfLatitude.Value;
			this.dataLongitude.Value =  m_InData.dfLongitude.Value;
			this.dataDepth.Value = m_InData.fDepth.Value;
			this.dataDiveRate.Value = m_InData.fClimbRate.Value;
			this.dataTurnRate.Value = m_InData.fTurnRate.Value;
			this.dataPitch.Value = m_InData.fPitch.Value;
			this.dataHeading.Value = m_InData.fHeading.Value;
			this.dataDriftCourse.Value = m_InData.fDriftCourse.Value;
			this.dataSpeed.Value = m_InData.fSpeed.Value;
			this.dataDriftSpeed.Value = m_InData.fDriftSpeed.Value;

			this.dataWhipAerial.Value = m_InData.bWhipAerial.Value;
			this.dataEmLight.Value = m_InData.bEmLight.Value ;
            this.dataDieselSmoke.Value = m_InData.bDieselSmoke.Value;

            this.dataRESM.Value = m_InData.bRESM.Value;
            this.dataWTComms.Value = m_InData.bWTComms.Value;
            this.dataHFDF.Value = m_InData.bCESM.Value;
            this.dataAttackPeri.Value = m_InData.bAttackPeriscope.Value;
            this.dataRadar.Value = m_InData.bRadar.Value;
            this.dataSnortInduction.Value = m_InData.bSnortInduction.Value;
            this.dataSnortExhaust.Value = m_InData.bSnortExhaust.Value;

			this.dataOwnBoatType.Value = m_InData.bType.Value;

		}

		public override void updateOutgoingData()
		{
			if(!m_initialised)
				return;	

            this.ptrGui.m_OutPIPData.oOwnboat.bWhipAerial.Value = dataWhipAerial.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.bEmLight.Value = dataEmLight.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.bDieselSmoke.Value = dataDieselSmoke.Value;

			this.ptrGui.m_OutPIPData.oOwnboat.dfLatitude.Value  = dataLatitude.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.dfLongitude.Value = dataLongitude.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.fDepth.Value      = dataDepth.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.fClimbRate.Value  = dataDiveRate.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.fTurnRate.Value   = dataTurnRate.Value;

			this.ptrGui.m_OutPIPData.oOwnboat.fPitch.Value       = dataPitch.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.fHeading.Value     = dataHeading.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.fDriftCourse.Value = dataDriftCourse.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.fSpeed.Value       = dataSpeed.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.fDriftSpeed.Value  = dataDriftSpeed.Value;

			this.ptrGui.m_OutPIPData.oOwnboat.bRESM.Value            = dataRESM.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.bWTComms.Value         = dataWTComms.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.bCESM.Value            = dataHFDF.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.bAttackPeriscope.Value = dataAttackPeri.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.bRadar.Value           = dataRadar.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.bSnortInduction.Value  = dataSnortInduction.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.bSnortExhaust.Value    = dataSnortExhaust.Value;
			this.ptrGui.m_OutPIPData.oOwnboat.bType.Value            = dataOwnBoatType.Value;

		
//			this.ptrGui.m_OutPIPData.oEnvironment.bFlags.Flag = dataWhipAerial.overrideChecked ||
//																dataEmLight.overrideChecked ||
//																dataDieselSmoke.overrideChecked; 

			this.ptrGui.m_OutPIPData.oOwnboat.dfLatitude.Flag  = dataLatitude.overrideChecked;
			this.ptrGui.m_OutPIPData.oOwnboat.dfLongitude.Flag = dataLongitude.overrideChecked;
			this.ptrGui.m_OutPIPData.oOwnboat.fDepth.Flag      = dataDepth.overrideChecked;
			this.ptrGui.m_OutPIPData.oOwnboat.fClimbRate.Flag  = dataDiveRate.overrideChecked;
			this.ptrGui.m_OutPIPData.oOwnboat.fTurnRate.Flag   = dataTurnRate.overrideChecked;

			this.ptrGui.m_OutPIPData.oOwnboat.fPitch.Flag       = dataPitch.overrideChecked;
			this.ptrGui.m_OutPIPData.oOwnboat.fHeading.Flag     = dataHeading.overrideChecked;
			this.ptrGui.m_OutPIPData.oOwnboat.fDriftCourse.Flag = dataDriftCourse.overrideChecked;
			this.ptrGui.m_OutPIPData.oOwnboat.fSpeed.Flag       = dataSpeed.overrideChecked;
			this.ptrGui.m_OutPIPData.oOwnboat.fDriftSpeed.Flag  = dataDriftSpeed.overrideChecked;

			this.ptrGui.m_OutPIPData.oOwnboat.bRESM.Flag            = dataRESM.overrideChecked;
			this.ptrGui.m_OutPIPData.oOwnboat.bWTComms.Flag         = dataWTComms.overrideChecked;
			this.ptrGui.m_OutPIPData.oOwnboat.bCESM.Flag            = dataHFDF.overrideChecked;
			this.ptrGui.m_OutPIPData.oOwnboat.bAttackPeriscope.Flag = dataAttackPeri.overrideChecked;
			this.ptrGui.m_OutPIPData.oOwnboat.bRadar.Flag           = dataRadar.overrideChecked;
			this.ptrGui.m_OutPIPData.oOwnboat.bSnortInduction.Flag  = dataSnortInduction.overrideChecked;
			this.ptrGui.m_OutPIPData.oOwnboat.bSnortExhaust.Flag    = dataSnortExhaust.overrideChecked;
			this.ptrGui.m_OutPIPData.oOwnboat.bType.Flag            = dataOwnBoatType.overrideChecked;
		}

		public override void enableOverrides(bool bOnOff)
		{
			dataLatitude.enableOverride(bOnOff);
			dataLongitude.enableOverride(bOnOff);
			dataDepth.enableOverride(bOnOff);
			dataDiveRate.enableOverride(bOnOff);
			dataPitch.enableOverride(bOnOff);
			dataTurnRate.enableOverride(bOnOff);
			dataHeading.enableOverride(bOnOff);
			dataDriftCourse.enableOverride(bOnOff);
			dataSpeed.enableOverride(bOnOff);
			dataDriftSpeed.enableOverride(bOnOff);
			dataWhipAerial.enableOverride(bOnOff);
			dataEmLight.enableOverride(bOnOff);
			dataDieselSmoke.enableOverride(bOnOff);
			dataRESM.enableOverride(bOnOff);
			dataWTComms.enableOverride(bOnOff);
			dataHFDF.enableOverride(bOnOff);
			dataAttackPeri.enableOverride(bOnOff);
			dataRadar.enableOverride(bOnOff);
			dataSnortInduction.enableOverride(bOnOff);
			dataSnortExhaust.enableOverride(bOnOff);
			dataOwnBoatType.enableOverride(bOnOff);
		}
	}
}
