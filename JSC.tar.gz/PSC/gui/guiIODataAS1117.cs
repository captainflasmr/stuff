//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiIODataAS1117.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Windows.Forms;

namespace PSCGenericBuild
{
	//-----------------------------------------------------------------------
	//The IO Data (AS1117/AS1118) Class.
	//-----------------------------------------------------------------------
	public class C_guiIODataAS1117 : C_guiTemplatePage
	{

		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		protected C_guiIODataItemFloat   dataBearing;
		protected C_guiIODataItemBoolean dataRangeCut;
		protected C_guiIODataItemBoolean dataBearingCut;
		protected C_guiIODataItemBoolean dataPTT;
		protected C_guiIODataItemBoolean dataHandlesDown;
		protected C_guiIODataItemFloat   dataElevControl;
		protected C_guiIODataItemFloat   dataStadControl;
		protected C_guiIODataItemBoolean dataMagnification;
		protected C_guiIODataItemFloat   dataRearDisplay;
		protected C_guiIODataItemInt     dataModeSelect;
		protected C_guiIODataItemBoolean dataDataOverlay;
		protected C_guiIODataItemBoolean dataTIOn;          
 		protected C_guiIODataItemFloat   dataTIBlackLevel;
		protected C_guiIODataItemFloat   dataTISensitivity; 
		protected C_guiIODataItemFloat   dataTIGratIllum;   
		protected C_guiIODataItemFloat   dataRearStadAngle; 
		protected C_guiIODataItemFloat   dataRearTrueBrg;   
		protected C_guiIODataItemFloat   dataRearRelBrg;    
		protected C_guiIODataItemFloat   dataBrgDisplay; 
		protected C_guiIODataItemFloat   dataElevDisplay;    

		public IO_Data m_InData;

		protected GroupBox m_inputGroupBox;
		protected GroupBox m_outputGroupBox;

		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		/************************************************************************
		  FUNCTION      : C_guiIODataAS1117()
		  DESCRIPTION   : The Constructor for IO Data Page (AS1117 / AS1118). 
		  PARAMETERS    : parentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the IO Data (AS1117/AS1118) Page.
		 ************************************************************************/
		public C_guiIODataAS1117 (C_gui parentForm)
		{
			this.ptrGui    = parentForm;
			//this.ptrPSC    = parentForm.psc;

			this.Text      = "IO Data";
			this.pageType  = C_gui.page.IO_DATA_AS1117;
			this.Size      = new Size(820, 720);

			string [] strTrueFalse = {"False", "True"};
			string [] strHighLow   = {"Low", "High"};

			//
			//Define the group boxes.
			//
		    m_inputGroupBox  = new GroupBox();
		    m_outputGroupBox = new GroupBox();

			m_inputGroupBox.Text = "Input Controls";
			m_outputGroupBox.Text = "Output Controls";

			m_inputGroupBox.Size = new Size(800, 430);
			m_inputGroupBox.Location = new Point(5, 5);

			m_outputGroupBox.Size = new Size(800, 230);
			m_outputGroupBox.Location = new Point(5, 450);

			this.Controls.Add(m_inputGroupBox);
			this.Controls.Add(m_outputGroupBox);



		    m_InData = this.ptrGui.m_InIOData;

			//-----------------------------------------------------
			//Declare the data items.
			//-----------------------------------------------------

			dataBearing       = new C_guiIODataItemFloat("Bearing",             "IO_DATA_AS1117_BEARING",          30,  30, this, "");
			dataRangeCut      = new C_guiIODataItemBoolean("Range Cut",         "IO_DATA_AS1117_RANGE_CUT",        30,  60, this, "");
			dataBearingCut    = new C_guiIODataItemBoolean("Bearing Cut",       "IO_DATA_AS1117_BEARING_CUT",      30,  90, this, "");
			dataPTT           = new C_guiIODataItemBoolean("PTT",               "IO_DATA_AS1117_PTT",              30, 120, this, "");
			dataHandlesDown   = new C_guiIODataItemBoolean("Handles Down",      "IO_DATA_AS1117_HANDLES_DOWN",     30, 150, this, "");
			dataModeSelect    = new C_guiIODataItemInt("Mode Select",         "IO_DATA_AS1117_MODE_SELECT",      30, 180, this, "");
			dataDataOverlay   = new C_guiIODataItemBoolean("Data Overlay",        "IO_DATA_AS1117_DATA_OVERLAY",     30, 210, this, "");			
			dataElevControl   = new C_guiIODataItemFloat("Elevation Control",   "IO_DATA_AS1117_ELEVATION_CONTROL",30, 240, this, "");
			dataStadControl   = new C_guiIODataItemFloat("Stadiametric Control","IO_DATA_AS1117_STADIAMETRIC",     30, 270, this, "");
			dataMagnification = new C_guiIODataItemBoolean("Magnification",       "IO_DATA_AS1117_MAGNIFICATION",    30, 300, this, "");
			dataTIBlackLevel  = new C_guiIODataItemFloat("TI Black Level",      "IO_DATA_AS1117_TI_BLACK_LEVEL",   30, 330, this, "");
			dataTISensitivity = new C_guiIODataItemFloat("TI Sensitivity",      "IO_DATA_AS1117_TI_SENSITIVITY",   30, 360, this, "");
			dataTIGratIllum   = new C_guiIODataItemFloat("TI Graticule Illum",  "IO_DATA_AS1117_TI_GRATICULE",     30, 390, this, "");

			dataRearStadAngle = new C_guiIODataItemFloat("Rear Display Stad Angle", "IO_DATA_AS1117_REAR_DISPLAY_STAD_ANGLE", 30, 30, this, "");
			dataRearTrueBrg   = new C_guiIODataItemFloat("Rear Display True Brg", "IO_DATA_AS1117_REAR_DISPLAY_TRUE_BRG",  30, 60, this, "");
			dataRearRelBrg    = new C_guiIODataItemFloat("Rear Display Rel Brg", "IO_DATA_AS1117_REAR_DISPLAY_REL_BRG",    30, 90, this, "");
            dataTIOn          = new C_guiIODataItemBoolean("TI ON",             "IO_DATA_AS1117_TI_ON",             30, 120, this, "");
			dataBrgDisplay    = new C_guiIODataItemFloat("Bearing Display",     "IO_DATA_AS1117_BEARING_DISPLAY",   30, 150, this, "");
			dataElevDisplay   = new C_guiIODataItemFloat("Elevation Display",   "IO_DATA_AS1117_ELEVATION_DISPLAY",30,  180, this, "");

			dataRangeCut.setListEntries(strTrueFalse);
			dataBearingCut.setListEntries(strTrueFalse);
			dataPTT.setListEntries(strTrueFalse);
			dataHandlesDown.setListEntries(strTrueFalse);
			dataDataOverlay.setListEntries(strTrueFalse);
			dataTIOn.setListEntries(strTrueFalse);
			dataMagnification.setListEntries(strHighLow);

//			dataTIBlackLevel.ioStatus = C_IODataItem.E_ioStatus.operational;
//			dataRearTrueBrg.ioStatus = C_IODataItem.E_ioStatus.unknown;

			m_inputGroupBox.Controls.Add(dataBearing);
			m_inputGroupBox.Controls.Add(dataRangeCut);
			m_inputGroupBox.Controls.Add(dataBearingCut);
			m_inputGroupBox.Controls.Add(dataPTT);
			m_inputGroupBox.Controls.Add(dataHandlesDown);
			m_inputGroupBox.Controls.Add(dataElevControl);
			m_inputGroupBox.Controls.Add(dataStadControl);
			m_inputGroupBox.Controls.Add(dataMagnification);
			m_inputGroupBox.Controls.Add(dataRearDisplay);
			m_inputGroupBox.Controls.Add(dataModeSelect);
			m_inputGroupBox.Controls.Add(dataDataOverlay);
			m_inputGroupBox.Controls.Add(dataTIBlackLevel);
			m_inputGroupBox.Controls.Add(dataTISensitivity);
			m_inputGroupBox.Controls.Add(dataTIGratIllum);

			m_outputGroupBox.Controls.Add(dataRearStadAngle);
			m_outputGroupBox.Controls.Add(dataRearTrueBrg);
			m_outputGroupBox.Controls.Add(dataRearRelBrg);
			m_outputGroupBox.Controls.Add(dataTIOn);
			m_outputGroupBox.Controls.Add(dataBrgDisplay);
			m_outputGroupBox.Controls.Add(dataElevDisplay);

			this.MdiParent = parentForm;

			//this.WindowState = FormWindowState.Maximized;
		}

		protected override void Dispose(bool disposing)
		{
			//Uncheck the 'io menu' item in the 'display' menu
			//MenuItem ioMenu = this.ptrMain.getMenuItem(C_gui.page.IO_DATA);
			//if(ioMenu != null) ioMenu.Checked = false;

			base.Dispose(disposing);
		}

		public override void updateIncomingData()
		{
			dataBearing.Value = m_InData.m_fBearing.Value;
			dataRangeCut.CurrentValue = m_InData.m_bRangeCut.Value;
			dataBearingCut.CurrentValue = m_InData.m_bBearingCut.Value;
			dataPTT.CurrentValue = m_InData.m_bPushToTalk.Value;
			dataHandlesDown.CurrentValue = m_InData.m_bHandlesDown.Value;
			dataModeSelect.CurrentValue = m_InData.m_iModeSelect.Value;
			dataDataOverlay.CurrentValue = m_InData.m_bDataOverlay.Value;
			dataTIOn.CurrentValue = m_InData.m_bTiOnIndicator.Value;
			dataElevControl.CurrentValue = m_InData.m_fElevation.Value;
			dataStadControl.CurrentValue = m_InData.m_fStadAngle.Value;
			dataMagnification.CurrentValue = m_InData.m_bMagnification.Value;
			dataTIBlackLevel.CurrentValue = m_InData.m_fTiBlackLevel.Value;
			dataTISensitivity.CurrentValue = m_InData.m_fTiSensitivity.Value;
			dataTIGratIllum.CurrentValue = m_InData.m_fTiGratIllum.Value;
			dataRearStadAngle.CurrentValue = m_InData.m_fRearStadAngle.Value;
			dataRearTrueBrg.CurrentValue = m_InData.m_fRearTrueBrg.Value;
			dataRearRelBrg.CurrentValue = m_InData.m_fRearRelBrg.Value;
			dataBrgDisplay.CurrentValue = m_InData.m_fDisplayBrg.Value;
			dataElevDisplay.CurrentValue = m_InData.m_fDisplayElev.Value;

			// Status
			dataBearing.ioStatus = m_InData.m_fBearing.Status;
			dataRangeCut.ioStatus = m_InData.m_bRangeCut.Status;
			dataBearingCut.ioStatus = m_InData.m_bBearingCut.Status;
			dataPTT.ioStatus = m_InData.m_bPushToTalk.Status;
			dataHandlesDown.ioStatus = m_InData.m_bHandlesDown.Status;
			dataModeSelect.ioStatus = m_InData.m_iModeSelect.Status;
			dataDataOverlay.ioStatus = m_InData.m_bDataOverlay.Status;
			dataTIOn.ioStatus = m_InData.m_bTiOnIndicator.Status;
			dataElevControl.ioStatus = m_InData.m_fElevation.Status;
			dataStadControl.ioStatus = m_InData.m_fStadAngle.Status;
			dataMagnification.ioStatus = m_InData.m_bMagnification.Status;
			dataTIBlackLevel.ioStatus = m_InData.m_fTiBlackLevel.Status;
			dataTISensitivity.ioStatus = m_InData.m_fTiSensitivity.Status;
			dataTIGratIllum.ioStatus = m_InData.m_fTiGratIllum.Status;
			dataRearStadAngle.ioStatus = m_InData.m_fRearStadAngle.Status;
			dataRearTrueBrg.ioStatus = m_InData.m_fRearTrueBrg.Status;
			dataRearRelBrg.ioStatus = m_InData.m_fRearRelBrg.Status;
			dataBrgDisplay.ioStatus = m_InData.m_fDisplayBrg.Status;
			dataElevDisplay.ioStatus = m_InData.m_fDisplayElev.Status;

		}

		public override void updateOutgoingData()
		{           
			ptrGui.m_OutIOData.m_fBearing.Value = dataBearing.Value;
			ptrGui.m_OutIOData.m_bRangeCut.Value = dataRangeCut.Value;
			ptrGui.m_OutIOData.m_bBearingCut.Value = dataBearingCut.Value;
			ptrGui.m_OutIOData.m_bPushToTalk.Value = dataPTT.Value;
			ptrGui.m_OutIOData.m_bHandlesDown.Value =dataHandlesDown.Value;
			ptrGui.m_OutIOData.m_fElevation.Value = dataElevControl.Value;
			ptrGui.m_OutIOData.m_fStadAngle.Value = dataStadControl.Value;
			ptrGui.m_OutIOData.m_bMagnification.Value = dataMagnification.Value;
			ptrGui.m_OutIOData.m_fRearRelBrg.Value = dataRearRelBrg.Value;
			ptrGui.m_OutIOData.m_iModeSelect.Value = dataModeSelect.Value;
			ptrGui.m_OutIOData.m_bTiOnIndicator.Value = dataTIOn.Value;
			ptrGui.m_OutIOData.m_bDataOverlay.Value = dataDataOverlay.Value;
			ptrGui.m_OutIOData.m_fTiBlackLevel.Value = dataTIBlackLevel.Value;
			ptrGui.m_OutIOData.m_fTiSensitivity.Value = dataTISensitivity.Value;
			ptrGui.m_OutIOData.m_fTiGratIllum.Value = dataTIGratIllum.Value;
			ptrGui.m_OutIOData.m_fRearStadAngle.Value = dataRearStadAngle.Value;
			ptrGui.m_OutIOData.m_fRearTrueBrg.Value = dataRearTrueBrg.Value;
			ptrGui.m_OutIOData.m_fDisplayBrg.Value = dataBrgDisplay.Value;
			ptrGui.m_OutIOData.m_fDisplayElev.Value = dataElevDisplay.Value;

			//Flags
			ptrGui.m_OutIOData.m_fBearing.Flag = dataBearing.overrideChecked;
			ptrGui.m_OutIOData.m_bRangeCut.Flag = dataRangeCut.overrideChecked;
			ptrGui.m_OutIOData.m_bBearingCut.Flag = dataBearingCut.overrideChecked;
			ptrGui.m_OutIOData.m_bPushToTalk.Flag = dataPTT.overrideChecked;
			ptrGui.m_OutIOData.m_bHandlesDown.Flag = dataHandlesDown.overrideChecked;
			ptrGui.m_OutIOData.m_fElevation.Flag = dataElevControl.overrideChecked;
			ptrGui.m_OutIOData.m_fStadAngle.Flag = dataStadControl.overrideChecked;
			ptrGui.m_OutIOData.m_bMagnification.Flag = dataMagnification.overrideChecked;
			ptrGui.m_OutIOData.m_fRearRelBrg.Flag = dataRearRelBrg.overrideChecked;
			ptrGui.m_OutIOData.m_iModeSelect.Flag = dataModeSelect.overrideChecked;
			ptrGui.m_OutIOData.m_bDataOverlay.Flag = dataBearing.overrideChecked;
			ptrGui.m_OutIOData.m_bTiOnIndicator.Flag = dataTIOn.overrideChecked;
			ptrGui.m_OutIOData.m_bDataOverlay.Flag = dataDataOverlay.overrideChecked;
			ptrGui.m_OutIOData.m_fTiBlackLevel.Flag = dataTIBlackLevel.overrideChecked;
			ptrGui.m_OutIOData.m_fTiSensitivity.Flag = dataTISensitivity.overrideChecked;
			ptrGui.m_OutIOData.m_fTiGratIllum.Flag = dataTIGratIllum.overrideChecked;
			ptrGui.m_OutIOData.m_fRearStadAngle.Flag = dataRearStadAngle.overrideChecked;
			ptrGui.m_OutIOData.m_fRearTrueBrg.Flag = dataRearTrueBrg.overrideChecked;
			ptrGui.m_OutIOData.m_fDisplayBrg.Flag = dataBrgDisplay.overrideChecked;
			ptrGui.m_OutIOData.m_fDisplayElev.Flag = dataElevDisplay.overrideChecked;
		}

		public override void enableOverrides(bool bOnOff)
		{
			dataBearing.enableOverride(bOnOff);
			dataRangeCut.enableOverride(bOnOff);
			dataBearingCut.enableOverride(bOnOff);
			dataPTT.enableOverride(bOnOff);
			dataHandlesDown.enableOverride(bOnOff);
			dataModeSelect.enableOverride(bOnOff);
			dataDataOverlay.enableOverride(bOnOff);
			dataElevControl.enableOverride(bOnOff);
			dataStadControl.enableOverride(bOnOff);
			dataMagnification.enableOverride(bOnOff);
			dataTIBlackLevel.enableOverride(bOnOff);
			dataTISensitivity.enableOverride(bOnOff);
			dataTIGratIllum.enableOverride(bOnOff);
		}
	}
}
