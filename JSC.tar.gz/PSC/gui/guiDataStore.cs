//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiDataStore.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.IO;
using System.Windows.Forms;


namespace PSCGenericBuild
{
	/// <summary>
	/// Summary description for Network.
	/// </summary>
	/// 

	// ---------------------
	// Data Store Item BYTE
	// ---------------------
	public class C_DataStoreItemByte
	{

		private byte	m_value;
		private bool	m_flag;
		private int		m_status;

		public byte Value
		{
			get
			{
				return m_value;
			}
			set
			{
				m_value = value;
			}
		}

		public bool Flag
		{
			get
			{
				return m_flag;
			}
			set
			{
				m_flag = value;
			}
		}

		public int Status
		{
			get
			{
				return m_status;
			}
			set
			{
				m_status = value;
			}
		}

		public C_DataStoreItemByte()
		{
		}	
	}

	// ----------------------
	// Data Store Item FLOAT
	// ----------------------
	public class C_DataStoreItemFloat
	{

		private float	m_value;
		private bool	m_flag;
		private int		m_status;


		public float Value
		{
			get
			{
				return m_value;
			}
			set
			{
				m_value = value;
			}
		}

		public bool Flag
		{
			get
			{
				return m_flag;
			}
			set
			{
				m_flag = value;
			}
		}

		public int Status
		{
			get
			{
				return m_status;
			}
			set
			{
				m_status = value;
			}
		}

		public C_DataStoreItemFloat()
		{
		}	
	}

	// ----------------------
	// Data Store Item SHORT
	// ----------------------
	public class C_DataStoreItemShort
	{

		private short	m_value;
		private bool	m_flag;
		private int		m_status;


		public short Value
		{
			get
			{
				return m_value;
			}
			set
			{
				m_value = value;
			}
		}

		public bool Flag
		{
			get
			{
				return m_flag;
			}
			set
			{
				m_flag = value;
			}
		}

		public int Status
		{
			get
			{
				return m_status;
			}
			set
			{
				m_status = value;
			}
		}

		public C_DataStoreItemShort()
		{
		}	
	}

	// ----------------------
	// Data Store Item LONG
	// ----------------------
	public class C_DataStoreItemLong
	{

		private long	m_value;
		private bool	m_flag;
		private int		m_status;


		public long Value
		{
			get
			{
				return m_value;
			}
			set
			{
				m_value = value;
			}
		}

		public bool Flag
		{
			get
			{
				return m_flag;
			}
			set
			{
				m_flag = value;
			}
		}

		public int Status
		{
			get
			{
				return m_status;
			}
			set
			{
				m_status = value;
			}
		}

		public C_DataStoreItemLong()
		{
		}	
	}


	// ---------------------
	// Data Store Item INT
	// ---------------------
	public class C_DataStoreItemInt
	{

		private int		m_value;
		private bool	m_flag;
		private int		m_status;


		public int Value
		{
			get
			{
				return m_value;
			}
			set
			{
				m_value = value;
			}
		}

		public bool Flag
		{
			get
			{
				return m_flag;
			}
			set
			{
				m_flag = value;
			}
		}

		public int Status
		{
			get
			{
				return m_status;
			}
			set
			{
				m_status = value;
			}
		}

		public C_DataStoreItemInt()
		{
		}	
	}

	// -----------------------
	// Data Store Item DOUBLE
	// -----------------------
	public class C_DataStoreItemDouble
	{

		private double	m_value;
		private bool	m_flag;
		private int		m_status;


		public double Value
		{
			get
			{
				return m_value;
			}
			set
			{
				m_value = value;
			}
		}

		public bool Flag
		{
			get
			{
				return m_flag;
			}
			set
			{
				m_flag = value;
			}
		}

		public int Status
		{
			get
			{
				return m_status;
			}
			set
			{
				m_status = value;
			}
		}

		public C_DataStoreItemDouble()
		{
		}	
	}

	// ---------------------
	// Data Store Item BOOL
	// ---------------------
	public class C_DataStoreItemBool
	{

		private bool	m_value;
		private bool	m_flag;
		private int		m_status;


		public bool Value
		{
			get
			{
				return m_value;
			}
			set
			{
				m_value = value;
			}
		}

		public bool Flag
		{
			get
			{
				return m_flag;
			}
			set
			{
				m_flag = value;
			}
		}

		public int Status
		{
			get
			{
				return m_status;
			}
			set
			{
				m_status = value;
			}
		}

		public C_DataStoreItemBool()
		{
		}	
	}

	// -----------------------
	// Data Store Item STRING
	// -----------------------
	public class C_DataStoreItemString
	{

		private string	m_value;
		private bool	m_flag;
		private int		m_status;


		public string Value
		{
			get
			{
				return m_value;
			}
			set
			{
				m_value = value;
			}
		}

		public bool Flag
		{
			get
			{
				return m_flag;
			}
			set
			{
				m_flag = value;
			}
		}

		public int Status
		{
			get
			{
				return m_status;
			}
			set
			{
				m_status = value;
			}
		}

		public C_DataStoreItemString()
		{
		}	
	}

	// ---------------------------
	// Data Store Item BYTE ARRAY
	// ---------------------------
	public class C_DataStoreItemByteArray
	{

		private byte []	m_value;
		private bool	m_flag;
		private int		m_status;


		public byte [] Value
		{
			get
			{
				return m_value;
			}
			set
			{
				m_value = value;
			}
		}

		public bool Flag
		{
			get
			{
				return m_flag;
			}
			set
			{
				m_flag = value;
			}
		}

		public string Text
		{
			get
			{
				char [] byteStream;
				if(m_value != null)
				{
					byteStream = new char[m_value.Length];  

					for(int i = 0 ; i < m_value.Length; i++)
					{
						byteStream[i] = (char) m_value[i];
					}
				
					return byteStream.ToString();

				}

				return null;
			}
			set
			{
				if(m_value != null)
				{
					for(int i=0; i < value.Length; i++)
					{
						if( i < m_value.Length)
						{
							m_value[i] = (byte) value[i];
						}
					}
				}
			}
		}

		public int Status
		{
			get
			{
				return m_status;
			}
			set
			{
				m_status = value;
			}
		}

		//Default Constructor
		public C_DataStoreItemByteArray()
		{
		}	

		public C_DataStoreItemByteArray(uint iLength)
		{
			m_value = new byte[iLength];
		}
	}


	//-----------------------------------------------------------------------
	//PIP Data
	//-----------------------------------------------------------------------
	public class PIPExerciseData
	{
		public C_DataStoreItemByte bRunMode;
		public C_DataStoreItemByte hours;
		public C_DataStoreItemByte minutes;
		public C_DataStoreItemByte seconds;
		public C_DataStoreItemByte day;
		public C_DataStoreItemByte month;
		public C_DataStoreItemByte year;

		public PIPExerciseData()
		{
			bRunMode = new C_DataStoreItemByte();
			hours = new C_DataStoreItemByte();
			minutes = new C_DataStoreItemByte();
			seconds = new C_DataStoreItemByte();
			day = new C_DataStoreItemByte();
			month = new C_DataStoreItemByte();
			year = new C_DataStoreItemByte();
		}
	}

	public class PIPPeriscopeData
	{
		//public C_DataStoreItemByte bFlags;

		public C_DataStoreItemBool bInstructor;
		public C_DataStoreItemBool bMast;
		public C_DataStoreItemBool bTiHotControl;
		public C_DataStoreItemBool bMagnification;

		public C_DataStoreItemByte  bDrainDownTime;
		public C_DataStoreItemByte  bLLTVGain;
		public C_DataStoreItemByte  bTIGain;
		public C_DataStoreItemFloat fRelBrg;
		public C_DataStoreItemFloat fElevation;
		

		public PIPPeriscopeData()
		{
			//			bFlags = new C_DataStoreItemByte();
			bInstructor = new C_DataStoreItemBool(); 
			bMast = new C_DataStoreItemBool();
			bTiHotControl = new C_DataStoreItemBool();
			bMagnification = new C_DataStoreItemBool();

			bDrainDownTime = new C_DataStoreItemByte();
			bLLTVGain = new C_DataStoreItemByte();
			bTIGain = new C_DataStoreItemByte();
			fRelBrg = new C_DataStoreItemFloat();
			fElevation = new C_DataStoreItemFloat();
		}
	}

	public class PIPEnvironmentData
	{
		//public C_DataStoreItemByte  bFlags;

		public C_DataStoreItemBool  bMoon;
		public C_DataStoreItemBool  bCoastLights;
		public C_DataStoreItemBool  bIceEdge;
		public C_DataStoreItemBool  bRemoteSun;
		public C_DataStoreItemByte  bVisibility;
		public C_DataStoreItemByte  bCoastline;
		public C_DataStoreItemByte  bSeaState;
		public C_DataStoreItemFloat fMoonBearing;
		public C_DataStoreItemFloat fMoonElevation;
		public C_DataStoreItemFloat fVisualRange;
		public C_DataStoreItemFloat fUWVisualRange;
		public C_DataStoreItemFloat fTIRange;
		public C_DataStoreItemFloat fWindSpeed;
		public C_DataStoreItemFloat fWindHeading;
		public C_DataStoreItemFloat fIceLat;
		public C_DataStoreItemFloat fIceLong;
		public C_DataStoreItemFloat fIceOrientation;
		public C_DataStoreItemFloat fSunBearing;
		public C_DataStoreItemFloat fSunElevation;

		public PIPEnvironmentData()
		{
			bMoon = new C_DataStoreItemBool();
			bCoastLights = new C_DataStoreItemBool();
			bIceEdge = new C_DataStoreItemBool();
			bRemoteSun = new C_DataStoreItemBool();

			bVisibility = new C_DataStoreItemByte();
			bCoastline = new C_DataStoreItemByte();
			bSeaState = new C_DataStoreItemByte();
			fMoonBearing = new C_DataStoreItemFloat();
			fMoonElevation = new C_DataStoreItemFloat();
			fVisualRange = new C_DataStoreItemFloat();
			fUWVisualRange = new C_DataStoreItemFloat();
			fTIRange = new C_DataStoreItemFloat();
			fWindSpeed = new C_DataStoreItemFloat();
			fWindHeading = new C_DataStoreItemFloat();
			fIceLat = new C_DataStoreItemFloat();
			fIceLong = new C_DataStoreItemFloat();
			fIceOrientation = new C_DataStoreItemFloat();
			fSunBearing = new C_DataStoreItemFloat();
			fSunElevation = new C_DataStoreItemFloat();
		}
	}

	public class PIPOwnboatData
	{
		public C_DataStoreItemDouble dfLatitude;
		public C_DataStoreItemDouble dfLongitude;
		public C_DataStoreItemFloat  fDepth;
		public C_DataStoreItemFloat  fClimbRate;
		public C_DataStoreItemFloat  fTurnRate;
		public C_DataStoreItemFloat  fPitch;
		public C_DataStoreItemFloat  fHeading;
		public C_DataStoreItemFloat  fDriftCourse;
		public C_DataStoreItemFloat  fSpeed;
		public C_DataStoreItemFloat  fDriftSpeed;

		public C_DataStoreItemBool  bWhipAerial;
		public C_DataStoreItemBool  bEmLight;
		public C_DataStoreItemBool  bDieselSmoke;

		public C_DataStoreItemByte bFlags;
		public C_DataStoreItemByte bRESM;
		public C_DataStoreItemByte bWTComms;
		public C_DataStoreItemByte bCESM;
		public C_DataStoreItemByte bAttackPeriscope;
		public C_DataStoreItemByte bRadar;
		public C_DataStoreItemByte bSnortInduction;
		public C_DataStoreItemByte bSnortExhaust;
		public C_DataStoreItemByte bType;		

		public PIPOwnboatData()
		{
			dfLatitude = new C_DataStoreItemDouble();
			dfLongitude  = new C_DataStoreItemDouble();
			fDepth  = new C_DataStoreItemFloat();
			fClimbRate  = new C_DataStoreItemFloat();
			fTurnRate  = new C_DataStoreItemFloat();
			fPitch  = new C_DataStoreItemFloat();
			fHeading  = new C_DataStoreItemFloat();
			fDriftCourse  = new C_DataStoreItemFloat();
			fSpeed  = new C_DataStoreItemFloat();
			fDriftSpeed  = new C_DataStoreItemFloat();

			bWhipAerial = new C_DataStoreItemBool();
			bEmLight = new C_DataStoreItemBool();
			bDieselSmoke = new C_DataStoreItemBool();

			bFlags  = new C_DataStoreItemByte();
			bRESM  = new C_DataStoreItemByte();
			bWTComms  = new C_DataStoreItemByte();
			bCESM  = new C_DataStoreItemByte();
			bAttackPeriscope  = new C_DataStoreItemByte();
			bRadar  = new C_DataStoreItemByte();
			bSnortInduction  = new C_DataStoreItemByte();
			bSnortExhaust  = new C_DataStoreItemByte();
			bType  = new C_DataStoreItemByte();	
		}
	}

	public class PIPTargetData
	{
		public C_DataStoreItemByte  bFlags;
		public C_DataStoreItemInt   iTargetNum;
		public C_DataStoreItemInt   iSlotID;
		public C_DataStoreItemFloat fX;
		public C_DataStoreItemFloat fY;
		public C_DataStoreItemFloat fDepth;
		public C_DataStoreItemFloat fClimbRate;
		public C_DataStoreItemFloat fTurnRate;
		public C_DataStoreItemFloat fPitch;
		public C_DataStoreItemFloat fHeading;
		public C_DataStoreItemFloat fDriftCourse;
		public C_DataStoreItemFloat fSpeed;
		public C_DataStoreItemFloat fDriftSpeed;

		public C_DataStoreItemBool bVisible;	
		public C_DataStoreItemBool bExplosion;	
		public C_DataStoreItemBool bMissileExplosion;	
		public C_DataStoreItemBool bTorpedoExplosion;	
		public C_DataStoreItemBool bSinking;	
		public C_DataStoreItemBool bNavLights;	
		public C_DataStoreItemBool bSonarDunking;
		public C_DataStoreItemBool bTLAMLaunch;	

		public C_DataStoreItemByte bDunkingSonar;
		public C_DataStoreItemByte bLightConfig;	
		public C_DataStoreItemByte bSpotLightConfig;
		public C_DataStoreItemBool bDieselSmoke;	
		public C_DataStoreItemBool bMissileLaunch;

		public PIPTargetData()
		{
			bFlags = new C_DataStoreItemByte();
   
			iTargetNum = new C_DataStoreItemInt();
			iSlotID = new C_DataStoreItemInt();
			fX = new C_DataStoreItemFloat();
			fY = new C_DataStoreItemFloat();
			fDepth = new C_DataStoreItemFloat();
			fClimbRate = new C_DataStoreItemFloat();
			fTurnRate = new C_DataStoreItemFloat();
			fPitch = new C_DataStoreItemFloat();
			fHeading = new C_DataStoreItemFloat();
			fDriftCourse = new C_DataStoreItemFloat();
			fSpeed = new C_DataStoreItemFloat();
			fDriftSpeed = new C_DataStoreItemFloat();

			bVisible = new C_DataStoreItemBool();	
			bExplosion = new C_DataStoreItemBool();	
			bMissileExplosion = new C_DataStoreItemBool();	
			bTorpedoExplosion = new C_DataStoreItemBool();	
			bSinking = new C_DataStoreItemBool();	
			bSonarDunking = new C_DataStoreItemBool();
			bNavLights = new C_DataStoreItemBool();
			bTLAMLaunch = new C_DataStoreItemBool();	
			bDunkingSonar = new C_DataStoreItemByte();
			bLightConfig = new C_DataStoreItemByte();
			bSpotLightConfig = new C_DataStoreItemByte();
			bDieselSmoke = new C_DataStoreItemBool();	
			bMissileLaunch = new C_DataStoreItemBool();
		}
	}

	public class PIPPolyniaData
	{
		public C_DataStoreItemInt   iPolyniaID;
		public C_DataStoreItemByte  bIceField;
		public C_DataStoreItemFloat fX;
		public C_DataStoreItemFloat fY;
		public C_DataStoreItemFloat fZ;
		public C_DataStoreItemFloat fOrientation;

		public PIPPolyniaData()
		{
			iPolyniaID = new C_DataStoreItemInt();
			bIceField = new C_DataStoreItemByte();
			fX = new C_DataStoreItemFloat();
			fY = new C_DataStoreItemFloat();
			fZ = new C_DataStoreItemFloat();
			fOrientation = new C_DataStoreItemFloat();
		}
	}

	public class PIPReturnData
	{
		public C_DataStoreItemBool bMastPosition;
		public C_DataStoreItemBool bTIHotControl;
		public C_DataStoreItemBool bMagnification;

		//public C_DataStoreItemByte  bStatusFlags;
		public C_DataStoreItemByte  bLLTVGain;
		public C_DataStoreItemByte  bTIGain;

		//WSDB/TWSH Message Data
		public C_DataStoreItemFloat fPeriTrueBrg;
		public C_DataStoreItemFloat fTargetTrueBrg;
		public C_DataStoreItemBool  fTargetTrueBrgCut;
		public C_DataStoreItemFloat fTargetRange;
		public C_DataStoreItemBool  fTargetRangeCut;
		public C_DataStoreItemFloat fElapsedTime;
		public C_DataStoreItemBool  fElapsedTimeCut;

		public C_DataStoreItemFloat fPeriRelBrg;
		public C_DataStoreItemFloat fElevation;
		public C_DataStoreItemFloat fSunBearing;
		public C_DataStoreItemFloat fSunElevation;

		public C_DataStoreItemInt   iPolynias;

		public PIPPolyniaData [] polyniaData;

		public C_DataStoreItemInt       iPSCErrorNumber;
		public C_DataStoreItemString	strPSCErrorString;


		public PIPReturnData()
		{

			bMastPosition = new C_DataStoreItemBool();
			bTIHotControl = new C_DataStoreItemBool();
			bMagnification = new C_DataStoreItemBool();

			bLLTVGain  = new C_DataStoreItemByte();
			bTIGain  = new C_DataStoreItemByte();
			fPeriRelBrg  = new C_DataStoreItemFloat();
			fElevation  = new C_DataStoreItemFloat();
			fSunBearing  = new C_DataStoreItemFloat();
			fSunElevation  = new C_DataStoreItemFloat();
			iPolynias = new C_DataStoreItemInt();

			polyniaData = new PIPPolyniaData[SIMControl.NUM_POLYNIA_TARGETS];

			for(int i=0; i < SIMControl.NUM_POLYNIA_TARGETS; i++)
			{
				polyniaData[i] = new PIPPolyniaData();
			}

			//
			//TWSH Message Data.
			//
			fPeriTrueBrg = new C_DataStoreItemFloat();
			fTargetTrueBrg  = new C_DataStoreItemFloat();
			fTargetTrueBrgCut  = new C_DataStoreItemBool();
			fTargetRange  = new C_DataStoreItemFloat();
			fTargetRangeCut  = new C_DataStoreItemBool();
			fElapsedTime  = new C_DataStoreItemFloat();
			fElapsedTimeCut  = new C_DataStoreItemBool();

			iPSCErrorNumber = new C_DataStoreItemInt();
			strPSCErrorString = new C_DataStoreItemString();
		}
	}

	public class NetworkStatusData
	{
		public int		m_Bytes;
		public int		m_MessageCount;
		public float	m_AverageTime;
		//public int		m_ArrayIndex;
		//public long[]	m_ArrayTimes;

		public NetworkStatusData()
		{

		}
	}

	public class PIP_Data
	{
		public PIPExerciseData      oExercise;
		public PIPPeriscopeData     oPeriscope;
		public PIPEnvironmentData   oEnvironment;
		public PIPOwnboatData       oOwnboat;
		public PIPTargetData     [] oTarget;
		public PIPReturnData        oReturn;
		public NetworkStatusData    oNetworkStatus;        

		public PIP_Data()
		{
			oExercise = new PIPExerciseData();
			oPeriscope = new PIPPeriscopeData();
			oEnvironment = new PIPEnvironmentData();
			oOwnboat = new PIPOwnboatData();
			oTarget  = new PIPTargetData[SIMControl.NUM_PERI_TARGETS];

			for(int i = 0; i < oTarget.Length; i++)
			{
				oTarget[i] = new PIPTargetData();
			}

			oReturn  = new PIPReturnData();

			oNetworkStatus = new NetworkStatusData();
		}
	}

	//-----------------------------------------------------------------------
	//PIG Data 
	//-----------------------------------------------------------------------

	public class PIGExerciseData
	{
		//		public int  iSystemID;
		//		public int  iRunMode;
		//
		//		public bool  iSystemIDFlag;
		//		public bool  iRunModeFlag;

		public C_DataStoreItemInt iSystemID;
		public C_DataStoreItemInt iRunMode;

		public PIGExerciseData()
		{
			iSystemID = new C_DataStoreItemInt();
			iRunMode  = new C_DataStoreItemInt();
		}

	}

	public class PIGEnvironmentData
	{
		//public C_DataStoreItemInt iFlags;
		public C_DataStoreItemBool bMoon;
		public C_DataStoreItemBool bCoastLights;
		public C_DataStoreItemBool bIceEdge;
		public C_DataStoreItemBool bRemoteSun;

		public C_DataStoreItemByte bHours;

		public C_DataStoreItemByte bMinutes;
		public C_DataStoreItemByte bSeconds;
		public C_DataStoreItemByte bDay;
		public C_DataStoreItemByte bMonth;
		public C_DataStoreItemByte bYear;
		public C_DataStoreItemByte bWeather;
		public C_DataStoreItemByte bCoastline;
		public C_DataStoreItemByte bSeaState;
		public C_DataStoreItemFloat fVisibleRange;
		public C_DataStoreItemFloat fThermalRange;
		public C_DataStoreItemFloat fUnderwaterVis;
		public C_DataStoreItemFloat fWindSpeed;
		public C_DataStoreItemFloat fWindDirection;
		public C_DataStoreItemFloat fMoonBearing;
		public C_DataStoreItemFloat fMoonAltitude;		
		public C_DataStoreItemFloat fSunBearing;
		public C_DataStoreItemFloat fSunAltitude;

		public C_DataStoreItemFloat fIceEdgeLat;
		public C_DataStoreItemFloat fIceEdgeLong;
		public C_DataStoreItemFloat fIceFloe;

		public PIGEnvironmentData()
		{
			//iFlags = new C_DataStoreItemInt();
			bHours = new C_DataStoreItemByte();

			bMoon          = new C_DataStoreItemBool();
			bCoastLights   = new C_DataStoreItemBool();
			bIceEdge       = new C_DataStoreItemBool();
			bRemoteSun     = new C_DataStoreItemBool();

			bMinutes       = new C_DataStoreItemByte();
			bSeconds       = new C_DataStoreItemByte();
			bDay           = new C_DataStoreItemByte();
			bMonth         = new C_DataStoreItemByte();
			bYear          = new C_DataStoreItemByte();
			bWeather       = new C_DataStoreItemByte();
			bCoastline     = new C_DataStoreItemByte();
			bSeaState      = new C_DataStoreItemByte();
			fVisibleRange  = new C_DataStoreItemFloat();
			fThermalRange  = new C_DataStoreItemFloat();
			fUnderwaterVis = new C_DataStoreItemFloat();
			fWindSpeed     = new C_DataStoreItemFloat();
			fWindDirection = new C_DataStoreItemFloat();
			fMoonBearing   = new C_DataStoreItemFloat();
			fMoonAltitude  = new C_DataStoreItemFloat();		
			fSunBearing    = new C_DataStoreItemFloat();
			fSunAltitude   = new C_DataStoreItemFloat();

			fIceEdgeLat    = new C_DataStoreItemFloat();
			fIceEdgeLong   = new C_DataStoreItemFloat();
			fIceFloe       = new C_DataStoreItemFloat();
		}

	}

	public class PIGOwnshipData
	{
		public C_DataStoreItemByte  bType;
		public C_DataStoreItemByte  bSmoke;
		//		public C_DataStoreItem  bSpare1;
		//		public C_DataStoreItem  bSpare2;
		public C_DataStoreItemFloat fLatitude;
		public C_DataStoreItemFloat fLogitude;
		public C_DataStoreItemFloat fX;
		public C_DataStoreItemFloat fY;
		public C_DataStoreItemFloat fDepth;
		public C_DataStoreItemFloat fHeading;
		public C_DataStoreItemFloat fRoll;
		public C_DataStoreItemFloat fPitch;
		public C_DataStoreItemFloat fSpeed;

		public C_DataStoreItemFloat [] mast;           /*10*/

		public PIGOwnshipData()
		{
			bType     = new C_DataStoreItemByte();
			bSmoke    = new C_DataStoreItemByte();
			//			bSpare1   = new C_DataStoreItem();
			//			bSpare2   = new C_DataStoreItem();
			fLatitude = new C_DataStoreItemFloat();
			fLogitude = new C_DataStoreItemFloat();
			fX        = new C_DataStoreItemFloat();
			fY        = new C_DataStoreItemFloat();
			fDepth    = new C_DataStoreItemFloat();
			fHeading  = new C_DataStoreItemFloat();
			fRoll     = new C_DataStoreItemFloat();
			fPitch    = new C_DataStoreItemFloat();
			fSpeed    = new C_DataStoreItemFloat();
			mast      = new C_DataStoreItemFloat[10];

			for(int i = 0; i < 10; i++)
			{
				mast[i] = new C_DataStoreItemFloat();
			}
		}
	}

	public class PIGPeriscopeData
	{
		public C_DataStoreItemByte  bSensorType;
		public C_DataStoreItemByte  bMagnification;
		public C_DataStoreItemByte  bSensorGain;
		public C_DataStoreItemByte  bSensorContrast;
		public C_DataStoreItemByte  bGraticuleInt;
		public C_DataStoreItemByte  bDraindownTime;
		public C_DataStoreItemFloat  fRelativeBearing;
		public C_DataStoreItemFloat  fElevation;
		public C_DataStoreItemFloat  fStadElev;

		public PIGPeriscopeData()
		{
			bSensorType       = new C_DataStoreItemByte();
			bMagnification    = new C_DataStoreItemByte();
			bSensorGain       = new C_DataStoreItemByte();
			bSensorContrast   = new C_DataStoreItemByte();
			bGraticuleInt     = new C_DataStoreItemByte();
			bDraindownTime    = new C_DataStoreItemByte();
			fRelativeBearing  = new C_DataStoreItemFloat();
			fElevation        = new C_DataStoreItemFloat();
			fStadElev         = new C_DataStoreItemFloat();
		}
	}

	public class PIGTargetData
	{
		public C_DataStoreItemShort sFlags;       
		public C_DataStoreItemShort sModelID;
		public C_DataStoreItemShort sTargetNum;
		public C_DataStoreItemByte bSpotlightConfig;  
		public C_DataStoreItemByte bLightConfig;
		public C_DataStoreItemFloat fX;           
		public C_DataStoreItemFloat fY;
		public C_DataStoreItemFloat fHeight;
		public C_DataStoreItemFloat fHeading;
		public C_DataStoreItemFloat fRoll;
		public C_DataStoreItemFloat fPitch;
		public C_DataStoreItemFloat fSpeed;
		public C_DataStoreItemFloat fAcceleration;

		public C_DataStoreItemBool bVisible;     
		public C_DataStoreItemBool bNavLights;     
		public C_DataStoreItemBool bMissileImpact;     
		public C_DataStoreItemBool bTorpedoImpact;     
		public C_DataStoreItemBool bSinking;     
		public C_DataStoreItemBool bSonarDunking;     
		public C_DataStoreItemBool bTLAMLaunch;     
		public C_DataStoreItemBool bExplosion ;     
		public C_DataStoreItemBool bDieselSmoke;     
		public C_DataStoreItemBool bMissileLaunch; 

		public PIGTargetData()
		{
			sFlags        = new C_DataStoreItemShort(); 
			sModelID      = new C_DataStoreItemShort();
			sTargetNum    = new C_DataStoreItemShort();
			bSpotlightConfig = new C_DataStoreItemByte(); 
			bLightConfig  = new C_DataStoreItemByte();
			fX            = new C_DataStoreItemFloat(); 
			fY            = new C_DataStoreItemFloat();
			fHeight       = new C_DataStoreItemFloat();
			fHeading      = new C_DataStoreItemFloat();
			fRoll         = new C_DataStoreItemFloat();
			fPitch        = new C_DataStoreItemFloat();
			fSpeed        = new C_DataStoreItemFloat();
			fAcceleration = new C_DataStoreItemFloat();

			bVisible       = new C_DataStoreItemBool();     
			bNavLights     = new C_DataStoreItemBool();     
			bMissileImpact = new C_DataStoreItemBool();     
			bTorpedoImpact = new C_DataStoreItemBool();     
			bSinking       = new C_DataStoreItemBool();     
			bSonarDunking  = new C_DataStoreItemBool();     
			bTLAMLaunch    = new C_DataStoreItemBool();     
			bExplosion     = new C_DataStoreItemBool();     
			bDieselSmoke   = new C_DataStoreItemBool();  
			bMissileLaunch = new C_DataStoreItemBool();
		}
	}

	public class PIGReturnData
	{
		public C_DataStoreItemLong lProcStat;       
		public C_DataStoreItemLong lModelStat;
		public C_DataStoreItemLong lSonarContacts;
		public PIGReturnSonarData [] SonarData;

		public PIGReturnData()
		{
			lProcStat = new C_DataStoreItemLong(); 
			lModelStat = new C_DataStoreItemLong();
			lSonarContacts = new C_DataStoreItemLong();
			SonarData = new PIGReturnSonarData[SIMControl.NUM_POLYNIA_TARGETS];          

			for(int i = 0; i < SIMControl.NUM_POLYNIA_TARGETS; i++)
			{
				SonarData[i] = new PIGReturnSonarData();
			}
		}
	}

	public class PIGReturnSonarData
	{
		public C_DataStoreItemLong identity;
		public C_DataStoreItemFloat x_offset;
		public C_DataStoreItemFloat y_offset;
		public C_DataStoreItemFloat z_offset;
		public C_DataStoreItemFloat orientation;
		public C_DataStoreItemLong slotNumber;

		public PIGReturnSonarData()
		{
			identity = new C_DataStoreItemLong();
			x_offset = new C_DataStoreItemFloat();
			y_offset = new C_DataStoreItemFloat();
			z_offset = new C_DataStoreItemFloat();
			orientation = new C_DataStoreItemFloat();
			slotNumber = new C_DataStoreItemLong();
		}
	}

	public class IO_Data
	{
		public C_DataStoreItemFloat	m_fBearing;
		public C_DataStoreItemFloat	m_fElevation;
		public C_DataStoreItemFloat	m_fStadAngle;
		public C_DataStoreItemBool	m_bMagnification;
		public C_DataStoreItemFloat	m_fTiBlackLevel;
		public C_DataStoreItemFloat	m_fTiSensitivity;
		public C_DataStoreItemFloat	m_fTiGratIllum;

		public C_DataStoreItemFloat	m_fRearStadAngle;
		public C_DataStoreItemFloat	m_fRearTrueBrg;
		public C_DataStoreItemFloat	m_fRearRelBrg;

		public C_DataStoreItemFloat	m_fDisplayBrg;
		public C_DataStoreItemFloat	m_fDisplayElev;
		public C_DataStoreItemFloat	m_fDisplayTar;
		public C_DataStoreItemFloat	m_fBeckmanTrue;
		public C_DataStoreItemFloat	m_fBeckmanRel;


		public C_DataStoreItemBool	m_bHandlesDown;
		public C_DataStoreItemBool	m_bRangeCut;
		public C_DataStoreItemBool	m_bBearingCut;
		public C_DataStoreItemBool	m_bPushToTalk;

		public C_DataStoreItemInt	m_iModeSelect;
		public C_DataStoreItemBool	m_bDataOverlay;
		public C_DataStoreItemBool	m_bTiOnIndicator;
		public C_DataStoreItemInt	m_bTarHeight;

        public int m_status;

		public IO_Data()
		{
			m_fBearing = new C_DataStoreItemFloat();
			m_fElevation = new C_DataStoreItemFloat();
			m_fStadAngle = new C_DataStoreItemFloat();
			m_bMagnification = new C_DataStoreItemBool();
			m_fTiBlackLevel = new C_DataStoreItemFloat();
			m_fTiSensitivity = new C_DataStoreItemFloat();
			m_fTiGratIllum = new C_DataStoreItemFloat();

			m_fRearStadAngle = new C_DataStoreItemFloat();
			m_fRearTrueBrg = new C_DataStoreItemFloat();
			m_fRearRelBrg = new C_DataStoreItemFloat();

			m_fDisplayBrg = new C_DataStoreItemFloat();
			m_fDisplayElev = new C_DataStoreItemFloat();
			m_fDisplayTar = new C_DataStoreItemFloat();
			m_fBeckmanTrue = new C_DataStoreItemFloat();
			m_fBeckmanRel = new C_DataStoreItemFloat();

			m_bHandlesDown = new C_DataStoreItemBool();
			m_bRangeCut = new C_DataStoreItemBool();
			m_bBearingCut = new C_DataStoreItemBool();
			m_bPushToTalk = new C_DataStoreItemBool();

			m_iModeSelect = new C_DataStoreItemInt();
			m_bDataOverlay = new C_DataStoreItemBool();
			m_bTiOnIndicator = new C_DataStoreItemBool();
			m_bTarHeight = new C_DataStoreItemInt();

			m_status = 0;
		}	
	}

	public class PIG_Data
	{
		public PIGExerciseData     oPIGExercise;
		public PIGEnvironmentData  oPIGEnvironment;
		public PIGPeriscopeData    oPIGPeriscope;
		public PIGOwnshipData      oPIGOwnship;
		public PIGTargetData[]     oPIGTarget;

		public PIGReturnData       oPIGReturn;
		public NetworkStatusData   oNetworkStatus;        

		public PIG_Data()
		{

			oPIGExercise     = new PIGExerciseData();
			oPIGEnvironment  = new PIGEnvironmentData();
			oPIGPeriscope    = new PIGPeriscopeData();
			oPIGOwnship      = new PIGOwnshipData();
			oPIGTarget       = new PIGTargetData[SIMControl.NUM_PERI_TARGETS];

			oPIGReturn       = new PIGReturnData();

			for(int i = 0 ; i < SIMControl.NUM_PERI_TARGETS ; i++)
			{
				oPIGTarget[i] = new PIGTargetData();
			}

			oNetworkStatus = new NetworkStatusData();        
		}
	}

	//
	//Error Log
	//
	public struct ErrorLogMessage
	{
		public String	m_ErrorTime;
		public String	m_ErrorType;
		public String	m_ErrorSource;
	}

	public class ErrorLogData
	{
		public bool m_ErrorLogClear;
		public int	m_ErrorLogIndex;
		public ErrorLogMessage [] m_ErrorLog;
	
		public ErrorLogData()
		{
			m_ErrorLog = new ErrorLogMessage[SIMControl.SIM_ERRORLOG_SIZE];

			for(int i=0; i < SIMControl.SIM_ERRORLOG_SIZE; i++)
			{
				m_ErrorLog[i] = new ErrorLogMessage();
			}
		}
	}
}

