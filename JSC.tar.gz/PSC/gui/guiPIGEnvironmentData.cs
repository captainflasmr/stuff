//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiPIGEnvironmentData.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Drawing;

namespace PSCGenericBuild
{

	//-----------------------------------------------------------------------
	//The PIG Environment Data Page Class.
	//-----------------------------------------------------------------------
	public class C_guiPIGEnvironmentData : C_guiTemplatePage
	{

		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		protected String     [] strDescription;
		public PIGEnvironmentData m_InData;

		public PIGEnvironmentData oPIGEnvironmentPacket;

		//-----------------------------------------------------------------------
		//Class Properties
		//-----------------------------------------------------------------------
		public const int MOON_ON      = 0x0001;
		public const int COAST_LIGHTS = 0x0002;
		public const int ICE_EDGE     = 0x0004;
		public const int REMOTE_SUN   = 0x0008;

		protected C_guiDataItemBoolean  dataMoon;
		protected C_guiDataItemBoolean  dataCoastLights;
		protected C_guiDataItemBoolean  dataIceEdge;
		protected C_guiDataItemBoolean  dataSun;
		protected C_guiDataItemByte  dataHours;
		protected C_guiDataItemByte  dataMinutes;
		protected C_guiDataItemByte  dataSeconds;
		protected C_guiDataItemByte  dataDay;
		protected C_guiDataItemByte  dataMonth;
		protected C_guiDataItemByte  dataYear;
		protected C_guiDataItemByte  dataWeather;
		protected C_guiDataItemByte  dataCoastline;

		protected C_guiDataItemByte  dataSeaState;
		protected C_guiDataItemFloat dataVisibleRange;
		protected C_guiDataItemFloat dataIRVisibleRange;
		protected C_guiDataItemFloat dataUWVisibleRange;
		protected C_guiDataItemFloat dataWindSpeed;
		protected C_guiDataItemFloat dataWindDir;
		protected C_guiDataItemFloat dataMoonBrg;
		protected C_guiDataItemFloat dataMoonElev;
		protected C_guiDataItemFloat dataSunBrg;
		protected C_guiDataItemFloat dataSunElev;
		protected C_guiDataItemFloat dataIceEdgeLat;
		protected C_guiDataItemFloat dataIceEdgeLon;
		protected C_guiDataItemFloat dataIceEdgeOrient;


		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		/************************************************************************
		  FUNCTION      : C_guiEnvironmentData()
		  DESCRIPTION   : The Constructor for Environment Data Page. 
		  PARAMETERS    : parentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the Environment Data Page.
		 ************************************************************************/
		public C_guiPIGEnvironmentData (C_gui parentForm)
		{
			this.ptrGui = parentForm;
			this.MdiParent = parentForm;
			
			this.Text      = "PIG Data - Environment Data";
			this.pageType  = C_gui.page.PIG_ENVIRONMENT;

            m_InData  = this.ptrGui.m_InPIGData.oPIGEnvironment;

			//-----------------------------------------------------
			//Declare the data items.
			//-----------------------------------------------------
			m_dataItem = new C_guiDataItem[25];

			strDescription = new String[25]; 

			strDescription[ 0] = "Draw moon at stated position (On/Off)";
			strDescription[ 1] = "Enable navigation lights on coastline models(On/Off)";
			strDescription[ 2] = "Draw ice-edge and ice-floe at stated position(On/Off)";
			strDescription[ 3] = "Position sun at stated location overriding internal model (On/Off)";
			strDescription[ 4] = "Time of day, hours ("          + ")";
			strDescription[ 5] = "Time of day, minutes ("        + ")";
			strDescription[ 6] = "Time of day, seconds ("        + ")";
			strDescription[ 7] = "Date, day ("                   + ")";
			strDescription[ 8] = "Date, month("                  + ")";
			strDescription[ 9] = "Date, year since 1990 ("       + ")";
			strDescription[10] = "General weather conditions (Clear/Cloudy/Overcast/Fog/Rain)";
			strDescription[11] = "Coastline identification (Open Sea/Clyde)";
			strDescription[12] = "Surface sea state ("           + ")";
			strDescription[13] = "Visible range above surface (" + ")";
			strDescription[14] = "Thermal image visible range (" + ")";
			strDescription[15] = "Underwater visible range ("    + ")";
			strDescription[16] = "Wind speed ("                  + "m-per-s)";
			strDescription[17] = "Wind direction coming from ("  + ")";
			strDescription[18] = "Moon bearing ("                + ")";
			strDescription[19] = "Moon altitude ("               + ")";
			strDescription[20] = "Sun bearing ("                 + ")";
			strDescription[21] = "Sun altitude ("                + ")";
			strDescription[22] = "Ice-edge pivot latitude ("     + ")";
			strDescription[23] = "Ice-edge pivot longitude ("    + ")";
			strDescription[24] = "Ice-floe orientation ("        + ")";

			//-----------------------------------------------------
			//Initialise each component.
			//-----------------------------------------------------
			dataMoon  = new C_guiDataItemBoolean( "Moon"         , "PIG_ENVIRONMENT_MOON",                  50,  10, this, strDescription[0]);
			dataCoastLights  = new C_guiDataItemBoolean( "Coast Lights" , "PIG_ENVIRONMENT_COAST_LIGHTS",          50,  40, this, strDescription[1]);
			dataIceEdge  = new C_guiDataItemBoolean( "Ice Edge"     , "PIG_ENVIRONMENT_ICE_EDGE",              50,  70, this, strDescription[2]);
			dataSun  = new C_guiDataItemBoolean( "Remote Sun "  , "PIG_ENVIRONMENT_REMOTE_SUN",            50, 100, this, strDescription[3]);
			dataHours  = new C_guiDataItemByte( "Hours "       , "PIG_ENVIRONMENT_HOURS",                 50, 130, this, strDescription[4]);
			dataMinutes = new C_guiDataItemByte( "Minutes "     , "PIG_ENVIRONMENT_MINUTES",               50, 160, this, strDescription[5]);
			dataSeconds = new C_guiDataItemByte( "Seconds "     , "PIG_ENVIRONMENT_SECONDS",               50, 190, this, strDescription[6]);
			dataDay  = new C_guiDataItemByte( "Day "         , "PIG_ENVIRONMENT_DAY",                   50, 220, this, strDescription[7]);
			dataMonth  = new C_guiDataItemByte( "Month"        , "PIG_ENVIRONMENT_MONTH",                 50, 250, this, strDescription[8]);
			dataYear  = new C_guiDataItemByte( "Year"         , "PIG_ENVIRONMENT_YEAR",                  50, 280, this, strDescription[9]);
			dataWeather = new C_guiDataItemByte( "Weather"      , "PIG_ENVIRONMENT_WEATHER",               50, 310, this, strDescription[10]);
			dataCoastline = new C_guiDataItemByte( "Coastline"    , "PIG_ENVIRONMENT_COASTLINE",             50, 340, this, strDescription[11]);
			dataSeaState = new C_guiDataItemByte( "Sea State"    , "PIG_ENVIRONMENT_SEA_STATE",             50, 370, this, strDescription[12]);
			dataVisibleRange = new C_guiDataItemFloat( "Visible Range", "PIG_ENVIRONMENT_VISIBLE_RANGE",         50, 400, this, strDescription[13]);
			dataIRVisibleRange = new C_guiDataItemFloat( "Thermal Range", "PIG_ENVIRONMENT_THERMAL_RANGE",         50, 430, this, strDescription[14]);
			dataUWVisibleRange = new C_guiDataItemFloat( "Underwater Vis","PIG_ENVIRONMENT_UNDERWATER_VIS",        50, 460, this, strDescription[15]);
			dataWindSpeed = new C_guiDataItemFloat( "Wind Speed",    "PIG_ENVIRONMENT_WIND_SPEED",            50, 490, this, strDescription[16]);
			dataWindDir = new C_guiDataItemFloat( "Wind Direction","PIG_ENVIRONMENT_WIND_DIRECTION",        50, 520, this, strDescription[17]);
			dataMoonBrg = new C_guiDataItemFloat( "Moon Bearing",  "PIG_ENVIRONMENT_MOON_BEARING",          50, 550, this, strDescription[18]);
			dataMoonElev = new C_guiDataItemFloat( "Moon Altitude", "PIG_ENVIRONMENT_MOON_ALTITUDE",         50, 580, this, strDescription[19]);
			dataSunBrg = new C_guiDataItemFloat( "Sun Bearing",   "PIG_ENVIRONMENT_SUN_BEARING",           50, 610, this, strDescription[20]);
			dataSunElev = new C_guiDataItemFloat( "Sun Altitude",  "PIG_ENVIRONMENT_SUN_ALTITUDE",          50, 640, this, strDescription[21]);
			dataIceEdgeLat = new C_guiDataItemFloat( "Ice Edge Lat",  "PIG_ENVIRONMENT_ICE_EDGE_LAT",          50, 670, this, strDescription[22]);
			dataIceEdgeLon = new C_guiDataItemFloat( "Ice Edge Long", "PIG_ENVIRONMENT_ICE_EDGE_LONG" ,        50, 700, this, strDescription[23]);			
			dataIceEdgeOrient = new C_guiDataItemFloat( "Ice Floe Orientation","PIG_ENVIRONMENT_ICE_EDGE_ORIENT", 50, 730, this, strDescription[24]);

			string [] strOnOff     = {"Off", "On"};
			string [] strWeather   = {"Clear", "Cloudy", "Overcast", "Fog", "Rain"};
			string [] strCoastline = {"Open Sea", "Clyde"};
			string [] strSeaState  = {"0", "1", "2", "3", "4", "5", "6"};

			dataMoon.setListEntries(strOnOff);
			dataCoastLights.setListEntries(strOnOff);
			dataIceEdge.setListEntries(strOnOff);
			dataSun.setListEntries(strOnOff);
			dataWeather.setListEntries(strWeather);
			dataCoastline.setListEntries(strCoastline);
			dataSeaState.setListEntries(strSeaState);

			//Lat/Lons are expressed to 1 d.p. on the pig.
			dataIceEdgeLat.setDecimalPlaces(1);
			dataIceEdgeLon.setDecimalPlaces(1);

			this.Controls.Add(dataMoon);
			this.Controls.Add(dataCoastLights);
			this.Controls.Add(dataIceEdge);
			this.Controls.Add(dataSun);
			this.Controls.Add(dataHours);
			this.Controls.Add(dataMinutes);
			this.Controls.Add(dataSeconds);
			this.Controls.Add(dataDay);
			this.Controls.Add(dataMonth);
			this.Controls.Add(dataYear);
			this.Controls.Add(dataWeather);
			this.Controls.Add(dataCoastline);
			this.Controls.Add(dataSeaState);
			this.Controls.Add(dataVisibleRange);
			this.Controls.Add(dataIRVisibleRange);
			this.Controls.Add(dataUWVisibleRange);
			this.Controls.Add(dataWindSpeed);
			this.Controls.Add(dataWindDir);
			this.Controls.Add(dataMoonBrg);
			this.Controls.Add(dataMoonElev);
			this.Controls.Add(dataSunBrg);
			this.Controls.Add(dataSunElev);
			this.Controls.Add(dataIceEdgeLat);
			this.Controls.Add(dataIceEdgeLon);
			this.Controls.Add(dataIceEdgeOrient);

			this.Size = new Size(850, 800);

			m_initialised = true;

		}

		public override void updateIncomingData()
		{
			if(!m_initialised)
				return;
			
			dataMoon.Value = m_InData.bMoon.Value;     
			dataCoastLights.Value = m_InData.bCoastLights.Value;
			dataIceEdge.Value = m_InData.bIceEdge.Value;    
			dataSun.Value = m_InData.bRemoteSun.Value; 

			dataHours.Value = m_InData.bHours.Value;
			dataMinutes.Value = m_InData.bMinutes.Value;
			dataSeconds.Value = m_InData.bSeconds.Value;
			dataDay.Value = m_InData.bDay.Value;
			dataMonth.Value = m_InData.bMonth.Value;
			dataYear.Value = m_InData.bYear.Value;
			dataWeather.Value = m_InData.bWeather.Value;
			dataCoastline.Value = m_InData.bCoastline.Value;
			dataSeaState.Value = m_InData.bSeaState.Value;
			dataVisibleRange.Value = m_InData.fVisibleRange.Value;
			dataIRVisibleRange.Value = m_InData.fThermalRange.Value;
			dataUWVisibleRange.Value = m_InData.fUnderwaterVis.Value;
			dataWindSpeed.Value = m_InData.fWindSpeed.Value;
			dataWindDir.Value = m_InData.fWindDirection.Value;
			dataMoonBrg.Value = m_InData.fMoonBearing.Value;
			dataMoonElev.Value = m_InData.fMoonAltitude.Value;
			dataSunBrg.Value = m_InData.fSunBearing.Value;
			dataSunElev.Value = m_InData.fSunAltitude.Value;
			dataIceEdgeLat.Value = m_InData.fIceEdgeLat.Value;
			dataIceEdgeLon.Value = m_InData.fIceEdgeLong.Value;
			dataIceEdgeOrient.Value = m_InData.fIceFloe.Value;

		}

		public override void updateOutgoingData()
		{
            if(!m_initialised)
				return;

//			int flags      = System.Convert.ToByte(dataSun.Value);
//			flags        <<= 1;
//			flags         |= System.Convert.ToByte(dataIceEdge.Value);
//			flags        <<= 1;
//			flags         |= System.Convert.ToByte(dataCoastLights.Value);
//			flags        <<= 1;
//			flags         |= System.Convert.ToByte(dataMoon.Value);

			this.ptrGui.m_OutPIGData.oPIGEnvironment.bMoon.Value           = dataMoon.Value;     
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bCoastLights.Value    = dataCoastLights.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bIceEdge.Value        = dataIceEdge.Value;    
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bRemoteSun.Value      = dataSun.Value; 

            //this.ptrGui.m_OutPIGData.oPIGEnvironment.iFlags.Value = flags;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bHours.Value          = dataHours.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bMinutes.Value        = dataMinutes.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bSeconds.Value        = dataSeconds.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bDay.Value            = dataDay.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bMonth.Value          = dataMonth.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bYear.Value           = dataYear.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bWeather.Value        = dataWeather.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bCoastline.Value      = dataCoastline.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bSeaState.Value       = dataSeaState.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fVisibleRange.Value   = dataVisibleRange.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fThermalRange.Value   = dataIRVisibleRange.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fUnderwaterVis.Value  = dataUWVisibleRange.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fWindSpeed.Value      = dataWindSpeed.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fWindDirection.Value  = dataWindDir.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fMoonBearing.Value    = dataMoonBrg.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fMoonAltitude.Value   = dataMoonElev.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fSunBearing.Value     = dataSunBrg.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fSunAltitude.Value    = dataSunElev.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fIceEdgeLat.Value     = dataIceEdgeLat.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fIceEdgeLong.Value    = dataIceEdgeLon.Value;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fIceFloe.Value        = dataIceEdgeOrient.Value;


			this.ptrGui.m_OutPIGData.oPIGEnvironment.bMoon.Flag           = dataMoon.overrideChecked;     
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bCoastLights.Flag    = dataCoastLights.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bIceEdge.Flag        = dataIceEdge.overrideChecked;    
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bRemoteSun.Flag      = dataSun.overrideChecked; 
				                                                             
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bHours.Flag          = dataHours.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bMinutes.Flag        = dataMinutes.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bSeconds.Flag        = dataSeconds.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bDay.Flag            = dataDay.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bMonth.Flag          = dataMonth.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bYear.Flag           = dataYear.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bWeather.Flag        = dataWeather.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bCoastline.Flag      = dataCoastline.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.bSeaState.Flag       = dataSeaState.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fVisibleRange.Flag   = dataVisibleRange.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fThermalRange.Flag   = dataIRVisibleRange.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fUnderwaterVis.Flag  = dataUWVisibleRange.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fWindSpeed.Flag      = dataWindSpeed.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fWindDirection.Flag  = dataWindDir.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fMoonBearing.Flag    = dataMoonBrg.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fMoonAltitude.Flag   = dataMoonElev.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fSunBearing.Flag     = dataSunBrg.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fSunAltitude.Flag    = dataSunElev.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fIceEdgeLat.Flag     = dataIceEdgeLat.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fIceEdgeLong.Flag    = dataIceEdgeLon.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGEnvironment.fIceFloe.Flag        = dataIceEdgeOrient.overrideChecked;

			//this.ptrMain.ptrNetwork.send();
		}

		public override void setOverride(bool bEnabled)
		{
			if(!m_initialised) 
				return;

			dataMoon.setOverride(bEnabled);
			dataCoastLights.setOverride(bEnabled);
			dataIceEdge.setOverride(bEnabled);
			dataSun.setOverride(bEnabled);
			dataHours.setOverride(bEnabled);
			dataMinutes.setOverride(bEnabled);
			dataSeconds.setOverride(bEnabled);
			dataDay.setOverride(bEnabled);
			dataMonth.setOverride(bEnabled);
			dataYear.setOverride(bEnabled);
			dataWeather.setOverride(bEnabled);
			dataCoastline.setOverride(bEnabled);
			dataSeaState.setOverride(bEnabled);
			dataVisibleRange.setOverride(bEnabled);
			dataIRVisibleRange.setOverride(bEnabled);
			dataUWVisibleRange.setOverride(bEnabled);
			dataWindSpeed.setOverride(bEnabled);
			dataWindDir.setOverride(bEnabled);
			dataMoonBrg.setOverride(bEnabled);
			dataMoonElev.setOverride(bEnabled);
			dataSunBrg.setOverride(bEnabled);
			dataSunElev.setOverride(bEnabled);
			dataIceEdgeLat.setOverride(bEnabled);
			dataIceEdgeLon.setOverride(bEnabled);
			dataIceEdgeOrient.setOverride(bEnabled);

		}
	}

}
