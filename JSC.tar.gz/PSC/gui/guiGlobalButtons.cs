//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiGlobalButtons.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Windows.Forms;


namespace PSCGenericBuild
{

	//-----------------------------------------------------------------------
	//The Global Buttons Class.
	//-----------------------------------------------------------------------
	public class C_guiGlobalButtons : ToolBar
	{
		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		protected Button m_Overrides;
		protected Button m_Scenarios;
		protected Button m_PIPEmulation;
		protected Button m_PIGEmulation;
		protected Button m_IOEmulation;

		protected int    m_pntX;

		protected C_gui  ptrParentGui;
		//protected PSC    ptrPSC;

		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------
		public C_guiGlobalButtons (C_gui ptrGui)
		{
			//Save the pointer to the GUI and the psc.
			ptrParentGui = ptrGui;
			//ptrPSC       = ptrGui.psc;

			m_pntX       = 10;

			//Create the 'Overrides Active' Button
			m_Overrides           = new Button();
			m_Overrides.Width     = 90;
			m_Overrides.Height    = 35;
			m_Overrides.Text      = "Overrides";

			//Create the 'Scenarios' Button
			m_Scenarios           = new Button();
			m_Scenarios.Width     = 90;
			m_Scenarios.Height    = 35;
			m_Scenarios.Click    += new EventHandler(scenarios);
			m_Scenarios.Text      = "Scenarios";

			//Create the 'PIP Emulation' Button
			m_PIPEmulation           = new Button();
			m_PIPEmulation.Width     = 90;
			m_PIPEmulation.Height    = 35;
			m_PIPEmulation.Click    += new EventHandler(toggleEmulation);
			m_PIPEmulation.Text      = "PIP Emulation";

			//Create the 'PIG Emulation' Button
			m_PIGEmulation           = new Button();
			m_PIGEmulation.Width     = 90;
			m_PIGEmulation.Height    = 35;
			m_PIGEmulation.Click    += new EventHandler(toggleEmulation);
			m_PIGEmulation.Text      = "PIG Emulation";

			//Create the 'IO Emulation' Button
			m_IOEmulation           = new Button();
			m_IOEmulation.Width     = 90;
			m_IOEmulation.Height    = 35;
			m_IOEmulation.Click    += new EventHandler(toggleEmulation);
			m_IOEmulation.Text      = "IO Emulation";

			this.ButtonSize = new Size(90, 40);
			this.TextAlign = ToolBarTextAlign.Underneath;
			this.Size       = new Size(50, 100);

			//
			//By default the global buttons are disabled.
			//
			enableGlobalButtons(true);


			this.Show();

		}

		public void enableGlobalButtons(bool bEnable)
		{
			if(bEnable)
			{
				m_Overrides.Enabled = true;
				m_Scenarios.Enabled = true;
				m_PIPEmulation.Enabled = true;
				m_PIGEmulation.Enabled = true;
				m_IOEmulation.Enabled = true;
			}
			else
			{
				m_Overrides.Enabled = false;
				m_Scenarios.Enabled = false;
				m_PIPEmulation.Enabled = false;
				m_PIGEmulation.Enabled = false;
				m_IOEmulation.Enabled = false;
			}
		}

		private void scenarios(object sender, EventArgs e)
		{
			if(sender == m_Scenarios)
			{
				if(this.ptrParentGui.ScenarioRunning == false)
				{
					//
					//When the data logger button is pressed in the default state, the data
					//logger form is displayed.
					//
					this.ptrParentGui.Scenarios.Show();
				}
				else
					this.ptrParentGui.Scenarios.scenarioStartStop(sender, e);
			}
		}

		private void toggleEmulation(object sender, EventArgs e)
		{
			Button pressed = (Button)sender;

			if(pressed == m_PIPEmulation)
			{
				if(ptrParentGui.PIPEmulation)
                   ptrParentGui.PIPEmulation = false;
				else
				   ptrParentGui.PIPEmulation = true;
			}

			else if(pressed == m_PIGEmulation)
			{
				if(ptrParentGui.PIGEmulation)
					ptrParentGui.PIGEmulation = false;
				else
					ptrParentGui.PIGEmulation = true;
			}

			else if(pressed == m_IOEmulation)
			{
				if(ptrParentGui.IOEmulation)
				  ptrParentGui.IOEmulation  = false;
				else
				  ptrParentGui.IOEmulation  = true;
			}
		}

		public void setPIPEmulation(bool bOnOff)
		{
			if(bOnOff)
			{
               m_PIPEmulation.BackColor = Color.Red;
			}
			else
			{
               m_PIPEmulation.BackColor = Color.Empty;
			}
		}

		public void setPIGEmulation(bool bOnOff)
		{
			if(bOnOff)
			{
				m_PIGEmulation.BackColor = Color.Red;
			}
			else
			{
				m_PIGEmulation.BackColor = Color.Empty;
			}
		}

		public void setIOEmulation(bool bOnOff)
		{
			if(bOnOff)
			{
				m_IOEmulation.BackColor = Color.Red;
			}
			else
			{
				m_IOEmulation.BackColor = Color.Empty;
			}
		}



		public void setOverridesSelected(bool bActive)
		{
			if(bActive)
				m_Overrides.BackColor = Color.Red;
			else
				m_Overrides.BackColor = Color.Empty;
		}

		public void setScenariosSelected(bool bActive)
		{
			if(bActive)
				m_Scenarios.BackColor = Color.Red;
			else
				m_Scenarios.BackColor = Color.Empty;
		}

		public void addGlobalButton(string strGlobalButton)
		{
			Button btnAdding = null;

			if(strGlobalButton.Equals("OVERRIDES"))
				btnAdding = m_Overrides;
			else if(strGlobalButton.Equals("EXERCISES"))
				btnAdding = m_Scenarios;
			else if(strGlobalButton.Equals("PIP_EMULATION"))
				btnAdding = m_PIPEmulation;
			else if(strGlobalButton.Equals("PIG_EMULATION"))
				btnAdding = m_PIGEmulation;
			else if(strGlobalButton.Equals("IO_EMULATION"))
				btnAdding = m_IOEmulation;

			if(btnAdding != null)
			{
				btnAdding.Location = new Point(m_pntX, 5);
				this.Controls.Add(btnAdding);
				m_pntX += 100;
			}
		}
	}
}
