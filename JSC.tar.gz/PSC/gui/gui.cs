//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : gui.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.IO;
using System.Threading;
using System.Collections;
using System.Runtime.InteropServices;

namespace PSCGenericBuild
{
	//-----------------------------------------------------------------------
	//The GUI Class.
	//
	//The GUI class contains all the functionality for the PSC Graphical User
	//Interface. The GUI class derives from the windows form class.
	//-----------------------------------------------------------------------
	public class C_gui : Form
	{

		protected bool       m_bPIPEmulation;
		protected bool       m_bPIGEmulation;
		protected bool       m_bIOEmulation;
		protected bool       m_bScenarioRunning;

		public Mutex m_Mutex;
		public bool	m_PIPEmulationUpdate;
		public System.Timers.Timer timerGUIUpdate;
		public double m_PIPEmulationTimer;
		public const float PIP_EMULATION_TIMER = 2000.0f;


        //
		//Gui Data Store... (repository of data received from SimControl)
		//
		public 	PIP_Data m_InPIPData;
		public 	PIG_Data m_InPIGData;

		public 	PIP_Data m_OutPIPData;
		public 	PIG_Data m_OutPIGData;

		public  IO_Data  m_InIOData;
		public  IO_Data  m_OutIOData;

		public  ErrorLogData m_ErrorLog;


		//PSC_Packet PIG;


		protected SIMControl m_simControl;
		protected ConfigFile m_configFile;

		protected Hashtable  m_hashtable;
		protected ArrayList  m_globalButtonList;
		protected ArrayList  m_scenariosList;

		protected C_gui.page m_ioDataPage;

		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		protected C_guiTemplatePage       m_guiIOData;
		protected C_guiNetworkStatus      m_guiNetworkStatus;
		protected C_guiScenarios          m_guiScenarios;

		protected C_guiPIPTargetData[]	  m_guiPIPTargets;

		protected C_guiPIPExerciseData    m_guiPIPExercise;
		protected C_guiPIPEnvironmentData m_guiPIPEnvironment;
		protected C_guiPIPOwnshipData     m_guiPIPOwnship;
		protected C_guiPIPPeriscopeData   m_guiPIPPeriscope;
		protected C_guiPIPReturnData      m_guiPIPReturn;

		protected C_guiPIGExerciseData    m_guiPIGExercise;
		protected C_guiPIGEnvironmentData m_guiPIGEnvironment;
		protected C_guiPIGOwnshipData     m_guiPIGOwnship;
		protected C_guiPIGPeriscopeData   m_guiPIGPeriscope;
		protected C_guiPIGTargetData[]    m_guiPIGTargets;
		protected C_guiPIGReturnData      m_guiPIGReturn;

		protected C_guiGlobalButtons m_guiGlobalButtons;
		//protected PSC ptrPSC;

		protected C_guiMainMenu m_mainMenu;

		protected int m_nNumberOfOverrides;

		Form ptrActiveForm;

		//The array of model names.
		public String [] m_modelNames;
		bool m_namesInitialised;

		public enum page { NONE = -1,
			               IO_DATA_AS1117,
			               IO_DATA_AS1082,
			               PIP_DATA,
			               NETWORK_STATUS,
			               IO_STATUS,
			               SCENARIOS,
			               PIP_EXERCISE,
			               PIP_ENVIRONMENT,
			               PIP_OWNSHIP,
			               PIP_PERISCOPE,
			               PIG_EXERCISE,
			               PIG_ENVIRONMENT,
			               PIG_OWNSHIP,
			               PIG_PERISCOPE,
			               PIG_TARGETS,
						   PIP_TARGETS,
		                   PIG_RETURN,
		                   PIP_RETURN};



		//Emulation modes
		public bool PIPEmulation
		{
			get
			{
				return m_bPIPEmulation;
			}
			set
			{
				m_bPIPEmulation = value;

				if(value)
				{
					//
					//Enable all the overrides except the Return data
					//
					PIPEnvironment.enableOverrides    (true);
					PIPExercise.enableOverrides       (true);
					PIPOwnship.enableOverrides        (true);
					PIPPeriscope.enableOverrides      (true);
					for ( int i = 0; i < SIMControl.NUM_PERI_TARGETS - 1 ; i++)
						PIPTarget(i).enableOverrides  (true);

					globalButtons.setPIPEmulation(true);

				}
				else
				{
					//
					//Disable all the overrides except the Return data
					//
					PIPEnvironment.enableOverrides    (false);
					PIPExercise.enableOverrides       (false);
					PIPOwnship.enableOverrides        (false);
					PIPPeriscope.enableOverrides      (false);
					for ( int i = 0; i < SIMControl.NUM_PERI_TARGETS - 1 ; i++)
						PIPTarget(i).enableOverrides  (false);

					globalButtons.setPIPEmulation(false);

					//
					//If any scenario is currently running, stop it.
					//
					this.Scenarios.scenarioStop();
				}

				//Refresh the network status page.
				this.NetworkStatus.Refresh();
			}
		}

		public bool PIGEmulation
		{
			get
			{
				return m_bPIGEmulation;
			}
			set
			{
				m_bPIGEmulation = value;

				if(m_bPIGEmulation)
				{
					PIGReturn.enableOverrides(true);
					globalButtons.setPIGEmulation(true);
				}
				else
				{
					PIGReturn.enableOverrides(false);
					globalButtons.setPIGEmulation(false);
				}

				//Refresh the network status page.
				this.NetworkStatus.Refresh();
			}
		}

		public bool IOEmulation
		{
			get
			{
				return m_bIOEmulation;
			}
			set
			{
				m_bIOEmulation = value;

				if(m_bIOEmulation)
				{
					IOData.enableOverrides(true);
					globalButtons.setIOEmulation(true);
				}
				else
				{
                    IOData.enableOverrides(false);
					globalButtons.setIOEmulation(false);
				}

				//Refresh the network status page.
				this.NetworkStatus.Refresh();
			}
		}

		public bool ScenarioRunning
		{
			get
			{
				return m_bScenarioRunning;
			}
			set
			{
				m_bScenarioRunning = value;
				//Highlight the 'Scenarios' button on the tool bar.
				this.globalButtons.setScenariosSelected(m_bScenarioRunning);
			}
		}


		public C_gui.page ioDataPage
		{
			get
			{
				return m_ioDataPage;
			}
			set
			{
				m_ioDataPage = value;
			}
		}

		public Hashtable hashtable
		{
			get
			{
				return m_hashtable;
			}
		}

		public ArrayList globalButtonList
		{
			get
			{
				return m_globalButtonList;
			}
		}

		public ArrayList scenariosList
		{
			get
			{
				return m_scenariosList;
			}
		}


		public C_guiMainMenu mainMenu
		{
			get
			{
				return m_mainMenu;
			}
		}


		public C_guiNetworkStatus NetworkStatus
		{
			get
			{
				return m_guiNetworkStatus;
			}
		}

		public C_guiScenarios Scenarios
		{
			get
			{
				return m_guiScenarios;
			}
		}

		public C_guiPIPReturnData PIPReturn
		{
			get
			{
				return m_guiPIPReturn;
			}
		}

		public C_guiPIPTargetData PIPTarget(int i)
		{
			return m_guiPIPTargets[i];
		}


		public C_guiPIPOwnshipData PIPOwnship
		{
			get
			{
				return m_guiPIPOwnship;
			}
		}

		public C_guiPIPEnvironmentData PIPEnvironment
		{
			get
			{
				return m_guiPIPEnvironment;
			}
		}

		public C_guiPIPExerciseData PIPExercise
		{
			get
			{
				return m_guiPIPExercise;
			}
		}

		public C_guiPIPPeriscopeData PIPPeriscope
		{
			get
			{
				return m_guiPIPPeriscope;
			}
		}


		public C_guiPIGOwnshipData PIGOwnship
		{
			get
			{
				return m_guiPIGOwnship;
			}
		}

		public C_guiPIGEnvironmentData PIGEnvironment
		{
			get
			{
				return m_guiPIGEnvironment;
			}
		}

		public C_guiPIGExerciseData PIGExercise
		{
			get
			{
				return m_guiPIGExercise;
			}
		}

		public C_guiPIGPeriscopeData PIGPeriscope
		{
			get
			{
				return m_guiPIGPeriscope;
			}
		}

		public C_guiPIGReturnData PIGReturn
		{
			get
			{
				return m_guiPIGReturn;
			}
		}

		public C_guiTemplatePage  IOData
		{
			get
			{
				return m_guiIOData;
			}
		}

		public C_guiGlobalButtons globalButtons
		{
			get
			{
				return m_guiGlobalButtons;
			}
		}

		public C_guiPIGTargetData getPIGTarget(int i)
		{
			return m_guiPIGTargets[i];
		}

		public int numberOfOverrides
		{
			get
			{
				return m_nNumberOfOverrides;
			}
			set
			{
				m_nNumberOfOverrides = value;
			}
		}

		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------
		public C_gui(SIMControl ptrSimControl)
		{
			m_simControl = ptrSimControl;
		}

		public void start()
		{
            System.Windows.Forms.Application.Run(this);
		}

		public void closeOpenPages()
		{
			//
			//Dispose of any active pages
			//
			m_guiIOData.Dispose();
			m_guiPIPExercise.Dispose();
			m_guiPIPEnvironment.Dispose();
			m_guiPIPOwnship.Dispose();
			m_guiPIPPeriscope.Dispose();
			m_guiPIPReturn.Dispose();
			m_guiPIGExercise.Dispose();
			m_guiPIGEnvironment.Dispose();
			m_guiPIGOwnship.Dispose();
			m_guiPIGPeriscope.Dispose();

			for(int i =0 ; i < SIMControl.NUM_PERI_TARGETS; i++)
			  m_guiPIGTargets[i].Dispose();

			for(int i =0 ; i < SIMControl.NUM_PERI_TARGETS; i++)
				m_guiPIPTargets[i].Dispose();

			m_guiPIGReturn.Dispose();
			m_guiScenarios.Dispose();

		}

		/************************************************************************
		  FUNCTION      : C_gui()
		  DESCRIPTION   : The Constructor for the Graphical User Interface (gui)
		                  Consists of a number of forms (pages).
		  PARAMETERS    : ptrParentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the GUI.
		 ************************************************************************/
		public void initialise()
		{
            //ptrPSC = ptrParentForm;

			//Set up the gui data store.
			//

			//Create the arrays defined in the structures (as this cant be done in the definition)...
			//m_InPIGData.oPIGOwnship.mast = new float[10];

			m_InPIGData  = new PIG_Data();
			m_OutPIGData = new PIG_Data();

            m_InPIPData = new PIP_Data();
			m_OutPIPData = new PIP_Data();

		    m_InIOData = new IO_Data();
		    m_OutIOData = new IO_Data();


			m_ErrorLog = new ErrorLogData();

			//
			// Get the mutex that protects the data between the GUI
			// and SimControl
			//
			m_Mutex = new Mutex(false, "mutexData");

			//
			// Initialise PIP Emulation update
			//
			m_PIPEmulationUpdate = false;
			m_PIPEmulationTimer = 0.0;

			//
			//Set the initial state of the windows form
			//

			this.IsMdiContainer = true;
			this.Text           = "PSC";

			//The window is not resizable
			this.FormBorderStyle = FormBorderStyle.Sizable;

			//Set the window maximised.
			this.WindowState = FormWindowState.Normal;

			//Disable the minimise and maximise boxes

			//Maximize the Application

			//Rectangle rect   = Screen.FromControl(this).WorkingArea;
			this.Size        = new Size(1024, 800);
			this.Location    = new Point(0,0);

			//
			//For some reason when i try to hide the minimize and maximize
			//buttons the form can be moved !!
			//

			//MinimizeBox = false;
			//MaximizeBox = false;

			//
			//By default the io page is the AS1117.
			//
			ioDataPage = C_gui.page.IO_DATA_AS1117;
			//

			//Create the config file hash table.
			//
			m_hashtable        = new Hashtable();
			m_globalButtonList = new ArrayList();
			m_scenariosList    = new ArrayList();

			//
			//Create the main menu class.
			//
			m_mainMenu = new C_guiMainMenu(this);

			//Set the main menu to be used by this form.
			this.Menu = m_mainMenu;

			//
			//Read the configuration file.
			//
			m_configFile = new ConfigFile(this);
			m_configFile.readConfigFile("PSCGuiConfig.txt");

			//Configure the menu structure.
			m_mainMenu.configureMenu();

			//-----------------------------------------------------
			//Create each of the pages.
			//-----------------------------------------------------
			m_guiNetworkStatus      = new C_guiNetworkStatus        (this);
			m_guiPIPExercise        = new C_guiPIPExerciseData      (this);
			m_guiPIPEnvironment     = new C_guiPIPEnvironmentData   (this);
			m_guiPIPOwnship         = new C_guiPIPOwnshipData       (this);
			m_guiPIPPeriscope       = new C_guiPIPPeriscopeData     (this);
			m_guiPIPReturn          = new C_guiPIPReturnData        (this);
			m_guiPIPTargets         = new C_guiPIPTargetData[SIMControl.NUM_PERI_TARGETS];

			m_guiPIGExercise        = new C_guiPIGExerciseData    (this);
			m_guiPIGEnvironment     = new C_guiPIGEnvironmentData (this);
			m_guiPIGOwnship         = new C_guiPIGOwnshipData     (this);
			m_guiPIGPeriscope       = new C_guiPIGPeriscopeData   (this);
			m_guiPIGTargets         = new C_guiPIGTargetData[SIMControl.NUM_PERI_TARGETS];
			m_guiPIGReturn          = new C_guiPIGReturnData   (this);
            m_guiScenarios          = new C_guiScenarios       (this);

			for(int i=0; i < SIMControl.NUM_PERI_TARGETS; i++)
			{
				String strLabel = "PIG Data - Target Data (" + (i+1).ToString() + ")";
				m_guiPIGTargets[i] = new C_guiPIGTargetData(this, strLabel, i);
			}

			for(int i=0; i < SIMControl.NUM_PERI_TARGETS; i++)
			{
				String strLabel = "PIP Data - Target Data (" + (i+1).ToString() + ")";
				m_guiPIPTargets[i] = new C_guiPIPTargetData(this, strLabel, i+1);
			}



			//
			//Create the appropriate IO Data page.
			//
			if(this.ioDataPage == C_gui.page.IO_DATA_AS1117)
				m_guiIOData     = new C_guiIODataAS1117(this);
			else
				m_guiIOData     = new C_guiIODataAS1082(this);


			//Set the page types for the target pages.
			m_guiPIGTargets[0].pageType = C_gui.page.PIG_TARGETS;
			m_guiPIPTargets[0].pageType = C_gui.page.PIP_TARGETS;

			//Create the global buttons.
            m_guiGlobalButtons = new C_guiGlobalButtons(this);

			//
			//Create the global buttons.
			//
			for(int i = 0; i < m_globalButtonList.Count; i++)
			{
				string strGlobalButton = (string) m_globalButtonList[i];
			    m_guiGlobalButtons.addGlobalButton(strGlobalButton);
			}

			this.Controls.Add(m_guiGlobalButtons);

			//The Network Status page is active by default (the rest are hidden).
			m_guiNetworkStatus.Show();
            ptrActiveForm = m_guiNetworkStatus;

			//By default no overrides are selected.
			m_nNumberOfOverrides = 0;

			//By default overrides are inactive when the application starts.
			this.SetOverrides(false);

			ScenarioRunning = false;

            // m_guiPIGEnvironment.Show();
				// m_guiPIGEnvironment.Focus();

            // this.ShowPage(page.PIG_ENVIRONMENT, 0);

            //
            // Create a timer to update with Sim Control
            //
            timerGUIUpdate = new System.Timers.Timer();
			timerGUIUpdate.Elapsed  += new System.Timers.ElapsedEventHandler(updateGUIData);
			timerGUIUpdate.Interval  = 500;
			timerGUIUpdate.Enabled   = true;
		}

		/************************************************************************
		  FUNCTION      : ShowPage()
		  DESCRIPTION   : Show the relevant page when the user selects a new page
		                  to display from the menu.
		  PARAMETERS    : page iPage : enumeration of the page to display.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : As read.
		 ************************************************************************/
		public void ShowPage(page iPage, int targetnumber)
		{
			Form pageToShow = new Form();

			switch(iPage)
			{
				case page.IO_DATA_AS1082:
				case page.IO_DATA_AS1117:  pageToShow = m_guiIOData;
					                       break;
				case page.NETWORK_STATUS:  pageToShow = m_guiNetworkStatus;
					                       break;
				case page.SCENARIOS: 	   pageToShow = m_guiScenarios;
					                       break;
				case page.PIG_EXERCISE:    pageToShow = m_guiPIGExercise;
					                       break;
				case page.PIG_ENVIRONMENT: pageToShow = m_guiPIGEnvironment;
					                       break;
				case page.PIG_OWNSHIP:     pageToShow = m_guiPIGOwnship;
					                       break;
				case page.PIG_PERISCOPE:   pageToShow = m_guiPIGPeriscope;
					                       break;

				case page.PIP_EXERCISE:    pageToShow = m_guiPIPExercise;
					                       break;
				case page.PIP_ENVIRONMENT: pageToShow = m_guiPIPEnvironment;
					                       break;
				case page.PIP_OWNSHIP:     pageToShow = m_guiPIPOwnship;
					                       break;
				case page.PIP_PERISCOPE:   pageToShow = m_guiPIPPeriscope;
					                       break;
				case page.PIP_RETURN:      pageToShow = m_guiPIPReturn;
					                       break;
				case page.PIG_RETURN:      pageToShow = m_guiPIGReturn;
					                       break;

				case page.PIG_TARGETS:   pageToShow = m_guiPIGTargets[targetnumber]; break;
				case page.PIP_TARGETS:   pageToShow = m_guiPIPTargets[targetnumber]; break;

				default:                   pageToShow = null;
					                       break;
			}

			if(pageToShow != null)
			{
				//Hide the currently displayed page and show the new page.
				ptrActiveForm = pageToShow;
				ptrActiveForm.Show();
				ptrActiveForm.Focus();
			}
		}

		//Disable/Enable all the overrides on each of the pages.
		public void SetOverrides(bool bEnable)
		{
				//guiPIPData       .setOverride(bEnable);
				m_guiNetworkStatus .setOverride(bEnable);
				//guiIOStatus      .setOverride(bEnable);
				m_guiScenarios     .setOverride(bEnable);

				m_guiPIGExercise   .setOverride(bEnable);
				m_guiPIGOwnship    .setOverride(bEnable);
				m_guiPIGPeriscope  .setOverride(bEnable);
				m_guiPIGEnvironment.setOverride(bEnable);

			    //guiPIPExercise   .setOverride(bEnable);
			    //guiPIPOwnship    .setOverride(bEnable);
			    m_guiPIPPeriscope  .setOverride(bEnable);
			    //guiPIPEnvironment.setOverride(bEnable);

		}

		/************************************************************************
		  FUNCTION      : Dispose()
		  DESCRIPTION   : This method is called when the user attempts to close the
		                  application.
		  PARAMETERS    : page iPage : enumeration of the page to display.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : As read.
		 ************************************************************************/
		protected override void Dispose(bool disposing)
		{
			ExitDialog exitDialog = new ExitDialog();
			if(exitDialog.ShowDialog() == DialogResult.OK)
			{
				//
				// Set the mutex-protected data in SimControl so that
				// the Main Thread can shut down.
				//
           		m_Mutex.WaitOne();
				m_simControl.m_GUIData.m_SIMRunApp = false;
				m_Mutex.ReleaseMutex();

				//
				// Close the GUI Thread
				//
				base.Dispose(disposing);
			}
		}

		public void updateGUIData(object source, System.Timers.ElapsedEventArgs e)
		{

			//
			// If Network Monitoring is OFF don't process
			//
			if (!NetworkStatus.m_bNetworkMonitoring)
				return;

			//
			// Update mutex-protected data from SimControl
			//
			m_Mutex.WaitOne();
			updateFromSimControl();
			m_Mutex.ReleaseMutex();


			//
			// Update GUI pages for incoming data
			//

			// PIP Pages
			m_guiPIPExercise.updateIncomingData();
			m_guiPIPEnvironment.updateIncomingData();
			m_guiPIPPeriscope.updateIncomingData();
			m_guiPIPOwnship.updateIncomingData();
			m_guiPIPReturn.updateIncomingData();

			for (int i = 0; i < SIMControl.NUM_PERI_TARGETS ; i++)
			{
				m_guiPIPTargets[i].updateIncomingData();
			}



			// PIG Pages
			m_guiPIGExercise.updateIncomingData();
			m_guiPIGEnvironment.updateIncomingData();
			m_guiPIGOwnship.updateIncomingData();
			m_guiPIGPeriscope.updateIncomingData();

			//IO Page
			m_guiIOData.updateIncomingData();


			for (int i = 0; i < SIMControl.NUM_PERI_TARGETS ; i++)
			{
				m_guiPIGTargets[i].updateIncomingData();
			}

			m_guiPIGReturn.updateIncomingData();

			// Network Status Page
			NetworkStatus.update();


			//
			// Update GUI pages for outgoing data
			//

			// PIP Pages
			m_guiPIPExercise.updateOutgoingData();
			m_guiPIPEnvironment.updateOutgoingData();
			m_guiPIPPeriscope.updateOutgoingData();
			m_guiPIPOwnship.updateOutgoingData();
			m_guiPIPReturn.updateOutgoingData();

			// PIG Pages
			m_guiPIGExercise.updateOutgoingData();
			m_guiPIGEnvironment.updateOutgoingData();
			m_guiPIGOwnship.updateOutgoingData();
			m_guiPIGPeriscope.updateOutgoingData();

			//IO Page
			m_guiIOData.updateOutgoingData();


			for (int i = 0; i < SIMControl.NUM_PERI_TARGETS ; i++)
			{
				m_guiPIGTargets[i].updateOutgoingData();
			}

			m_guiPIGReturn.updateOutgoingData();


			//
			// Update mutex-protected data to SimControl
			//
			m_Mutex.WaitOne();
			updateToSimControl();
			m_Mutex.ReleaseMutex();


			//
			// If emulating the PIP then update every two seconds
			//
			if (PIPEmulation)
			{
				m_PIPEmulationTimer += timerGUIUpdate.Interval;

				// Add 0.1 to account for floating point errors
				if ((m_PIPEmulationTimer + 0.1) >= PIP_EMULATION_TIMER)
				{
					updatePIPEmulation(PIP_EMULATION_TIMER * 0.001f);
					m_PIPEmulationTimer  = 0.0f;
				}
			}
		}

		public void updateFromSimControl()
		{
			//
			// Model names (only need to get once)
			//
			if(!m_namesInitialised)
			{
				m_modelNames = new String[1000];

				if(m_simControl.m_GUIData.m_ModelNamesSet)
				{
					for(int i=0; i < 1000; i++)
					{
						m_modelNames[i] = m_simControl.m_GUIData.m_ModelNames[i];
					}
					m_namesInitialised = true;
				}
			}

			//
			// Update the PIP data
			//

			// Exercise
	        m_InPIPData.oExercise.bRunMode.Value = m_simControl.m_GUIData.m_PIPExRunMode.GetRawValue();
			m_InPIPData.oExercise.hours.Value = m_simControl.m_GUIData.m_PIPExHours.GetRawValue();
			m_InPIPData.oExercise.minutes.Value = m_simControl.m_GUIData.m_PIPExMins.GetRawValue();
			m_InPIPData.oExercise.seconds.Value = m_simControl.m_GUIData.m_PIPExSecs.GetRawValue();
			m_InPIPData.oExercise.day.Value = m_simControl.m_GUIData.m_PIPExDay.GetRawValue();
			m_InPIPData.oExercise.month.Value = m_simControl.m_GUIData.m_PIPExMonth.GetRawValue();
			m_InPIPData.oExercise.year.Value = m_simControl.m_GUIData.m_PIPExYear.GetRawValue();

			// Environment
			m_InPIPData.oEnvironment.bMoon.Value  = m_simControl.m_GUIData.m_PIPEnvMoonOverride.GetRawValue();
			m_InPIPData.oEnvironment.bCoastLights.Value = m_simControl.m_GUIData.m_PIPEnvCoastLights.GetRawValue();
			m_InPIPData.oEnvironment.bIceEdge.Value  = m_simControl.m_GUIData.m_PIPEnvIceEdgeOn.GetRawValue();
			m_InPIPData.oEnvironment.bRemoteSun.Value  = m_simControl.m_GUIData.m_PIPEnvSunOverride.GetRawValue();
			m_InPIPData.oEnvironment.bVisibility.Value = m_simControl.m_GUIData.m_PIPEnvWeather.GetRawValue();
            m_InPIPData.oEnvironment.bCoastline.Value = m_simControl.m_GUIData.m_PIPEnvCoastline.GetRawValue();
            m_InPIPData.oEnvironment.bSeaState.Value = m_simControl.m_GUIData.m_PIPEnvSeaState.GetRawValue();
            m_InPIPData.oEnvironment.fMoonBearing.Value = m_simControl.m_GUIData.m_PIPEnvMoonBrg.GetRawValue();
            m_InPIPData.oEnvironment.fMoonElevation.Value = m_simControl.m_GUIData.m_PIPEnvMoonElev.GetRawValue();
            m_InPIPData.oEnvironment.fVisualRange.Value = m_simControl.m_GUIData.m_PIPEnvVisualRange.GetRawValue();
            m_InPIPData.oEnvironment.fUWVisualRange.Value = m_simControl.m_GUIData.m_PIPEnvUnderWaterRange.GetRawValue();
            m_InPIPData.oEnvironment.fTIRange.Value = m_simControl.m_GUIData.m_PIPEnvThermalRange.GetRawValue();
            m_InPIPData.oEnvironment.fWindSpeed.Value = m_simControl.m_GUIData.m_PIPEnvWindSpeed.GetRawValue();
            m_InPIPData.oEnvironment.fWindHeading.Value = m_simControl.m_GUIData.m_PIPEnvWindHeading.GetRawValue();
            m_InPIPData.oEnvironment.fIceLat.Value = m_simControl.m_GUIData.m_PIPEnvIceLat.GetRawValue();
			m_InPIPData.oEnvironment.fIceLong.Value = m_simControl.m_GUIData.m_PIPEnvIceLon.GetRawValue();
			m_InPIPData.oEnvironment.fIceOrientation.Value = m_simControl.m_GUIData.m_PIPEnvIceOrien.GetRawValue();
			m_InPIPData.oEnvironment.fSunBearing.Value = m_simControl.m_GUIData.m_PIPEnvSunBrg.GetRawValue();
			m_InPIPData.oEnvironment.fSunElevation.Value = m_simControl.m_GUIData.m_PIPEnvSunElev.GetRawValue();

			// Periscope
		    m_InPIPData.oPeriscope.bInstructor.Value = m_simControl.m_GUIData.m_PIPPeriInstructCtrl.GetRawValue();
		    m_InPIPData.oPeriscope.bMast.Value = m_simControl.m_GUIData.m_PIPPeriSearchUp.GetRawValue();
		    m_InPIPData.oPeriscope.bTiHotControl.Value = m_simControl.m_GUIData.m_PIPPeriPolarityWhite.GetRawValue();
		    m_InPIPData.oPeriscope.bMagnification.Value = m_simControl.m_GUIData.m_PIPPeriHighMag.GetRawValue();

			m_InPIPData.oPeriscope.bDrainDownTime.Value = m_simControl.m_GUIData.m_PIPPeriDraindown.GetRawValue();
			m_InPIPData.oPeriscope.bLLTVGain.Value = m_simControl.m_GUIData.m_PIPPeriLLTVGain.GetRawValue();
			m_InPIPData.oPeriscope.bTIGain.Value = m_simControl.m_GUIData.m_PIPPeriThermalGain.GetRawValue();
	  		m_InPIPData.oPeriscope.fElevation.Value = m_simControl.m_GUIData.m_PIPPeriElevation.GetRawValue();
	  		m_InPIPData.oPeriscope.fRelBrg.Value = m_simControl.m_GUIData.m_PIPPeriRelBearing.GetRawValue();

			// Ownship
			m_InPIPData.oOwnboat.dfLatitude.Value = m_simControl.m_GUIData.m_PIPOwnLat.GetRawValue();
			m_InPIPData.oOwnboat.dfLongitude.Value = m_simControl.m_GUIData.m_PIPOwnLon.GetRawValue();
			m_InPIPData.oOwnboat.fDepth.Value = m_simControl.m_GUIData.m_PIPOwnDepth.GetRawValue();
			m_InPIPData.oOwnboat.fClimbRate.Value = m_simControl.m_GUIData.m_PIPOwnClimbRate.GetRawValue();
			m_InPIPData.oOwnboat.fTurnRate.Value = m_simControl.m_GUIData.m_PIPOwnTurnRate.GetRawValue();
			m_InPIPData.oOwnboat.fPitch.Value = m_simControl.m_GUIData.m_PIPOwnPitch.GetRawValue();
			m_InPIPData.oOwnboat.fHeading.Value = m_simControl.m_GUIData.m_PIPOwnHeading.GetRawValue();
			m_InPIPData.oOwnboat.fDriftCourse.Value = m_simControl.m_GUIData.m_PIPOwnDriftCourse.GetRawValue();
			m_InPIPData.oOwnboat.fSpeed.Value = m_simControl.m_GUIData.m_PIPOwnSpeed.GetRawValue();
			m_InPIPData.oOwnboat.fDriftSpeed.Value = m_simControl.m_GUIData.m_PIPOwnDriftSpeed.GetRawValue();
			m_InPIPData.oOwnboat.bType.Value = m_simControl.m_GUIData.m_PIPOwnType.GetRawValue();

			m_InPIPData.oOwnboat.bWhipAerial.Value = m_simControl.m_GUIData.m_PIPOwnWhipAerialUp.GetRawValue();
			m_InPIPData.oOwnboat.bEmLight.Value = m_simControl.m_GUIData.m_PIPOwnEmerLightUp.GetRawValue()    ;
			m_InPIPData.oOwnboat.bDieselSmoke.Value = m_simControl.m_GUIData.m_PIPOwnDieselSmoke.GetRawValue();

			m_InPIPData.oOwnboat.bRESM.Value = m_simControl.m_GUIData.m_PIPOwnMastRESM.GetRawValue();
			m_InPIPData.oOwnboat.bWTComms.Value = m_simControl.m_GUIData.m_PIPOwnMastWTComms.GetRawValue();
			m_InPIPData.oOwnboat.bCESM.Value = m_simControl.m_GUIData.m_PIPOwnMastHFDF.GetRawValue();
			m_InPIPData.oOwnboat.bAttackPeriscope.Value = m_simControl.m_GUIData.m_PIPOwnMastAttack.GetRawValue();
			m_InPIPData.oOwnboat.bRadar.Value = m_simControl.m_GUIData.m_PIPOwnMastRadar.GetRawValue();
			m_InPIPData.oOwnboat.bSnortInduction.Value = m_simControl.m_GUIData.m_PIPOwnMastSnortInd.GetRawValue();
			m_InPIPData.oOwnboat.bSnortExhaust.Value = m_simControl.m_GUIData.m_PIPOwnMastSnortExh.GetRawValue();

			// Target
			for(int i=0; i < m_InPIPData.oTarget.Length; i++)
			{

				m_InPIPData.oTarget[i].iTargetNum.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarModelID.GetRawValue();
				m_InPIPData.oTarget[i].iSlotID.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarSlotID.GetRawValue();
				m_InPIPData.oTarget[i].fX.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarX.GetRawValue();
				m_InPIPData.oTarget[i].fY.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarY.GetRawValue();
				m_InPIPData.oTarget[i].fDepth.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarHeight.GetRawValue();
				m_InPIPData.oTarget[i].fClimbRate.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarClimbRate.GetRawValue();
				m_InPIPData.oTarget[i].fTurnRate.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarTurnRate.GetRawValue();
				m_InPIPData.oTarget[i].fPitch.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarPitch.GetRawValue();
				m_InPIPData.oTarget[i].fHeading.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarHeading.GetRawValue();
				m_InPIPData.oTarget[i].fDriftCourse.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarDriftCourse.GetRawValue();
				m_InPIPData.oTarget[i].fSpeed.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarSpeed.GetRawValue();
				m_InPIPData.oTarget[i].fDriftSpeed.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarDriftSpeed.GetRawValue();
	            m_InPIPData.oTarget[i].bDunkingSonar.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarDunkingData.GetRawValue();
				m_InPIPData.oTarget[i].bLightConfig.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarLightConfig.GetRawValue();
				m_InPIPData.oTarget[i].bSpotLightConfig.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarSpotConfig.GetRawValue();
				m_InPIPData.oTarget[i].bVisible.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarPresent.GetRawValue();
				m_InPIPData.oTarget[i].bExplosion.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarFlames.GetRawValue();
				m_InPIPData.oTarget[i].bMissileExplosion.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarMissileHit.GetRawValue();
				m_InPIPData.oTarget[i].bTorpedoExplosion.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarTorpedoHit.GetRawValue();
				m_InPIPData.oTarget[i].bSinking.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarSinking.GetRawValue();
				m_InPIPData.oTarget[i].bNavLights.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarNavLights.GetRawValue();
				m_InPIPData.oTarget[i].bSonarDunking.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarDunkingSonar.GetRawValue();
				m_InPIPData.oTarget[i].bDunkingSonar.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarDunkingData.GetRawValue();
				m_InPIPData.oTarget[i].bLightConfig.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarLightConfig.GetRawValue();
				m_InPIPData.oTarget[i].bSpotLightConfig.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarSpotConfig.GetRawValue();
				m_InPIPData.oTarget[i].bDieselSmoke.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarDieselSmoke.GetRawValue();
				m_InPIPData.oTarget[i].bMissileLaunch.Value = m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarFireMissile.GetRawValue();
			}

			// Return Data
			m_InPIPData.oReturn.bMastPosition.Value = m_simControl.m_GUIData.m_PIPRetSearchUp.GetRawValue();
			m_InPIPData.oReturn.bTIHotControl.Value = m_simControl.m_GUIData.m_PIPRetPolarityWhite.GetRawValue();
			m_InPIPData.oReturn.bMagnification.Value = m_simControl.m_GUIData.m_PIPRetHighMag.GetRawValue();
			m_InPIPData.oReturn.bLLTVGain.Value = m_simControl.m_GUIData.m_PIPRetPeriLLTVGain.GetRawValue();
			m_InPIPData.oReturn.bTIGain.Value = m_simControl.m_GUIData.m_PIPRetPeriTIGain.GetRawValue();

			m_InPIPData.oReturn.fPeriTrueBrg.Value = m_simControl.m_GUIData.m_PIPRetTWSHPeriTrueBrg.GetRawValue();
			m_InPIPData.oReturn.fTargetTrueBrg.Value = m_simControl.m_GUIData.m_PIPRetTWSHTarTrueBrg.GetRawValue();
			m_InPIPData.oReturn.fTargetTrueBrgCut.Value = m_simControl.m_GUIData.m_PIPRetTWSHTarTrueBrgCut.GetRawValue();
			m_InPIPData.oReturn.fTargetRange.Value = m_simControl.m_GUIData.m_PIPRetTWSHTarRange.GetRawValue();
			m_InPIPData.oReturn.fTargetRangeCut.Value = m_simControl.m_GUIData.m_PIPRetTWSHTarRangeCut.GetRawValue();
			m_InPIPData.oReturn.fElapsedTime.Value = m_simControl.m_GUIData.m_PIPRetTWSHTarElpsdTime.GetRawValue();
			m_InPIPData.oReturn.fElapsedTimeCut.Value = m_simControl.m_GUIData.m_PIPRetTWSHTarElpsdTimeCut.GetRawValue();

			m_InPIPData.oReturn.fPeriRelBrg.Value = m_simControl.m_GUIData.m_PIPRetPeriRelBrg.GetRawValue();
			m_InPIPData.oReturn.fElevation.Value = m_simControl.m_GUIData.m_PIPRetPeriElev.GetRawValue();
			m_InPIPData.oReturn.fSunBearing.Value = m_simControl.m_GUIData.m_PIPRetPeriSunBrg.GetRawValue();
			m_InPIPData.oReturn.fSunElevation.Value = m_simControl.m_GUIData.m_PIPRetPeriSunElev.GetRawValue();
			m_InPIPData.oReturn.iPSCErrorNumber.Value = m_simControl.m_GUIData.m_PIPRetPeriErrorNo.GetRawValue();
			m_InPIPData.oReturn.strPSCErrorString.Value = m_simControl.m_GUIData.m_PIPRetPeriErrorString.GetRawValue();

            m_InPIPData.oReturn.iPolynias.Value = m_simControl.m_GUIData.m_PIPRetNumPolynia.GetRawValue();

            // Polynia Data
			for(int i = 0 ; i < SIMControl.NUM_POLYNIA_TARGETS; i++)
			{
				m_InPIPData.oReturn.polyniaData[i].iPolyniaID.Value = m_simControl.m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolIdentity.GetRawValue();
				m_InPIPData.oReturn.polyniaData[i].bIceField.Value = m_simControl.m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolPresent.GetRawValue();
				m_InPIPData.oReturn.polyniaData[i].fX.Value = m_simControl.m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolX.GetRawValue();
				m_InPIPData.oReturn.polyniaData[i].fY.Value = m_simControl.m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolY.GetRawValue();
				m_InPIPData.oReturn.polyniaData[i].fZ.Value = m_simControl.m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolZ.GetRawValue();
				m_InPIPData.oReturn.polyniaData[i].fOrientation.Value = m_simControl.m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolOrientation.GetRawValue();
			}


			//
			// Update the PIG data
			//

			m_InPIGData.oPIGExercise.iSystemID.Value = m_simControl.m_GUIData.m_PIGExSystemID.GetRawValue();
			m_InPIGData.oPIGExercise.iRunMode.Value = m_simControl.m_GUIData.m_PIGExRunMode.GetRawValue();

			m_InPIGData.oPIGEnvironment.bMoon.Value = m_simControl.m_GUIData.m_PIGEnvMoonOverride.GetRawValue();
			m_InPIGData.oPIGEnvironment.bCoastLights.Value = m_simControl.m_GUIData.m_PIGEnvCoastLights.GetRawValue();
			m_InPIGData.oPIGEnvironment.bIceEdge.Value = m_simControl.m_GUIData.m_PIGEnvIceEdgeOn.GetRawValue();
			m_InPIGData.oPIGEnvironment.bRemoteSun.Value = m_simControl.m_GUIData.m_PIGEnvSunOverride.GetRawValue();
			m_InPIGData.oPIGEnvironment.bHours.Value = m_simControl.m_GUIData.m_PIGEnvHours.GetRawValue();
			m_InPIGData.oPIGEnvironment.bMinutes.Value = m_simControl.m_GUIData.m_PIGEnvMins.GetRawValue();


			m_InPIGData.oPIGEnvironment.bSeconds.Value = m_simControl.m_GUIData.m_PIGEnvSecs.GetRawValue();
			m_InPIGData.oPIGEnvironment.bDay.Value = m_simControl.m_GUIData.m_PIGEnvDay.GetRawValue();
			m_InPIGData.oPIGEnvironment.bMonth.Value = m_simControl.m_GUIData.m_PIGEnvMonth.GetRawValue();
			m_InPIGData.oPIGEnvironment.bYear.Value = m_simControl.m_GUIData.m_PIGEnvYear.GetRawValue();
			m_InPIGData.oPIGEnvironment.bWeather.Value = m_simControl.m_GUIData.m_PIGEnvWeather.GetRawValue();
			m_InPIGData.oPIGEnvironment.bCoastline.Value = m_simControl.m_GUIData.m_PIGEnvCoastline.GetRawValue();
			m_InPIGData.oPIGEnvironment.bSeaState.Value = m_simControl.m_GUIData.m_PIGEnvSeaState.GetRawValue();
			m_InPIGData.oPIGEnvironment.fVisibleRange.Value = m_simControl.m_GUIData.m_PIGEnvVisualRange.GetRawValue();
			m_InPIGData.oPIGEnvironment.fThermalRange.Value = m_simControl.m_GUIData.m_PIGEnvThermalRange.GetRawValue();
			m_InPIGData.oPIGEnvironment.fUnderwaterVis.Value = m_simControl.m_GUIData.m_PIGEnvUnderWaterRange.GetRawValue();
			m_InPIGData.oPIGEnvironment.fWindSpeed.Value = m_simControl.m_GUIData.m_PIGEnvWindSpeed.GetRawValue();
			m_InPIGData.oPIGEnvironment.fWindDirection.Value = m_simControl.m_GUIData.m_PIGEnvWindDirn.GetRawValue();
			m_InPIGData.oPIGEnvironment.fMoonBearing.Value = m_simControl.m_GUIData.m_PIGEnvMoonBrgOverRide.GetRawValue();
			m_InPIGData.oPIGEnvironment.fMoonAltitude.Value = m_simControl.m_GUIData.m_PIGEnvMoonElevOverRide.GetRawValue();
			m_InPIGData.oPIGEnvironment.fSunBearing.Value = m_simControl.m_GUIData.m_PIGEnvSunBrgOverRide.GetRawValue();
			m_InPIGData.oPIGEnvironment.fSunAltitude.Value = m_simControl.m_GUIData.m_PIGEnvSunElevOverRide.GetRawValue();
			m_InPIGData.oPIGEnvironment.fIceEdgeLat.Value = m_simControl.m_GUIData.m_PIGEnvIceEdgeLat.GetRawValue();
			m_InPIGData.oPIGEnvironment.fIceEdgeLong.Value = m_simControl.m_GUIData.m_PIGEnvIceEdgeLon.GetRawValue();
			m_InPIGData.oPIGEnvironment.fIceFloe.Value = m_simControl.m_GUIData.m_PIGEnvIceEdgeOrien.GetRawValue();

			m_InPIGData.oPIGOwnship.bType.Value = m_simControl.m_GUIData.m_PIGOwnType.GetRawValue();
			m_InPIGData.oPIGOwnship.bSmoke.Value = m_simControl.m_GUIData.m_PIGOwnSmoke.GetRawValue();
			m_InPIGData.oPIGOwnship.fLatitude.Value = m_simControl.m_GUIData.m_PIGOwnLatitude.GetRawValue();
			m_InPIGData.oPIGOwnship.fLogitude.Value = m_simControl.m_GUIData.m_PIGOwnLongitude.GetRawValue();
			m_InPIGData.oPIGOwnship.fX.Value = m_simControl.m_GUIData.m_PIGOwnX.GetRawValue();
			m_InPIGData.oPIGOwnship.fY.Value = m_simControl.m_GUIData.m_PIGOwnY.GetRawValue();
			m_InPIGData.oPIGOwnship.fDepth.Value = m_simControl.m_GUIData.m_PIGOwnDepth.GetRawValue();
			m_InPIGData.oPIGOwnship.fHeading.Value = m_simControl.m_GUIData.m_PIGOwnHeading.GetRawValue();
			m_InPIGData.oPIGOwnship.fRoll.Value = m_simControl.m_GUIData.m_PIGOwnRoll.GetRawValue();
			m_InPIGData.oPIGOwnship.fPitch.Value = m_simControl.m_GUIData.m_PIGOwnPitch.GetRawValue();
			m_InPIGData.oPIGOwnship.fSpeed.Value = m_simControl.m_GUIData.m_PIGOwnSpeed.GetRawValue();

			for(int i=0; i < 10 ; i++)
				m_InPIGData.oPIGOwnship.mast[i].Value = m_simControl.m_GUIData.m_PIGOwnMast[i].GetRawValue();

			m_InPIGData.oPIGPeriscope.bSensorType.Value = m_simControl.m_GUIData.m_PIGPeriSensor.GetRawValue();
			m_InPIGData.oPIGPeriscope.bMagnification.Value = m_simControl.m_GUIData.m_PIGPeriMagnification.GetRawValue();
			m_InPIGData.oPIGPeriscope.bSensorGain.Value = m_simControl.m_GUIData.m_PIGPeriGain.GetRawValue();
			m_InPIGData.oPIGPeriscope.bSensorContrast.Value = m_simControl.m_GUIData.m_PIGPeriContrast.GetRawValue();
			m_InPIGData.oPIGPeriscope.bGraticuleInt.Value = m_simControl.m_GUIData.m_PIGPeriGratIntensity.GetRawValue();
			m_InPIGData.oPIGPeriscope.bDraindownTime.Value = m_simControl.m_GUIData.m_PIGPeriDraindown.GetRawValue();
			m_InPIGData.oPIGPeriscope.fRelativeBearing.Value = m_simControl.m_GUIData.m_PIGPeriRelBrg.GetRawValue();
			m_InPIGData.oPIGPeriscope.fElevation.Value = m_simControl.m_GUIData.m_PIGPeriElevation.GetRawValue();
			m_InPIGData.oPIGPeriscope.fStadElev.Value = m_simControl.m_GUIData.m_PIGPeriStadAngle.GetRawValue();

			for (int i = 0; i < SIMControl.NUM_PERI_TARGETS ; i++)
			{
				m_InPIGData.oPIGTarget[i].bVisible.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarPresent.GetRawValue();
				m_InPIGData.oPIGTarget[i].bNavLights.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarNavLights.GetRawValue();
				m_InPIGData.oPIGTarget[i].bMissileImpact.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarMissileHit.GetRawValue();
				m_InPIGData.oPIGTarget[i].bTorpedoImpact.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarTorpedoHit.GetRawValue();
				m_InPIGData.oPIGTarget[i].bSinking.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarSinking.GetRawValue();
				m_InPIGData.oPIGTarget[i].bSonarDunking.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarDunkingSonar.GetRawValue();
				m_InPIGData.oPIGTarget[i].bTLAMLaunch.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarTLAM.GetRawValue();
				m_InPIGData.oPIGTarget[i].bExplosion.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarFlames.GetRawValue();
				m_InPIGData.oPIGTarget[i].bDieselSmoke.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarDieselSmoke.GetRawValue();
				m_InPIGData.oPIGTarget[i].bMissileLaunch.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarFireMissile.GetRawValue();

				m_InPIGData.oPIGTarget[i].sModelID.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarModelID.GetRawValue();
				m_InPIGData.oPIGTarget[i].sTargetNum.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarSlotNum.GetRawValue();
				m_InPIGData.oPIGTarget[i].bSpotlightConfig.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarSpotConfig.GetRawValue();
				m_InPIGData.oPIGTarget[i].bLightConfig.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarLightConfig.GetRawValue();
				m_InPIGData.oPIGTarget[i].fX.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarX.GetRawValue();
				m_InPIGData.oPIGTarget[i].fY.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarY.GetRawValue();
				m_InPIGData.oPIGTarget[i].fHeight.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarHeight.GetRawValue();
				m_InPIGData.oPIGTarget[i].fHeading.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarHeading.GetRawValue();
				m_InPIGData.oPIGTarget[i].fRoll.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarRoll.GetRawValue();
				m_InPIGData.oPIGTarget[i].fPitch.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarPitch.GetRawValue();
				m_InPIGData.oPIGTarget[i].fSpeed.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarSpeed.GetRawValue();
				m_InPIGData.oPIGTarget[i].fAcceleration.Value = m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarAccel.GetRawValue();
			}

			m_InPIGData.oPIGReturn.lModelStat.Value = m_simControl.m_GUIData.m_PIGRetModelStat.GetRawValue();
			m_InPIGData.oPIGReturn.lProcStat.Value = m_simControl.m_GUIData.m_PIGRetProcStat.GetRawValue();
			m_InPIGData.oPIGReturn.lSonarContacts.Value = m_simControl.m_GUIData.m_PIGRetPolyniaNum.GetRawValue();

			for (int i = 0; i < SIMControl.NUM_POLYNIA_TARGETS ; i++)
			{
				m_InPIGData.oPIGReturn.SonarData[i].identity.Value = m_simControl.m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolIdentity.GetRawValue();
				m_InPIGData.oPIGReturn.SonarData[i].orientation.Value = m_simControl.m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolOrien.GetRawValue();
				m_InPIGData.oPIGReturn.SonarData[i].slotNumber.Value = m_simControl.m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolSlotNum.GetRawValue();
				m_InPIGData.oPIGReturn.SonarData[i].x_offset.Value = m_simControl.m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolX.GetRawValue();
				m_InPIGData.oPIGReturn.SonarData[i].y_offset.Value = m_simControl.m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolY.GetRawValue();
				m_InPIGData.oPIGReturn.SonarData[i].z_offset.Value = m_simControl.m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolZ.GetRawValue();
			}

			//
			//Update the IO Data.
			//

			// Values
			m_InIOData.m_fBearing.Value = m_simControl.m_GUIData.m_IOBearing.GetRawValue();
			m_InIOData.m_fElevation.Value = m_simControl.m_GUIData.m_IOElevation.GetRawValue();
			m_InIOData.m_fStadAngle.Value = m_simControl.m_GUIData.m_IOStadAngle.GetRawValue();
			m_InIOData.m_fTiBlackLevel.Value = m_simControl.m_GUIData.m_IOTiBlackLevel.GetRawValue();
			m_InIOData.m_fTiSensitivity.Value = m_simControl.m_GUIData.m_IOTiSensitivity.GetRawValue();
			m_InIOData.m_fTiGratIllum.Value = m_simControl.m_GUIData.m_IOTiGratIllum.GetRawValue();
			m_InIOData.m_fRearStadAngle.Value = m_simControl.m_GUIData.m_IORearStadAngle.GetRawValue();
			m_InIOData.m_fRearTrueBrg.Value = m_simControl.m_GUIData.m_IORearTrueBrg.GetRawValue();
			m_InIOData.m_fRearRelBrg.Value = m_simControl.m_GUIData.m_IORearRelBrg.GetRawValue();
			m_InIOData.m_fDisplayBrg.Value = m_simControl.m_GUIData.m_IODisplayBrg.GetRawValue();
			m_InIOData.m_fDisplayElev.Value = m_simControl.m_GUIData.m_IODisplayElev.GetRawValue();
			m_InIOData.m_fDisplayTar.Value = m_simControl.m_GUIData.m_IODisplayTar.GetRawValue();
			m_InIOData.m_bHandlesDown.Value = m_simControl.m_GUIData.m_IOHandlesDown.GetRawValue();
			m_InIOData.m_bMagnification.Value = m_simControl.m_GUIData.m_IOHighMag.GetRawValue();
			m_InIOData.m_bRangeCut.Value = m_simControl.m_GUIData.m_IORangeCut.GetRawValue();
			m_InIOData.m_bBearingCut.Value = m_simControl.m_GUIData.m_IOBearingCut.GetRawValue();
			m_InIOData.m_bPushToTalk.Value = m_simControl.m_GUIData.m_IOPushToTalk.GetRawValue();
			m_InIOData.m_iModeSelect.Value = m_simControl.m_GUIData.m_IOModeSelect.GetRawValue();
			m_InIOData.m_bDataOverlay.Value = m_simControl.m_GUIData.m_IODataOverlay.GetRawValue();
			m_InIOData.m_bTiOnIndicator.Value = m_simControl.m_GUIData.m_IOTiOnIndicator.GetRawValue();
			m_InIOData.m_bTarHeight.Value = m_simControl.m_GUIData.m_IOTarHeight.GetRawValue();
			m_InIOData.m_fBeckmanTrue.Value = m_simControl.m_GUIData.m_IOBeckmanTrue.GetRawValue();
			m_InIOData.m_fBeckmanRel.Value = m_simControl.m_GUIData.m_IOBeckmanRel.GetRawValue();


			// Status
			m_InIOData.m_fBearing.Status = m_simControl.m_GUIData.m_IOBearing.GetStatus();
			m_InIOData.m_fElevation.Status = m_simControl.m_GUIData.m_IOElevation.GetStatus();
			m_InIOData.m_fStadAngle.Status = m_simControl.m_GUIData.m_IOStadAngle.GetStatus();
			m_InIOData.m_fTiBlackLevel.Status = m_simControl.m_GUIData.m_IOTiBlackLevel.GetStatus();
			m_InIOData.m_fTiSensitivity.Status = m_simControl.m_GUIData.m_IOTiSensitivity.GetStatus();
			m_InIOData.m_fTiGratIllum.Status = m_simControl.m_GUIData.m_IOTiGratIllum.GetStatus();
			m_InIOData.m_fRearStadAngle.Status = m_simControl.m_GUIData.m_IORearStadAngle.GetStatus();
			m_InIOData.m_fRearTrueBrg.Status = m_simControl.m_GUIData.m_IORearTrueBrg.GetStatus();
			m_InIOData.m_fRearRelBrg.Status = m_simControl.m_GUIData.m_IORearRelBrg.GetStatus();
			m_InIOData.m_fDisplayBrg.Status = m_simControl.m_GUIData.m_IODisplayBrg.GetStatus();
			m_InIOData.m_fDisplayElev.Status = m_simControl.m_GUIData.m_IODisplayElev.GetStatus();
			m_InIOData.m_fDisplayTar.Status = m_simControl.m_GUIData.m_IODisplayTar.GetStatus();
			m_InIOData.m_bHandlesDown.Status = m_simControl.m_GUIData.m_IOHandlesDown.GetStatus();
			m_InIOData.m_bMagnification.Status = m_simControl.m_GUIData.m_IOHighMag.GetStatus();
			m_InIOData.m_bRangeCut.Status = m_simControl.m_GUIData.m_IORangeCut.GetStatus();
			m_InIOData.m_bBearingCut.Status = m_simControl.m_GUIData.m_IOBearingCut.GetStatus();
			m_InIOData.m_bPushToTalk.Status = m_simControl.m_GUIData.m_IOPushToTalk.GetStatus();
			m_InIOData.m_iModeSelect.Status = m_simControl.m_GUIData.m_IOModeSelect.GetStatus();
			m_InIOData.m_bDataOverlay.Status = m_simControl.m_GUIData.m_IODataOverlay.GetStatus();
			m_InIOData.m_bTiOnIndicator.Status = m_simControl.m_GUIData.m_IOTiOnIndicator.GetStatus();
			m_InIOData.m_bTarHeight.Status = m_simControl.m_GUIData.m_IOTarHeight.GetStatus();
			m_InIOData.m_fBeckmanTrue.Status = m_simControl.m_GUIData.m_IOBeckmanTrue.GetStatus();
			m_InIOData.m_fBeckmanRel.Status = m_simControl.m_GUIData.m_IOBeckmanRel.GetStatus();

			m_InIOData.m_status = m_simControl.m_GUIData.m_SIMStatusIO;


			//
			// Update the Network Status Data.
			//
			m_InPIPData.oNetworkStatus.m_AverageTime = m_simControl.m_GUIData.m_PIPAverageTimeIn;
			m_InPIPData.oNetworkStatus.m_Bytes       = m_simControl.m_GUIData.m_PIPBytesIn;
			m_InPIPData.oNetworkStatus.m_MessageCount= m_simControl.m_GUIData.m_PIPMessageCountIn;

			m_OutPIPData.oNetworkStatus.m_AverageTime = m_simControl.m_GUIData.m_PIPAverageTimeOut;
			m_OutPIPData.oNetworkStatus.m_Bytes       = m_simControl.m_GUIData.m_PIPBytesOut;
			m_OutPIPData.oNetworkStatus.m_MessageCount= m_simControl.m_GUIData.m_PIPMessageCountOut;

			m_InPIGData.oNetworkStatus.m_AverageTime = m_simControl.m_GUIData.m_PIGAverageTimeIn;
			m_InPIGData.oNetworkStatus.m_Bytes       = m_simControl.m_GUIData.m_PIGBytesIn;
			m_InPIGData.oNetworkStatus.m_MessageCount= m_simControl.m_GUIData.m_PIGMessageCountIn;

			m_OutPIGData.oNetworkStatus.m_AverageTime = m_simControl.m_GUIData.m_PIGAverageTimeOut;
			m_OutPIGData.oNetworkStatus.m_Bytes       = m_simControl.m_GUIData.m_PIGBytesOut;
			m_OutPIGData.oNetworkStatus.m_MessageCount= m_simControl.m_GUIData.m_PIGMessageCountOut;

			//
			// Update the Error Log Data
			//
			m_ErrorLog.m_ErrorLogIndex = m_simControl.m_GUIData.m_SIMErrorLogIndex;

			for(int i=0; i < SIMControl.SIM_ERRORLOG_SIZE; i++)
			{
			   m_ErrorLog.m_ErrorLog[i].m_ErrorSource = m_simControl.m_GUIData.m_SIMErrorLog[i].m_ErrorSource;
			   m_ErrorLog.m_ErrorLog[i].m_ErrorTime   = m_simControl.m_GUIData.m_SIMErrorLog[i].m_ErrorTime;
			   m_ErrorLog.m_ErrorLog[i].m_ErrorType   = m_simControl.m_GUIData.m_SIMErrorLog[i].m_ErrorType;
			}
		}



		public void updateToSimControl()
		{
			//
			// Update the PIP data
			//

			// Exercise
			m_simControl.m_GUIData.m_PIPExRunMode.SetOverride(m_OutPIPData.oExercise.bRunMode);
			m_simControl.m_GUIData.m_PIPExHours.SetOverride(m_OutPIPData.oExercise.hours);
			m_simControl.m_GUIData.m_PIPExMins.SetOverride(m_OutPIPData.oExercise.minutes);
			m_simControl.m_GUIData.m_PIPExSecs.SetOverride(m_OutPIPData.oExercise.seconds);
			m_simControl.m_GUIData.m_PIPExDay.SetOverride(m_OutPIPData.oExercise.day);
			m_simControl.m_GUIData.m_PIPExMonth.SetOverride(m_OutPIPData.oExercise.month);
			m_simControl.m_GUIData.m_PIPExYear.SetOverride(m_OutPIPData.oExercise.year);

			// Periscope
		    m_simControl.m_GUIData.m_PIPPeriInstructCtrl.SetOverride(m_OutPIPData.oPeriscope.bInstructor);
			m_simControl.m_GUIData.m_PIPPeriSearchUp.SetOverride(m_OutPIPData.oPeriscope.bMast);
			m_simControl.m_GUIData.m_PIPPeriPolarityWhite.SetOverride(m_OutPIPData.oPeriscope.bTiHotControl);
			m_simControl.m_GUIData.m_PIPPeriHighMag.SetOverride(m_OutPIPData.oPeriscope.bMagnification);
			m_simControl.m_GUIData.m_PIPPeriDraindown.SetOverride(m_OutPIPData.oPeriscope.bDrainDownTime);
			m_simControl.m_GUIData.m_PIPPeriLLTVGain.SetOverride(m_OutPIPData.oPeriscope.bLLTVGain);
			m_simControl.m_GUIData.m_PIPPeriThermalGain.SetOverride(m_OutPIPData.oPeriscope.bTIGain);
            m_simControl.m_GUIData.m_PIPPeriRelBearing.SetOverride(m_OutPIPData.oPeriscope.fRelBrg);
            m_simControl.m_GUIData.m_PIPPeriElevation.SetOverride(m_OutPIPData.oPeriscope.fElevation);

			// Environment
			m_simControl.m_GUIData.m_PIPEnvMoonOverride.SetOverride(m_OutPIPData.oEnvironment.bMoon);
			m_simControl.m_GUIData.m_PIPEnvCoastLights.SetOverride(m_OutPIPData.oEnvironment.bCoastLights);
			m_simControl.m_GUIData.m_PIPEnvIceEdgeOn.SetOverride(m_OutPIPData.oEnvironment.bIceEdge);
			m_simControl.m_GUIData.m_PIPEnvSunOverride.SetOverride(m_OutPIPData.oEnvironment.bRemoteSun);
			m_simControl.m_GUIData.m_PIPEnvWeather.SetOverride(m_OutPIPData.oEnvironment.bVisibility);
			m_simControl.m_GUIData.m_PIPEnvCoastline.SetOverride(m_OutPIPData.oEnvironment.bCoastline);
			m_simControl.m_GUIData.m_PIPEnvSeaState.SetOverride(m_OutPIPData.oEnvironment.bSeaState);
			m_simControl.m_GUIData.m_PIPEnvMoonBrg.SetOverride(m_OutPIPData.oEnvironment.fMoonBearing);
			m_simControl.m_GUIData.m_PIPEnvMoonElev.SetOverride(m_OutPIPData.oEnvironment.fMoonElevation);
			m_simControl.m_GUIData.m_PIPEnvVisualRange.SetOverride(m_OutPIPData.oEnvironment.fVisualRange);
			m_simControl.m_GUIData.m_PIPEnvUnderWaterRange.SetOverride(m_OutPIPData.oEnvironment.fUWVisualRange);
			m_simControl.m_GUIData.m_PIPEnvThermalRange.SetOverride(m_OutPIPData.oEnvironment.fTIRange);
			m_simControl.m_GUIData.m_PIPEnvWindSpeed.SetOverride(m_OutPIPData.oEnvironment.fWindSpeed);
			m_simControl.m_GUIData.m_PIPEnvWindHeading.SetOverride(m_OutPIPData.oEnvironment.fWindHeading);
			m_simControl.m_GUIData.m_PIPEnvIceLat.SetOverride(m_OutPIPData.oEnvironment.fIceLat);
			m_simControl.m_GUIData.m_PIPEnvIceLon.SetOverride(m_OutPIPData.oEnvironment.fIceLong);
			m_simControl.m_GUIData.m_PIPEnvIceOrien.SetOverride(m_OutPIPData.oEnvironment.fIceOrientation);
			m_simControl.m_GUIData.m_PIPEnvSunBrg.SetOverride(m_OutPIPData.oEnvironment.fSunBearing);
			m_simControl.m_GUIData.m_PIPEnvSunElev.SetOverride(m_OutPIPData.oEnvironment.fSunElevation);

			// Ownship
            m_simControl.m_GUIData.m_PIPOwnLat.SetOverride(m_OutPIPData.oOwnboat.dfLatitude);
            m_simControl.m_GUIData.m_PIPOwnLon.SetOverride(m_OutPIPData.oOwnboat.dfLongitude);
            m_simControl.m_GUIData.m_PIPOwnDepth.SetOverride(m_OutPIPData.oOwnboat.fDepth);
            m_simControl.m_GUIData.m_PIPOwnClimbRate.SetOverride(m_OutPIPData.oOwnboat.fClimbRate);
			m_simControl.m_GUIData.m_PIPOwnTurnRate.SetOverride(m_OutPIPData.oOwnboat.fTurnRate);
			m_simControl.m_GUIData.m_PIPOwnPitch.SetOverride(m_OutPIPData.oOwnboat.fPitch);
			m_simControl.m_GUIData.m_PIPOwnHeading.SetOverride(m_OutPIPData.oOwnboat.fHeading);
			m_simControl.m_GUIData.m_PIPOwnDriftCourse.SetOverride(m_OutPIPData.oOwnboat.fDriftCourse);
			m_simControl.m_GUIData.m_PIPOwnSpeed.SetOverride(m_OutPIPData.oOwnboat.fSpeed);
			m_simControl.m_GUIData.m_PIPOwnDriftSpeed.SetOverride(m_OutPIPData.oOwnboat.fDriftSpeed);
			m_simControl.m_GUIData.m_PIPOwnWhipAerialUp.SetOverride(m_OutPIPData.oOwnboat.bWhipAerial);
			m_simControl.m_GUIData.m_PIPOwnEmerLightUp.SetOverride(m_OutPIPData.oOwnboat.bEmLight);
			m_simControl.m_GUIData.m_PIPOwnDieselSmoke.SetOverride(m_OutPIPData.oOwnboat.bDieselSmoke);
			m_simControl.m_GUIData.m_PIPOwnMastRESM.SetOverride(m_OutPIPData.oOwnboat.bRESM);
			m_simControl.m_GUIData.m_PIPOwnMastWTComms.SetOverride(m_OutPIPData.oOwnboat.bWTComms);
			m_simControl.m_GUIData.m_PIPOwnMastHFDF.SetOverride(m_OutPIPData.oOwnboat.bCESM);
			m_simControl.m_GUIData.m_PIPOwnMastAttack.SetOverride(m_OutPIPData.oOwnboat.bAttackPeriscope);
			m_simControl.m_GUIData.m_PIPOwnMastRadar.SetOverride(m_OutPIPData.oOwnboat.bRadar);
			m_simControl.m_GUIData.m_PIPOwnMastSnortInd.SetOverride(m_OutPIPData.oOwnboat.bSnortInduction);
			m_simControl.m_GUIData.m_PIPOwnMastSnortExh.SetOverride(m_OutPIPData.oOwnboat.bSnortExhaust);
			m_simControl.m_GUIData.m_PIPOwnType.SetOverride(m_OutPIPData.oOwnboat.bType);

			// Target
			for(int i=0; i < m_simControl.m_GUIData.m_PIPTargets.Length; i++)
			{
                m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarDunkingData.SetOverride(m_OutPIPData.oTarget[i].bDunkingSonar);
                m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarLightConfig.SetOverride(m_OutPIPData.oTarget[i].bLightConfig);
                m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarSpotConfig.SetOverride(m_OutPIPData.oTarget[i].bSpotLightConfig);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarModelID.SetOverride(m_OutPIPData.oTarget[i].iTargetNum);

				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarSlotID.SetOverride(m_OutPIPData.oTarget[i].iSlotID);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarX.SetOverride(m_OutPIPData.oTarget[i].fX);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarY.SetOverride(m_OutPIPData.oTarget[i].fY);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarHeight.SetOverride(m_OutPIPData.oTarget[i].fDepth);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarClimbRate.SetOverride(m_OutPIPData.oTarget[i].fClimbRate);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarTurnRate.SetOverride(m_OutPIPData.oTarget[i].fTurnRate);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarPitch.SetOverride(m_OutPIPData.oTarget[i].fPitch );
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarHeading.SetOverride(m_OutPIPData.oTarget[i].fHeading);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarDriftCourse.SetOverride(m_OutPIPData.oTarget[i].fDriftCourse);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarSpeed.SetOverride(m_OutPIPData.oTarget[i].fSpeed);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarDriftSpeed.SetOverride(m_OutPIPData.oTarget[i].fDriftSpeed);

				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarPresent.SetOverride(m_OutPIPData.oTarget[i].bVisible);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarFlames.SetOverride(m_OutPIPData.oTarget[i].bExplosion);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarMissileHit.SetOverride(m_OutPIPData.oTarget[i].bMissileExplosion);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarTorpedoHit.SetOverride(m_OutPIPData.oTarget[i].bTorpedoExplosion);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarSinking.SetOverride(m_OutPIPData.oTarget[i].bSinking);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarNavLights.SetOverride(m_OutPIPData.oTarget[i].bNavLights);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarDunkingData.SetOverride(m_OutPIPData.oTarget[i].bDunkingSonar);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarDunkingSonar.SetOverride(m_OutPIPData.oTarget[i].bSonarDunking);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarLightConfig.SetOverride(m_OutPIPData.oTarget[i].bLightConfig);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarSpotConfig.SetOverride(m_OutPIPData.oTarget[i].bSpotLightConfig);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarDieselSmoke.SetOverride(m_OutPIPData.oTarget[i].bDieselSmoke);
				m_simControl.m_GUIData.m_PIPTargets[i].m_PIPTarFireMissile.SetOverride(m_OutPIPData.oTarget[i].bMissileLaunch);
			}

			// Return
			m_simControl.m_GUIData.m_PIPRetSearchUp.SetOverride(m_OutPIPData.oReturn.bMastPosition);
			m_simControl.m_GUIData.m_PIPRetPolarityWhite.SetOverride(m_OutPIPData.oReturn.bTIHotControl);
			m_simControl.m_GUIData.m_PIPRetHighMag.SetOverride(m_OutPIPData.oReturn.bMagnification);

			m_simControl.m_GUIData.m_PIPRetPeriLLTVGain.SetOverride(m_OutPIPData.oReturn.bLLTVGain);
			m_simControl.m_GUIData.m_PIPRetPeriTIGain.SetOverride(m_OutPIPData.oReturn.bTIGain);

			m_simControl.m_GUIData.m_PIPRetTWSHPeriTrueBrg.SetOverride(m_OutPIPData.oReturn.fPeriTrueBrg);
			m_simControl.m_GUIData.m_PIPRetTWSHTarTrueBrg.SetOverride(m_OutPIPData.oReturn.fTargetTrueBrg);
			m_simControl.m_GUIData.m_PIPRetTWSHTarTrueBrgCut.SetOverride(m_OutPIPData.oReturn.fTargetTrueBrgCut);
			m_simControl.m_GUIData.m_PIPRetTWSHTarRange.SetOverride(m_OutPIPData.oReturn.fTargetRange);
			m_simControl.m_GUIData.m_PIPRetTWSHTarRangeCut.SetOverride(m_OutPIPData.oReturn.fTargetRangeCut);
			m_simControl.m_GUIData.m_PIPRetTWSHTarElpsdTime.SetOverride(m_OutPIPData.oReturn.fElapsedTime);
			m_simControl.m_GUIData.m_PIPRetTWSHTarElpsdTimeCut.SetOverride(m_OutPIPData.oReturn.fElapsedTimeCut);

			m_simControl.m_GUIData.m_PIPRetPeriRelBrg.SetOverride(m_OutPIPData.oReturn.fPeriRelBrg);
			m_simControl.m_GUIData.m_PIPRetPeriElev.SetOverride(m_OutPIPData.oReturn.fElevation);
			m_simControl.m_GUIData.m_PIPRetPeriSunBrg.SetOverride(m_OutPIPData.oReturn.fSunBearing);
			m_simControl.m_GUIData.m_PIPRetPeriSunElev.SetOverride(m_OutPIPData.oReturn.fSunElevation);

			m_simControl.m_GUIData.m_PIPRetPeriErrorNo.SetOverride(m_OutPIPData.oReturn.iPSCErrorNumber);
			m_simControl.m_GUIData.m_PIPRetPeriErrorString.SetOverride(m_OutPIPData.oReturn.strPSCErrorString);

            //C_DataStoreItemInt polynia = new C_DataStoreItemInt();
			//polynia.Value = 10;
			//polynia.Flag  = true;
			//m_simControl.m_GUIData.m_PIPRetNumPolynia.SetOverride(polynia);
			m_simControl.m_GUIData.m_PIPRetNumPolynia.SetOverride(m_OutPIPData.oReturn.iPolynias);

			for(int i = 0 ; i < SIMControl.NUM_POLYNIA_TARGETS; i++)
			{
				 m_simControl.m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolIdentity.SetOverride(m_OutPIPData.oReturn.polyniaData[i].iPolyniaID);
				 m_simControl.m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolPresent.SetOverride(m_OutPIPData.oReturn.polyniaData[i].bIceField);
				 m_simControl.m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolX.SetOverride(m_OutPIPData.oReturn.polyniaData[i].fX);
				 m_simControl.m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolY.SetOverride(m_OutPIPData.oReturn.polyniaData[i].fY);
				 m_simControl.m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolZ.SetOverride(m_OutPIPData.oReturn.polyniaData[i].fZ);
				 m_simControl.m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolOrientation.SetOverride(m_OutPIPData.oReturn.polyniaData[i].fOrientation);
			}

			//
			// Update the PIG data
			//

			// Exercise
			m_simControl.m_GUIData.m_PIGExRunMode.SetOverride(m_OutPIGData.oPIGExercise.iRunMode);
			m_simControl.m_GUIData.m_PIGExSystemID.SetOverride(m_OutPIGData.oPIGExercise.iRunMode);

			// Environment
			m_simControl.m_GUIData.m_PIGEnvMoonOverride.SetOverride(m_OutPIGData.oPIGEnvironment.bMoon);
			m_simControl.m_GUIData.m_PIGEnvCoastLights.SetOverride(m_OutPIGData.oPIGEnvironment.bCoastLights);
			m_simControl.m_GUIData.m_PIGEnvIceEdgeOn.SetOverride(m_OutPIGData.oPIGEnvironment.bIceEdge);
			m_simControl.m_GUIData.m_PIGEnvSunOverride.SetOverride(m_OutPIGData.oPIGEnvironment.bRemoteSun);
			m_simControl.m_GUIData.m_PIGEnvHours.SetOverride(m_OutPIGData.oPIGEnvironment.bHours);
			m_simControl.m_GUIData.m_PIGEnvMins.SetOverride(m_OutPIGData.oPIGEnvironment.bMinutes);
			m_simControl.m_GUIData.m_PIGEnvSecs.SetOverride(m_OutPIGData.oPIGEnvironment.bSeconds);
			m_simControl.m_GUIData.m_PIGEnvDay.SetOverride(m_OutPIGData.oPIGEnvironment.bDay);
			m_simControl.m_GUIData.m_PIGEnvMonth.SetOverride(m_OutPIGData.oPIGEnvironment.bMonth);
			m_simControl.m_GUIData.m_PIGEnvYear.SetOverride(m_OutPIGData.oPIGEnvironment.bYear);
			m_simControl.m_GUIData.m_PIGEnvWeather.SetOverride(m_OutPIGData.oPIGEnvironment.bWeather);
			m_simControl.m_GUIData.m_PIGEnvCoastline.SetOverride(m_OutPIGData.oPIGEnvironment.bCoastline);
			m_simControl.m_GUIData.m_PIGEnvSeaState.SetOverride(m_OutPIGData.oPIGEnvironment.bSeaState);
			m_simControl.m_GUIData.m_PIGEnvVisualRange.SetOverride(m_OutPIGData.oPIGEnvironment.fVisibleRange);
			m_simControl.m_GUIData.m_PIGEnvThermalRange.SetOverride(m_OutPIGData.oPIGEnvironment.fThermalRange);
			m_simControl.m_GUIData.m_PIGEnvUnderWaterRange.SetOverride(m_OutPIGData.oPIGEnvironment.fUnderwaterVis);
			m_simControl.m_GUIData.m_PIGEnvWindSpeed.SetOverride(m_OutPIGData.oPIGEnvironment.fWindSpeed);
			m_simControl.m_GUIData.m_PIGEnvWindDirn.SetOverride(m_OutPIGData.oPIGEnvironment.fWindDirection);
			m_simControl.m_GUIData.m_PIGEnvMoonBrgOverRide.SetOverride(m_OutPIGData.oPIGEnvironment.fMoonBearing);
			m_simControl.m_GUIData.m_PIGEnvMoonElevOverRide.SetOverride(m_OutPIGData.oPIGEnvironment.fMoonAltitude);
			m_simControl.m_GUIData.m_PIGEnvSunBrgOverRide.SetOverride(m_OutPIGData.oPIGEnvironment.fSunBearing);
			m_simControl.m_GUIData.m_PIGEnvSunElevOverRide.SetOverride(m_OutPIGData.oPIGEnvironment.fSunAltitude);
			m_simControl.m_GUIData.m_PIGEnvIceEdgeLat.SetOverride(m_OutPIGData.oPIGEnvironment.fIceEdgeLat);
			m_simControl.m_GUIData.m_PIGEnvIceEdgeLon.SetOverride(m_OutPIGData.oPIGEnvironment.fIceEdgeLong);
			m_simControl.m_GUIData.m_PIGEnvIceEdgeOrien.SetOverride(m_OutPIGData.oPIGEnvironment.fIceFloe);

			// Ownboat
			m_simControl.m_GUIData.m_PIGOwnType.SetOverride(m_OutPIGData.oPIGOwnship.bType);
			m_simControl.m_GUIData.m_PIGOwnSmoke.SetOverride(m_OutPIGData.oPIGOwnship.bSmoke);
			m_simControl.m_GUIData.m_PIGOwnLatitude.SetOverride(m_OutPIGData.oPIGOwnship.fLatitude);
			m_simControl.m_GUIData.m_PIGOwnLongitude.SetOverride(m_OutPIGData.oPIGOwnship.fLogitude);
			m_simControl.m_GUIData.m_PIGOwnX.SetOverride(m_OutPIGData.oPIGOwnship.fX);
			m_simControl.m_GUIData.m_PIGOwnY.SetOverride(m_OutPIGData.oPIGOwnship.fY);
			m_simControl.m_GUIData.m_PIGOwnDepth.SetOverride(m_OutPIGData.oPIGOwnship.fDepth);
			m_simControl.m_GUIData.m_PIGOwnHeading.SetOverride(m_OutPIGData.oPIGOwnship.fHeading);
			m_simControl.m_GUIData.m_PIGOwnRoll.SetOverride(m_OutPIGData.oPIGOwnship.fRoll);
			m_simControl.m_GUIData.m_PIGOwnPitch.SetOverride(m_OutPIGData.oPIGOwnship.fPitch);
			m_simControl.m_GUIData.m_PIGOwnSpeed.SetOverride(m_OutPIGData.oPIGOwnship.fSpeed);

			for (int i = 0; i < 10; i++)
				m_simControl.m_GUIData.m_PIGOwnMast[i].SetOverride(m_OutPIGData.oPIGOwnship.mast[i]);

			// Periscope
			m_simControl.m_GUIData.m_PIGPeriSensor.SetOverride(m_OutPIGData.oPIGPeriscope.bSensorType);
			m_simControl.m_GUIData.m_PIGPeriMagnification.SetOverride(m_OutPIGData.oPIGPeriscope.bMagnification);
			m_simControl.m_GUIData.m_PIGPeriGain.SetOverride(m_OutPIGData.oPIGPeriscope.bSensorGain);
			m_simControl.m_GUIData.m_PIGPeriContrast.SetOverride(m_OutPIGData.oPIGPeriscope.bSensorContrast);
			m_simControl.m_GUIData.m_PIGPeriGratIntensity.SetOverride(m_OutPIGData.oPIGPeriscope.bGraticuleInt);
			m_simControl.m_GUIData.m_PIGPeriDraindown.SetOverride(m_OutPIGData.oPIGPeriscope.bDraindownTime);
			m_simControl.m_GUIData.m_PIGPeriRelBrg.SetOverride(m_OutPIGData.oPIGPeriscope.fRelativeBearing);
			m_simControl.m_GUIData.m_PIGPeriElevation.SetOverride(m_OutPIGData.oPIGPeriscope.fElevation);
			m_simControl.m_GUIData.m_PIGPeriStadAngle.SetOverride(m_OutPIGData.oPIGPeriscope.fStadElev);

			// Target
			for (int i = 0; i < SIMControl.NUM_PERI_TARGETS ; i++)
			{
                m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarPresent.SetOverride(m_OutPIGData.oPIGTarget[i].bVisible);
                m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarNavLights.SetOverride(m_OutPIGData.oPIGTarget[i].bNavLights);
                m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarMissileHit.SetOverride(m_OutPIGData.oPIGTarget[i].bMissileImpact);
                m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarTorpedoHit.SetOverride(m_OutPIGData.oPIGTarget[i].bTorpedoImpact);
                m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarSinking.SetOverride(m_OutPIGData.oPIGTarget[i].bSinking);
                m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarDunkingSonar.SetOverride(m_OutPIGData.oPIGTarget[i].bSonarDunking);
                m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarTLAM.SetOverride(m_OutPIGData.oPIGTarget[i].bTLAMLaunch);
                m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarFlames.SetOverride(m_OutPIGData.oPIGTarget[i].bExplosion);
                m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarDieselSmoke.SetOverride(m_OutPIGData.oPIGTarget[i].bDieselSmoke);
				m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarFireMissile.SetOverride(m_OutPIGData.oPIGTarget[i].bMissileLaunch);

			    m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarModelID.SetOverride(m_OutPIGData.oPIGTarget[i].sModelID);
			    m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarSlotNum.SetOverride(m_OutPIGData.oPIGTarget[i].sTargetNum);
			    m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarSpotConfig.SetOverride(m_OutPIGData.oPIGTarget[i].bSpotlightConfig);
			    m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarLightConfig.SetOverride(m_OutPIGData.oPIGTarget[i].bLightConfig);
				m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarX.SetOverride(m_OutPIGData.oPIGTarget[i].fX);
				m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarY.SetOverride(m_OutPIGData.oPIGTarget[i].fY);
				m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarHeight.SetOverride(m_OutPIGData.oPIGTarget[i].fHeight);
				m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarHeading.SetOverride(m_OutPIGData.oPIGTarget[i].fHeading);
				m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarRoll.SetOverride(m_OutPIGData.oPIGTarget[i].fRoll);
				m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarPitch.SetOverride(m_OutPIGData.oPIGTarget[i].fPitch);
				m_simControl.m_GUIData.m_PIGTargets[i].m_PIGTarSpeed.SetOverride(m_OutPIGData.oPIGTarget[i].fSpeed);
			}

			//TODO: Return Data
			m_simControl.m_GUIData.m_PIGRetModelStat.SetOverride(m_OutPIGData.oPIGReturn.lModelStat);
		    m_simControl.m_GUIData.m_PIGRetProcStat.SetOverride(m_OutPIGData.oPIGReturn.lProcStat);
			m_simControl.m_GUIData.m_PIGRetPolyniaNum.SetOverride(m_OutPIGData.oPIGReturn.lSonarContacts);
			//m_simControl.m_GUIData.m_PIGRetPolynia.SetOverride(m_OutPIGData.oPIGReturn.bTIHotControl);

			for(int i=0; i < SIMControl.NUM_POLYNIA_TARGETS ; i++)
			{
				m_simControl.m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolIdentity.SetOverride(m_OutPIGData.oPIGReturn.SonarData[i].identity);
				m_simControl.m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolOrien.SetOverride(m_OutPIGData.oPIGReturn.SonarData[i].orientation);
				m_simControl.m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolSlotNum.SetOverride(m_OutPIGData.oPIGReturn.SonarData[i].slotNumber);
				m_simControl.m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolX.SetOverride(m_OutPIGData.oPIGReturn.SonarData[i].x_offset);
				m_simControl.m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolY.SetOverride(m_OutPIGData.oPIGReturn.SonarData[i].y_offset);
				m_simControl.m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolZ.SetOverride(m_OutPIGData.oPIGReturn.SonarData[i].z_offset);
			}

			//
			//Update the IO Data
			//
			m_simControl.m_GUIData.m_IOBearing.SetOverride(m_OutIOData.m_fBearing);
			m_simControl.m_GUIData.m_IOElevation.SetOverride(m_OutIOData.m_fElevation);
			m_simControl.m_GUIData.m_IOStadAngle.SetOverride(m_OutIOData.m_fStadAngle);
			m_simControl.m_GUIData.m_IOTiBlackLevel.SetOverride(m_OutIOData.m_fTiBlackLevel);
			m_simControl.m_GUIData.m_IOTiSensitivity.SetOverride(m_OutIOData.m_fTiSensitivity);
			m_simControl.m_GUIData.m_IOTiGratIllum.SetOverride(m_OutIOData.m_fTiGratIllum);
			m_simControl.m_GUIData.m_IORearStadAngle.SetOverride(m_OutIOData.m_fRearStadAngle);
			m_simControl.m_GUIData.m_IORearTrueBrg.SetOverride(m_OutIOData.m_fRearTrueBrg);
			m_simControl.m_GUIData.m_IORearRelBrg.SetOverride(m_OutIOData.m_fRearRelBrg);
			m_simControl.m_GUIData.m_IODisplayBrg.SetOverride(m_OutIOData.m_fDisplayBrg);
			m_simControl.m_GUIData.m_IODisplayElev.SetOverride(m_OutIOData.m_fDisplayElev);
			m_simControl.m_GUIData.m_IODisplayTar.SetOverride(m_OutIOData.m_fDisplayTar);
			m_simControl.m_GUIData.m_IOHandlesDown.SetOverride(m_OutIOData.m_bHandlesDown);
			m_simControl.m_GUIData.m_IOHighMag.SetOverride(m_OutIOData.m_bMagnification);
			m_simControl.m_GUIData.m_IORangeCut.SetOverride(m_OutIOData.m_bRangeCut);
			m_simControl.m_GUIData.m_IOBearingCut.SetOverride(m_OutIOData.m_bBearingCut);
			m_simControl.m_GUIData.m_IOPushToTalk.SetOverride(m_OutIOData.m_bPushToTalk);
			m_simControl.m_GUIData.m_IOModeSelect.SetOverride(m_OutIOData.m_iModeSelect);
			m_simControl.m_GUIData.m_IODataOverlay.SetOverride(m_OutIOData.m_bDataOverlay);
			m_simControl.m_GUIData.m_IOTiOnIndicator.SetOverride(m_OutIOData.m_bTiOnIndicator);
			m_simControl.m_GUIData.m_IOTarHeight.SetOverride(m_OutIOData.m_bTarHeight);
			m_simControl.m_GUIData.m_IOBeckmanTrue.SetOverride(m_OutIOData.m_fBeckmanTrue);
			m_simControl.m_GUIData.m_IOBeckmanRel.SetOverride(m_OutIOData.m_fBeckmanRel);


			//
			// Update the System Data
			//
			m_simControl.m_GUIData.m_SIMEmulatingPIP = PIPEmulation;
			m_simControl.m_GUIData.m_SIMEmulatingPIG = PIGEmulation;
			m_simControl.m_GUIData.m_SIMEmulatingIO = IOEmulation;

			if (m_PIPEmulationUpdate)
			{
				m_simControl.m_GUIData.m_SIMPIPUpdate = true;
				m_PIPEmulationUpdate =  false;
			}

			//
			// Update the Error Log Data
			//
			m_simControl.m_GUIData.m_SIMErrorLogClear = m_ErrorLog.m_ErrorLogClear;
		}



		public void updatePIPEmulation(float updateDelta)
		{

			Console.WriteLine("In Update PIP Emulation");
			//
			// Function to respond to timer
			//
			m_PIPEmulationUpdate = true;

			//
			// If there is a scenario running, update it
			//
			if (ScenarioRunning)
			  m_guiScenarios.updateScenario(updateDelta);
		}

		private void InitializeComponent()
		{
			//
			// C_gui
			//
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Name = "C_gui";

		}

	}



	//
	//Exit Dialog
	//
	class ExitDialog : Form
	{
		protected Label    m_Confirmation;
		protected Button   m_ok;
		protected Button   m_cancel;

		public ExitDialog()
		{
			this.Text = "Exit Application...";
			this.Size = new Size(300, 170);

			//
			// pathLabel
			//
			m_Confirmation           = new Label();
			m_Confirmation.Location  = new System.Drawing.Point(40, 16);
			m_Confirmation.Size      = new System.Drawing.Size(300, 20);
			m_Confirmation.Text      = "Are you sure you want to Exit ?";
			Controls.Add(m_Confirmation);

			//
			// ok
			//
			m_ok          = new Button();
			m_ok.Location = new System.Drawing.Point(48, 100);
			m_ok.Size     = new System.Drawing.Size(72, 24);
			m_ok.TabIndex = 13;
			m_ok.Text     = "OK";
			m_ok.Click   += new EventHandler(okClick);
			this.Controls.Add(m_ok);

			//
			// cancel
			//
			m_cancel          = new Button();
			m_cancel.Location = new System.Drawing.Point(150, 100);
			m_cancel.Size     = new System.Drawing.Size(72, 24);
			m_cancel.TabIndex = 14;
			m_cancel.Text     = "Cancel";
			m_cancel.Click   += new EventHandler(cancelClick);
			this.Controls.Add(m_cancel);
		}

		public void cancelClick(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}

		public void okClick(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.OK;
		}
	}
}
