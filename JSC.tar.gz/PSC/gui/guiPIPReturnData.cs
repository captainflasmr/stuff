//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiPIPReturnData.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;
using System.Drawing;

using System.Collections;

namespace PSCGenericBuild
{
	public struct PolyniaData
	{
		public C_DataStoreItemInt   iPolyniaID;	
		public C_DataStoreItemByte  bPolyniaIceField;	
		public C_DataStoreItemFloat fX;	
		public C_DataStoreItemFloat fY;	
		public C_DataStoreItemFloat fZ;	
		public C_DataStoreItemFloat fPolyniaOrienation;	
	}

	//-----------------------------------------------------------------------
	//The Return Data Page Class.
	//-----------------------------------------------------------------------
	public class C_guiPIPReturnData : C_guiTemplatePage
	{
		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		string [] strDownUp     = {"Down",  "Up"};
		string [] strBlackWhite = {"Black", "White"};
		string [] strLowHigh    = {"Low",   "High"};
		string [] strFalseTrue  = {"False", "True"};

		public PIGExerciseData oPIGExercisePacket;

		protected ComboBox m_comboPolynia;
		protected Label    m_labelPolynia;

		protected GroupBox m_twshGroupBox;
		protected PolyniaData [] m_polyniaData;
		protected PIPReturnData   m_InData;

		public int m_iPolynia;  //The index of the currently used polynia
		public int m_iNumPolynias; //The number of polynias returned by the PIG

		public const int NUM_POLYNIAS = SIMControl.NUM_POLYNIA_TARGETS;

		public const byte MAST_POS      = 0x01;
		public const byte TI_CONTROL    = 0x02;
		public const byte MAGNIFICATION = 0x04;

		public ArrayList m_DataItem;

		public C_guiDataItemBoolean  dataItemMastPosition;
		public C_guiDataItemBoolean  dataTIHotControl;
		public C_guiDataItemBoolean  dataMagnification;
		public C_guiDataItemByte   dataLLTVGain;
		public C_guiDataItemByte  dataTIGain;
		public C_guiDataItemFloat dataRelativeBearing;
		public C_guiDataItemFloat dataElevation;
		public C_guiDataItemFloat dataSunBearing;
		public C_guiDataItemFloat dataSunElevation;
		public C_guiDataItemInt   dataErrorNumber;

		public C_guiDataItemString dataErrorString;
        public C_guiDataItemInt    dataNumPolynia;
		public C_guiDataItemInt    dataPolyniaId;
		public C_guiDataItemByte   dataPolyniaIceField;
		public C_guiDataItemFloat  dataX;
		public C_guiDataItemFloat  dataY;
		public C_guiDataItemFloat  dataZ;
		public C_guiDataItemFloat  dataPolyniaOrn;

		public C_guiDataItemFloat dataPeriTrueBrg;
		public C_guiDataItemFloat dataTargetTrueBrg;
		public C_guiDataItemBoolean  dataTargetTrueBrgCut;
		public C_guiDataItemFloat dataTargetRange;
		public C_guiDataItemBoolean  dataTargetRangeCut;
		public C_guiDataItemFloat dataElapsedTime;
		public C_guiDataItemBoolean  dataElapsedTimeCut;



		//-----------------------------------------------------------------------
		//Class Properties
		//-----------------------------------------------------------------------

		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		/************************************************************************
		  FUNCTION      : C_guiPIPReturnData()
		  DESCRIPTION   : The Constructor for PIP Return Data Page. 
		  PARAMETERS    : parentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the PIP Return Data Page.
		 ************************************************************************/
		public C_guiPIPReturnData (C_gui parentForm)
		{

			this.ptrGui    = parentForm;

			m_InData = this.ptrGui.m_InPIPData.oReturn;

			//Create the polynia data, the data store for the gui values.
			m_polyniaData = new PolyniaData[SIMControl.NUM_POLYNIA_TARGETS];

			for(int i=0; i < SIMControl.NUM_POLYNIA_TARGETS; i++)
			{
				m_polyniaData[i].iPolyniaID = new C_DataStoreItemInt();	
				m_polyniaData[i].bPolyniaIceField = new C_DataStoreItemByte();	
				m_polyniaData[i].fX = new C_DataStoreItemFloat();		
				m_polyniaData[i].fY = new C_DataStoreItemFloat();		
				m_polyniaData[i].fZ = new C_DataStoreItemFloat();	
				m_polyniaData[i].fPolyniaOrienation = new C_DataStoreItemFloat();	
			}

			//-----------------------------------------------------
			//Declare the data items.
			//-----------------------------------------------------
			m_dataItem = new C_guiDataItem[24];

			m_DataItem = new ArrayList(24);

			this.Text      = "PIP Data - Return Data";
			this.pageType  = C_gui.page.PIP_RETURN;


			m_labelPolynia          = new Label();
			m_labelPolynia.Text     = "Polynia";
			m_labelPolynia.Location = new Point(50, 430);
			this.Controls.Add(m_labelPolynia);

			m_comboPolynia          = new ComboBox();
			m_comboPolynia.Location = new Point(180, 430);
			m_comboPolynia.Text     = "1";

			m_comboPolynia.KeyPress    += new KeyPressEventHandler(integerKeyPress);
			m_comboPolynia.TextChanged += new EventHandler(polyniaNumberChanged);

			m_comboPolynia.TextChanged += new EventHandler(polyniaIndexChanged);



			m_comboPolynia.BeginUpdate();
			for(int i=0; i < NUM_POLYNIAS; i++)
			{
				m_comboPolynia.Items.Add((i+1).ToString());
			}
			m_comboPolynia.EndUpdate();

			this.Controls.Add(m_comboPolynia);

			//Create the TWSH group Box.
			m_twshGroupBox = new GroupBox();
			m_twshGroupBox.Location = new Point(10, 640);
            m_twshGroupBox.Size = new Size(800, 235);
			m_twshGroupBox.Text = "WSDB / TWSH Message";
			this.Controls.Add(m_twshGroupBox);


			//-----------------------------------------------------
			//Initialise each data item.
			//-----------------------------------------------------

		    dataItemMastPosition = new C_guiDataItemBoolean( "Mast Position",        "PIP_RETURN_MAST_POSITION",	50,  10, this, "System Identifier ");
			dataTIHotControl     = new C_guiDataItemBoolean( "TI Hot Control" ,      "PIP_RETURN_TI_CONTROL",	50,  40, this, "Run Mode (Run/Stop/Freeze/Reset)");
			dataMagnification    = new C_guiDataItemBoolean( "Magnification",        "PIP_RETURN_MAGNIFICATION",	50,  70, this, "System Identifier ");
			dataLLTVGain         = new C_guiDataItemByte( "LLTV gain" ,           "PIP_RETURN_LLTV_GAIN",		50, 100, this, "Run Mode (Run/Stop/Freeze/Reset)");
			dataTIGain           = new C_guiDataItemByte( "TI gain",              "PIP_RETURN_TI_GAIN",		50, 130, this, "System Identifier ");
			dataRelativeBearing  = new C_guiDataItemFloat( "Relative Bearing",     "PIP_RETURN_REL_BRG",		50, 170, this, "System Identifier ");
			dataElevation        = new C_guiDataItemFloat( "Elevation" ,           "PIP_RETURN_ELEVATION",		50, 200, this, "Run Mode (Run/Stop/Freeze/Reset)");
			dataSunBearing       = new C_guiDataItemFloat( "Auto-sun bearing",     "PIP_RETURN_AUTO_SUN_BRG",	50, 230, this, "System Identifier ");
			dataSunElevation     = new C_guiDataItemFloat( "Auto-sun elevation",   "PIP_RETURN_AUTO_SUN_ELEV",	50, 260, this, "Run Mode (Run/Stop/Freeze/Reset)");
			dataErrorNumber      = new C_guiDataItemInt( "PSC error number",     "PIP_RETURN_ERROR_NUMBER",	50, 290, this, "Error Number ");
			dataErrorString      = new C_guiDataItemString( "PSC error string",     "PIP_RETURN_ERROR_STRING",	50, 320, this, "Error String ");
			dataNumPolynia       = new C_guiDataItemInt("Number of Polynia", "PIP_RETURN_NUM_POLYNIA", 50, 390, this, "Number of Polynia");
			dataPolyniaId        = new C_guiDataItemInt  ("Polynia Identity" ,   "PIP_RETURN_POLYNIA_ID",	    50, 460, this, "Run Mode (Run/Stop/Freeze/Reset)");
			dataPolyniaIceField  = new C_guiDataItemByte ("Polynia in ice field","PIP_RETURN_POLYNIA_ICE_FIELD",	50, 490, this, "System Identifier ");
			dataX                = new C_guiDataItemFloat("X Coord" ,            "PIP_RETURN_POLYNIA_X",		    50, 520, this, "Run Mode (Run/Stop/Freeze/Reset)");
			dataY                = new C_guiDataItemFloat("Y Coord",             "PIP_RETURN_POLYNIA_Y",	        50, 550, this, "System Identifier ");
			dataZ                = new C_guiDataItemFloat("Z Offset",            "PIP_RETURN_POLYNIA_Z",	        50, 580, this, "Run Mode (Run/Stop/Freeze/Reset)");
			dataPolyniaOrn       = new C_guiDataItemFloat("Polynia Orientation", "PIP_RETURN_POLYNIA_ORIENTATION",50,610, this, "System Identifier ");

			dataPeriTrueBrg      = new C_guiDataItemFloat( "Periscope True Brg" , "PIP_RETURN_PERI_TRUE_BRG",		 40, 20, this, "Periscope True Bearing");
			dataTargetTrueBrg    = new C_guiDataItemFloat( "Target True Brg",     "PIP_RETURN_TARGET_TRUE_BRG",	 40, 50, this, "Target True Bearing");
			dataTargetTrueBrgCut = new C_guiDataItemBoolean( "Target True Brg Cut", "PIP_RETURN_TARGET_TRUE_BRG_CUT",40, 80, this, "Target True Bearing Cut");
			dataTargetRange      = new C_guiDataItemFloat( "Target Range",        "PIP_RETURN_TARGET_RANGE",       40, 110, this, "Target Range");
			dataTargetRangeCut   = new C_guiDataItemBoolean( "Target Range Cut",    "PIP_RETURN_TARGET_RANGE_CUT",   40, 140, this, "Target Range Cut");
			dataElapsedTime      = new C_guiDataItemFloat( "Elapsed Time",        "PIP_RETURN_ELAPSED_TIME",       40, 170, this, "Elapsed Time");
			dataElapsedTimeCut   = new C_guiDataItemBoolean( "Elapsed Time Cut",    "PIP_RETURN_ELAPSED_TIME_CUT",   40, 200, this, "Elapsed Time Cut");

			Size textSize = new Size(160, 60);
			dataErrorString.setTextBoxDimension(textSize);

			dataItemMastPosition.setListEntries(strDownUp);
			dataTIHotControl.setListEntries(strBlackWhite);
			dataMagnification.setListEntries(strLowHigh);
			dataPolyniaIceField.setListEntries(strFalseTrue);

			dataTargetTrueBrgCut.setListEntries(strFalseTrue);
			dataTargetRangeCut.setListEntries(strFalseTrue);
			dataElapsedTimeCut.setListEntries(strFalseTrue);

			this.Controls.Add( dataItemMastPosition);
			this.Controls.Add( dataTIHotControl);
			this.Controls.Add( dataMagnification);
			this.Controls.Add( dataLLTVGain);
			this.Controls.Add( dataTIGain);
			this.Controls.Add( dataRelativeBearing);
			this.Controls.Add( dataElevation);
			this.Controls.Add( dataSunBearing);
			this.Controls.Add( dataSunElevation);
			this.Controls.Add( dataErrorNumber);
			this.Controls.Add( dataErrorString);
			this.Controls.Add( dataNumPolynia);
			this.Controls.Add( dataPolyniaId);
			this.Controls.Add( dataPolyniaIceField);
			this.Controls.Add( dataX);
			this.Controls.Add( dataY);
			this.Controls.Add( dataZ);
			this.Controls.Add( dataPolyniaOrn);


			m_twshGroupBox.Controls.Add( dataPeriTrueBrg);
			m_twshGroupBox.Controls.Add( dataTargetTrueBrg);
			m_twshGroupBox.Controls.Add( dataTargetTrueBrgCut);
			m_twshGroupBox.Controls.Add( dataTargetRange);
			m_twshGroupBox.Controls.Add( dataTargetRangeCut);
			m_twshGroupBox.Controls.Add( dataElapsedTime);
			m_twshGroupBox.Controls.Add( dataElapsedTimeCut);

			Point Pos1 = new Point(130, 0);
			Point Pos2 = new Point(300, 0);
			Point Pos3 = new Point(350, 0);
			Point Pos4 = new Point(520, 0);

			dataItemMastPosition.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataTIHotControl.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataMagnification.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataLLTVGain.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataTIGain.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataRelativeBearing.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataElevation.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataSunBearing.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataSunElevation.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataErrorNumber.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataErrorString.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataPolyniaId.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataPolyniaIceField.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataX.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataY.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataZ.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataPolyniaOrn.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataNumPolynia.positionDataItems(Pos1, Pos2, Pos3, Pos4);

			dataPeriTrueBrg.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataTargetTrueBrg.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataTargetTrueBrgCut.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataTargetRange.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataTargetRangeCut.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataElapsedTime.positionDataItems(Pos1, Pos2, Pos3, Pos4);
			dataElapsedTimeCut.positionDataItems(Pos1, Pos2, Pos3, Pos4);

            dataPolyniaId.numeric.ValueChanged  += new EventHandler(polyniaChanged);
            dataX.numeric.ValueChanged          += new EventHandler(polyniaChanged);
            dataY.numeric.ValueChanged          += new EventHandler(polyniaChanged);
            dataZ.numeric.ValueChanged          += new EventHandler(polyniaChanged);
            dataPolyniaOrn.numeric.ValueChanged += new EventHandler(polyniaChanged);
            dataPolyniaIceField.comboBox.SelectedIndexChanged += new EventHandler(polyniaChanged);

			dataPolyniaId.checkBox.CheckedChanged       += new EventHandler(polyniaCheckChanged);
			dataX.checkBox.CheckedChanged               += new EventHandler(polyniaCheckChanged);
			dataY.checkBox.CheckedChanged               += new EventHandler(polyniaCheckChanged);
			dataZ.checkBox.CheckedChanged               += new EventHandler(polyniaCheckChanged);
			dataPolyniaOrn.checkBox.CheckedChanged      += new EventHandler(polyniaCheckChanged);
			dataPolyniaIceField.checkBox.CheckedChanged += new EventHandler(polyniaCheckChanged);


			this.MdiParent = parentForm;
			this.Size        = new Size(850, 910);

			m_initialised = true;
		}

		public void polyniaIndexChanged(object sender, EventArgs e)
		{
			int iPolynia = Int32.Parse(m_comboPolynia.Text) - 1;

			changePageContent(m_iPolynia, iPolynia);

			//Refresh the content of the screen.
			//updateIncomingData();

			m_iPolynia = iPolynia;           
		}

		public void changePageContent(int iOldPolynia, int iNewPolynia)
		{

			//
			//Save the existing values...
			//
			m_polyniaData[iOldPolynia].iPolyniaID.Value = dataPolyniaId.Value;
			m_polyniaData[iOldPolynia].bPolyniaIceField.Value = dataPolyniaIceField.Value;
			m_polyniaData[iOldPolynia].fX.Value = dataX.Value;
			m_polyniaData[iOldPolynia].fY.Value = dataY.Value;
			m_polyniaData[iOldPolynia].fZ.Value = dataZ.Value;
			m_polyniaData[iOldPolynia].fPolyniaOrienation.Value = dataPolyniaOrn.Value;

			m_polyniaData[iOldPolynia].iPolyniaID.Flag = dataPolyniaId.overrideChecked;
			m_polyniaData[iOldPolynia].bPolyniaIceField.Flag = dataPolyniaIceField.overrideChecked;
			m_polyniaData[iOldPolynia].fX.Flag = dataX.overrideChecked;
			m_polyniaData[iOldPolynia].fY.Flag = dataY.overrideChecked;
			m_polyniaData[iOldPolynia].fZ.Flag = dataZ.overrideChecked;
			m_polyniaData[iOldPolynia].fPolyniaOrienation.Flag = dataPolyniaOrn.overrideChecked;

			//
			//Display the values for the new target page.
			//
			dataPolyniaId.OverrideValue = m_polyniaData[iNewPolynia].iPolyniaID.Value;
			dataPolyniaIceField.OverrideValue = m_polyniaData[iNewPolynia].bPolyniaIceField.Value;
			dataX.OverrideValue = m_polyniaData[iNewPolynia].fX.Value;
			dataY.OverrideValue = m_polyniaData[iNewPolynia].fY.Value;
			dataZ.OverrideValue = m_polyniaData[iNewPolynia].fZ.Value;
			dataPolyniaOrn.OverrideValue = m_polyniaData[iNewPolynia].fPolyniaOrienation.Value;

			dataPolyniaId.setupOverride(m_polyniaData[iNewPolynia].iPolyniaID.Flag);
			dataPolyniaIceField.setupOverride(m_polyniaData[iNewPolynia].bPolyniaIceField.Flag);
			dataX.setupOverride(m_polyniaData[iNewPolynia].fX.Flag);
			dataY.setupOverride(m_polyniaData[iNewPolynia].fY.Flag);
			dataZ.setupOverride(m_polyniaData[iNewPolynia].fZ.Flag);
			dataPolyniaOrn.setupOverride(m_polyniaData[iNewPolynia].fPolyniaOrienation.Flag);

		}

		public override void updateIncomingData()
		{
			if(!m_initialised) 
				return;

			dataItemMastPosition.Value = m_InData.bMastPosition.Value;
			dataTIHotControl.Value     = m_InData.bTIHotControl.Value;
			dataMagnification.Value    = m_InData.bMagnification.Value;

			dataLLTVGain.Value = m_InData.bLLTVGain.Value;
			dataTIGain.Value = m_InData.bTIGain.Value;
			dataRelativeBearing.Value = m_InData.fPeriRelBrg.Value;
			dataElevation.Value = m_InData.fElevation.Value;
			dataSunBearing.Value = m_InData.fSunBearing.Value;
			dataSunElevation.Value = m_InData.fSunElevation.Value;

			dataErrorNumber.Value  = m_InData.iPSCErrorNumber.Value;
			dataErrorString.Value  = m_InData.strPSCErrorString.Value;

			//TWSH message...
		    dataPeriTrueBrg.Value = m_InData.fPeriTrueBrg.Value;
		    dataTargetTrueBrg.Value = m_InData.fTargetTrueBrg.Value;
		    dataTargetTrueBrgCut.Value = m_InData.fTargetTrueBrgCut.Value;
		    dataTargetRange.Value = m_InData.fTargetRange.Value;
		    dataTargetRangeCut.Value = m_InData.fTargetRangeCut.Value;
		    dataElapsedTime.Value = m_InData.fElapsedTime.Value;
		    dataElapsedTimeCut.Value = m_InData.fElapsedTimeCut.Value;

			dataNumPolynia.Value = m_InData.iPolynias.Value;
			dataPolyniaId.Value = m_InData.polyniaData[m_iPolynia].iPolyniaID.Value;
			dataPolyniaIceField.Value = m_InData.polyniaData[m_iPolynia].bIceField.Value;
			dataX.Value = m_InData.polyniaData[m_iPolynia].fX.Value;
			dataY.Value = m_InData.polyniaData[m_iPolynia].fY.Value;
			dataZ.Value = m_InData.polyniaData[m_iPolynia].fZ.Value;
			dataPolyniaOrn.Value = m_InData.polyniaData[m_iPolynia].fOrientation.Value;

		}

		public override void updateOutgoingData()
		{           
			if(!m_initialised) 
				return;

			this.ptrGui.m_OutPIPData.oReturn.bMastPosition.Value =  dataItemMastPosition.Value;
			this.ptrGui.m_OutPIPData.oReturn.bTIHotControl.Value =  dataTIHotControl.Value;
			this.ptrGui.m_OutPIPData.oReturn.bMagnification.Value = dataMagnification.Value;
			this.ptrGui.m_OutPIPData.oReturn.bLLTVGain.Value =  dataLLTVGain.Value;
			this.ptrGui.m_OutPIPData.oReturn.bTIGain.Value =  dataTIGain.Value;
			this.ptrGui.m_OutPIPData.oReturn.fPeriRelBrg.Value = dataRelativeBearing.Value;

			this.ptrGui.m_OutPIPData.oReturn.fElevation.Value =  dataElevation.Value;
			this.ptrGui.m_OutPIPData.oReturn.fSunBearing.Value =  dataSunBearing.Value;
			this.ptrGui.m_OutPIPData.oReturn.fSunElevation.Value = dataSunElevation.Value;
			this.ptrGui.m_OutPIPData.oReturn.iPSCErrorNumber.Value =  dataErrorNumber.Value;
			this.ptrGui.m_OutPIPData.oReturn.strPSCErrorString.Value =  dataErrorString.Value;

			this.ptrGui.m_OutPIPData.oReturn.iPolynias.Value = dataNumPolynia.Value;

			//TWSH message...
			this.ptrGui.m_OutPIPData.oReturn.fPeriTrueBrg.Value = dataPeriTrueBrg.Value;
            this.ptrGui.m_OutPIPData.oReturn.fTargetTrueBrg.Value = dataTargetTrueBrg.Value;
			this.ptrGui.m_OutPIPData.oReturn.fTargetTrueBrgCut.Value =  dataTargetTrueBrgCut.Value;
			this.ptrGui.m_OutPIPData.oReturn.fTargetRange.Value =  dataTargetRange.Value;
			this.ptrGui.m_OutPIPData.oReturn.fTargetRangeCut.Value = dataTargetRangeCut.Value;
			this.ptrGui.m_OutPIPData.oReturn.fElapsedTime.Value = dataElapsedTime.Value;
			this.ptrGui.m_OutPIPData.oReturn.fElapsedTimeCut.Value = dataElapsedTimeCut.Value;

            this.ptrGui.m_OutPIPData.oReturn.iPolynias.Value =  10;

			this.ptrGui.m_OutPIPData.oReturn.bMastPosition.Flag = dataItemMastPosition.overrideChecked ;
			this.ptrGui.m_OutPIPData.oReturn.bTIHotControl.Flag =  dataTIHotControl.overrideChecked;
			this.ptrGui.m_OutPIPData.oReturn.bMagnification.Flag = dataMagnification.overrideChecked;
			this.ptrGui.m_OutPIPData.oReturn.bLLTVGain.Flag =  dataLLTVGain.overrideChecked;
			this.ptrGui.m_OutPIPData.oReturn.bTIGain.Flag =  dataTIGain.overrideChecked;
			this.ptrGui.m_OutPIPData.oReturn.fPeriRelBrg.Flag = dataRelativeBearing.overrideChecked;

			this.ptrGui.m_OutPIPData.oReturn.fElevation.Flag =  dataElevation.overrideChecked;
			this.ptrGui.m_OutPIPData.oReturn.fSunBearing.Flag =  dataSunBearing.overrideChecked;
			this.ptrGui.m_OutPIPData.oReturn.fSunElevation.Flag = dataSunElevation.overrideChecked;
			this.ptrGui.m_OutPIPData.oReturn.iPSCErrorNumber.Flag =  dataErrorNumber.overrideChecked;
			this.ptrGui.m_OutPIPData.oReturn.strPSCErrorString.Flag =  dataErrorString.overrideChecked;

			this.ptrGui.m_OutPIPData.oReturn.iPolynias.Flag = dataNumPolynia.overrideChecked;
			for(int i = 0 ; i < SIMControl.NUM_POLYNIA_TARGETS; i++)
			{
				this.ptrGui.m_OutPIPData.oReturn.polyniaData[i].iPolyniaID.Flag = m_polyniaData[i].iPolyniaID.Flag;
				this.ptrGui.m_OutPIPData.oReturn.polyniaData[i].bIceField.Flag = m_polyniaData[i].bPolyniaIceField.Flag;
				this.ptrGui.m_OutPIPData.oReturn.polyniaData[i].fX.Flag  = m_polyniaData[i].fX.Flag;
				this.ptrGui.m_OutPIPData.oReturn.polyniaData[i].fY.Flag = m_polyniaData[i].fY.Flag;
				this.ptrGui.m_OutPIPData.oReturn.polyniaData[i].fZ.Flag  = m_polyniaData[i].fZ.Flag;
				this.ptrGui.m_OutPIPData.oReturn.polyniaData[i].fOrientation.Flag  = m_polyniaData[i].fPolyniaOrienation.Flag;

				this.ptrGui.m_OutPIPData.oReturn.polyniaData[i].iPolyniaID.Value = m_polyniaData[i].iPolyniaID.Value;
				this.ptrGui.m_OutPIPData.oReturn.polyniaData[i].bIceField.Value = m_polyniaData[i].bPolyniaIceField.Value;
				this.ptrGui.m_OutPIPData.oReturn.polyniaData[i].fX.Value  = m_polyniaData[i].fX.Value;
				this.ptrGui.m_OutPIPData.oReturn.polyniaData[i].fY.Value = m_polyniaData[i].fY.Value;
				this.ptrGui.m_OutPIPData.oReturn.polyniaData[i].fZ.Value  = m_polyniaData[i].fZ.Value;
				this.ptrGui.m_OutPIPData.oReturn.polyniaData[i].fOrientation.Value  = m_polyniaData[i].fPolyniaOrienation.Value;
			}
		}

		private void polyniaChanged(object sender, EventArgs e)
		{
			//
			//The polynia values signal a change in value when the combo box index has changed. This is handled
			//by the 'polyniaNumberChanged' method.
			//
			if(! m_comboPolynia.ContainsFocus)
			{
				if(sender == dataPolyniaId.numeric)
				{
					m_polyniaData[m_iPolynia].iPolyniaID.Value = dataPolyniaId.Value;
				}

				if(sender == dataPolyniaIceField.comboBox)
				{
					m_polyniaData[m_iPolynia].bPolyniaIceField.Value = dataPolyniaIceField.Value;
				}

				if(sender == dataX.numeric)
				{
					m_polyniaData[m_iPolynia].fX.Value = dataX.Value;
				}

				if(sender == dataY.numeric)
				{
					m_polyniaData[m_iPolynia].fY.Value = dataY.Value;
				}

				if(sender == dataZ.numeric)
				{
					m_polyniaData[m_iPolynia].fZ.Value = dataZ.Value;
				}

				if(sender == dataPolyniaOrn.numeric)
				{
					m_polyniaData[m_iPolynia].fPolyniaOrienation.Value = dataPolyniaOrn.Value;
				}
			}
		}


		private void polyniaNumberChanged(object sender, EventArgs e)
		{
			if(m_comboPolynia.Text.Length == 0)
			   m_comboPolynia.Text = "1";

			if(Int32.Parse(m_comboPolynia.Text) == 0)
			{
               m_comboPolynia.Text = "1";
			}		   
			else if(Int32.Parse(m_comboPolynia.Text) > SIMControl.NUM_POLYNIA_TARGETS)
			{
				m_comboPolynia.Text = NUM_POLYNIAS.ToString();
			}
		}

		private void polyniaCheckChanged(object sender, EventArgs e)
		{
			if(! m_comboPolynia.ContainsFocus)
			{

				CheckBox checkBox = (CheckBox) sender;			

				if(sender == dataPolyniaId.checkBox)
				{
					m_polyniaData[m_iPolynia].iPolyniaID.Flag = dataPolyniaId.overrideChecked;
					m_polyniaData[m_iPolynia].iPolyniaID.Value = dataPolyniaId.Value;
				}

				if(sender == dataPolyniaIceField.checkBox)
				{
					m_polyniaData[m_iPolynia].bPolyniaIceField.Flag = dataPolyniaIceField.overrideChecked;
					m_polyniaData[m_iPolynia].bPolyniaIceField.Value = dataPolyniaIceField.Value;
				}

				if(sender == dataX.checkBox)
				{
					m_polyniaData[m_iPolynia].fX.Flag = dataX.overrideChecked;
					m_polyniaData[m_iPolynia].fX.Value = dataX.Value;
				}

				if(sender == dataY.checkBox)
				{
					m_polyniaData[m_iPolynia].fY.Flag = dataY.overrideChecked;
					m_polyniaData[m_iPolynia].fY.Value = dataY.Value;
				}

				if(sender == dataZ.checkBox)
				{
					m_polyniaData[m_iPolynia].fZ.Flag = dataZ.overrideChecked;
					m_polyniaData[m_iPolynia].fZ.Value = dataZ.Value;
				}

				if(sender == dataPolyniaOrn.checkBox)
				{
					m_polyniaData[m_iPolynia].fPolyniaOrienation.Flag = dataPolyniaOrn.overrideChecked;
					m_polyniaData[m_iPolynia].fPolyniaOrienation.Value = dataPolyniaOrn.Value;
				}
			}
		}
	}
}
