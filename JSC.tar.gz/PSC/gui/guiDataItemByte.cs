//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiDataItemByte.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Drawing;

namespace PSCGenericBuild
{
	/// <summary>
	/// Summary description for guiDataItemInt.
	/// </summary>
	public class C_guiDataItemByte : C_guiDataItem
	{
		protected byte m_iMaxValue     ;
		protected byte m_iMinValue     ;
		protected byte m_iDefaultValue ;

		protected byte m_overrideValue;

		public C_guiDataItemByte()
		{
		}

		public byte MinValue
		{
			get
			{
				return m_iMinValue;
			}
		}

		public byte MaxValue
		{
			get
			{
				return m_iMaxValue;
			}
		}

		public C_guiDataItemByte(string strLabel, string strHashTableKey, int iLeft, int iTop, C_guiTemplatePage parent, string strDescription)
		{
			m_iMaxValue     = 0;
			m_iMinValue     = 0;
			m_iDefaultValue = 0;

			//
			//Retrieve the data from the config hash table
			//
			if(strHashTableKey == null) return;

			//
			//Initialise the data item by creating the various components.
			//
			initDataItem(strLabel, strHashTableKey, iLeft, iTop, parent, strDescription);

			CurrentValue  = m_iDefaultValue;
			OverrideValue = m_iDefaultValue;

			setDecimalPlaces(0);
		}

		protected override void setData(DataFields data)
		{
			if(data != null)
			{
				m_iMinValue      = (byte)data.fMin;
				m_iMaxValue      = (byte)data.fMax;
				m_iDefaultValue  = (byte)data.fDefault;
				m_Description.Text  = data.strDescription;
				m_strDescription    = data.strDescription;
				m_Description.Width = data.strDescription.Length * 7;
				this.Width += m_Description.Width;

				m_Numeric.Maximum = (decimal) data.fMax;
				m_Numeric.Minimum = (decimal) data.fMin;
			}
			else
			{
				m_Description.Width = m_Description.Text.Length * 7;
				this.Width += m_Description.Width;
			}

		}

		public override void setDefaultValues()
		{
			//placeholder for the defaultValues
			CurrentValue  = m_iDefaultValue;
			OverrideValue = m_iDefaultValue;
		}

		public byte CurrentValue
		{
			get
			{
				if(m_overrideControl == m_Numeric)
				{
					return Convert.ToByte(m_TextBox.Text);
				}
				else
				{
					return (byte) m_ComboBox.FindString(m_TextBox.Text);
				}
			}
			set
			{
                if (!guiPage.IsDisposed)
                {
                    if (m_overrideControl == m_Numeric)
                    {
                        // m_TextBox.Text = value.ToString();
                        setTextboxText(value.ToString());
                    }
                    else
                    {
                        //
                        //If the value is a combo box set the text to the enumerated value if it is in
                        //bounds, otherwise show the text "Undefined" and the value which was out of bounds.
                        //
                        if (value >= 0 && value < m_ComboBox.Items.Count)
                            //m_TextBox.Text = m_ComboBox.Items[value].ToString();
                            setTextboxText(m_ComboBox.Items[value].ToString());
                        else
                            //m_TextBox.Text = "Undefined (" + value.ToString() + ")";
                            setTextboxText("Undefined (" + value.ToString() + ")");
                    }
                }
			}
		}

		/************************************************************************
		  PROPERTY      : OverrideValue
		  TYPE          : int
		  GET           : Returns the floating point value for the numeric override value
						  or, the enumerated value if a combobox entry.
		  SET           : Sets the text in the override value text box to a value if
						  a numeric override value, or a string if it is a string.
		 ************************************************************************/
		public byte OverrideValue
		{
			get
			{
				return m_overrideValue;
			}
			set
			{
				m_overrideValue = value;
                if (!guiPage.IsDisposed)
                {
                    if (m_overrideControl == m_Numeric)
                    {
                        m_Numeric.Text = value.ToString();
                    }
                    else
                    {
                        if (value >= 0 && value < m_ComboBox.Items.Count)
                            m_ComboBox.SelectedIndex = (int)value;
                    }
                }
			}
		}

		/************************************************************************
		  PROPERTY      : Value
		  TYPE          : float
		  GET           : If the override check is checked returns the override value
						  otherwise returns the current value.
		  SET           : Sets the text in the override value text box to a value if
						  a numeric override value, or a string if it is a string.
		 ************************************************************************/
		public byte Value
		{
			get
			{
				//
				//If the Override box is checked return the override value otherwise return the 
				//value supplied by the pip.
				//
				if(m_CheckBox.Checked)
				{			
					return OverrideValue;
				}
				else
				{
					return CurrentValue;
				}
			}
			set
			{
                if (!guiPage.IsDisposed)
                {
                    if (m_overrideControl == m_Numeric)
                    {
                        //m_TextBox.Text = value.ToString();
                        setTextboxText(value.ToString());
                    }
                    else
                    {
                        if (value >= 0 && value < m_ComboBox.Items.Count)
                            //m_TextBox.Text = m_ComboBox.Items[(int)value].ToString();
                            setTextboxText(m_ComboBox.Items[(int)value].ToString());
                        else
                            //m_TextBox.Text = "Undefined (" + value.ToString() + ")";
                            setTextboxText("Undefined (" + value.ToString() + ")");
                    }
                }
			}
		}

		public override void enableOverride(bool bOnOff)
		{
			if(bOnOff)
			{
				this.OverrideValue = this.m_iDefaultValue;
			}

			base.enableOverride(bOnOff);
		}


		protected override void OverrideValueChanged(object sender, EventArgs eArgs)
		{
			if(sender == m_Numeric)
			{
				OverrideValue = (byte)m_Numeric.Value;
			}
			else
			{
				OverrideValue = (byte)this.m_ComboBox.Items.IndexOf(m_ComboBox.Text);					
			}
			
			//
			//Update the PIG Data (and send the packet to the PIG).
			//		
			guiPage.updateOutgoingData();
		}
	}
}
