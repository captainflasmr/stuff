//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiDataItemString.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;
using System.Drawing;

namespace PSCGenericBuild
{


	public class C_guiDataItemString : C_guiDataItem
	{
		TextBox m_textString;

		protected int  m_iMaxValue     ;
		protected int  m_iMinValue     ;
		protected int  m_iDefaultValue ;
		protected int     m_overrideValue;


		public string CurrentValue
		{
			get
			{
				return m_TextBox.Text;
			}
			set
			{
                if (!guiPage.IsDisposed)
                {
                    //m_TextBox.Text = value;
                    setTextboxText(value);
                }
			}
		}

		public string OverrideValue
		{
			get
			{
				return m_overrideControl.Text;
			}
			set
			{
                if (!guiPage.IsDisposed)
                {
                    m_overrideControl.Text = value;
                }
			}
		}

		public string Value
		{
			get
			{
				return m_textString.Text;
			}
			set
			{
                if (guiPage.IsDisposed)
                {
                    //m_TextBox.Text = value;
                    setTextboxText(value);
                }
			}
		}

//		public byte [] Value
//		{
//			get
//			{
//				char [] strValue = m_textString.Text.ToCharArray();
//				byte [] strBytes = new byte[strValue.Length];
//
//				for(int i=0; i < strBytes.Length; i++)
//				{
//					strBytes[i] = (byte)strValue[i];
//				}
//
//				return strBytes;
//			}
//			set
//			{
//				//base.Value = value;
//			}
//		}



		public C_guiDataItemString()
		{
		}

		/************************************************************************
			  FUNCTION      : C_guiDataItemString()
			  DESCRIPTION   : The Constructor for a String Data Item. 
			  PARAMETERS    : string strLabel: Label string
							  int iMinValue : Minimum Value
							  int iMaxValue : Maximum Value 						  
							  int iLeft     : Pixel position in from the left of the screen. 						  
							  int iTop      : Pixel position in from the top of the screen. 						  						  
							  Form parent   : Form to add the data item to.						  
							  string strDescription : Description string label.
			  RETURNS       : Nothing.
			  GLOBALS USED  : None
			  METHOD USED   : Initialises the Data Item
			 ************************************************************************/
		public C_guiDataItemString(string strLabel, string strHashTableKey, int iLeft, int iTop, C_guiTemplatePage parent, string strDescription)
		{
			m_iMaxValue     = 0;
			m_iMinValue     = 0;
			m_iDefaultValue = 0;

			//
			//Retrieve the data from the config hash table
			//
			if(strHashTableKey == null) return;

			//
			//Initialise the data item by creating the various components.
			//
			initDataItem(strLabel, strHashTableKey, iLeft, iTop, parent, strDescription);
		}

		protected override void positionDataItems()
		{
			m_TextBox.Location     = new Point(130, 0);
			m_CheckBox.Location    = new Point(350, 0);
			m_textString.Location  = new Point(400, 0);
			m_Description.Location = new Point(650, 0);
		}

		public void setTextBoxDimension(Size size)
		{
			int iTotalWidth;
			if((size.Height > 0) && (size.Width > 0))
			{
				if(size.Height > 20)
				{
					m_TextBox.Size      = size;
					m_TextBox.WordWrap  = true;
					m_TextBox.Multiline = true;	

					m_textString.Size      = size;
					m_textString.WordWrap  = true;
					m_textString.Multiline = true;	

					iTotalWidth = m_Label.Width +
						m_textString.Width + 
						m_overrideControl.Width + 
						m_Description.Width +
						60;

					this.Size = new Size(iTotalWidth, size.Height);
				}
			}
		}

		protected override void initDataItem(string strLabel, string strHashTableKey, int iLeft, int iTop, C_guiTemplatePage parent, string strDescription)
		{
			this.Location = new Point(iLeft, iTop);
			guiPage    = parent;

			if(parent.ptrGUI.hashtable != null)
			{
				DataFields data = (DataFields) parent.ptrGUI.hashtable[strHashTableKey];

				if(data != null)
				{
					m_iMinValue      = (int)data.fMin;
					m_iMaxValue      = (int)data.fMax;
					m_iDefaultValue  = (int)data.fDefault;
					strDescription = (string) data.strDescription;
				}
			}

			//
			//Create the Label.
			//
			m_Label       = new Label();
			m_Label.Text  = strLabel;
			m_Label.Left  = 0;
			m_Label.Top   = 0;
			m_Label.Width = 130;

			//
			//Create the Text Box. Make the text box read only. By default this will change the colour of the 
			//component background to grey, so set the colour manually to white.
			//
			m_TextBox           = new TextBox();
			m_TextBox.ReadOnly  = true;
			m_TextBox.ForeColor = Color.Black;
			m_TextBox.TabStop   = false;
			m_TextBox.BackColor = Color.White;
				
			//
			//Create the Check Box.
			//
			m_CheckBox           = new CheckBox();
			m_CheckBox.Width     = 20;
			m_CheckBox.Click    += new EventHandler(ToggleOverrideActive);           

			//
			//Create the NumericUpDown.
			//
			m_textString                = new TextBox();
			m_textString.Enabled        = false;
			m_textString.TabStop        = false;
			m_textString.GotFocus      += new EventHandler(override_GotFocus);
			m_textString.LostFocus     += new EventHandler(override_LostFocus);
			//m_textString.Size           = new Size(150, 60);
			//m_textString.WordWrap       = true;
			//m_textString.Multiline      = true;



			//Add an Event Handler when the override value is changed.
			//m_textString.ValueChanged += new EventHandler(OverrideValueChanged);

			//aNumeric.Maximum        = (decimal)someDouble;
			//aNumeric.Validating    += new System.ComponentModel.CancelEventHandler (numeric_Validating);			

			//
			//Create the ComboBox
			//
			m_ComboBox = new ComboBox();

			//By default the override control is a NumericUpDown.
			m_overrideControl = m_textString;


			//
			//Create the description label.
			//
			m_Description       = new Label();
			m_Description.Text  = strDescription;
			m_strDescription    = strDescription;
			m_Description.Width = strDescription.Length * 8;

			//
			//Set the default values for the controls.
			//
			//this.CurrentValue  = "abcdefghijklmnopqrstuvwxyz_abcdefghijklmnopqrstuvwxyz_abcdefghijklmnopqrstuvwxyz_abcdefghijklmnopqr";
			this.CurrentValue  = "test text";
			this.OverrideValue = "error message text";

			//
			//Add the controls to the panel.
			//
			this.Controls.Add (m_Label);
			this.Controls.Add (m_TextBox);
			this.Controls.Add (m_CheckBox);
			this.Controls.Add (m_overrideControl);
			this.Controls.Add (m_Description);

			//Update the size of the panel.
			this.Size      = new Size(640 + m_Description.Width, 30);

			//
			//Position the data items.
			//
			positionDataItems(); 
		}
	}
}