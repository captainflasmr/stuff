//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiPIGExerciseData.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Drawing;

namespace PSCGenericBuild
{
	
	//-----------------------------------------------------------------------
	//The Exercise Data Page Class.
	//-----------------------------------------------------------------------
	public class C_guiPIGExerciseData : C_guiTemplatePage
	{
		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		//protected C_guiDataItem [] dataItem;
		string [] strMode = {"Run", "Stop", "Freeze", "Reset"};
		public PIGExerciseData m_InData;
		public PIGExerciseData m_OutData;

		public C_guiDataItemInt  dataSystemID;
		public C_guiDataItemInt  dataRunMode;

		//-----------------------------------------------------------------------
		//Class Properties
		//-----------------------------------------------------------------------

		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		/************************************************************************
		  FUNCTION      : C_guiPIGExerciseData()
		  DESCRIPTION   : The Constructor for Exercise Data Page. 
		  PARAMETERS    : parentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the Exercise Data Page.
		 ************************************************************************/
		public C_guiPIGExerciseData (C_gui parentForm)
		{            
			this.ptrGui    = parentForm;

            m_InData  = this.ptrGui.m_InPIGData.oPIGExercise;
			m_OutData = this.ptrGui.m_OutPIGData.oPIGExercise;

			//-----------------------------------------------------
			//Declare the data items.
			//-----------------------------------------------------
			m_dataItem = new C_guiDataItem[2];

			this.Text      = "PIG Data - Exercise Data";
			this.pageType  = C_gui.page.PIG_EXERCISE;


			//-----------------------------------------------------
			//Initialise each data item.
			//-----------------------------------------------------
			dataSystemID = new C_guiDataItemInt( "System ID", "PIG_EXERCISE_SYSTEM_ID", 50,  10, this, "System Identifier ");
			dataRunMode  = new C_guiDataItemInt( "Run Mode" , "PIG_EXERCISE_RUN_MODE",  50,  50, this, "Run Mode (Run/Stop/Freeze/Reset)");

			dataRunMode.setListEntries(strMode);

			this.Controls.Add(dataSystemID);
			this.Controls.Add(dataRunMode);

			this.MdiParent = parentForm;
			this.Size        = new Size(700, 120);

			m_initialised = true;
		}

		public override void updateIncomingData()
		{

			this.dataSystemID.CurrentValue = m_InData.iSystemID.Value;
			this.dataRunMode.CurrentValue  = m_InData.iRunMode.Value;

		}

		public override void updateOutgoingData()
		{
            if (m_initialised) { 
                this.ptrGui.m_OutPIGData.oPIGExercise.iSystemID.Value = dataSystemID.Value;
			    this.ptrGui.m_OutPIGData.oPIGExercise.iRunMode.Value  = dataRunMode.Value;
			
			    this.ptrGui.m_OutPIGData.oPIGExercise.iSystemID.Flag  = dataSystemID.overrideChecked;
			    this.ptrGui.m_OutPIGData.oPIGExercise.iRunMode.Flag   = dataRunMode.overrideChecked;
            }
		}

		public override void setOverride(bool bEnabled)
		{
			dataSystemID.setOverride(bEnabled);
			dataRunMode.setOverride(bEnabled);	
		}

		public override void enableOverrides(bool bOnOff)
		{
			dataSystemID.enableOverride(bOnOff);
			dataRunMode.enableOverride(bOnOff);
		}
	}

}
