//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiIODataAS1082.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Windows.Forms;

namespace PSCGenericBuild
{
	//-----------------------------------------------------------------------
	//The IO Data Class.
	//-----------------------------------------------------------------------
	public class C_guiIODataAS1082 : C_guiTemplatePage
	{

		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		public IO_Data m_InData;

		protected C_guiIODataItemFloat   dataBearing;
		protected C_guiIODataItemBoolean dataRangeCut;
		protected C_guiIODataItemBoolean dataBearingCut;
		//protected C_guiIODataItemBoolean dataPTT;
		protected C_guiIODataItemBoolean dataHandlesDown;
		protected C_guiIODataItemFloat   dataElevControl;
		protected C_guiIODataItemFloat   dataStadControl;
		protected C_guiIODataItemBoolean dataMagnification;
		protected C_guiIODataItemInt	 dataTargetHeight;
		protected C_guiIODataItemFloat   dataRearStadAngle; 
		protected C_guiIODataItemFloat   dataRearTrueBrg;   
		protected C_guiIODataItemFloat   dataRearRelBrg;    
		//protected C_guiIODataItemFloat   dataTargetDisplay;
		protected C_guiIODataItemFloat   dataBeckmanTrue;
		protected C_guiIODataItemFloat   dataBeckmanRel;

		protected GroupBox m_inputGroupBox;
		protected GroupBox m_outputGroupBox;



		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		/************************************************************************
		  FUNCTION      : C_guiIODataAS1082()
		  DESCRIPTION   : The Constructor for IO Data Page (AS1082). 
		  PARAMETERS    : parentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the IO Data (AS1082) Page.
		 ************************************************************************/
		public C_guiIODataAS1082 (C_gui parentForm)
		{
			string [] strTrueFalse = {"False", "True"};
			string [] strHighLow = {"Low", "High"};

			this.ptrGui = parentForm;
			this.MdiParent = parentForm;

			this.Text      = "IO Data";
			this.Size      = new Size(820, 530);			
			this.pageType  = C_gui.page.IO_DATA_AS1082;

		    m_InData = this.ptrGui.m_InIOData;

			//
			//Define the group boxes.
			//
			m_inputGroupBox  = new GroupBox();
			m_outputGroupBox = new GroupBox();

			m_inputGroupBox.Text = "Input Controls";
			m_outputGroupBox.Text = "Output Controls";

			m_inputGroupBox.Size = new Size(800, 280);
			m_inputGroupBox.Location = new Point(5, 5);

			m_outputGroupBox.Size = new Size(800, 190);
			m_outputGroupBox.Location = new Point(5, 300);

			this.Controls.Add(m_inputGroupBox);
			this.Controls.Add(m_outputGroupBox);

			//-----------------------------------------------------
			//Declare the data items.
			//-----------------------------------------------------
			dataBearing       = new C_guiIODataItemFloat("Bearing",             "IO_DATA_AS1082_BEARING",          30,  30, this, "");
			dataRangeCut      = new C_guiIODataItemBoolean("Range Cut",         "IO_DATA_AS1082_RANGE_CUT",        30,  60, this, "");
			dataBearingCut    = new C_guiIODataItemBoolean("Bearing Cut",       "IO_DATA_AS1082_BEARING_CUT",      30,  90, this, "");
			//dataPTT           = new C_guiIODataItemBoolean("PTT",               "IO_DATA_AS1082_PTT",              30, 120, this, "");
			dataHandlesDown   = new C_guiIODataItemBoolean("Handles Down",      "IO_DATA_AS1082_HANDLES_DOWN",     30, 120, this, "");
			dataElevControl   = new C_guiIODataItemFloat("Elevation Control",   "IO_DATA_AS1082_ELEVATION_CONTROL",30, 150, this, "");
			dataStadControl   = new C_guiIODataItemFloat("Stadiametric Control","IO_DATA_AS1082_STADIAMETRIC",     30, 180, this, "");
			dataMagnification = new C_guiIODataItemBoolean("Magnification",       "IO_DATA_AS1082_MAGNIFICATION",    30, 210, this, "");
			dataTargetHeight  = new C_guiIODataItemInt("Target Height",     "IO_DATA_AS1082_TARGET_HEIGHT",    30, 240, this, "");

			dataRearStadAngle = new C_guiIODataItemFloat("Rear Display Stad Angle", "IO_DATA_AS1082_REAR_DISPLAY_STAD_ANGLE", 30, 30, this, "");
			dataRearTrueBrg   = new C_guiIODataItemFloat("Rear Display True Brg", "IO_DATA_AS1082_REAR_DISPLAY_TRUE_BRG",  30, 60, this, "");
			dataRearRelBrg    = new C_guiIODataItemFloat("Rear Display Rel Brg", "IO_DATA_AS1082_REAR_DISPLAY_REL_BRG",    30, 90, this, "");
			//dataTargetDisplay = new C_guiIODataItemFloat("Target Display",      "IO_DATA_AS1082_TARGET_DISPLAY",   30, 120, this, "");
			dataBeckmanTrue = new C_guiIODataItemFloat("Beckman True Brg",      "IO_DATA_AS1082_BECKMAN_TRUE",   30, 120, this, "");
			dataBeckmanRel = new C_guiIODataItemFloat("Beckman Rel Brg",      "IO_DATA_AS1082_BECKMAN_REL",   30, 150, this, "");

			dataRangeCut.setListEntries(strTrueFalse);
			dataBearingCut.setListEntries(strTrueFalse);
			//dataPTT.setListEntries(strTrueFalse);
			dataHandlesDown.setListEntries(strTrueFalse);
			//dataTargetHeight.setListEntries(strTrueFalse);
			dataMagnification.setListEntries(strHighLow);

			m_inputGroupBox.Controls.Add(dataBearing);
			m_inputGroupBox.Controls.Add(dataRangeCut);
			m_inputGroupBox.Controls.Add(dataBearingCut);
			//m_inputGroupBox.Controls.Add(dataPTT);
			m_inputGroupBox.Controls.Add(dataHandlesDown);
			m_inputGroupBox.Controls.Add(dataElevControl);
			m_inputGroupBox.Controls.Add(dataStadControl);
			m_inputGroupBox.Controls.Add(dataMagnification);
			m_inputGroupBox.Controls.Add(dataTargetHeight);

			m_outputGroupBox.Controls.Add(dataRearStadAngle);
			m_outputGroupBox.Controls.Add(dataRearTrueBrg);
			m_outputGroupBox.Controls.Add(dataRearRelBrg);
			//m_outputGroupBox.Controls.Add(dataTargetDisplay);
			m_outputGroupBox.Controls.Add(dataBeckmanTrue);
			m_outputGroupBox.Controls.Add(dataBeckmanRel);

		}

		protected override void Dispose(bool disposing)
		{
			//Uncheck the 'io menu' item in the 'display' menu
			//MenuItem ioMenu = this.ptrMain.getMenuItem(C_gui.page.IO_DATA);
			//if(ioMenu != null) ioMenu.Checked = false;

			base.Dispose(disposing);
		}

		public override void updateIncomingData()
		{
			dataBearing.CurrentValue = m_InData.m_fBearing.Value;
			dataRangeCut.CurrentValue = m_InData.m_bRangeCut.Value;
			dataBearingCut.CurrentValue = m_InData.m_bBearingCut.Value;
			//dataPTT.CurrentValue = m_InData.m_bPushToTalk.Value;
			dataHandlesDown.CurrentValue = m_InData.m_bHandlesDown.Value;
			dataElevControl.CurrentValue = m_InData.m_fElevation.Value;
			dataStadControl.CurrentValue = m_InData.m_fStadAngle.Value;
			dataMagnification.CurrentValue = m_InData.m_bMagnification.Value;
			dataRearStadAngle.CurrentValue = m_InData.m_fRearStadAngle.Value; 
			dataRearTrueBrg.CurrentValue = m_InData.m_fRearTrueBrg.Value;   
			dataRearRelBrg.CurrentValue = m_InData.m_fRearRelBrg.Value;    
			dataTargetHeight.CurrentValue = m_InData.m_bTarHeight.Value;
			//dataTargetDisplay.CurrentValue = m_InData.m_fDisplayTar.Value;
			dataBeckmanTrue.CurrentValue = m_InData.m_fBeckmanTrue.Value;
			dataBeckmanRel.CurrentValue = m_InData.m_fBeckmanRel.Value;

			// Status
			dataBearing.ioStatus = m_InData.m_fBearing.Status;
			dataRangeCut.ioStatus = m_InData.m_bRangeCut.Status;
			dataBearingCut.ioStatus = m_InData.m_bBearingCut.Status;
			//dataPTT.ioStatus = m_InData.m_bPushToTalk.Status;
			dataHandlesDown.ioStatus = m_InData.m_bHandlesDown.Status;
			dataElevControl.ioStatus = m_InData.m_fElevation.Status;
			dataStadControl.ioStatus = m_InData.m_fStadAngle.Status;
			dataMagnification.ioStatus = m_InData.m_bMagnification.Status;
			dataRearStadAngle.ioStatus = m_InData.m_fRearStadAngle.Status; 
			dataRearTrueBrg.ioStatus = m_InData.m_fRearTrueBrg.Status;   
			dataRearRelBrg.ioStatus = m_InData.m_fRearRelBrg.Status;    
			dataTargetHeight.ioStatus = m_InData.m_bTarHeight.Status;
			//dataTargetDisplay.ioStatus = m_InData.m_fDisplayTar.Status;
			dataBeckmanTrue.ioStatus = m_InData.m_fBeckmanTrue.Status;
			dataBeckmanRel.ioStatus = m_InData.m_fBeckmanRel.Status;

		}

		public override void updateOutgoingData()
		{           
			ptrGui.m_OutIOData.m_fBearing.Value = dataBearing.Value;
			ptrGui.m_OutIOData.m_bRangeCut.Value = dataRangeCut.Value;
			ptrGui.m_OutIOData.m_bBearingCut.Value = dataBearingCut.Value;
			//ptrGui.m_OutIOData.m_bPushToTalk.Value = dataPTT.Value;
			ptrGui.m_OutIOData.m_bHandlesDown.Value =dataHandlesDown.Value;
			ptrGui.m_OutIOData.m_fElevation.Value = dataElevControl.Value;
			ptrGui.m_OutIOData.m_fStadAngle.Value = dataStadControl.Value;
			ptrGui.m_OutIOData.m_bMagnification.Value = dataMagnification.Value;
			ptrGui.m_OutIOData.m_fRearStadAngle.Value = dataRearStadAngle.Value; 
			ptrGui.m_OutIOData.m_fRearTrueBrg.Value = dataRearTrueBrg.Value;   
			ptrGui.m_OutIOData.m_fRearRelBrg.Value = dataRearRelBrg.Value;    
			ptrGui.m_OutIOData.m_bTarHeight.Value = dataTargetHeight.Value;
			//ptrGui.m_OutIOData.m_fDisplayTar.Value = dataTargetDisplay.Value;
			ptrGui.m_OutIOData.m_fBeckmanTrue.Value = dataBeckmanTrue.Value;
			ptrGui.m_OutIOData.m_fBeckmanRel.Value = dataBeckmanRel.Value;

			//Flags
			ptrGui.m_OutIOData.m_fBearing.Flag = dataBearing.overrideChecked;
			ptrGui.m_OutIOData.m_bRangeCut.Flag = dataRangeCut.overrideChecked;
			ptrGui.m_OutIOData.m_bBearingCut.Flag = dataBearingCut.overrideChecked;
			//ptrGui.m_OutIOData.m_bPushToTalk.Flag = dataPTT.overrideChecked;
			ptrGui.m_OutIOData.m_bHandlesDown.Flag = dataHandlesDown.overrideChecked;
			ptrGui.m_OutIOData.m_fElevation.Flag = dataElevControl.overrideChecked;
			ptrGui.m_OutIOData.m_fStadAngle.Flag = dataStadControl.overrideChecked;
			ptrGui.m_OutIOData.m_bMagnification.Flag = dataMagnification.overrideChecked;
			ptrGui.m_OutIOData.m_fRearStadAngle.Flag = dataRearStadAngle.overrideChecked; 
			ptrGui.m_OutIOData.m_fRearTrueBrg.Flag = dataRearTrueBrg.overrideChecked;   
			ptrGui.m_OutIOData.m_fRearRelBrg.Flag = dataRearRelBrg.overrideChecked;    
			ptrGui.m_OutIOData.m_bTarHeight.Flag = dataTargetHeight.overrideChecked;
			//ptrGui.m_OutIOData.m_fDisplayTar.Flag = dataTargetDisplay.overrideChecked;
			ptrGui.m_OutIOData.m_fBeckmanTrue.Flag = dataBeckmanTrue.overrideChecked;
			ptrGui.m_OutIOData.m_fBeckmanRel.Flag = dataBeckmanRel.overrideChecked;
		}

		public override void enableOverrides(bool bOnOff)
		{
		  dataBearing.enableOverride(bOnOff);
		  dataRangeCut.enableOverride(bOnOff);
		  dataBearingCut.enableOverride(bOnOff);
		  //dataPTT.enableOverride(bOnOff);
		  dataHandlesDown.enableOverride(bOnOff);
		  dataElevControl.enableOverride(bOnOff);
		  dataStadControl.enableOverride(bOnOff);
		  dataMagnification.enableOverride(bOnOff);
		  dataTargetHeight.enableOverride(bOnOff);
		}

	}
}
