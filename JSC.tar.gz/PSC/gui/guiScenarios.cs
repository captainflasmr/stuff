//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiScenarios.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Windows.Forms;

namespace PSCGenericBuild
{

	public struct TargetDynamicData
	{
		public float fTargetRange;         // PIP target true range array
		public float fTargetBearing;       // PIP target true bearing array
		public float fTargetAcceleration;  // PIP target scenario accelaration
		public float fTargetX;             // PIP target x coordinate
		public float fTargetY;             // PIP target y coordinate
		public bool  bTargetInitialised;   // Target starting position has been calculated.
	}


	//-----------------------------------------------------------------------
	//The Scenarios Page Class.
	//-----------------------------------------------------------------------
	public class C_guiScenarios : C_guiTemplatePage
	{
		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		protected Button          m_StartStop;
		protected ListView        m_scenarioList;
		protected ListViewItem [] m_scenarioListItems;
		protected ListViewItem    m_selected;
		protected ScenarioData    m_selectedData;
		protected ColumnHeader [] m_columnHeader;

		protected Label m_runningScenario;
		protected int   m_iRunningScenario;

		public const int NUM_SCENARIOS = 10;
		public const int NUM_COLUMNS   = 3;

		public const int MAX_SCENARIO_INDEX = 63;

		public const int OPEN_SEA = 0;
		public const int CLYDE    = 1;

		public const int CLEAR    = 0;
		public const int CLOUDY   = 1;
		public const int OVERCAST = 2;
		public const int FOG      = 3;
		public const int RAIN     = 4;

		public const int FREEZE   = 0;
		public const int RUN      = 1;
		public const int TARGET_FREEZE = 2;
		public const int FAST_RUN = 3;

		public const float KGRID       =  6366707.00f;   // grid conversion factor
		public const float KDEGTORAD   = 0.017453292f;   // degrees to radians conversion
		public const float KFTTOM      = 0.3048f;        // feet to metres conversion
		public const float KYDSTOM     = 0.9144f;        // yards to metres conversion
		public const float KKTSTOMPS   = 0.5144f;        // knots to metres/sec conversion
		public const float KKTSTOYPS   = 0.5626f;        // knots to yards/sec conversion
		public const float KBRAM16     = 0.00549316f;    // 16 bit BRAM scale factor
		public const float KBRAM32     = 8.3819e-08f;    // 32 bit BRAM scale factor
		public const float KILO        = 1000.0f;        // Kilo multiplication factor
		public const float KILOYARD    = 914.4f;         // One thousand yards - as metres
		public const float KDEGTODEC   = 91.0222223f;    // Degrees to decimal factor

		public const float OWN_CLIMB_MIN = -30.48f;      // minimum own boat climb rate (m/sec)
		public const float OWN_CLIMB_MID =   0.0f;       // mid own boat climb rate (m/sec)
		public const float OWN_CLIMB_MAX =  30.48f;      // maximum own boat climb rate (m/sec)
		public const float OWN_SPEED_MIN =   0.0f;       // minimum own boat speed (m/sec)
		public const float OWN_SPEED_MAX =  30.864f;     // maximum own boat speed (m/sec)

		public const float X_OFFSET_MIN   = -100000.0f;   // minimum x-offset coordinate (m)
		public const float X_OFFSET_MID   =       0.0f;   // mid x-offset coordinate (m)
		public const float X_OFFSET_MAX   =  100000.0f;   // maximum x-offset coordinate (m)
		public const float Y_OFFSET_MIN   = -100000.0f;   // minimum y-offset coordinate (m)
		public const float Y_OFFSET_MID   =       0.0f;   // mid y-offset coordinate (m)
		public const float Y_OFFSET_MAX   =  100000.0f;   // maximum y-offset coordinate (m)
		public const float Z_OFFSET_MIN   =    -304.8f;   // minimum z-offset coordinate (m)
		//public const float Z_OFFSET_MID   = SEA_LEVEL;     // mid z-offset coordinate (m)
		public const float Z_OFFSET_MAX   =    6096.1f;   // maximum z-offset coordinate (m)
		public const float TAR_OFFSET_MIN =       0.0f;   // minimum target offset coordinate (m)
		public const float TAR_OFFSET_MAX =  141422.0f;   // maximum target offset coordinate (m)
		public const float TAR_SPEED_MIN  = 0.0f;         // minimum target speed (m/sec)
		public const float TAR_SPEED_MAX  = 514.4f;       // maximum target speed (m/sec)

		public const float DRIFT_SPEED_MIN = 0.0f;        // minimum drift speed (m/sec)
		public const float DRIFT_SPEED_MAX = 32.864f;     // minimum drift speed (m/sec)

		public const int SECS_IN_MINUTE   =    60;        // The number of seconds in a minute
		public const int SECS_IN_HOUR     =  3600;        // The number of seconds in an hour
		public const int SECS_IN_DAY      = 86400;        // The number of seconds in a day

		public const float LATITUDE_MIN    = -90.0f;      // minimum latitude (deg)
		public const float LATITUDE_MID    = 0.0f;        // mid latitude (deg)
		public const float LATITUDE_MAX    = 90.0f;       // maximum latitude (deg)
		public const float LATITUDE_THRESH = 89.999f;     // lat. threshold for big jump calc.
		public const float LONGITUDE_MIN   = -180.0f;     // minimum longitude (deg)
		public const float LONGITUDE_MID   = 0.0f;        // mid longitude (deg)
		public const float LONGITUDE_MAX   = 180.0f;      // maximum longitude (deg)

		public const float BRG_MIN         = 0.0f;        // minimum bearing (deg)
		public const float BRG_MID         = 180.0f;      // mid bearing (deg)
		public const float BRG_MAX         = 360.0f;      // maximum bearing (deg)



		//
		//Variables used in scenario dynamics calculations.
		//
		protected float m_fDiveTime;
		protected float m_fTimeFactor;
		protected int   m_iFrameCounter;

		protected float m_fOwnX;
		protected float m_fOwnY;
		protected float m_fOwnDeltaX;
		protected float m_fOwnDeltaY;

		protected float m_fTargetDeltaX;
		protected float m_fTargetDeltaY;
		protected float m_fAcceleration;

        protected int iLastTargetID;

		protected float [] PIP_tar_range;          // PIP target true range array
		protected float [] PIP_tar_bearing;        // PIP target true bearing array
		protected float [] PIP_tar_accel;          // PIP target scenario accelaration
		protected float [] PIP_tar_x;              // PIP target x coordinate
		protected float [] PIP_tar_y;              // PIP target y coordinate

		TargetDynamicData [] DynamicData;

		protected bool bTargetInitialise;
		protected double m_ReferenceLat;
		protected double m_ReferenceLon;

		protected float m_fDeltaTime;

		//-----------------------------------------------------------------------
		//Class Properties
		//-----------------------------------------------------------------------

		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		/************************************************************************
		  FUNCTION      : C_guiScenarios()
		  DESCRIPTION   : The Constructor for the Scenarios Page.
		  PARAMETERS    : parentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the Scenarios Page.
		 ************************************************************************/
		public C_guiScenarios (C_gui parentForm)
		{
			ScenarioData data;
			string strText;
			string [,] strScenario = {{"Scenario 1", "Description 1", "0"},
									  {"Scenario 2", "Description 2", "1"},
									  {"Scenario 3", "Description 3", "2"},
									  {"Scenario 4", "Description 4", "3"},
									  {"Scenario 5", "Description 5", "4"},
									  {"Scenario 6", "Description 6", "5"},
									  {"Scenario 7", "Description 7", "6"},
									  {"Scenario 8", "Description 8", "7"},
									  {"Scenario 9", "Description 9", "8"},
									  {"Scenario 10","Description 10","9"}};

			ListViewItem    listNumber;
			ListViewItem.ListViewSubItem listName;
			ListViewItem.ListViewSubItem listDesc;
			ListViewItem.ListViewSubItem listIndex;


			this.ptrGui    = parentForm;
			//this.ptrMain   = parentForm.psc;

			this.Text      = "Scenarios";
			this.pageType  = C_gui.page.SCENARIOS;

			//-----------------------------------------------------
			//Initialise each data item.
			//-----------------------------------------------------
			this.MdiParent = parentForm;
			this.Size      = new Size(450, 360);

			m_StartStop          = new Button();
			m_StartStop.Location = new Point( 20, 20);
			m_StartStop.Width    = 90;
			m_StartStop.Height   = 35;
			m_StartStop.Click  += new EventHandler(scenarioStartStop);
			m_StartStop.Text     = "Scenario\nStart Stop";
			m_StartStop.Enabled  = false;                                //By default the button is disabled.
			Controls.Add(m_StartStop);

			//
			//Create a Label
			//
			m_runningScenario          = new Label();
			m_runningScenario.Location = new Point( 150, 30);
			m_runningScenario.Width    = 200;
			Controls.Add(m_runningScenario);

			//
			//Create the scenario list view.
			//
			m_scenarioListItems = new ListViewItem[NUM_SCENARIOS];
			m_scenarioList      = new ListView();

			m_scenarioList.Location      = new Point(20, 80);
			m_scenarioList.Size          = new Size (400, 230);
			m_scenarioList.View          = View.Details;
			m_scenarioList.FullRowSelect = true;
			m_scenarioList.MultiSelect   = false;
			m_scenarioList.HideSelection = false;
			m_scenarioList.Enabled       = true;
			m_scenarioList.SelectedIndexChanged += new EventHandler(scenarioListSelection);


			//
			//Create the column headers
			//
			m_columnHeader = new ColumnHeader[NUM_COLUMNS];

			for(int i = 0; i < NUM_COLUMNS; i++)
			{
				m_columnHeader[i] = new ColumnHeader();
			}

			m_columnHeader[0].Text = "Number";
			m_columnHeader[1].Text = "Name";
			m_columnHeader[2].Text = "Description";

			m_columnHeader[1].Width = 135;
			m_columnHeader[2].Width = 200;

			for(int i = 0; i < NUM_COLUMNS; i++)
			{
				m_scenarioList.Columns.Add(m_columnHeader[i]);
			}

			//for(int i = 0; i < NUM_SCENARIOS; i++)
			for(int i=0 ; i < ptrGui.scenariosList.Count; i++)
			{
				data = (ScenarioData) ptrGui.scenariosList[i];

				strText = String.Format("{0}", i+1);

				listNumber = new ListViewItem(strText);
				listName   = new ListViewItem.ListViewSubItem(listNumber, data.strName);
				listDesc   = new ListViewItem.ListViewSubItem(listNumber, data.strDescription);
				listIndex  = new ListViewItem.ListViewSubItem(listNumber, data.iIndex.ToString());

				ListViewItem dataItem = m_scenarioList.Items.Add(listNumber);
				dataItem.SubItems.Add(listName);
				dataItem.SubItems.Add(listDesc);
				dataItem.SubItems.Add(listIndex);
			}

			//
			//Create the dynamics data.
			//
			DynamicData   = new TargetDynamicData[SIMControl.NUM_PERI_TARGETS];

			for(int i=0; i < DynamicData.Length; i++)
			  DynamicData[i] = new TargetDynamicData();

			this.Controls.Add(m_scenarioList);
		}

		public void scenarioStop()
		{
			if( this.ptrGui.ScenarioRunning == true)
			{
				this.ptrGui.ScenarioRunning = false;
				m_scenarioList.Enabled       = true;

				for(int i=0; i < m_scenarioList.Items.Count; i++)
				{
					m_scenarioList.Items[i].BackColor = Color.White;
				}

				m_runningScenario.Text = "";
			}
		}

		public void scenarioStartStop(object sender, EventArgs eArgs)
		{
			string strText;
			int    index;

			if( this.ptrGui.ScenarioRunning == true)
			{
				//
				//Stop the scenario from running.
				//
				scenarioStop();
			}
			else
			{
				if(m_selected != null)
				{
					this.ptrGui.ScenarioRunning = true;
					m_scenarioList.Enabled       = false;

					for(int i=0; i < m_scenarioList.Items.Count; i++)
					{
						m_scenarioList.Items[i].BackColor = Color.FromArgb(220, 215, 205) ;
					}

					index   = m_selected.Index;
					strText = m_selected.SubItems[1].Text;

					m_runningScenario.Text = "Running: " + strText;

					//
					//Emulate the PIP.
					//
					ptrGui.PIPEmulation = true;

					//
					//Run the selected scenario.
					//
					runScenario(m_selectedData.iIndex);
				}
			}
		}

		private void scenarioListSelection(object sender, EventArgs e)
		{
			int iIndex;
			ListView listView = (ListView)sender;

			if(listView == null)
				return;

			if(m_StartStop.Enabled == false)
				m_StartStop.Enabled  = true;

			if(listView.SelectedItems.Count > 0)
			{
				try
				{
					m_selected = listView.SelectedItems[0];

					if(m_selected.SubItems.Count >= 4)
					{
						iIndex = Int32.Parse(m_selected.SubItems[3].Text);

						if(iIndex > 0 && iIndex <= MAX_SCENARIO_INDEX)
						  m_selectedData = (ScenarioData)ptrGui.scenariosList[iIndex -1];
					}
				}
				catch(FormatException)
				{
					m_selected     = null;
				}
			}
		}

		protected void runScenario(int iScenario)
		{
			if(iScenario < 0 || iScenario > MAX_SCENARIO_INDEX)
				return;

			m_iRunningScenario = iScenario;
			bTargetInitialise = false;

			// Reset the scenario time
			m_fDeltaTime = 0.0f;

			//Set up the default scenario data.
			initialiseScenario();

			//Set up the specific scenario data.
            setupScenario(iScenario);
		}

		protected void initialiseScenario()
		{
			//
			//Default Exercise Conditions.
			//
			ptrGui.PIPExercise.dataRunMode.OverrideValue = RUN;
			ptrGui.PIPExercise.dataHours.OverrideValue   = 12;
			ptrGui.PIPExercise.dataMinutes.OverrideValue = ptrGui.PIPExercise.dataMinutes.MinValue;
			ptrGui.PIPExercise.dataSeconds.OverrideValue = ptrGui.PIPExercise.dataSeconds.MinValue;
			ptrGui.PIPExercise.dataDay.OverrideValue     = ptrGui.PIPExercise.dataDay.MinValue;
			ptrGui.PIPExercise.dataMonth.OverrideValue   = ptrGui.PIPExercise.dataMonth.MinValue;
			ptrGui.PIPExercise.dataYear.OverrideValue    = ptrGui.PIPExercise.dataYear.MinValue;

			//
			//Default Periscope Conditions.
			//
			ptrGui.PIPPeriscope.dataPeriDrainDown.OverrideValue = 15;
			ptrGui.PIPPeriscope.dataLLTVGain.OverrideValue      = 0;
			ptrGui.PIPPeriscope.dataTIGain.OverrideValue        = 0;
			ptrGui.PIPPeriscope.dataPeriRelBrg.OverrideValue    = 0.0f;
			ptrGui.PIPPeriscope.dataPeriRelElev.OverrideValue   = 0.0f;
			ptrGui.PIPPeriscope.dataInstControl.OverrideValue   = true;
			ptrGui.PIPPeriscope.dataMag.OverrideValue           = false;
			ptrGui.PIPPeriscope.dataMastPosition.OverrideValue  = true;
			ptrGui.PIPPeriscope.dataTIHotControl.OverrideValue  = false;

			//
			//Default Environment Conditions.
			//
			ptrGui.PIPEnvironment.dataMoon.OverrideValue        = false;
			ptrGui.PIPEnvironment.dataCoastLights.OverrideValue = false;
			ptrGui.PIPEnvironment.dataIceEdge.OverrideValue     = false;
			ptrGui.PIPEnvironment.dataSun.OverrideValue         = false;

			ptrGui.PIPEnvironment.dataWeather.OverrideValue        = 0;
			ptrGui.PIPEnvironment.dataCoastline.OverrideValue      = 1;
			ptrGui.PIPEnvironment.dataSeaState.OverrideValue       = 3;
			ptrGui.PIPEnvironment.dataMoonBrg.OverrideValue        = 0.0f;
			ptrGui.PIPEnvironment.dataMoonElev.OverrideValue       = 0.0f;
			ptrGui.PIPEnvironment.dataVisibleRange.OverrideValue   = 32.0f;
			ptrGui.PIPEnvironment.dataIRVisibleRange.OverrideValue = 32.0f;
			ptrGui.PIPEnvironment.dataUWVisibleRange.OverrideValue = 0.5f;
			ptrGui.PIPEnvironment.dataWindSpeed.OverrideValue      = 10.0f;
			ptrGui.PIPEnvironment.dataWindDirection.OverrideValue  = 90.0f;
			ptrGui.PIPEnvironment.dataIceEdgeLat.OverrideValue     = 0.0f;
			ptrGui.PIPEnvironment.dataIceEdgeLon.OverrideValue     = 0.0f;
			ptrGui.PIPEnvironment.dataIceEdgeOrient.OverrideValue  = 0.0f;
			ptrGui.PIPEnvironment.dataSunBrg.OverrideValue         = 0.0f;
			ptrGui.PIPEnvironment.dataSunElev.OverrideValue        = 0.0f;

			//
			//Default Ownboat Conditions.
			//
			ptrGui.PIPOwnship.dataDepth.OverrideValue              = 0.0f;
			ptrGui.PIPOwnship.dataDiveRate.OverrideValue           = 0.0f;
			ptrGui.PIPOwnship.dataTurnRate.OverrideValue           = 0.0f;
			ptrGui.PIPOwnship.dataPitch.OverrideValue              = 0.0f;
			ptrGui.PIPOwnship.dataHeading.OverrideValue            = 0.0f;
			ptrGui.PIPOwnship.dataDriftCourse.OverrideValue        = 0.0f;
			ptrGui.PIPOwnship.dataSpeed.OverrideValue              = 0.0f;
			ptrGui.PIPOwnship.dataDriftSpeed.OverrideValue         = 0.0f;

			m_fOwnX      = 0.0f;
			m_fOwnY      = 0.0f;
			m_fOwnDeltaX = 0.0f;
			m_fOwnDeltaY = 0.0f;



			//
			//Reset the dynamic data
			//
			for(int i = 0 ; i < DynamicData.Length; i++)
			{
				DynamicData[i].bTargetInitialised = false;
			}

		}

		protected void setupScenario(int iScenarioIndex)
		{
            TargetData lpTargetData;

			switch(iScenarioIndex)
			{
					//-----------------------------------------
					//AS1117 Scenario 1
					//-----------------------------------------
				case 1:
					setReferenceLatLon(55.4666, -5.4);
					setOwnboatPosLatLon(55.4666, -5.4);
					break;

					//-----------------------------------------
					//AS1117 Scenario 2
					//-----------------------------------------
				case 2:
					//Setup Ownboat data.
					setReferenceLatLon(55.4666, -5.4);
					setOwnboatPosLatLon(55.4666, -5.4);
					ptrGui.PIPOwnship.dataSpeed.OverrideValue = 12.0f;

					//Setup Target data.
					deployTarget(0, 23, -1.0f, 0.0f, 0.0f, 0.0f, 12.0f); //Broadsword
					break;

					//-----------------------------------------
					//AS1117 Scenario 3 - Underwater Look
					//-----------------------------------------
				case 3:

					//Setup Ownship data
					ptrGui.PIPOwnship.dataDepth.OverrideValue              = -50.0f;
					ptrGui.PIPOwnship.dataHeading.OverrideValue            = 180.0f;

					//Setup Environment data
					ptrGui.PIPEnvironment.dataUWVisibleRange.OverrideValue = 1.0f;

					//Setup target data
					deployTarget(0, 34, -0.5f, -0.5f, 0.0f, 45.0f, 10.0f); //Sovremenny Destroyer

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(0);
					if(lpTargetData != null)
					{
						lpTargetData.fTurnRate.Value = 3.0f;

						if ((lpTargetData.fX.Value > 200.0) &&
							(lpTargetData.fX.Value > 210.0))
						{
							lpTargetData.fX.Value = 200.0f;
							lpTargetData.fY.Value = -190.0f;
							lpTargetData.fHeading.Value = 315.0f;
							lpTargetData.fDriftCourse.Value = 315.0f;
						}
						else if ((lpTargetData.fX.Value < -200.0f) &&
							     (lpTargetData.fY.Value > 210.0f))
						{
							lpTargetData.fX.Value = -200.0f;
							lpTargetData.fY.Value = -190.0f;
							lpTargetData.fHeading.Value = 45.0f;
							lpTargetData.fDriftCourse.Value = 45.0f;
						}
					}

					break;

					//-----------------------------------------
					//AS1117 Scenario 4 - Bow waves and Wakes
					//-----------------------------------------
				case 4:
					deployTarget(0, 23, -1.0f, -0.0f, 0.0f, 0.0f, 0.0f); //Broadsword
					break;

					//-----------------------------------------
					//AS1117 Scenario 5 - Time of Day
					//-----------------------------------------
				case 5:
					//Setup Ownboat data.
					setReferenceLatLon(55.25, -5.41666);
					setOwnboatPosLatLon(55.25, -5.41666);
					ptrGui.PIPOwnship.dataSpeed.OverrideValue = 10.0f;

					//Setup Target data.
					deployTarget(0, 42, 0.0f, 0.9f, 0.0f, 210.0f, 20.0f);   //Frigate
					deployTarget(1, 23, 1.9f, 3.2909f, 0.0f, 180.0f, 20.0f);//Broadsword
					deployTarget(2, 54, 0.0f, -1.4f, -1.0f, 315.0f, 15.0f); //Tango Submarine
					deployTarget(3, 14, -0.707f, -0.707f, 60.0f, 0.0f, 25.0f);//Helix Helicopter
					deployTarget(4, 34, 0.122166845f, 6.998933866f, 0.0f, 180.0f, 9.0f);//Sovremenny Destroyer
					deployTarget(5, 10, -5.657f, 5.657f, 0.0f, 90.0f, 18.0f);//Udaloy Destroyer
					deployTarget(6, 129, 0.471f, 8.9877f, 0.0f, 109.0f, 8.5f);//Manchester
					deployTarget(7, 48, 5.657f, 5.657f, 500.0f, 225.0f, 250.0f);//Orion Aircraft

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(0);
					if(lpTargetData != null)
					{
						lpTargetData.fPitch.Value = 3.0f;
					}
					break;

					//-----------------------------------------
					//AS1117 Scenario 6 - Navigation Lights
					//-----------------------------------------
				case 6:
					//Setup the exercise data
					ptrGui.PIPExercise.dataHours.OverrideValue   = 0;

					//Setup the environment data
					ptrGui.PIPEnvironment.dataMoon.OverrideValue     = true;
					ptrGui.PIPEnvironment.dataMoonElev.OverrideValue = 40.0f;
					ptrGui.PIPEnvironment.dataMoonBrg.OverrideValue  = 90.0f;

					//Setup the target data
					deployTarget(0, 23, 0.0f, 0.2f, 0.0f, 90.0f, 0.0f); //Broadsword
					ptrGui.PIPTarget(0).dataNavLights.OverrideValue = true;
					break;

					//-----------------------------------------
					//AS1117 Scenario 7 - Sonar Dip
					//-----------------------------------------
				case 7:
					//Setup the ownboat data
					ptrGui.PIPOwnship.dataSpeed.OverrideValue   = 0.0f;

					//Setup the periscope data
					ptrGui.PIPPeriscope.dataPeriDrainDown.OverrideValue  = 10;

					//Setup the environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue  = OPEN_SEA;

					//Setup the target data
					deployTarget(0, 14, 0.0f, 1.0f, 100.0f, 90.0f, 0.0f);//Helix Helicopter
					break;

					//-----------------------------------------
					//AS1117 Scenario 8 - Sea State
					//-----------------------------------------
				case 8:
					//Setup the target data
					deployTarget(0, 129, -1.0f, 0.0f, 0.0f, 0.0f, 12.0f);//Manchester
					break;

					//-----------------------------------------
					//AS1117 Scenario 9 - Clouds
					//-----------------------------------------
				case 9:
					//Setup the target data
					deployTarget(0, 129, -1.0f, 0.0f, 0.0f, 0.0f, 12.0f);//Manchester
					break;

					//-----------------------------------------
					//AS1117 Scenario 10 - Visibility
					//-----------------------------------------
				case 10:
					//Setup the periscope data.
					ptrGui.PIPPeriscope.dataPeriDrainDown.OverrideValue = 10;

					//Setup the environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue  = 1;

					deployTarget(0, 129, 0.0f, 10.0f, 0.0f, 175.0f, 10.0f);  //Manchester
					deployTarget(1, 175, 0.0f, -0.02f, 50.0f, 0.0f, 100.0f); //Sea Sprite Helicopter

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(1);
					if(lpTargetData != null)
					{
						lpTargetData.fTurnRate.Value = 2.2f;
					}

					ptrGui.PIPTarget(0).dataTurnRate.OverrideValue = 2.2f;
					break;

					//-----------------------------------------
					//AS1117 Scenario 11 Rain Squalls
					//-----------------------------------------
				case 11:
					// Set up own boat data
					setReferenceLatLon (70.0, 0.0);
					setOwnboatPosLatLon (70.0, 0.0);

					// Set up environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue  = OPEN_SEA;
					ptrGui.PIPEnvironment.dataWeather.OverrideValue    = 1;

					// Set up target data
					deployTarget (0, 139, 0.0f, 10.0f, 0.0f, 0.0f, 0.0f);      //Squall 1
					deployTarget (1, 140, 3.5355f, 3.5355f, 0.0f, 0.0f, 0.0f); //Squall 2
					break;

					//-----------------------------------------
					//AS1117 Scenario 12 Ice Edge
					//-----------------------------------------
				case 12:
					// Set up own boat data
					setReferenceLatLon (70.0, 0.0);
					setOwnboatPosLatLon (70.0, 0.0);
					ptrGui.PIPOwnship.dataDepth.OverrideValue   = 6.0f;
					ptrGui.PIPOwnship.dataHeading.OverrideValue = 45.0f;
					ptrGui.PIPOwnship.dataSpeed.OverrideValue   = 20.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue     = OPEN_SEA;
					ptrGui.PIPEnvironment.dataIceEdgeLat.OverrideValue    = 70.05f;
					ptrGui.PIPEnvironment.dataIceEdgeLon.OverrideValue    = -0.05f;
					ptrGui.PIPEnvironment.dataIceEdgeOrient.OverrideValue = 315.0f;
					ptrGui.PIPEnvironment.dataIceEdge.OverrideValue       = true;
					break;

					//-----------------------------------------
					//AS1117 Scenario 13 Under Ice Edge
					//-----------------------------------------
				case 13:
					// Set up own boat data
					setReferenceLatLon (70.0, 0.0);
					setOwnboatPosLatLon (70.0, 0.0);
					ptrGui.PIPOwnship.dataDepth.OverrideValue   = 6.0f;
					ptrGui.PIPOwnship.dataHeading.OverrideValue = 0.0f;
					ptrGui.PIPOwnship.dataSpeed.OverrideValue   = 20.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue     = OPEN_SEA;
					ptrGui.PIPEnvironment.dataIceEdgeLat.OverrideValue    = 70.01667f;
					ptrGui.PIPEnvironment.dataIceEdgeLon.OverrideValue    = 0.0f;
					ptrGui.PIPEnvironment.dataIceEdgeOrient.OverrideValue = 0.0f;

					ptrGui.PIPEnvironment.dataIceEdge.OverrideValue       = true;
					break;

					//-----------------------------------------
					//AS1117 Scenario 14 Angle on Bow (AOB) Assessment
					//-----------------------------------------
				case 14:
					// Set up target data
					deployTarget (0, 179, 0.0f, 0.3f, 0.0f, 90.0f, 0.0f); //Nanuchka
					break;

					//-----------------------------------------
					//AS1117 Scenario 15 Coastline Navigation
					//-----------------------------------------
				case 15:
					// Set up own boat data
					setReferenceLatLon (55.4667, -5.4);
					setOwnboatPosLatLon (55.275, -5.3333);

					ptrGui.PIPOwnship.dataSpeed.OverrideValue   = 10.0f;
					ptrGui.PIPOwnship.dataHeading.OverrideValue = 0.0f;
					break;

					//-----------------------------------------
					//AS1117 Scenario 16 Environmental Data
					//-----------------------------------------
				case 16:
					// Set up own boat data
					setReferenceLatLon (55.4667, -5.4);
					setOwnboatPosLatLon (55.4667, -5.4);

					ptrGui.PIPOwnship.dataSpeed.OverrideValue   = 10.0f;

					// Set up target data
					deployTarget (0, 42, 0.0f, 0.9f, 0.0f, 210.0f, 20.0f);    //Frigate
					deployTarget (1, 23, 1.9f, 3.2909f, 0.0f, 180.0f, 20.0f); //Broadsword
					deployTarget (2, 54, 0.0f, -1.4f, -1.0f, 315.0f, 15.0f);  //Tango Submarine
					deployTarget (3, 14, -0.707f, -0.707f, 60.0f, 0.0f, 25.0f);//Helix Helicopter
					deployTarget (4, 34, 0.122166845f, 6.998933866f, 0.0f, 180.0f, 9.0f);//Sovremenny Destroyer
					deployTarget (5, 10, -5.657f, 5.657f, 0.0f, 90.0f, 18.0f);//Udaloy Destroyer
					deployTarget (6, 129, 0.4187f, 7.9890f, 0.0f, 109.0f, 8.5f);//Manchester
					deployTarget (7, 48, 5.657f, 5.657f, 500.0f, 225.0f, 250.0f);//Orion Aircraft

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(7);
					if(lpTargetData != null)
					{
						lpTargetData.bNavLights.Value = true;
	                    lpTargetData.fTurnRate.Value = 3.0f;
					}


					//PIP_tar_ptr->flags = PRESENT + NAV_LIGHTS_ON;
					//PIP_tar_ptr->turn_rate = 3.0;
					//m_fDiveTime = 0.0;

					break;

					//-----------------------------------------
					//AS1117 Scenario 17 General Own Vessel Data
					//-----------------------------------------
				case 17:
					// Set up own boat data
					setReferenceLatLon (55.55, -5.4667);
					setOwnboatPosLatLon (55.55, -5.4667);

					ptrGui.PIPOwnship.dataSpeed.OverrideValue   = 10.0f;
					ptrGui.PIPOwnship.dataHeading.OverrideValue = 90.0f;

					// Set up target data
					deployTarget (0, 42, 0.0f, 0.9f, 0.0f, 210.0f, 20.0f);      //Frigate
					deployTarget (1, 23, 1.9f, 3.2909f, 0.0f, 180.0f, 20.0f);   //Broadsword
					deployTarget (2, 54, 0.0f, -1.4f, -1.0f, 315.0f, 15.0f);    //Tango Submarine
					deployTarget (3, 14, -0.707f, -0.707f, 60.0f, 0.0f, 25.0f); //Helix Helicopter
					break;

					//-----------------------------------------
					//AS1117 Scenario 18 IG Performance Tests
					//-----------------------------------------
				case 18:
					// Set up own boat data
					setReferenceLatLon (55.4666, -5.4);
					setOwnboatPosLatLon (55.4666, -5.4);

					// Set up target data
					deployTarget (0, 85, -0.64278761f, 0.7660444f, 0.0f, 30.0f, 15.0f);   //Kuznetsov
					deployTarget (1, 61, -0.53530449f, 0.59451586f, 0.0f, 30.0f, 15.0f);  //Koni II
					deployTarget (2, 152, -0.4702282f, 0.6472136f, 0.0f, 30.0f, 15.0f);   //Neustrashimy
					deployTarget (3, 156, -0.67103148f, 0.99484509f, 0.0f, 30.0f, 15.0f); //Petya III
					deployTarget (4, 169, 1.2855752f, -1.5320889f, 0.0f, 340.0f, 20.0f);  //Exeter
					deployTarget (5, 170, 1.0300761f, -1.7143346f, 0.0f, 340.0f, 20.0f);  //Sandown
					deployTarget (6, 146, 1.14715287f, -1.63830409f, 0.0f, 340.0f, 20.0f);//Isle of Arran Ferry
					deployTarget (7, 15, 1.08927807f, -1.67734114f, 0.0f, 340.0f, 20.0f); //British Ranger
					deployTarget (8, 65, 2.11602691f, -2.91246118f, 0.0f, 340.0f, 20.0f); //A69 Frigate
					deployTarget (9, 30, 3.755535f, -4.80686560f, 40.0f, 322.0f, 40.0f);  //Nimrod
					break;

					//-----------------------------------------
					//AS1117 Scenario 19 TI Controls
					//-----------------------------------------
				case 19:
					// Set up own boat data
					setReferenceLatLon (55.4666, -5.4);
					setOwnboatPosLatLon (55.4666, -5.4);

					// Set up target data
					deployTarget (0, 85, -0.64278761f, 0.7660444f, 0.0f, 30.0f, 15.0f); //Kuznetsov
					deployTarget (1, 9, -0.53330449f, 0.59451586f, 0.0f, 30.0f, 15.0f); //Slava Crusier
					deployTarget (2, 152, -0.4702282f, 0.6472136f, 0.0f, 30.0f, 15.0f); //Neustrashimy
					deployTarget (3, 6, -0.67103148f, 0.99484509f, 0.0f, 30.0f, 15.0f); //Kirov Cruiser
					deployTarget (4, 78, 1.2855752f, -1.5320889f, 0.0f, 340.0f, 20.0f); //Cambeltown
					deployTarget (5, 26, 1.0300761f, -1.7143346f, 0.0f, 340.0f, 20.0f);//Norfolk
					deployTarget (6, 172, 1.7207793f, -2.4574561f, 0.0f, 340.0f, 20.0f);//Fort Victoria
					deployTarget (7, 16, 2.7231952f, -4.1933828f, 0.0f, 340.0f, 20.0f); //Birling
					deployTarget (8, 27, 1.4694631f, -2.0225425f, 0.0f, 340.0f, 20.0f); //Oliver Hazard Perry

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(0);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(1);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(2);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(3);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(4);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(5);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(6);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(7);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(8);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;
					break;

					//-----------------------------------------
					//AS1117 Scenario 20 LLTV Controls
					//-----------------------------------------
				case 20:
					// Set up own boat data
					setReferenceLatLon (55.4666, -5.4);
					setOwnboatPosLatLon (55.4666, -5.4);

					// Set up target data
					deployTarget (0, 85, -0.64278761f, 0.7660444f, 0.0f, 30.0f, 5.0f);//Kuznetsov
					deployTarget (1, 9, -0.53330449f, 0.59451586f, 0.0f, 30.0f, 5.0f);//Slava Cruiser
					deployTarget (2, 152, -0.4702282f, 0.6472136f, 0.0f, 30.0f, 6.0f);//Neustrashimy
					deployTarget (3, 6, -0.67103148f, 0.99484509f, 0.0f, 30.0f, 5.0f);//Kirov Cruiser
					deployTarget (4, 78, 1.2855752f, -1.5320889f, 0.0f, 340.0f, 12.0f);//Cambeltown
					deployTarget (5, 26, 1.0300761f, -1.7143346f, 0.0f, 340.0f, 11.0f);//Norfolk
					deployTarget (6, 172, 1.7207793f, -2.4574561f, 0.0f, 340.0f, 12.0f);//Fort Victoria
					deployTarget (7, 16, 2.7231952f, -4.1933828f, 0.0f, 340.0f, 10.0f);//Birling
					deployTarget (8, 27, 1.4694631f, -2.0225425f, 0.0f, 340.0f, 10.0f);//Oliver Hazard Perry

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(0);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(1);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(2);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(3);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(4);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(5);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(6);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(7);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(8);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;
					break;

					//-----------------------------------------
					//AS1117 Scenario 21
					//-----------------------------------------
				case 21:
					// Set up own boat data
					ptrGui.PIPOwnship.dataDepth.OverrideValue   = 15.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataWeather.OverrideValue   = 0;
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue = OPEN_SEA;
					ptrGui.PIPEnvironment.dataSeaState.OverrideValue  = 0;
					ptrGui.PIPEnvironment.dataWindSpeed.OverrideValue = 0.0f;

					deployTarget (0, 5, 0.0f, 2.17192f, 0.0f, 90.0f, 0.0f);   //Kiev
					deployTarget (1, 34, 2.44313f, 0.0f, 0.0f, 180.0f, 0.0f); //Sovremenny Destroyer
					deployTarget (2, 48, 0.0f, -0.662f, 2000.0f, 270.0f, 0.0f);//Orion Aircraft
					deployTarget (3, 129, -6.0f, 0.0f, 0.0f, 0.0f, 0.0f);      //Manchester
					break;

					//-----------------------------------------
					//AS1117 Scenario 22
					//-----------------------------------------
				case 22:
					// Set up own boat data
					ptrGui.PIPOwnship.dataDepth.OverrideValue   = 15.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataWeather.OverrideValue   = 0;
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue = OPEN_SEA;
					ptrGui.PIPEnvironment.dataSeaState.OverrideValue  = 0;
					ptrGui.PIPEnvironment.dataWindSpeed.OverrideValue = 0.0f;

					deployTarget (0, 5, 0.0f, 2.285f, 0.0f, 90.0f, 0.0f);      //Kiev
					deployTarget (1, 34, 2.431f, 0.0f, 0.0f, 180.0f, 0.0f);    //Sovremenny Destroyer
					deployTarget (2, 48, 0.0f, -0.662f, 2000.0f, 270.0f, 0.0f);//Orion Aircraft
					deployTarget (3, 129, -6.0f, 0.0f, 0.0f, 0.0f, 0.0f);      //Manchester
					break;

					//-----------------------------------------
					//AS1117 Scenario 23
					//-----------------------------------------
				case 23:
					// Set up own boat data
					ptrGui.PIPOwnship.dataSpeed.OverrideValue = 0.0f;

					// Set up periscope data
					ptrGui.PIPPeriscope.dataPeriDrainDown.OverrideValue = 10;

					// Set up environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue     = OPEN_SEA;
					ptrGui.PIPEnvironment.dataWindSpeed.OverrideValue     = 10.0f;
					ptrGui.PIPEnvironment.dataWindDirection.OverrideValue = 225.0f;

					// Set up target data
					deployTarget (0, 23, 0.0f, 5.0f, 0.0f, 177.0f, 10.0f); //Broadsword
					break;

					//-----------------------------------------
					//AS1117 Scenario 24
					//-----------------------------------------
				case 24:
					// Set up periscope data
					ptrGui.PIPPeriscope.dataPeriDrainDown.OverrideValue = 10;

					// Set up own boat data
					ptrGui.PIPOwnship.dataSpeed.OverrideValue = 0.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue     = OPEN_SEA;
					ptrGui.PIPEnvironment.dataWindSpeed.OverrideValue     = 10.0f;
					ptrGui.PIPEnvironment.dataWindDirection.OverrideValue = 225.0f;

					// Set up target data
					deployTarget (0, 14, 0.0f, 5.0f, 100.0f, 177.0f, 10.0f);//Helix Helicopter
					break;

					//-----------------------------------------
					//AS1117 Scenario 25
					//-----------------------------------------
				case 25:
					// Set up own boat data
					setReferenceLatLon (55.4667, -5.4);
					setOwnboatPosLatLon (55.4667, -5.4);
					ptrGui.PIPOwnship.dataDepth.OverrideValue = 15.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataWeather.OverrideValue   = 0;
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue = OPEN_SEA;
					ptrGui.PIPEnvironment.dataSeaState.OverrideValue  = 0;
					ptrGui.PIPEnvironment.dataWindSpeed.OverrideValue = 0.0f;

					deployTarget (0, 5, 0.0f, 2.285f, 0.0f, 90.0f, 0.0f);       //Kiev
					deployTarget (1, 34, 2.431f, 0.0f, 0.0f, 180.0f, 0.0f);     //Sovremenny Destroyer
					deployTarget (2, 48, 0.0f, -0.662f, 2000.0f, 270.0f, 0.0f); //Orion Aircraft
					deployTarget (3, 129, -6.0f, 0.0f, 0.0f, 0.0f, 0.0f);       //Manchester
					break;

					//-----------------------------------------
					//AS1117 Scenario 26
					//-----------------------------------------
				case 26:
					// Set up environment data
					ptrGui.PIPEnvironment.dataWeather.OverrideValue   = 1;
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue = OPEN_SEA;
					ptrGui.PIPEnvironment.dataWindSpeed.OverrideValue = 10.0f;
					ptrGui.PIPEnvironment.dataWindDirection.OverrideValue = 45.0f;

					// Set up target data
					deployTarget (0, 129, 0.0f, 2.0f, 0.0f, 180.0f, 0.0f); //Manchester
					deployTarget (1, 23, 2.0f, 0.0f, 0.0f, 270.0f, 0.0f);  //Broadsword
					deployTarget (2, 24, 0.0f, -2.0f, 0.0f, 0.0f, 0.0f);   //Amazon
					deployTarget (3, 42, -2.0f, 0.0f, 0.0f, 90.0f, 0.0f);  //Frigate
					break;

					//-----------------------------------------
					//AS1117 Scenario 27
					//-----------------------------------------
				case 27:
					// Set up own boat data
					ptrGui.PIPOwnship.dataDepth.OverrideValue   = 15.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue   = OPEN_SEA;

					// Set up target data
					deployTarget (0, 5, 0.0f, 2.285f, 0.0f, 90.0f, 0.0f); //Kiev
					deployTarget (1, 34, 2.431f, 0.0f, 0.0f, 180.0f, 0.0f);//Sovremenny Destroyer
					deployTarget (2, 48, 0.0f, -0.662f, 2000.0f, 270.0f, 0.0f);//Orion Aircraft
					deployTarget (3, 129, -6.0f, 0.0f, 0.0f, 0.0f, 0.0f);//Manchester
					break;

					//-----------------------------------------
					//AS1117 Scenario 28
					//-----------------------------------------
				case 28:

					// Set up own boat data
					setReferenceLatLon (55.4666, -5.4);
					setOwnboatPosLatLon (55.4666, -5.4);

					ptrGui.PIPOwnship.dataSpeed.OverrideValue   = 10.0f;
					ptrGui.PIPOwnship.dataDepth.OverrideValue   = 15.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataWeather.OverrideValue = 0;

					deployTarget (0, 85, -0.64278761f, 0.7660444f, 0.0f, 30.0f, 5.0f);//Kuznetsov
					deployTarget (1, 9, -0.53330449f, 0.59451586f, 0.0f, 30.0f, 5.0f); //Slava
					deployTarget (2, 152, -0.4702282f, 0.6472136f, 0.0f, 30.0f, 6.0f);//Neustrashimy
					deployTarget (3, 6, -0.67103148f, 0.99484509f, 0.0f, 30.0f, 5.0f); //Kirov
					deployTarget (4, 78, 1.2855752f, -1.5320889f, 0.0f, 340.0f, 12.0f);//Cambeltown
					deployTarget (5, 26, 1.0300761f, -1.7143346f, 0.0f, 340.0f, 11.0f); //Norfolk
					deployTarget (6, 172, 1.7207793f, -2.4574561f, 0.0f, 340.0f, 12.0f);//Fort Vicoria
					deployTarget (7, 16, 2.7231952f, -4.1933828f, 0.0f, 340.0f, 10.0f);//Birling
					deployTarget (8, 27, 1.4694631f, -2.0225425f, 0.0f, 340.0f, 10.0f);//Oliver Hazard Perry

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(0);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(1);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(2);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(3);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(4);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(5);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(6);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(7);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(8);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;
					break;

					//-----------------------------------------
					//AS1117 Scenario 29
					//-----------------------------------------
				case 29:

					// Set up own boat data
					ptrGui.PIPOwnship.dataDepth.OverrideValue   = 15.0f;

					// Set up target data
					deployTarget (0, 85, -0.64278761f, 0.7660444f, 0.0f, 30.0f, 5.0f);//Kuznetsov
					deployTarget (1, 9, -0.53330449f, 0.59451586f, 0.0f, 30.0f, 5.0f);//Slava
					deployTarget (2, 152, -0.4702282f, 0.6472136f, 0.0f, 30.0f, 6.0f);//Neustrashimy
					deployTarget (3, 6, -0.67103148f, 0.99484509f, 0.0f, 30.0f, 5.0f);//Kirov
					deployTarget (4, 78, 1.2855752f, -1.5320889f, 0.0f, 340.0f, 12.0f);//Cambeltown
					deployTarget (5, 26, 1.0300761f, -1.7143346f, 0.0f, 340.0f, 11.0f); //Norfolk
					deployTarget (6, 172, 1.7207793f, -2.4574561f, 0.0f, 340.0f, 12.0f);//Fort Vicoria
					deployTarget (7, 16, 2.7231952f, -4.1933828f, 0.0f, 340.0f, 10.0f);//Birling
					deployTarget (8, 27, 1.4694631f, -2.0225425f, 0.0f, 340.0f, 10.0f);//Oliver Hazard Perry

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(0);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(1);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(2);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(3);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(4);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(5);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(6);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(7);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(8);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;
					break;

					//-----------------------------------------
					//AS1117 Scenario 30 - Accelerated simulator time
					//-----------------------------------------
				case 30:

					// Set up own boat data
					setReferenceLatLon (55.4667, -5.4);
					setOwnboatPosLatLon (55.4667, -5.4);

					ptrGui.PIPOwnship.dataSpeed.OverrideValue   = 10.0f;

					// Set up exercise data

					ptrGui.PIPExercise.dataHours.OverrideValue     = 12;
					ptrGui.PIPExercise.dataMinutes.OverrideValue   = 1;
					ptrGui.PIPExercise.dataSeconds.OverrideValue   = 1;
					//time_factor = 360.0;

					// Set up environment data
					ptrGui.PIPEnvironment.dataMoonElev.OverrideValue       = 60.0f;
					ptrGui.PIPEnvironment.dataMoonBrg.OverrideValue        = 90.0f;
					ptrGui.PIPEnvironment.dataWindDirection.OverrideValue  = 270.0f;

					// Set up target data
					deployTarget (0, 42, 0.0f, 0.9f, 0.0f, 210.0f, 20.0f);       //Frigate
					deployTarget (1, 23, 1.9f, 3.2909f, 0.0f, 180.0f, 20.0f);    //Broadsword
					deployTarget (2, 54, 0.0f, -1.4f, -1.0f, 315.0f, 15.0f);     //Tango Submarine
					deployTarget (3, 14, -0.707f, -0.707f, 60.0f, 0.0f, 25.0f);  //Helix Helicopter
					deployTarget (4, 34, 0.122166845f, 6.998933866f, 0.0f, 180.0f, 9.0f);//Sovremenny Destroyer
					deployTarget (5, 10, -5.657f, 5.657f, 0.0f, 90.0f, 18.0f);   //Udaloy Destroyer
					deployTarget (6, 129, 0.45f, 7.794f, 0.0f, 109.9f, 8.5f);    //Manchester
					deployTarget (7, 48, 5.657f, 5.657f, 500.0f, 225.0f, 250.0f);//Orion Aircraft

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(7);
					if(lpTargetData != null)
					{
						lpTargetData.bNavLights.Value = true;
						lpTargetData.fTurnRate.Value  = 3.0f;
					}

					m_fDiveTime = 0.0f;
					break;

					//-----------------------------------------
					//AS1117 Scenario 31 -lat/long calculations
					//-----------------------------------------
				case 31:

					// Set up own boat data
					setReferenceLatLon (55.4667, -5.4);
					setOwnboatPosLatLon (55.4283, -5.5);

					// Set up the ownship data
					ptrGui.PIPOwnship.dataSpeed.OverrideValue = 10.0f;

					// Set up exercise data
					ptrGui.PIPExercise.dataHours.OverrideValue   = 12;
					ptrGui.PIPExercise.dataMinutes.OverrideValue = 1;
					ptrGui.PIPExercise.dataSeconds.OverrideValue = 1;

					// Set up environment data
					ptrGui.PIPEnvironment.dataMoonElev.OverrideValue      = 60.0f;
					ptrGui.PIPEnvironment.dataMoonBrg.OverrideValue       = 90.0f;
					ptrGui.PIPEnvironment.dataWindDirection.OverrideValue = 270.0f;
					m_iFrameCounter = 0;
					break;


					//-----------------------------------------
					// AS1118 Scenario 1
					//-----------------------------------------
				case 32:

					// Set up own boat data
					setReferenceLatLon (55.4665, -5.4);
					setOwnboatPosLatLon (55.4666, -5.4);
					ptrGui.PIPOwnship.dataSpeed.OverrideValue   = 10.0f;
					ptrGui.PIPOwnship.dataDepth.OverrideValue   = -6.0f;

					// Set up exercise data
					ptrGui.PIPExercise.dataMinutes.OverrideValue = 30;
					ptrGui.PIPExercise.dataSeconds.OverrideValue = 60;

					// Set up environment data
			        ptrGui.PIPEnvironment.dataSeaState.OverrideValue      = 0;
					ptrGui.PIPEnvironment.dataMoonElev.OverrideValue      = 60.0f;
					ptrGui.PIPEnvironment.dataMoonBrg.OverrideValue       = 90.0f;
					ptrGui.PIPEnvironment.dataWindDirection.OverrideValue = 270.0f;

					// Set up target data
					deployTarget (0, 42, 0.0f, 0.9f, 0.0f, 210.0f, 20.0f);          //Frigate
					deployTarget (1, 23, 1.9f, 3.2909f, 0.0f, 180.0f, 20.0f);       //Broadsword
					deployTarget (2, 54, 0.0f, -1.4f, -1.0f, 315.0f, 15.0f);        //Tango Submarine
					deployTarget (3, 14, -0.707f, -0.707f, 60.0f, 0.0f, 25.0f);     //Helix Helicopter
					deployTarget (4, 34, 0.122166845f, 6.998933866f, 0.0f, 180.0f, 9.0f);//Sovremenny Destroyer
					deployTarget (5, 10, -5.657f, 5.657f, 0.0f, 90.0f, 18.0f);      //Udaloy Destroyer
					deployTarget (6, 129, 0.45f, 7.794f, 0.0f, 109.9f, 8.5f);       //Manchester
					deployTarget (7, 48, 5.657f, 5.657f, 500.0f, 225.0f, 250.0f);   //Orion Aircraft

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(7);
					if(lpTargetData != null)
					{
						lpTargetData.bNavLights.Value = true;
						lpTargetData.fTurnRate.Value  = 3.0f;
					}

					m_fDiveTime = 0.0f;
					break;

					//-----------------------------------------
					// Scenario 2
					//-----------------------------------------
				case 33:

					// Set up own boat data
					setReferenceLatLon (55.55, -5.466);
					setOwnboatPosLatLon (55.55, -5.466);

					ptrGui.PIPOwnship.dataSpeed.OverrideValue   = 10.0f;
					ptrGui.PIPOwnship.dataHeading.OverrideValue = 90.0f;

					// Set up target data
					deployTarget (0, 42, 0.0f, 0.9f, 0.0f, 210.0f, 20.0f);     //Frigate
					deployTarget (1, 23, 1.9f, 3.2909f, 0.0f, 180.0f, 20.0f);  //Broadsword
					deployTarget (2, 54, 0.0f, -1.4f, -1.0f, 315.0f, 15.0f);   //Tango Submarine
					deployTarget (3, 14, -0.707f, -0.707f, 60.0f, 0.0f, 25.0f);//Helix Helicopter
					break;

					//-----------------------------------------
					// Scenario 3
					//-----------------------------------------
				case 34:

					// Set up periscope data
			        ptrGui.PIPPeriscope.dataPeriDrainDown.OverrideValue = 10;

					// Set up environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue      = OPEN_SEA;
					ptrGui.PIPEnvironment.dataWindDirection.OverrideValue  = 225.0f;

					// Set up target data
					deployTarget (0, 23, 0.0f, 5.0f, 0.0f, 177.0f, 10.0f); //Broadsword
					break;

					//-----------------------------------------
					// Scenario 4
					//-----------------------------------------
				case 35:

					// Set up periscope data
			        ptrGui.PIPPeriscope.dataPeriDrainDown.OverrideValue = 10;

					// Set up environment data
			        ptrGui.PIPEnvironment.dataCoastline.OverrideValue     = OPEN_SEA;
					ptrGui.PIPEnvironment.dataWindDirection.OverrideValue = 225.0f;

					// Set up target data
					deployTarget (0, 14, 0.0f, 5.0f, 100.0f, 177.0f, 10.0f);//Helix Helicopter
					break;

					//-----------------------------------------
					// Scenario 5
					//-----------------------------------------
				case 36:

					// Set up environment data
                    ptrGui.PIPEnvironment.dataCoastline.OverrideValue     = OPEN_SEA;
					ptrGui.PIPEnvironment.dataWeather.OverrideValue       = CLEAR;
					ptrGui.PIPEnvironment.dataWindDirection.OverrideValue = 45.0f;

					// Set up target data
					deployTarget (0, 129, 0.0f, 2.0f, 0.0f, 180.0f, 0.0f);//Manchester
					deployTarget (1, 23, 2.0f, 0.0f, 0.0f, 270.0f, 0.0f); //Broadsword
					deployTarget (2, 24, 0.0f, -2.0f, 0.0f, 0.0f, 0.0f);  //Amazon (Type 21)
					deployTarget (3, 42, -2.0f, 0.0f, 0.0f, 90.0f, 0.0f);//Frigate
					break;

					//-----------------------------------------
					// Scenario 6
					//-----------------------------------------
				case 37:

					// Set up own boat data
					ptrGui.PIPOwnship.dataDepth.OverrideValue = -15.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataWeather.OverrideValue   = CLEAR;
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue = OPEN_SEA;
					ptrGui.PIPEnvironment.dataSeaState.OverrideValue  = 0;
					ptrGui.PIPEnvironment.dataWindSpeed.OverrideValue = 0.0f;

					deployTarget (0, 5, 0.0f, 2.17192f, 0.0f, 90.0f, 0.0f); //Kiev
					deployTarget (1, 34, 2.44313f, 0.0f, 0.0f, 180.0f, 0.0f);//Sovremenny Destroyer
					deployTarget (2, 48, 0.0f, -0.662f, 2000.0f, 270.0f, 0.0f);//Orion Aircraft
					deployTarget (3, 129, -6.0f, 0.0f, 0.0f, 0.0f, 0.0f);//Manchester
					break;

					//-----------------------------------------
					// Scenario 7
					//-----------------------------------------
				case 38:

					// Set up own boat data
					ptrGui.PIPOwnship.dataDepth.OverrideValue = -15.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataWeather.OverrideValue   = CLEAR;
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue = OPEN_SEA;
					ptrGui.PIPEnvironment.dataSeaState.OverrideValue  = 0;
					ptrGui.PIPEnvironment.dataWindSpeed.OverrideValue = 0.0f;

					deployTarget (0, 5, 0.0f, 2.285f, 0.0f, 90.0f, 0.0f); //Kiev
					deployTarget (1, 34, 2.431f, 0.0f, 0.0f, 180.0f, 0.0f);//Sovremenny Destroyer
					deployTarget (2, 48, 0.0f, -0.662f, 2000.0f, 270.0f, 0.0f);//Orion Aircraft
					deployTarget (3, 129, -6.0f, 0.0f, 0.0f, 0.0f, 0.0f);//Manchester
					break;

					//-----------------------------------------
					// Scenario 8
					//-----------------------------------------
				case 39:

					// Set up own boat data
					setReferenceLatLon (55.4667, -5.4);
					setOwnboatPosLatLon (55.4667, -5.4);
					ptrGui.PIPOwnship.dataDepth.OverrideValue = -15.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataWeather.OverrideValue   = CLEAR;
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue = OPEN_SEA;
					ptrGui.PIPEnvironment.dataSeaState.OverrideValue  = 0;
					ptrGui.PIPEnvironment.dataWindSpeed.OverrideValue = 0.0f;

					deployTarget (0, 5, 0.0f, 2.285f, 0.0f, 90.0f, 0.0f);      //Kiev
					deployTarget (1, 34, 2.431f, 0.0f, 0.0f, 180.0f, 0.0f);    //Sovremenny Destroyer
					deployTarget (2, 48, 0.0f, -0.662f, 2000.0f, 270.0f, 0.0f);//Orion Aircraft
					deployTarget (3, 129, -6.0f, 0.0f, 0.0f, 0.0f, 0.0f);      //Manchester
					break;

					//-----------------------------------------
					// Scenario 9
					//-----------------------------------------
				case 40:

					// Set up own boat data
					setReferenceLatLon (55.4666, -5.4);
					setOwnboatPosLatLon (55.4666, -5.4);
					ptrGui.PIPOwnship.dataSpeed.OverrideValue  = 10.0f;
					ptrGui.PIPOwnship.dataDepth.OverrideValue  = 15.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataWeather.OverrideValue = CLEAR;

					deployTarget (0, 85, -0.64278761f, 0.7660444f, 0.0f, 30.0f, 5.0f);//Kuznetsov
					deployTarget (1, 9, -0.53330449f, 0.59451586f, 0.0f, 30.0f, 5.0f);//Slava
					deployTarget (2, 152, -0.4702282f, 0.6472136f, 0.0f, 30.0f, 6.0f);//Neustrashimy
					deployTarget (3, 6, -0.67103148f, 0.99484509f, 0.0f, 30.0f, 5.0f);//Kirov
					deployTarget (4, 78, 1.2855752f, -1.5320889f, 0.0f, 340.0f, 12.0f);//Cambeltown
					deployTarget (5, 26, 1.0300761f, -1.7143346f, 0.0f, 340.0f, 11.0f);//Norfolk
					deployTarget (6, 172, 1.7207793f, -2.4574561f, 0.0f, 340.0f, 12.0f);//Fort Victoria
					deployTarget (7, 16, 2.7231952f, -4.1933828f, 0.0f, 340.0f, 10.0f);//Birling
					deployTarget (8, 27, 1.4694631f, -2.0225425f, 0.0f, 340.0f, 10.0f);//Oliver Hazard Perry

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(0);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(1);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(2);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(3);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(4);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(5);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(6);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(7);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(8);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					break;

					//-----------------------------------------
					// Scenario 10
					//-----------------------------------------
				case 41:

					// Set up own boat data
					setReferenceLatLon (55.4666, -5.4);
					setOwnboatPosLatLon (55.4666, -5.4);

					ptrGui.PIPOwnship.dataSpeed.OverrideValue  =  0.0f;
					ptrGui.PIPOwnship.dataDepth.OverrideValue  = 15.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataWeather.OverrideValue  =  CLEAR;

					deployTarget (0, 85, -0.64278761f, 0.7660444f, 0.0f, 30.0f, 5.0f);//Kuznetsov
					deployTarget (1, 9, -0.53330449f, 0.59451586f, 0.0f, 30.0f, 5.0f);//Slava
					deployTarget (2, 152, -0.4702282f, 0.6472136f, 0.0f, 30.0f, 6.0f);//Neustrashimy
					deployTarget (3, 6, -0.67103148f, 0.99484509f, 0.0f, 30.0f, 5.0f); //Kirov
					deployTarget (4, 78, 1.2855752f, -1.5320889f, 0.0f, 340.0f, 12.0f);//Cambeltown
					deployTarget (5, 26, 1.0300761f, -1.7143346f, 0.0f, 340.0f, 11.0f);//Norfolk
					deployTarget (6, 172, 1.7207793f, -2.4574561f, 0.0f, 340.0f, 12.0f);//Fort Victoria
					deployTarget (7, 16, 2.7231952f, -4.1933828f, 0.0f, 340.0f, 10.0f);//Birling
					deployTarget (8, 27, 1.4694631f, -2.0225425f, 0.0f, 340.0f, 10.0f);//Oliver Hazard Perry

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(0);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(1);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(2);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(3);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(4);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(5);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(6);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(7);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(8);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					break;

					//-----------------------------------------
					// Scenario 11
					//-----------------------------------------
				case 42:

					// Set up own boat data
					setReferenceLatLon (55.4666, -5.4);
					setOwnboatPosLatLon (55.4666, -5.4);

					ptrGui.PIPOwnship.dataSpeed.OverrideValue  = 10.0f;
					ptrGui.PIPOwnship.dataDepth.OverrideValue  =  6.0f;

					// Set up target data
					deployTarget (0, 42, 0.0f, 0.9f, 0.0f, 210.0f, 20.0f);       //Frigate
					deployTarget (1, 23, 1.9f, 3.2909f, 0.0f, 180.0f, 20.0f);    //Broadsword
					deployTarget (2, 54, 0.0f, -1.4f, -1.0f, 315.0f, 15.0f);     //Tango Submarine
					deployTarget (3, 14, -0.707f, -0.707f, 60.0f, 0.0f, 25.0f);  //Helix Helicopter
					deployTarget (4, 34, 0.122166845f, 6.998933866f, 0.0f, 180.0f, 9.0f);//Sovremenny Destroyer
					deployTarget (5, 10, -5.657f, 5.657f, 0.0f, 90.0f, 18.0f);   //Udaloy Destroyer
					deployTarget (6, 129, 0.45f, 7.794f, 0.0f, 109.9f, 8.5f);    //Manchester
					deployTarget (7, 48, 5.657f, 5.657f, 500.0f, 225.0f, 250.0f);//Orion Aircraft

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(7);
					if(lpTargetData != null)
						lpTargetData.fTurnRate.Value = 3.0f;

					m_fDiveTime = 0.0f;
					break;

					//-----------------------------------------
					// Scenario 12
					//-----------------------------------------
				case 43:

					/* Set up target data */
					deployTarget (0, 129, -1.0f, 0.0f, 0.0f, 0.0f, 12.0f);//Manchester

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(0);
					if(lpTargetData != null)
						lpTargetData.fTurnRate.Value = 2.0f;
					//PIP_tar_ptr->turn_rate = 2.0;
					break;

					//-----------------------------------------
					// Scenario 13
					//-----------------------------------------
				case 44:

					// Set up own boat data
					ptrGui.PIPOwnship.dataHeading.OverrideValue  = 180.0f;
					ptrGui.PIPOwnship.dataDepth.OverrideValue    = -50.0f;

					// Set up target data
					deployTarget (0, 23, -0.5f, -0.5f, 0.0f, 45.0f, 10.0f); //Broadsword

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(0);
					if(lpTargetData != null)
						lpTargetData.fTurnRate.Value = 3.0f;

					if ((lpTargetData.fX.Value > 200.0f) &&
						(lpTargetData.fY.Value > 210.0f))
					{
						lpTargetData.fX.Value = 200.0f;
						lpTargetData.fY.Value = -190.0f;
						lpTargetData.fHeading.Value = 315.0f;
						lpTargetData.fDriftCourse.Value = 315.0f;
					}
					else if ((lpTargetData.fX.Value < -200.0f) &&
						     (lpTargetData.fY.Value > 210.0f))
					{
						lpTargetData.fX.Value = -200.0f;
						lpTargetData.fY.Value = -190.0f;
						lpTargetData.fHeading.Value = 45.0f;
						lpTargetData.fDriftCourse.Value = 45.0f;
					}
					break;

					//-----------------------------------------
					// Scenario 14
					//-----------------------------------------
				case 45:

					/* Set up target data */
					deployTarget (0, 23, -1.0f, 0.0f, 0.0f, 0.0f, 0.0f); //Broadsword
					deployTarget (1, 30, 0.0f, 0.0f, 300.0f, 0.0f, 200.0f); //Nimrod

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(1);
					if(lpTargetData != null)
					{
						lpTargetData.fTurnRate.Value  = 2.0f;
					}
					break;

					//-----------------------------------------
					// Scenario 15
					//-----------------------------------------
				case 46:

					// Set up own boat data
					setReferenceLatLon (55.25, -5.41666);
					setOwnboatPosLatLon (55.25, -5.41666);

					ptrGui.PIPOwnship.dataHeading.OverrideValue  =  0.0f;
					ptrGui.PIPOwnship.dataSpeed.OverrideValue    = 10.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataMoonElev.OverrideValue = 40.0f;
					ptrGui.PIPEnvironment.dataMoonBrg.OverrideValue  = 90.0f;

					// Set up target data
					deployTarget (0, 42, 0.0f, 0.9f, 0.0f, 210.0f, 20.0f);           //Frigate
					deployTarget (1, 23, 1.9f, 3.2909f, 0.0f, 180.0f, 20.0f);        //Broadsword
					deployTarget (2, 54, 0.0f, -1.4f, -1.0f, 315.0f, 15.0f);         //Tango Submarine
					deployTarget (3, 14, -0.707f, -0.707f, 60.0f, 0.0f, 25.0f);      //Helix Helicopter
					deployTarget (4, 34, 0.122166845f, 6.998933866f, 0.0f, 180.0f, 9.0f);//Sovremenny Destroyer
					deployTarget (5, 10, -5.657f, 5.657f, 0.0f, 90.0f, 18.0f);       //Udaloy Destroyer
					deployTarget (6, 129, 0.45f, 7.794f, 0.0f, 109.9f, 8.5f);        //Manchester
					deployTarget (7, 48, 5.657f, 5.657f, 500.0f, 225.0f, 250.0f);    //Orion Aircraft
					deployTarget (8, 30, 0.0f, 0.0f, 80.0f, 0.0f, 100.0f);           //Nimrod Aircraft

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(8);
					if(lpTargetData != null)
					{
						lpTargetData.fTurnRate.Value = 3.0f;
					}

					m_fDiveTime = 0.0f;
					break;

					//-----------------------------------------
					// Scenario 16
					//-----------------------------------------
				case 47:

					// Set up exercise data
					ptrGui.PIPExercise.dataHours.OverrideValue   = 0;

					// Set up environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue = OPEN_SEA;
					ptrGui.PIPEnvironment.dataSeaState.OverrideValue  = 3;
					ptrGui.PIPEnvironment.dataUWVisibleRange.OverrideValue = 0.0f;

					// Set up target data
					deployTarget (0, 129, 0.0f, 1.0f, 0.0f, 90.0f, 0.0f);//Manchester
					break;

					//-----------------------------------------
					// Scenario 17
					//-----------------------------------------
				case 48:

					// Set up own boat data
					ptrGui.PIPOwnship.dataSpeed.OverrideValue = 0.0f;

					// Set up periscope data
					ptrGui.PIPPeriscope.dataPeriDrainDown.OverrideValue = 10;

					// Set up environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue = OPEN_SEA;

					/* Set up target data */
					deployTarget (0, 14, 0.0f, 1.0f, 100.0f, 90.0f, 0.0f);//Helix Helicopter
					break;

					//-----------------------------------------
					// Scenario 18
					//-----------------------------------------
				case 49:

					/* Set up target data */
					deployTarget (0, 129, -1.0f, 0.0f, 0.0f, 0.0f, 12.0f);//Manchester
					deployTarget (1, 30, 0.0f, 0.0f, 300.0f, 0.0f, 200.0f);//Nimrod
					//PIP_tar_ptr->turn_rate = 2.0;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(1);
					if(lpTargetData != null)
					{
						lpTargetData.fTurnRate.Value = 2.0f;
					}
					break;

					//-----------------------------------------
					// Scenario 19
					//-----------------------------------------
				case 50:

					/* Set up target data */
					deployTarget (0, 129, -1.0f, 0.0f, 0.0f, 0.0f, 12.0f);//Manchester
					deployTarget (1, 30, 0.0f, 0.0f, 300.0f, 0.0f, 200.0f);//Nimrod

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(1);
					if(lpTargetData != null)
					{
						lpTargetData.fTurnRate.Value = 2.0f;
					}

					break;

					//-----------------------------------------
					// Scenario 20
					//-----------------------------------------
				case 51:

					// Set up periscope data
					ptrGui.PIPPeriscope.dataPeriDrainDown.OverrideValue = 10;

					// Set up environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue = OPEN_SEA;

					// Set up own boat data
					ptrGui.PIPOwnship.dataHeading.OverrideValue  =  0.0f;
					ptrGui.PIPOwnship.dataSpeed.OverrideValue    =  0.0f;

					// Set up target data
					deployTarget (0, 129, 0.0f, 10.0f, 0.0f, 175.0f, 10.0f);//Manchester
					deployTarget (1, 175, 0.0f, -0.02f, 50.0f, 0.0f, 50.0f);//Sea Sprite
					deployTarget (2, 175, -0.02f, 0.0f, 53.0f, 0.0f, 50.0f);//Sea Sprite
					deployTarget (3, 175, 0.02f, 0.0f, 57.0f, 0.0f, 50.0f); //Sea Sprite
					deployTarget (4, 175, 0.0f, 0.02f, 52.0f, 0.0f, 50.0f); //Sea Sprite

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(1);
					if(lpTargetData != null)
					{
						lpTargetData.fTurnRate.Value = 2.2f;
					}

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(2);
					if(lpTargetData != null)
					{
						lpTargetData.fTurnRate.Value = 2.2f;
					}

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(3);
					if(lpTargetData != null)
					{
						lpTargetData.fTurnRate.Value = 2.2f;
					}

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(4);
					if(lpTargetData != null)
					{
						lpTargetData.fTurnRate.Value = 2.2f;
					}


					break;

					//-----------------------------------------
					// Scenario 21
					//-----------------------------------------
				case 52:

					// Set up own boat data
					setReferenceLatLon (70.0, 0.0);
					setOwnboatPosLatLon (70.0, 0.0);

					ptrGui.PIPOwnship.dataDepth.OverrideValue   =  -6.0f;
					ptrGui.PIPOwnship.dataHeading.OverrideValue =  45.0f;
					ptrGui.PIPOwnship.dataSpeed.OverrideValue   =  20.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue     =  OPEN_SEA;
					ptrGui.PIPEnvironment.dataWeather.OverrideValue       =  CLOUDY;
					ptrGui.PIPEnvironment.dataIceEdgeLat.OverrideValue    =  70.2f;
					ptrGui.PIPEnvironment.dataIceEdgeLon.OverrideValue    =  -0.2f;
					ptrGui.PIPEnvironment.dataIceEdgeOrient.OverrideValue = 315.0f;

					// Set up target data
					deployTarget (0, 139, 1.7554f, 1.7554f, 0.0f, 0.0f, 0.0f);//Rain Squall
					deployTarget (1, 140, 0.0f, -15.0f, 0.0f, 0.0f, 0.0f);    //Rain Squall II
					deployTarget (2, 177, -15.0f, 0.0f, 0.0f, 0.0f, 0.0f);    //Polynia 1
					break;

					//-----------------------------------------
					// Scenario 22
					//-----------------------------------------
				case 53:

					/* Set up own boat data */
					setReferenceLatLon (70.0, 0.0);
					setOwnboatPosLatLon (70.0, 0.0);

					ptrGui.PIPOwnship.dataDepth.OverrideValue   =  -6.0f;
					ptrGui.PIPOwnship.dataHeading.OverrideValue =  45.0f;
					ptrGui.PIPOwnship.dataSpeed.OverrideValue   =  20.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue     =  OPEN_SEA;
					ptrGui.PIPEnvironment.dataIceEdgeLat.OverrideValue    =  70.2f;
					ptrGui.PIPEnvironment.dataIceEdgeLon.OverrideValue    =  -0.2f;
					ptrGui.PIPEnvironment.dataIceEdgeOrient.OverrideValue = 315.0f;
					break;

					//-----------------------------------------
					// Scenario 23
					//-----------------------------------------
				case 54:

					// Set up own boat data
					setReferenceLatLon (70.0, 0.0);
					setOwnboatPosLatLon (70.0, 0.0);

					ptrGui.PIPOwnship.dataDepth.OverrideValue   =  -6.0f;
					ptrGui.PIPOwnship.dataHeading.OverrideValue =   0.0f;
					ptrGui.PIPOwnship.dataSpeed.OverrideValue   =  20.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue     =  OPEN_SEA;
					ptrGui.PIPEnvironment.dataIceEdgeLat.OverrideValue    =  70.015f;
					ptrGui.PIPEnvironment.dataIceEdgeLon.OverrideValue    =   0.0f;
					ptrGui.PIPEnvironment.dataIceEdgeOrient.OverrideValue =   0.0f;
					break;

					//-----------------------------------------
					// Scenario 24
					//-----------------------------------------
				case 55:

					// Set up environment data
					ptrGui.PIPEnvironment.dataSeaState.OverrideValue      =  0;
					ptrGui.PIPEnvironment.dataWeather.OverrideValue       =  CLEAR;
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue     =  OPEN_SEA;
					ptrGui.PIPEnvironment.dataWindSpeed.OverrideValue     =  10.0f;
					ptrGui.PIPEnvironment.dataWindDirection.OverrideValue =  45.0f;

					// Set up target data
					deployTarget (0, 179, 0.0f, 0.3f, 0.0f, 90.0f, 0.0f); //Nanuchka II Frigate
					break;

					//-----------------------------------------
					// Scenario 25
					//-----------------------------------------
				case 56:

					// Set up target data
					deployTarget (0, 85, -0.64278761f, 0.7660444f, 0.0f, 30.0f, 5.0f);//Kuznetsov
					deployTarget (1, 9, -0.53330449f, 0.59451586f, 0.0f, 30.0f, 5.0f);     //Slava
					deployTarget (2, 152, -0.4702282f, 0.6472136f, 0.0f, 30.0f, 6.0f);//Neustrashimy
					deployTarget (3, 6, -0.67103148f, 0.99484509f, 0.0f, 30.0f, 5.0f);//Manchester
					deployTarget (4, 78, 1.2855752f, -1.5320889f, 0.0f, 340.0f, 12.0f);//Cambeltown
					deployTarget (5, 26, 1.0300761f, -1.7143346f, 0.0f, 340.0f, 11.0f);//Norfolk
					deployTarget (6, 172, 1.7207793f, -2.4574561f, 0.0f, 340.0f, 12.0f);//Fort Victoria
					deployTarget (7, 16, 2.7231952f, -4.1933828f, 0.0f, 340.0f, 10.0f);//Birling
					deployTarget (8, 27, 1.4694631f, -2.0225425f, 0.0f, 340.0f, 10.0f);//Oliver Hazard Perry
					deployTarget (9, 185, 1.231323f, -1.5760215f, 40.0f, 322.0f, 40.0f); //Lynx Helicopter
					break;

					//-----------------------------------------
					// Scenario 26
					//-----------------------------------------
				case 57:

					// Set up own boat data
					setReferenceLatLon (55.267, -5.4);
					setOwnboatPosLatLon (55.267, -5.4);
					ptrGui.PIPOwnship.dataSpeed.OverrideValue   =  10.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataVisibleRange.OverrideValue   =  32.0f;
					ptrGui.PIPEnvironment.dataIRVisibleRange.OverrideValue =  32.0f;

					break;

					//-----------------------------------------
					// Scenario 27
					//-----------------------------------------
				case 58:

					// Set up own boat data
					ptrGui.PIPOwnship.dataDepth.OverrideValue   =  -15.0f;

					// Set up environment data
					ptrGui.PIPEnvironment.dataCoastline.OverrideValue     = OPEN_SEA;

					// Set up target data
					deployTarget (0, 5, 0.0f, 2.285f, 0.0f, 90.0f, 0.0f); //Kiev
					deployTarget (1, 34, 2.431f, 0.0f, 0.0f, 180.0f, 0.0f);    //Sovremenny
					deployTarget (2, 48, 0.0f, -0.662f, 2000.0f, 270.0f, 0.0f);//Orion Aircraft
					deployTarget (3, 129, -6.0f, 0.0f, 0.0f, 0.0f, 0.0f);//Manchester
					break;

					//-----------------------------------------
					// Scenario 28
					//-----------------------------------------
				case 59:

					// Set up own boat data
					ptrGui.PIPOwnship.dataDepth.OverrideValue   =  -15.0f;

					// Set up target data
					deployTarget (0, 85, -0.64278761f, 0.7660444f, 0.0f, 30.0f, 5.0f);//Kuznetsov
					deployTarget (1, 9, -0.53330449f, 0.59451586f, 0.0f, 30.0f, 5.0f);//Slava
					deployTarget (2, 152, -0.4702282f, 0.6472136f, 0.0f, 30.0f, 6.0f);//Neustrashimy
					deployTarget (3, 6, -0.67103148f, 0.99484509f, 0.0f, 30.0f, 5.0f);//Manchester
					deployTarget (4, 78, 1.2855752f, -1.5320889f, 0.0f, 340.0f, 12.0f);//Cambeltown
					deployTarget (5, 26, 1.0300761f, -1.7143346f, 0.0f, 340.0f, 11.0f);//Norfolk
					deployTarget (6, 172, 1.7207793f, -2.4574561f, 0.0f, 340.0f, 12.0f);//Fort Victoria
					deployTarget (7, 16, 2.7231952f, -4.1933828f, 0.0f, 340.0f, 10.0f);//Birling
					deployTarget (8, 27, 1.4694631f, -2.0225425f, 0.0f, 340.0f, 10.0f);//Oliver Hazard Perry

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(0);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(1);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(2);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(3);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(4);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(5);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(6);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(7);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(8);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					break;

					//-----------------------------------------
					// Scenario 29
					//-----------------------------------------
				case 60:

					/* Set up own boat data */
					//PIP_own_ptr->z_offset = 15.0;
					ptrGui.PIPOwnship.dataDepth.OverrideValue   =  -15.0f;

					/* Set up target data */
					deployTarget (0, 85, -0.64278761f, 0.7660444f, 0.0f, 30.0f, 5.0f);//Kuznetsov
					deployTarget (1, 9, -0.53330449f, 0.59451586f, 0.0f, 30.0f, 5.0f);//Slava
					deployTarget (2, 152, -0.4702282f, 0.6472136f, 0.0f, 30.0f, 6.0f);//Neustrashimy
					deployTarget (3, 6, -0.67103148f, 0.99484509f, 0.0f, 30.0f, 5.0f);//Manchester
					deployTarget (4, 78, 1.2855752f, -1.5320889f, 0.0f, 340.0f, 12.0f);//Cambeltown
					deployTarget (5, 26, 1.0300761f, -1.7143346f, 0.0f, 340.0f, 11.0f);//Norfolk
					deployTarget (6, 172, 1.7207793f, -2.4574561f, 0.0f, 340.0f, 12.0f);//Fort Victoria
					deployTarget (7, 16, 2.7231952f, -4.1933828f, 0.0f, 340.0f, 10.0f);//Birling
					deployTarget (8, 27, 1.4694631f, -2.0225425f, 0.0f, 340.0f, 10.0f);//Oliver Hazard Perry

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(0);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(1);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(2);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(3);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(4);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(5);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(6);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(7);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(8);
					if(lpTargetData != null)
						lpTargetData.bNavLights.Value = true;
					break;

					//-----------------------------------------
					// Scenario 30
					//-----------------------------------------
				case 61:

					// Set up own boat data
					setReferenceLatLon (55.4667, -5.4);
					setOwnboatPosLatLon (55.4667, -5.4);
					ptrGui.PIPOwnship.dataSpeed.OverrideValue   = 10.0f;

					// Set up exercise data
					m_fTimeFactor = 360.0f;

					ptrGui.PIPExercise.dataHours.OverrideValue   = 12;
					ptrGui.PIPExercise.dataMinutes.OverrideValue = 1;
					ptrGui.PIPExercise.dataSeconds.OverrideValue = 1;

					// Set up environment data
					ptrGui.PIPEnvironment.dataMoonElev.OverrideValue      = 60.0f;
					ptrGui.PIPEnvironment.dataMoonBrg.OverrideValue       = 90.0f;
					ptrGui.PIPEnvironment.dataWindDirection.OverrideValue = 270.0f;

					// Set up target data
					deployTarget (0, 42, 0.0f, 0.9f, 0.0f, 210.0f, 20.0f);         //Frigate
					deployTarget (1, 23, 1.9f, 3.2909f, 0.0f, 180.0f, 20.0f);      //Broadsword
					deployTarget (2, 54, 0.0f, -1.4f, -1.0f, 315.0f, 15.0f);       //Tango Submarine
					deployTarget (3, 14, -0.707f, -0.707f, 60.0f, 0.0f, 25.0f);    //Helix Helicopter
					deployTarget (4, 34, 0.122166845f, 6.998933866f, 0.0f, 180.0f, 9.0f); //Sovremenny Destroyer
					deployTarget (5, 10, -5.657f, 5.657f, 0.0f, 90.0f, 18.0f);     //Udaloy Destroyer
					deployTarget (6, 129, 0.45f, 7.794f, 0.0f, 109.9f, 8.5f);      //Manchester
					deployTarget (7, 48, 5.657f, 5.657f, 500.0f, 225.0f, 250.0f);  //Orion Aircraft

					lpTargetData = ptrGui.PIPTarget(0).getTargetData(7);
					if(lpTargetData != null)
					{
						lpTargetData.fTurnRate.Value = 3.0f;
						lpTargetData.bNavLights.Value = true;
					}
					m_fDiveTime = 0.0f;
					break;

					//-----------------------------------------
					// Scenario 31
					//-----------------------------------------
				case 62:

					// Set up own boat data
					setReferenceLatLon (56.4667, -5.4);
					setOwnboatPosLatLon (55.4283, -5.5);

					ptrGui.PIPOwnship.dataSpeed.OverrideValue   = 10.0f;
					ptrGui.PIPOwnship.dataHeading.OverrideValue =  0.0f;

					// Set up exercise data
					ptrGui.PIPExercise.dataHours.OverrideValue   = 12;
					ptrGui.PIPExercise.dataMinutes.OverrideValue = 1;
					ptrGui.PIPExercise.dataSeconds.OverrideValue = 1;

					// Set up environment data
					ptrGui.PIPEnvironment.dataMoonElev.OverrideValue      =  60.0f;
					ptrGui.PIPEnvironment.dataMoonBrg.OverrideValue       =  90.0f;
					ptrGui.PIPEnvironment.dataWindDirection.OverrideValue = 270.0f;

					m_iFrameCounter = 0;
					break;

					//-----------------------------------------
					// Scenario 32
					//-----------------------------------------
				case 63:

					/* Set up target data */
					deployTarget (0, 24, 0.0f, 1.2f, 0.0f, 180.0f, 0.0f);  //Amazon Frigate
					deployTarget (1, 165, 0.04f, 1.2f, 0.0f, 182.0f, 0.0f);//Arktika Ice Breaker
					deployTarget (2, 23, 0.08f, 1.2f, 0.0f, 184.0f, 0.0f); //Broadsword
					deployTarget (3, 169, 0.12f, 1.2f, 0.0f, 186.0f, 0.0f);//Exeter
					deployTarget (4, 120, 0.16f, 1.2f, 0.0f, 188.0f, 0.0f);//Fishing 3 (Wavesheaf)
					deployTarget (5, 34, 0.20f, 1.2f, 0.0f, 190.0f, 0.0f); //Sovremenny
					deployTarget (6, 56, 0.24f, 1.2f, 0.0f, 192.0f, 0.0f); //Sentinel
					deployTarget (7, 170, 0.28f, 1.2f, 0.0f, 194.0f, 0.0f);//Sandown Minehunter
					deployTarget (8, 117, 0.32f, 1.2f, 0.0f, 196.0f, 0.0f);//Upholder Submarine
					deployTarget (9, 44, 0.36f, 1.2f, 0.0f, 198.0f, 0.0f); //Pauk
					deployTarget (10, 7, 0.0f, -1.2f, 0.0f, 0.0f, 0.0f);   //Moskva Aircraft Carrier
					m_iFrameCounter = 0;

					break;

			}
		}
		/*******************************************************************************
		Function Name       : setReferenceLatLon
		Description         : This routine scenario reference latitude and longitude,
							  to which all target positions are referred.
		Parameters          : lat - latitude in degrees.
							  lon - longitude in degrees.
		Results             : None
		Globals Used        : sc_rlat - Reference latitude (radians)
							  sc_rlon - Reference longitude (radians)
		Scope               : Global
		*******************************************************************************/
		protected void setReferenceLatLon (double lat, double lon)
		{
			m_ReferenceLat = lat * KDEGTORAD;
			m_ReferenceLon = lon * KDEGTORAD;
		}


		/*******************************************************************************
		Function Name       : setOwnboatPosLatLon
		Description         : Calculates ownboat position X/Y position relative to the
							  scenario reference point. The resultant values are used
							  to adjust deployed target positions so that ownboat may
							  move at will, but targets remain referred to the
							  reference point.
		Parameters          : None
		Results             : None
		Globals Used        : sc_os_x - Ownboat X, relative to reference
							: SC_os_y - Ownboat Y, relative to reference
		Scope               : Global
		*******************************************************************************/

		protected void setOwnboatPosLatLon (double lat, double lon)
		{
			ptrGui.PIPOwnship.dataLatitude.OverrideValue   = lat;
			ptrGui.PIPOwnship.dataLongitude.OverrideValue  = lon;

			//convert_lat_lon (lat, lon, &sc_os_x, &sc_os_y);
		}

		/*******************************************************************************
		Function Name       : deployTarget
		Description         : This routine deploys a target into the scenario.
		Parameters          : None
		Results             : None
		Globals Used        : PIP_data_raw  - Raw PIP scenario data
		Scope               : Global
		*******************************************************************************/
		protected void deployTarget (int iTargetNo, int iTargetType,
				                          float fX, float fY, float fZ,
				                          float fHeading, float fSpeed)
		{
			TargetData targetData = ptrGui.PIPTarget(iTargetNo).getTargetData(iTargetNo);
			if(targetData != null)
			{
			    //
				//Set the target data for this target.
                //
				targetData.iTargetNum.Value = iTargetType;
				targetData.bVisible.Value   = true;
				targetData.fX.Value         = fX;
				targetData.fY.Value         = fY;
				targetData.fDepth.Value     = fZ;
				targetData.fHeading.Value   = fHeading;
				targetData.fSpeed.Value     = fSpeed;

				//PIP_tar_x[target_no] = ((double)PIP_tar_ptr->x_offset * KILO) * KYDSTOM;
				//PIP_tar_y[target_no] = ((double)PIP_tar_ptr->y_offset * KILO) * KYDSTOM;

				//ptrGui.PIPTarget(iTargetNo).setTargetData(iTargetNo, targetData);
			}
		}

		/*******************************************************************************
		Function Name       : updateScenario
		Description         : Update the scenario.
		Parameters          : None
		Results             : None
		Globals Used        :
		Scope               : Global
		*******************************************************************************/
		public void updateScenario(float fScenarioTime)
		{
			//Update the scenario time
			//m_fDeltaTime = fScenarioTime - m_fDeltaTime;
			m_fDeltaTime = fScenarioTime;

			//
			//PAL: Hmmm, not sure about freeze flags etc. What effect should this have on
		    //     delta time ?
			//

			//Update the ownboat dynamics
			updateOwnboatDynamics();

			//Update the target dynamics
			updateTargetDynamics();
		}

		/*******************************************************************************
		Function Name       : updateOwnboatDynamics
		Description         : Update the ownboat dynamics.
		Parameters          : None
		Results             : None
		Globals Used        :
		Scope               : Global
		*******************************************************************************/
		protected void updateOwnboatDynamics()
		{
			double lfLatLongConstant;
			double lfCosBearing;
			double lfSinBearing;
			double lfLatConstant;
			double lfLongConstant;

			if ((ptrGui.PIPExercise.dataRunMode.OverrideValue == RUN) ||
				(ptrGui.PIPExercise.dataRunMode.OverrideValue == FAST_RUN) ||
				(ptrGui.PIPExercise.dataRunMode.OverrideValue == TARGET_FREEZE))
			{
				// send out updated lat/long once every 2 seconds
				//if (frame_time > PIP_TIME)
				{
					lfLatLongConstant = (double)(ptrGui.PIPOwnship.dataSpeed.OverrideValue) /
						(SECS_IN_HOUR * SECS_IN_MINUTE);

					lfCosBearing = Math.Cos ((ptrGui.PIPOwnship.dataHeading.OverrideValue * KDEGTORAD));
					lfSinBearing = Math.Sin ((ptrGui.PIPOwnship.dataHeading.OverrideValue * KDEGTORAD));
					lfLatConstant = lfCosBearing * lfLatLongConstant;
					lfLongConstant = lfSinBearing * lfLatLongConstant;

					// if the latitude is further north or south than the threshold
					// there is a possibility of a divide by zero error. In these
					// situations, there is no real need to increment the longitude
					// as all longitude lines converge at the north pole.

					if (Math.Abs(ptrGui.PIPOwnship.dataLatitude.OverrideValue) < LATITUDE_THRESH)
						ptrGui.PIPOwnship.dataLongitude.OverrideValue += lfLongConstant /
							Math.Cos(ptrGui.PIPOwnship.dataLatitude.OverrideValue * KDEGTORAD);

					// wrap round longitude value at +/-180 degrees
					if (ptrGui.PIPOwnship.dataLongitude.OverrideValue > LONGITUDE_MAX)
						ptrGui.PIPOwnship.dataLongitude.OverrideValue -= BRG_MAX;

					if (ptrGui.PIPOwnship.dataLongitude.OverrideValue < LONGITUDE_MIN)
						ptrGui.PIPOwnship.dataLongitude.OverrideValue += BRG_MAX;

					// we don't like -180, so ...
					if (ptrGui.PIPOwnship.dataLongitude.OverrideValue == LONGITUDE_MIN)
						ptrGui.PIPOwnship.dataLongitude.OverrideValue = LONGITUDE_MAX;

					ptrGui.PIPOwnship.dataLatitude.OverrideValue  += lfLatConstant;

					// now deal with wrapping round earth at n/s poles
					if (ptrGui.PIPOwnship.dataLatitude.OverrideValue > LATITUDE_MAX)
					{
						ptrGui.PIPOwnship.dataLatitude.OverrideValue = LONGITUDE_MAX - ptrGui.PIPOwnship.dataLatitude.OverrideValue;
						ptrGui.PIPOwnship.dataLongitude.OverrideValue -= LONGITUDE_MAX;
						ptrGui.PIPOwnship.dataHeading.OverrideValue += LONGITUDE_MAX;
						if (ptrGui.PIPOwnship.dataHeading.OverrideValue > BRG_MAX)
							ptrGui.PIPOwnship.dataHeading.OverrideValue -= BRG_MAX;
					}

					if (ptrGui.PIPOwnship.dataLatitude.OverrideValue < LATITUDE_MIN)
					{
						ptrGui.PIPOwnship.dataLatitude.OverrideValue = LONGITUDE_MIN - ptrGui.PIPOwnship.dataLatitude.OverrideValue;
						ptrGui.PIPOwnship.dataLongitude.OverrideValue -= LONGITUDE_MAX;
						ptrGui.PIPOwnship.dataHeading.OverrideValue += LONGITUDE_MAX;
						if (ptrGui.PIPOwnship.dataHeading.OverrideValue > BRG_MAX)
							ptrGui.PIPOwnship.dataHeading.OverrideValue-= BRG_MAX;
					}

					//frame_time -= PIP_TIME;
				}
				//else
				//	frame_time += deltat;

				// own boat speed
				ptrGui.PIPOwnship.dataSpeed.OverrideValue += m_fAcceleration * m_fDeltaTime;
				if (ptrGui.PIPOwnship.dataSpeed.OverrideValue < (OWN_SPEED_MIN / KKTSTOMPS))
					ptrGui.PIPOwnship.dataSpeed.OverrideValue = OWN_SPEED_MIN / KKTSTOMPS;

				else if (ptrGui.PIPOwnship.dataSpeed.OverrideValue > OWN_SPEED_MAX / KKTSTOMPS)
					ptrGui.PIPOwnship.dataSpeed.OverrideValue = OWN_SPEED_MAX / KKTSTOMPS;


				// own boat heading
				ptrGui.PIPOwnship.dataHeading.OverrideValue += ptrGui.PIPOwnship.dataTurnRate.OverrideValue * m_fDeltaTime;
				if (ptrGui.PIPOwnship.dataHeading.OverrideValue < BRG_MIN)
					ptrGui.PIPOwnship.dataHeading.OverrideValue += BRG_MAX;

				else if (ptrGui.PIPOwnship.dataHeading.OverrideValue > BRG_MAX)
					ptrGui.PIPOwnship.dataHeading.OverrideValue -= BRG_MAX;


				// own boat cartesian x position
				m_fOwnDeltaX = ptrGui.PIPOwnship.dataDriftSpeed.OverrideValue * KKTSTOMPS *
					((float)Math.Sin (ptrGui.PIPOwnship.dataDriftCourse.OverrideValue * KDEGTORAD))	*
					m_fDeltaTime;

				m_fOwnX += (ptrGui.PIPOwnship.dataSpeed.OverrideValue * KKTSTOMPS *
					((float)Math.Sin (ptrGui.PIPOwnship.dataHeading.OverrideValue * KDEGTORAD)) * m_fDeltaTime) +
					m_fOwnDeltaX;

				if (m_fOwnX < X_OFFSET_MIN)
					m_fOwnX = X_OFFSET_MIN;
				else if (m_fOwnX >  X_OFFSET_MAX)
					m_fOwnX = X_OFFSET_MAX;


				// compute own boat cartesian y position
				m_fOwnDeltaY = ptrGui.PIPOwnship.dataDriftSpeed.OverrideValue * KKTSTOMPS *
					((float)Math.Cos(ptrGui.PIPOwnship.dataDriftCourse.OverrideValue * KDEGTORAD)) * m_fDeltaTime;

				m_fOwnY += (ptrGui.PIPOwnship.dataSpeed.OverrideValue * KKTSTOMPS *
					((float)Math.Cos(ptrGui.PIPOwnship.dataHeading.OverrideValue * KDEGTORAD)) * m_fDeltaTime) +
					m_fOwnDeltaY;

				if (m_fOwnY < Y_OFFSET_MIN)
					m_fOwnY = Y_OFFSET_MIN;
				else if (m_fOwnY > Y_OFFSET_MAX)
					m_fOwnY = Y_OFFSET_MAX;

				// own boat z offset change
				//PIP_own_ptr->z_offset += PIP_own_ptr->climb_rate * deltat;
                ptrGui.PIPOwnship.dataDepth.OverrideValue += ptrGui.PIPOwnship.dataDiveRate.OverrideValue * m_fDeltaTime;
			}
		}

		/*******************************************************************************
		Function Name       : updateTargetDynamics
		Description         : Update the target dynamics.
		Parameters          : None
		Results             : None
		Globals Used        :
		Scope               : Global
		*******************************************************************************/
		protected void updateTargetDynamics()
		{

			short  i;  // index for loop control
			TargetData lpTargetData;

			if ((ptrGui.PIPExercise.dataRunMode.OverrideValue == RUN)           ||
				(ptrGui.PIPExercise.dataRunMode.OverrideValue == FAST_RUN)      ||
				(ptrGui.PIPExercise.dataRunMode.OverrideValue == TARGET_FREEZE))
			{
				//Update the targets
				for (i = 0; i < ptrGui.PIPTarget(0).iNumberOfTargets; i++)
				{
					lpTargetData = ptrGui.PIPTarget(0).getTargetData(i);

					if(lpTargetData == null)
						return;

					updateTargetData(lpTargetData, ref DynamicData[i]);
				}
			}
		}

		protected void updateTargetData(TargetData lpTargetData, ref TargetDynamicData dynamicData)
		{
			TargetData targetData;

			// if the target is present in the slot.
			if (lpTargetData.bVisible.Value)
			{
				// calculate target speed
				lpTargetData.fSpeed.Value += dynamicData.fTargetAcceleration * m_fDeltaTime;
				if (lpTargetData.fSpeed.Value < TAR_SPEED_MIN / KKTSTOMPS)
					lpTargetData.fSpeed.Value = TAR_SPEED_MIN / KKTSTOMPS;
				if (lpTargetData.fSpeed.Value > TAR_SPEED_MAX / KKTSTOMPS)
					lpTargetData.fSpeed.Value = TAR_SPEED_MAX / KKTSTOMPS;

				// clamp target drift speed
				if (lpTargetData.fDriftSpeed.Value < DRIFT_SPEED_MIN / KKTSTOMPS)
					lpTargetData.fDriftSpeed.Value = DRIFT_SPEED_MIN / KKTSTOMPS;
				if (lpTargetData.fDriftSpeed.Value > DRIFT_SPEED_MAX / KKTSTOMPS)
					lpTargetData.fDriftSpeed.Value = DRIFT_SPEED_MAX / KKTSTOMPS;

				//
				//The old PSC did a radial coordinate conversion, but the new PSC will only
				//allow a cartesian conversion (first time through).
				//
				if(dynamicData.bTargetInitialised == false)
				{
					// calculate target reposition using
					// cartesian coordinates

					dynamicData.fTargetX = m_fOwnX + (KYDSTOM * KILO * (lpTargetData.fX.Value));
					dynamicData.fTargetY = m_fOwnY + (KYDSTOM * KILO * (lpTargetData.fY.Value));

					//Target X/Y starting position has been calculated.
					dynamicData.bTargetInitialised = true;
				}
				else
				{
					//
					//Update the target position from the dynamics data.
					//
					if (ptrGui.PIPExercise.dataRunMode.OverrideValue != TARGET_FREEZE)
					{
						// calculate target delta x coordinate relative to origin */
						m_fTargetDeltaX = m_fDeltaTime * ((KKTSTOMPS * lpTargetData.fDriftSpeed.Value) *
							              (float)(Math.Sin (lpTargetData.fDriftCourse.Value * KDEGTORAD)));

						// calculate target x coordinate relative to origin */
						dynamicData.fTargetX += (lpTargetData.fSpeed.Value *
 							                     KKTSTOMPS * (float)Math.Sin (lpTargetData.fHeading.Value *
							                     KDEGTORAD)* m_fDeltaTime) + m_fTargetDeltaX;

						// calculate target delta y coordinate relative to origin */
						m_fTargetDeltaY = m_fDeltaTime * (KKTSTOMPS * lpTargetData.fDriftSpeed.Value) *
							              (float)(Math.Cos (lpTargetData.fDriftCourse.Value * KDEGTORAD));

						// calculate target y coordinate relative to origin */
						dynamicData.fTargetY += (lpTargetData.fSpeed.Value *
							                     KKTSTOMPS * ((float)Math.Cos (lpTargetData.fHeading.Value * KDEGTORAD)) *
							                     m_fDeltaTime) + m_fTargetDeltaY;
					}

					/* calculate target x coordinate relative to ownboat */
					lpTargetData.fX.Value = (float)((dynamicData.fTargetX - m_fOwnX) / (KILO * KYDSTOM));

					/* calculate target y coordinate relative to ownboat */
					lpTargetData.fY.Value = (float)((dynamicData.fTargetY - m_fOwnY) / (KILO * KYDSTOM));
				}

				// check for targets about to fall off
				// the edge of the playing area.
				if (dynamicData.fTargetX < X_OFFSET_MIN)
				{
					dynamicData.fTargetX = X_OFFSET_MIN;
					lpTargetData.fHeading.Value += BRG_MID;
				}

				if (dynamicData.fTargetX > X_OFFSET_MAX)
				{
					dynamicData.fTargetX = X_OFFSET_MAX;
					lpTargetData.fHeading.Value += BRG_MID;
				}

				if (dynamicData.fTargetY < Y_OFFSET_MIN)
				{
					dynamicData.fTargetY = Y_OFFSET_MIN;
					lpTargetData.fHeading.Value += BRG_MID;
				}

				if (dynamicData.fTargetY > Y_OFFSET_MAX)
				{
					dynamicData.fTargetY = Y_OFFSET_MAX;
					lpTargetData.fHeading.Value += BRG_MID;
				}

				if (ptrGui.PIPExercise.dataRunMode.OverrideValue !=	TARGET_FREEZE)
				{
					// calculate target z coordinate
					lpTargetData.fDepth.Value += lpTargetData.fClimbRate.Value * m_fDeltaTime;

					if (lpTargetData.fDepth.Value < Z_OFFSET_MIN / KFTTOM)
						lpTargetData.fDepth.Value = Z_OFFSET_MIN / KFTTOM;

					else if (lpTargetData.fDepth.Value > Z_OFFSET_MAX / KFTTOM)
						lpTargetData.fDepth.Value = Z_OFFSET_MAX / KFTTOM;

					// calculate target heading
					lpTargetData.fHeading.Value += lpTargetData.fTurnRate.Value * m_fDeltaTime;

					// clamp target heading
					if (lpTargetData.fHeading.Value > BRG_MAX)
						lpTargetData.fHeading.Value -= BRG_MAX;
					else if (lpTargetData.fHeading.Value < BRG_MIN)
						lpTargetData.fHeading.Value += BRG_MAX;

					// clamp target drift heading
					if (lpTargetData.fDriftCourse.Value > BRG_MAX)
						lpTargetData.fDriftCourse.Value -= BRG_MAX;
					else if (lpTargetData.fDriftCourse.Value < BRG_MIN)
						lpTargetData.fDriftCourse.Value += BRG_MAX;
				}
			}


			else if(m_iRunningScenario == 1  ||
				    m_iRunningScenario == 5  ||
				    m_iRunningScenario == 16 ||
				    m_iRunningScenario == 17 ||
				    m_iRunningScenario == 30)
			{
				// Dive/surface manoeuvre for Tango submarine
				//PIP_tar_ptr = &(PIP_data_raw.target[2]);

				targetData = ptrGui.PIPTarget(0).getTargetData(2);
				if(targetData != null)
				{
					if (targetData.fDepth.Value < -30.0f)
						targetData.fDepth.Value = -30.0f;

					if (targetData.fDepth.Value > -1.0f)
						targetData.fDepth.Value = -1.0f;

					m_fDiveTime += m_fDeltaTime;

					if ((m_fDiveTime > 60.0f) && (m_fDiveTime < 90.0f))
					{
						// dive for thirty seconds
						targetData.fClimbRate.Value = -2.0f;
					}
					else if ((m_fDiveTime > 90.0f) && (m_fDiveTime < 120.0f))
					{
						// level out for thirty seconds
						targetData.fClimbRate.Value = 0.0f;
					}
					else if ((m_fDiveTime > 120.0f) && (m_fDiveTime < 150.0f))
					{
						// surface for thirty seconds
						if (targetData.fDepth.Value > -0.1f)
							targetData.fClimbRate.Value = 0.0f;
						else
							targetData.fClimbRate.Value = 2.0f;
					}
					else if ((m_fDiveTime > 150.0f) && (m_fDiveTime < 240.0f))
					{
						// level out for ninety seconds
						targetData.fClimbRate.Value = 0.0f;
					}
					else if (m_fDiveTime > 240.0f)
						m_fDiveTime = 0.0f;
				}
			}

			else if( m_iRunningScenario == 10 ||
				     m_iRunningScenario == 23 ||
				     m_iRunningScenario == 24 )
			{
				targetData = ptrGui.PIPTarget(0).getTargetData(0);
				if(targetData != null)
				{
					if (((targetData.iTargetNum.Value == 14) ||
						(targetData.iTargetNum.Value == 48)) && (targetData.iTargetNum.Value != iLastTargetID))
					{
						// aircraft / helicopters
						targetData.fDepth.Value = 100.0f;
						targetData.fSpeed.Value = 150.0f;
						targetData.fDriftSpeed.Value = 0.0f;
					}
					else if (targetData.iTargetNum.Value != iLastTargetID)
					{
						// surface vessels
						targetData.fDepth.Value = 0.0f;
						targetData.fSpeed.Value = 10.0f;
						targetData.fDriftSpeed.Value = 0.0f;
					}

					iLastTargetID = targetData.iTargetNum.Value;
				}
			}

			else if( m_iRunningScenario == 2 ||
				     m_iRunningScenario == 4 ||
				     m_iRunningScenario == 8 ||
				     m_iRunningScenario == 9 )
			{
				// shadow target's speed and heading
				targetData = ptrGui.PIPTarget(0).getTargetData(0);
				if(targetData != null)
				{
					ptrGui.PIPOwnship.dataSpeed.OverrideValue = targetData.fSpeed.Value;
					ptrGui.PIPOwnship.dataDriftSpeed.OverrideValue = targetData.fDriftSpeed.Value;
					ptrGui.PIPOwnship.dataHeading.OverrideValue = targetData.fHeading.Value;
					ptrGui.PIPOwnship.dataDriftCourse.OverrideValue = targetData.fDriftCourse.Value;
					ptrGui.PIPOwnship.dataTurnRate.OverrideValue = targetData.fTurnRate.Value;
				}
			}

			else if( m_iRunningScenario == 32 ||
				     m_iRunningScenario == 33 ||
				     m_iRunningScenario == 42 ||
				     m_iRunningScenario == 46 ||
				     m_iRunningScenario == 61 )
			{
				// Dive/surface manoeuvre for Tango submarine
				targetData = ptrGui.PIPTarget(0).getTargetData(2);
				if(targetData != null)
				{

					if (targetData.fDepth.Value < -30.0f)
						targetData.fDepth.Value = -30.0f;

					if (targetData.fDepth.Value > -1.0f)
						targetData.fDepth.Value = -1.0f;

					m_fDiveTime += m_fDeltaTime;

					if ((m_fDiveTime > 60.0) && (m_fDiveTime < 90.0))
					{
						// dive for thirty seconds
						targetData.fClimbRate.Value = -2.0f;
					}
					else if ((m_fDiveTime > 90.0) && (m_fDiveTime < 120.0))
					{
						// level out for thirty seconds
						targetData.fClimbRate.Value = 0.0f;
					}
					else if ((m_fDiveTime > 120.0) && (m_fDiveTime < 150.0))
					{
						// surface for thirty seconds
						if (targetData.fDepth.Value > -0.1f)
							targetData.fClimbRate.Value = 0.0f;
						else
							targetData.fClimbRate.Value = 2.0f;
					}
					else if ((m_fDiveTime > 150.0f) && (m_fDiveTime < 240.0f))
					{
						// level out for ninety seconds
						targetData.fClimbRate.Value = 0.0f;
					}
					else if (m_fDiveTime > 240.0f)
						m_fDiveTime = 0.0f;
				}
			}

			else if( m_iRunningScenario == 34 ||
				     m_iRunningScenario == 35 ||
				     m_iRunningScenario == 51 )
			{
				targetData = ptrGui.PIPTarget(0).getTargetData(0);
				if(targetData != null)
				{
					if (((targetData.iTargetNum.Value == 14) ||
						(targetData.iTargetNum.Value == 48)) &&
						(targetData.iTargetNum.Value != iLastTargetID))
					{
						// aircraft and helicopters
						targetData.fDepth.Value = 100.0f;
						targetData.fSpeed.Value = 150.0f;
						targetData.fDriftSpeed.Value = 0.0f;
					}
					else if (targetData.iTargetNum.Value != iLastTargetID)
					{
						// surface vessels
						targetData.fDepth.Value = 0.0f;
						targetData.fSpeed.Value = 10.0f;
						targetData.fDriftSpeed.Value = 0.0f;
					}
					iLastTargetID = targetData.iTargetNum.Value;
				}
			}

			else if( m_iRunningScenario == 43 ||
				     m_iRunningScenario == 45 ||
				     m_iRunningScenario == 49 ||
				     m_iRunningScenario == 50 )
			{
				// shadow target's speed and heading
				targetData = ptrGui.PIPTarget(0).getTargetData(0);
				if(targetData != null)
				{
					ptrGui.PIPOwnship.dataSpeed.OverrideValue = targetData.fSpeed.Value;
					ptrGui.PIPOwnship.dataDriftSpeed.OverrideValue = targetData.fDriftSpeed.Value;
					ptrGui.PIPOwnship.dataHeading.OverrideValue = targetData.fHeading.Value;
					ptrGui.PIPOwnship.dataDriftCourse.OverrideValue = targetData.fDriftCourse.Value;
					ptrGui.PIPOwnship.dataTurnRate.OverrideValue = targetData.fTurnRate.Value;
				}
			}
		}
	}
}
