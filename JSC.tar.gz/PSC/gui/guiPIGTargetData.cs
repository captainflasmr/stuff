//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiPIGTargetData.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Windows.Forms;

namespace PSCGenericBuild
{
	
	//-----------------------------------------------------------------------
	//The Target Data Page Class.
	//-----------------------------------------------------------------------
	public class C_guiPIGTargetData : C_guiTemplatePage
	{
		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		//protected C_guiDataItem [] dataItem;
		protected string     [] strDescription;
		protected int           iTarget;
        protected PIGTargetData   m_InData;

		public PIGTargetData oPIGTargetDataPacket;

		public C_guiDataItemShort dataModelID;	
		public C_guiDataItemShort dataTargetNum;	
		public C_guiDataItemFloat dataSpotLightConfig;	
		public C_guiDataItemFloat dataLightConfig;	
		public C_guiDataItemFloat dataX;	
		public C_guiDataItemFloat dataY;	
		public C_guiDataItemFloat dataHeight;	
		public C_guiDataItemFloat dataHeading;
		public C_guiDataItemFloat dataRoll;	
		public C_guiDataItemFloat dataPitch;	
		public C_guiDataItemFloat dataSpeed;	
		public C_guiDataItemFloat dataAcceleration;	

		public C_guiDataItemBoolean dataVisible;	
		public C_guiDataItemBoolean dataNavLights;	
		public C_guiDataItemBoolean dataMissileImpact;	
		public C_guiDataItemBoolean dataTorpedoImpact;	
		public C_guiDataItemBoolean dataSinking;	
		public C_guiDataItemBoolean dataSonarDunking;
		public C_guiDataItemBoolean dataTLAMLaunch;	

		public C_guiDataItemBoolean dataExplosion;	

		public C_guiDataItemBoolean dataDieselSmoke;
		public C_guiDataItemBoolean dataMissileLaunch;
		public C_guiDataItemByte dataFishingLights;	
		public C_guiDataItemByte dataSpotLights;

		public int m_modelID;


		//-----------------------------------------------------------------------
		//Class Properties
		//-----------------------------------------------------------------------

		public const int NET_VISIBLE                 = 0x0001;
		public const int NET_NAV_LIGHTS              = 0x0002;
		public const int NET_MISSILE_IMPACT          = 0x0004;
		public const int NET_TORPEDO_IMPACT          = 0x0008;
		public const int NET_SINKING                 = 0x0010;
		public const int NET_SONAR_DIP               = 0x0020;
		public const int NET_TLAM_LAUNCH             = 0x0040;
		public const int NET_EXPLOSION               = 0x0080;
		public const int NET_DIESEL_SMOKE            = 0x0100;

		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		/************************************************************************
		  FUNCTION      : C_guiPIGTargetData()
		  DESCRIPTION   : The Constructor for Target Data Page. 
		  PARAMETERS    : parentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the Target Data Page.
		 ************************************************************************/
		public C_guiPIGTargetData (C_gui parentForm, String strLabel, int iTargetPage)
		{
			this.ptrGui = parentForm;
			//this.ptrPSC = parentForm.psc;

			//-----------------------------------------------------
			//Declare the data items.
			//-----------------------------------------------------
			m_dataItem = new C_guiDataItem[21];

			iTarget   = iTargetPage;
            m_InData  = this.ptrGui.m_InPIGData.oPIGTarget[iTarget];

			string [] strOnOff     = {"Off", "On"};
			string [] strSetReset   = {"Reset", "Set"};
			string [] strLights     = {"Making Way", 
										  "Short Fishing", 
										  "Long Fishing", 
										  "Trawling", 
										  "Shooting Nets", 
										  "Hauling Nets", 
										  "Nets Snagged",
										  "Purse Seining",
										  "On Pilot Duty"};				           
			string [] strSpotlights = {"Off", "Port", "Starboard"};

			this.SuspendLayout();
			this.Text      = strLabel;

			strDescription = new String [22];

			strDescription[0]  = "Model ID ("            + 1     + ".." + 1     + ")";
			strDescription[1]  = "Target Number ("       + 1       + ".." + 1       + ")";
			strDescription[2]  = "X position in scene (" + 1            + ".." + 1            + ")";
			strDescription[3]  = "Y position in scene (" + 1            + ".." + 1            + ")";
			strDescription[4]  = "Height above water ("  + 1       + ".." + 1       + ")";
			strDescription[5]  = "Target heading ("      + 1      + ".." + 1      + ")";
			strDescription[6]  = "Target roll ("         + 1         + ".." + 1         + ")";
			strDescription[7]  = "Target pitch ("        + 1        + ".." + 1        + ")";
			strDescription[8]  = "Target speed ("        + 1        + ".." + 1        + ")";
			strDescription[9] = "Target acceleration (" + 1        + ".." + 1        + ")";
			strDescription[10] = "Target is visible in the scenario(On/Off)";
			strDescription[11] = "Nav lights are illuminated(On/Off)";
			strDescription[12] = "Missile impact on target(On/Off)";
			strDescription[13] = "Torpedo explosion on target(On/Off)";
			strDescription[14] = "Target Sinking(On/Off)";
			strDescription[15] = "Helicopter target has sonar dip(On/Off)";
			strDescription[16] = "TLAM launch(Reset/Set)";
			strDescription[17] = "Flames and smoke required(On/Off)";
			strDescription[18] = "Diesel smoke required(On/Off)";
			strDescription[19] = "Missile Launch (On/Off)";
			strDescription[20] = "(Making Way / Short Fishing / Long Fishing / Trawling /Shooting Nets\n" +
				" Hauling Nets / Nets Snagged / Purse Seining / On Pilot Duty";
			strDescription[21] = "(OFF/PORT/STARBOARD)";
			

			//-----------------------------------------------------
			//Initialise each data item.
			//-----------------------------------------------------
			dataModelID      = new C_guiDataItemShort( "Model ID",                "PIG_TARGET_MODEL_ID",          50,  10, this, strDescription[0]);
			dataTargetNum    = new C_guiDataItemShort( "Target Number",           "PIG_TARGET_TARGET_NUM",        50,  40, this, strDescription[1]);
			dataX            = new C_guiDataItemFloat( "X",                       "PIG_TARGET_X",                 50,  70, this, strDescription[2]);
			dataY            = new C_guiDataItemFloat( "Y",                       "PIG_TARGET_Y",                 50, 100, this, strDescription[3]);
			dataHeight       = new C_guiDataItemFloat( "Height",                  "PIG_TARGET_HEIGHT",            50, 130, this, strDescription[4]);
			dataHeading      = new C_guiDataItemFloat( "Heading",                 "PIG_TARGET_HEADING",           50, 160, this, strDescription[5]);
			dataRoll         = new C_guiDataItemFloat( "Roll",                    "PIG_TARGET_ROLL",              50, 190, this, strDescription[6]);
			dataPitch        = new C_guiDataItemFloat( "Pitch",                   "PIG_TARGET_PITCH",             50, 220, this, strDescription[7]);
			dataSpeed        = new C_guiDataItemFloat( "Speed",                   "PIG_TARGET_SPEED",             50, 250, this, strDescription[8]);
			dataAcceleration = new C_guiDataItemFloat( "Acceleration",            "PIG_TARGET_ACCELERATION",      50, 280, this, strDescription[9]);
			dataVisible      = new C_guiDataItemBoolean( "Visible",                 "PIG_TARGET_VISIBLE",           50, 320, this, strDescription[10]);
			dataNavLights    = new C_guiDataItemBoolean( "Nav Lights",              "PIG_TARGET_NAV_LIGHTS",        50, 350, this, strDescription[11]);
			dataMissileImpact= new C_guiDataItemBoolean( "Missile Impact",          "PIG_TARGET_MISSILE_IMPACT",    50, 380, this, strDescription[12]);
			dataTorpedoImpact= new C_guiDataItemBoolean( "Torpedo Impact",          "PIG_TARGET_TORPEDO_IMPACT",    50, 410, this, strDescription[13]);
			dataSinking      = new C_guiDataItemBoolean( "Sinking",                 "PIG_TARGET_SINKING",           50, 440, this, strDescription[14]);
			dataSonarDunking = new C_guiDataItemBoolean( "Sonar Dip",               "PIG_TARGET_SONAR_DIP",         50, 470, this, strDescription[15]);
			dataTLAMLaunch   = new C_guiDataItemBoolean( "TLAM Launch",             "PIG_TARGET_TLAM_LAUNCH",       50, 500, this, strDescription[16]);
			dataExplosion    = new C_guiDataItemBoolean( "Explosion",               "PIG_TARGET_EXPLOSION",         50, 530, this, strDescription[17]);
			dataDieselSmoke  = new C_guiDataItemBoolean( "Diesel Smoke",            "PIG_TARGET_DIESEL_SMOKE",      50, 560, this, strDescription[18]);
			dataMissileLaunch  = new C_guiDataItemBoolean( "Missile Launch",          "PIG_TARGET_MISSILE_LAUNCH",    50, 590, this, strDescription[19]);
			dataFishingLights= new C_guiDataItemByte( "Fising Vessel Lights",    "PIG_TARGET_FISHING_LIGHTS",    50, 620, this, strDescription[20]);
			dataSpotLights   = new C_guiDataItemByte( "Fising Vessel SpotLights","PIG_TARGET_FISHING_SPOTS",     50, 655, this, strDescription[21]);

			dataModelID.description.Width = 300;
			dataModelID.Width = 800;
		
			dataVisible.setListEntries(strOnOff);
			dataNavLights.setListEntries(strOnOff);
			dataMissileImpact.setListEntries(strOnOff);
			dataTorpedoImpact.setListEntries(strOnOff);
			dataSinking.setListEntries(strOnOff);
			dataSonarDunking.setListEntries(strOnOff);
			dataTLAMLaunch.setListEntries(strSetReset);
			dataExplosion.setListEntries(strOnOff);
			dataDieselSmoke.setListEntries(strOnOff);
			dataMissileLaunch.setListEntries(strOnOff);

			dataFishingLights.setListEntries(strLights);
			dataFishingLights.description.Height = 30;
			dataSpotLights.setListEntries(strSpotlights);


			this.Controls.Add(dataModelID);
			this.Controls.Add(dataTargetNum);
			this.Controls.Add(dataSpotLightConfig);
			this.Controls.Add(dataLightConfig);
			this.Controls.Add(dataX);
			this.Controls.Add(dataY);
			this.Controls.Add(dataHeight);
			this.Controls.Add(dataHeading);
			this.Controls.Add(dataRoll);
			this.Controls.Add(dataPitch);
			this.Controls.Add(dataSpeed);
			this.Controls.Add(dataAcceleration);
			this.Controls.Add(dataVisible);
			this.Controls.Add(dataNavLights);
			this.Controls.Add(dataMissileImpact);
			this.Controls.Add(dataTorpedoImpact);
			this.Controls.Add(dataSinking);
			this.Controls.Add(dataSonarDunking);
			this.Controls.Add(dataTLAMLaunch);

			this.Controls.Add(dataExplosion);
			this.Controls.Add(dataDieselSmoke);
			this.Controls.Add(dataMissileLaunch);
			this.Controls.Add(dataFishingLights);
			this.Controls.Add(dataSpotLights);

			this.MdiParent = parentForm;
			//this.WindowState = FormWindowState.Maximized;

			this.Size        = new Size(860, 730);
			this.MinimumSize = new Size(200, 200);

			this.ResumeLayout(false );

            m_initialised = true;

            m_modelID = -1;
		}

		public override void updateIncomingData()
		{
			if(!m_initialised)
				return;

			dataModelID.Value = m_InData.sModelID.Value;

			//
			//Update the model name in the description field if the model id has changed.
			//
			if(dataModelID.Value != m_modelID)
			{
				if(dataModelID.Value >= 0 && dataModelID.Value < 1000)
				{
					dataModelID.description.Text = dataModelID.strDescription + " (" + ptrGui.m_modelNames[dataModelID.Value] + ")";
                    m_modelID = dataModelID.Value;
				}
			}

			dataTargetNum.Value = m_InData.sTargetNum.Value;
			dataX.Value = m_InData.fX.Value;
			dataY.Value = m_InData.fY.Value;
			dataHeight.Value = m_InData.fHeight.Value;
			dataHeading.Value = m_InData.fHeading.Value;
			dataRoll.Value = m_InData.fRoll.Value;
			dataPitch.Value = m_InData.fPitch.Value;
			dataSpeed.Value = m_InData.fSpeed.Value;
			dataAcceleration.Value = m_InData.fAcceleration.Value;

			dataVisible.Value = m_InData.bVisible.Value;     
			dataNavLights.Value = m_InData.bNavLights.Value;     
			dataMissileImpact.Value = m_InData.bMissileImpact.Value;     
			dataTorpedoImpact.Value = m_InData.bTorpedoImpact.Value;     
			dataSinking.Value = m_InData.bSinking.Value;     
			dataSonarDunking.Value = m_InData.bSonarDunking.Value;     
			dataTLAMLaunch.Value = m_InData.bTLAMLaunch.Value;     
			dataExplosion.Value = m_InData.bExplosion.Value;     
			dataDieselSmoke.Value = m_InData.bDieselSmoke.Value;     
			dataMissileLaunch.Value = m_InData.bMissileLaunch.Value;

			dataFishingLights.Value = m_InData.bLightConfig.Value;     
			dataSpotLights.Value = m_InData.bSpotlightConfig.Value;        

		}

		public override void updateOutgoingData()
		{
			if(!m_initialised)
				return;

			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bVisible.Value = dataVisible.Value;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bNavLights.Value = dataNavLights.Value;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bMissileImpact.Value = dataMissileImpact.Value;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bTorpedoImpact.Value = dataTorpedoImpact.Value;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bSinking.Value = dataSinking.Value ;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bSonarDunking.Value = dataSonarDunking.Value;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bTLAMLaunch.Value = dataTLAMLaunch.Value;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bExplosion.Value = dataExplosion.Value;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bDieselSmoke.Value = dataDieselSmoke.Value;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bMissileLaunch.Value = dataMissileLaunch.Value;     

            this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].sModelID.Value      = dataModelID.Value;
            this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].sTargetNum.Value    = dataTargetNum.Value;
            this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fX.Value            = dataX.Value;
            this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fY.Value            = dataY.Value;
            this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fHeight.Value       = dataHeight.Value;
            this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fHeading.Value      = dataHeading.Value;
            this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fRoll.Value         = dataRoll.Value;
            this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fPitch.Value        = dataPitch.Value;
            this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fSpeed.Value        = dataSpeed.Value;
            this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fAcceleration.Value = dataAcceleration.Value;
            this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bLightConfig.Value  = dataFishingLights.Value;
            this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bSpotlightConfig.Value = dataSpotLights.Value;


			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bVisible.Flag = dataVisible.overrideChecked;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bNavLights.Flag = dataNavLights.overrideChecked;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bMissileImpact.Flag = dataMissileImpact.overrideChecked;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bTorpedoImpact.Flag = dataTorpedoImpact.overrideChecked;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bSinking.Flag = dataSinking.overrideChecked ;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bSonarDunking.Flag = dataSonarDunking.overrideChecked;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bTLAMLaunch.Flag = dataTLAMLaunch.overrideChecked;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bExplosion.Flag = dataExplosion.overrideChecked;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bDieselSmoke.Flag = dataDieselSmoke.overrideChecked;     
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bMissileLaunch.Flag = dataMissileLaunch.overrideChecked;     
				
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].sModelID.Flag      = dataModelID.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].sTargetNum.Flag    = dataTargetNum.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fX.Flag            = dataX.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fY.Flag            = dataY.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fHeight.Flag       = dataHeight.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fHeading.Flag      = dataHeading.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fRoll.Flag         = dataRoll.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fPitch.Flag        = dataPitch.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fSpeed.Flag        = dataSpeed.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].fAcceleration.Flag = dataAcceleration.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bLightConfig.Flag  = dataFishingLights.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGTarget[iTarget].bSpotlightConfig.Flag = dataSpotLights.overrideChecked;


			//this.ptrMain.ptrNetwork.send();
		}

		public override void setOverride(bool bEnabled)
		{
			if(!m_initialised) 
				return;

			dataVisible.setOverride(bEnabled);     
			dataNavLights.setOverride(bEnabled);     
			dataMissileImpact.setOverride(bEnabled);     
			dataTorpedoImpact.setOverride(bEnabled);     
			dataSinking.setOverride(bEnabled);     
			dataSonarDunking.setOverride(bEnabled);     
			dataTLAMLaunch.setOverride(bEnabled);     
			dataExplosion.setOverride(bEnabled);     
			dataDieselSmoke.setOverride(bEnabled);     
			dataMissileLaunch.setOverride(bEnabled); 

			dataModelID.setOverride(bEnabled);	
			dataTargetNum.setOverride(bEnabled);	
			dataSpotLightConfig.setOverride(bEnabled);	
			dataLightConfig.setOverride(bEnabled);	
			dataX.setOverride(bEnabled);	
			dataY.setOverride(bEnabled);	
			dataHeight.setOverride(bEnabled);	
			dataHeading.setOverride(bEnabled);
			dataRoll.setOverride(bEnabled);	
			dataPitch.setOverride(bEnabled);	
			dataSpeed.setOverride(bEnabled);
			dataAcceleration.setOverride(bEnabled);	
			dataVisible.setOverride(bEnabled);	
			dataNavLights.setOverride(bEnabled);	
			dataMissileImpact.setOverride(bEnabled);	
			dataTorpedoImpact.setOverride(bEnabled);	
			dataSinking.setOverride(bEnabled);	
			dataSonarDunking.setOverride(bEnabled);
			dataTLAMLaunch.setOverride(bEnabled);	
			dataExplosion.setOverride(bEnabled);	
			dataDieselSmoke.setOverride(bEnabled);
			dataFishingLights.setOverride(bEnabled);	
			dataSpotLights.setOverride(bEnabled);
		}
	}
}
