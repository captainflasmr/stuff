//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiPIGReturnData.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;
using System.Drawing;

namespace PSCGenericBuild
{
	
	public struct PIGPolyniaData
	{
		public C_DataStoreItemLong  iPolyniaID;	
		public C_DataStoreItemFloat fX;	
		public C_DataStoreItemFloat fY;	
		public C_DataStoreItemFloat fZ;	
		public C_DataStoreItemFloat fPolyniaOrienation;	
		public C_DataStoreItemLong  iSlotNumber;
	}

	//-----------------------------------------------------------------------
	//The Exercise Data Page Class.
	//-----------------------------------------------------------------------
	public class C_guiPIGReturnData : C_guiTemplatePage
	{
		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		//protected C_guiDataItem [] dataItem;
		string [] strMode = {"Run", "Stop", "Freeze", "Reset"};
		string [] strPolynia = {"Polynia I","Polynia II","Polynia III","Polynia IV"};
		protected ComboBox m_comboPolynia;
		protected Label    m_labelPolynia;
		public PIGReturnData   m_InData;

		public C_guiDataItemLong  dataProcStatus;	
		public C_guiDataItemLong  dataModelStatus;	
		public C_guiDataItemLong  dataContacts;	
		public C_guiDataItemLong  dataIdentity;	
		public C_guiDataItemFloat dataX;	
		public C_guiDataItemFloat dataY;	
		public C_guiDataItemFloat dataZ;	
		public C_guiDataItemFloat dataOrientation;	
		public C_guiDataItemLong  dataSlotNumber;	

		public PIGPolyniaData [] polyniaData;

		protected int m_iPolynia;

		//-----------------------------------------------------------------------
		//Class Properties
		//-----------------------------------------------------------------------

		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		/************************************************************************
		  FUNCTION      : C_guiPIGReturnData()
		  DESCRIPTION   : The Constructor for the PIG Return Data Page. 
		  PARAMETERS    : parentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the PIG Return Data Page.
		 ************************************************************************/
		public C_guiPIGReturnData (C_gui parentForm)
		{
			this.ptrGui = parentForm;
			//this.ptrPSC = parentForm.psc;

			//-----------------------------------------------------
			//Declare the data items.
			//-----------------------------------------------------
			m_InData  = this.ptrGui.m_InPIGData.oPIGReturn;

			this.Text      = "PIG Data - Return";
			this.pageType  = C_gui.page.PIG_RETURN;

			m_labelPolynia          = new Label();
			m_labelPolynia.Text     = "Polynia";
			m_labelPolynia.Location = new Point(50, 110);
			this.Controls.Add(m_labelPolynia);

			m_comboPolynia          = new ComboBox();
			m_comboPolynia.Location = new Point(180, 110);
			m_comboPolynia.Text     = "1";
			m_comboPolynia.KeyPress    += new KeyPressEventHandler(integerKeyPress);
			m_comboPolynia.TextChanged += new EventHandler(polyniaIndexChanged);

			m_comboPolynia.BeginUpdate();
			for(int i=0; i < SIMControl.NUM_POLYNIA_TARGETS; i++)
			{
				m_comboPolynia.Items.Add((i+1).ToString());
			}
			m_comboPolynia.EndUpdate();

			this.Controls.Add(m_comboPolynia);

			polyniaData = new PIGPolyniaData[SIMControl.NUM_POLYNIA_TARGETS];

			for(int i=0; i < polyniaData.Length; i++)
			{
				polyniaData[i].iPolyniaID = new C_DataStoreItemLong();	
				polyniaData[i].fX = new C_DataStoreItemFloat();	
				polyniaData[i].fY = new C_DataStoreItemFloat();	
				polyniaData[i].fZ = new C_DataStoreItemFloat();	
				polyniaData[i].fPolyniaOrienation = new C_DataStoreItemFloat();	
				polyniaData[i].iSlotNumber = new C_DataStoreItemLong();
			}

			//-----------------------------------------------------
			//Initialise each data item.
			//-----------------------------------------------------
			dataProcStatus  = new C_guiDataItemLong( "Processor Status","PIG_RETURN_PROC_STATUS",  50,  10, this, "System Identifier ");
			dataModelStatus = new C_guiDataItemLong( "Model Status" ,   "PIG_RETURN_MODEL_STATUS", 50,  40, this, "Run Mode (Run/Stop/Freeze/Reset)");
			dataContacts    = new C_guiDataItemLong( "Contacts" ,       "PIG_RETURN_CONTACTS",     50,  70, this, "Run Mode (Run/Stop/Freeze/Reset)");
			dataIdentity    = new C_guiDataItemLong( "Type",            "PIG_RETURN_IDENTITY",     50, 140, this, "System Identifier ");
			dataX           = new C_guiDataItemFloat("X Offset" ,       "PIG_RETURN_X",            50, 170, this, "Run Mode (Run/Stop/Freeze/Reset)");
			dataY           = new C_guiDataItemFloat("Y Offset" ,       "PIG_RETURN_Y",            50, 200, this, "Run Mode (Run/Stop/Freeze/Reset)");
			dataZ           = new C_guiDataItemFloat("Z Offset" ,       "PIG_RETURN_Z",            50, 230, this, "Run Mode (Run/Stop/Freeze/Reset)");
			dataOrientation = new C_guiDataItemFloat("Orientation" ,    "PIG_RETURN_ORIENTATION",  50, 260, this, "Run Mode (Run/Stop/Freeze/Reset)");
			dataSlotNumber  = new C_guiDataItemLong( "Slot Number" ,    "PIG_RETURN_SLOT_NUM",     50, 290, this, "Run Mode (Run/Stop/Freeze/Reset)");

			dataIdentity.numeric.ValueChanged  += new EventHandler(polyniaChanged);
			dataX.numeric.ValueChanged          += new EventHandler(polyniaChanged);
			dataY.numeric.ValueChanged          += new EventHandler(polyniaChanged);
			dataZ.numeric.ValueChanged          += new EventHandler(polyniaChanged);
			dataOrientation.numeric.ValueChanged += new EventHandler(polyniaChanged);
			dataSlotNumber.numeric.ValueChanged += new EventHandler(polyniaChanged);

			dataIdentity.checkBox.CheckedChanged       += new EventHandler(polyniaCheckChanged);
			dataX.checkBox.CheckedChanged               += new EventHandler(polyniaCheckChanged);
			dataY.checkBox.CheckedChanged               += new EventHandler(polyniaCheckChanged);
			dataZ.checkBox.CheckedChanged               += new EventHandler(polyniaCheckChanged);
			dataOrientation.checkBox.CheckedChanged      += new EventHandler(polyniaCheckChanged);
			dataSlotNumber.checkBox.CheckedChanged += new EventHandler(polyniaCheckChanged);

            dataIdentity.setListEntries(strPolynia);

			this.Controls.Add(dataProcStatus);
			this.Controls.Add(dataModelStatus);
			this.Controls.Add(dataContacts);
			this.Controls.Add(dataIdentity);
			this.Controls.Add(dataX);
			this.Controls.Add(dataY);
			this.Controls.Add(dataZ);
			this.Controls.Add(dataOrientation);
			this.Controls.Add(dataSlotNumber);

			this.MdiParent = parentForm;
			this.Size      = new Size(850, 360);

			m_initialised = true;
			m_iPolynia    = 0;
		}

		public void polyniaIndexChanged(object sender, EventArgs e)
		{
            int iPolynia;

			//
            //Check the bounds.
			//
			if(m_comboPolynia.Text.Length == 0)
				m_comboPolynia.Text = "1";
		   
			if(Int32.Parse(m_comboPolynia.Text) == 0)
			{
				m_comboPolynia.Text = "1";
			}		   
			else if(Int32.Parse(m_comboPolynia.Text) > SIMControl.NUM_POLYNIA_TARGETS)
			{
				m_comboPolynia.Text = SIMControl.NUM_POLYNIA_TARGETS.ToString();
			}

	        iPolynia = Int32.Parse(m_comboPolynia.Text) - 1;

			changePageContent(iPolynia);

			//Refresh the content of the screen.
			//updateIncomingData();

			m_iPolynia = iPolynia;           
		}

		public void changePageContent(int iNewPolynia)
		{

			//
			//Save the existing values...
			//
			polyniaData[m_iPolynia].iPolyniaID.Value = dataIdentity.Value;
			polyniaData[m_iPolynia].fX.Value = dataX.Value;
			polyniaData[m_iPolynia].fY.Value = dataY.Value;
			polyniaData[m_iPolynia].fZ.Value = dataZ.Value;
			polyniaData[m_iPolynia].fPolyniaOrienation.Value = dataOrientation.Value;
			polyniaData[m_iPolynia].iSlotNumber.Value  = dataSlotNumber.Value;

			polyniaData[m_iPolynia].iPolyniaID.Flag = dataIdentity.overrideChecked;
			polyniaData[m_iPolynia].fX.Flag = dataX.overrideChecked;
			polyniaData[m_iPolynia].fY.Flag = dataY.overrideChecked;
			polyniaData[m_iPolynia].fZ.Flag = dataZ.overrideChecked;
			polyniaData[m_iPolynia].fPolyniaOrienation.Flag = dataOrientation.overrideChecked;
			polyniaData[m_iPolynia].iSlotNumber.Flag  = dataSlotNumber.overrideChecked;
            
//
			dataIdentity.OverrideValue = polyniaData[iNewPolynia].iPolyniaID.Value;
			dataX.OverrideValue = polyniaData[iNewPolynia].fX.Value;
			dataY.OverrideValue = polyniaData[iNewPolynia].fY.Value;
			dataZ.OverrideValue = polyniaData[iNewPolynia].fZ.Value;
			dataOrientation.OverrideValue = polyniaData[iNewPolynia].fPolyniaOrienation.Value;
			dataSlotNumber.OverrideValue = polyniaData[iNewPolynia].iSlotNumber.Value;

			dataIdentity.setupOverride(polyniaData[iNewPolynia].iPolyniaID.Flag);
			dataX.setupOverride(polyniaData[iNewPolynia].fX.Flag);
			dataY.setupOverride( polyniaData[iNewPolynia].fY.Flag);
			dataZ.setupOverride(polyniaData[iNewPolynia].fZ.Flag);
			dataOrientation.setupOverride(polyniaData[iNewPolynia].fPolyniaOrienation.Flag);
			dataSlotNumber.setupOverride(polyniaData[iNewPolynia].iSlotNumber.Flag);


//			//
//			//Display the values for the new target page.
//			//
//			dataPolyniaId.OverrideValue = m_polyniaData[iNewPolynia].iPolyniaID.Value;
//			dataPolyniaIceField.OverrideValue = m_polyniaData[iNewPolynia].iPolyniaIceField.Value;
//			dataX.OverrideValue = m_polyniaData[iNewPolynia].fX.Value;
//			dataY.OverrideValue = m_polyniaData[iNewPolynia].fY.Value;
//			dataZ.OverrideValue = m_polyniaData[iNewPolynia].fZ.Value;
//			dataPolyniaOrn.OverrideValue = m_polyniaData[iNewPolynia].fPolyniaOrienation.Value;
//
//			dataPolyniaId.setupOverride(m_polyniaData[iNewPolynia].iPolyniaID.Flag);
//			dataPolyniaIceField.setupOverride(m_polyniaData[iNewPolynia].iPolyniaIceField.Flag);
//			dataX.setupOverride(m_polyniaData[iNewPolynia].fX.Flag);
//			dataY.setupOverride(m_polyniaData[iNewPolynia].fY.Flag);
//			dataZ.setupOverride(m_polyniaData[iNewPolynia].fZ.Flag);
//			dataPolyniaOrn.setupOverride(m_polyniaData[iNewPolynia].fPolyniaOrienation.Flag);
//
		}


		public override void updateIncomingData()
		{
			if(!m_initialised)
				return;

			this.dataProcStatus.Value = m_InData.lProcStat.Value;
			this.dataModelStatus.Value = m_InData.lModelStat.Value;
			this.dataContacts.Value =  m_InData.lSonarContacts.Value;

			int iContact = Convert.ToInt32(m_comboPolynia.Text) - 1 ;

			this.dataIdentity.Value = m_InData.SonarData[iContact].identity.Value;
			this.dataX.Value =  m_InData.SonarData[iContact].x_offset.Value;
			this.dataY.Value =  m_InData.SonarData[iContact].y_offset.Value;
			this.dataZ.Value =  m_InData.SonarData[iContact].z_offset.Value;
			this.dataOrientation.Value = m_InData.SonarData[iContact].orientation.Value;
			this.dataSlotNumber.Value = m_InData.SonarData[iContact].slotNumber.Value;

		}

		public override void updateOutgoingData()
		{           
			if(!m_initialised) 
				return;

			this.ptrGui.m_OutPIGData.oPIGReturn.lProcStat.Value =  dataProcStatus.Value;
			this.ptrGui.m_OutPIGData.oPIGReturn.lModelStat.Value =  dataModelStatus.Value;
			this.ptrGui.m_OutPIGData.oPIGReturn.lSonarContacts.Value = dataContacts.Value;

			this.ptrGui.m_OutPIGData.oPIGReturn.lProcStat.Flag =  dataProcStatus.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGReturn.lModelStat.Flag =  dataModelStatus.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGReturn.lSonarContacts.Flag = dataContacts.overrideChecked;

			this.ptrGui.m_OutPIGData.oPIGReturn.SonarData[m_iPolynia].identity.Value   = polyniaData[m_iPolynia].iPolyniaID.Value;
			this.ptrGui.m_OutPIGData.oPIGReturn.SonarData[m_iPolynia].orientation.Value= polyniaData[m_iPolynia].fPolyniaOrienation.Value;
			this.ptrGui.m_OutPIGData.oPIGReturn.SonarData[m_iPolynia].slotNumber.Value = polyniaData[m_iPolynia].iSlotNumber.Value;
			this.ptrGui.m_OutPIGData.oPIGReturn.SonarData[m_iPolynia].x_offset.Value   = polyniaData[m_iPolynia].fX.Value;
			this.ptrGui.m_OutPIGData.oPIGReturn.SonarData[m_iPolynia].y_offset.Value   = polyniaData[m_iPolynia].fY.Value;
			this.ptrGui.m_OutPIGData.oPIGReturn.SonarData[m_iPolynia].z_offset.Value   = polyniaData[m_iPolynia].fZ.Value;

			this.ptrGui.m_OutPIGData.oPIGReturn.SonarData[m_iPolynia].identity.Flag   = polyniaData[m_iPolynia].iPolyniaID.Flag;
			this.ptrGui.m_OutPIGData.oPIGReturn.SonarData[m_iPolynia].orientation.Flag= polyniaData[m_iPolynia].fPolyniaOrienation.Flag;
			this.ptrGui.m_OutPIGData.oPIGReturn.SonarData[m_iPolynia].slotNumber.Flag = polyniaData[m_iPolynia].iSlotNumber.Flag;
			this.ptrGui.m_OutPIGData.oPIGReturn.SonarData[m_iPolynia].x_offset.Flag   = polyniaData[m_iPolynia].fX.Flag;
			this.ptrGui.m_OutPIGData.oPIGReturn.SonarData[m_iPolynia].y_offset.Flag   = polyniaData[m_iPolynia].fY.Flag;
			this.ptrGui.m_OutPIGData.oPIGReturn.SonarData[m_iPolynia].z_offset.Flag   = polyniaData[m_iPolynia].fZ.Flag;
		}

		public override void enableOverrides(bool bEnabled)
		{
			dataProcStatus.enableOverride(bEnabled);	
			dataModelStatus.enableOverride(bEnabled);	
			dataContacts.enableOverride(bEnabled);	
			dataIdentity.enableOverride(bEnabled);	
			dataX.enableOverride(bEnabled);	
			dataY.enableOverride(bEnabled);	
			dataZ.enableOverride(bEnabled);
			dataOrientation.enableOverride(bEnabled);
			dataSlotNumber.enableOverride(bEnabled);		  
		}

		private void polyniaChanged(object sender, EventArgs e)
		{
			//
			//The polynia values signal a change in value when the combo box index has changed. This is handled
			//by the 'polyniaNumberChanged' method.
			//
			if(! m_comboPolynia.ContainsFocus)
			{
				if(sender == dataIdentity.numeric)
				{
					polyniaData[m_iPolynia].iPolyniaID.Value = dataIdentity.Value;
				}

				if(sender == dataX.numeric)
				{
					polyniaData[m_iPolynia].fX.Value = dataX.Value;
				}

				if(sender == dataY.numeric)
				{
					polyniaData[m_iPolynia].fY.Value = dataY.Value;
				}

				if(sender == dataZ.numeric)
				{
					polyniaData[m_iPolynia].fZ.Value = dataZ.Value;
				}

				if(sender == dataOrientation.numeric)
				{
					polyniaData[m_iPolynia].fPolyniaOrienation.Value = dataOrientation.Value;
				}

				if(sender == dataSlotNumber.numeric)
				{
					polyniaData[m_iPolynia].iSlotNumber.Value = dataSlotNumber.Value;
				}

			}
		}

		private void polyniaCheckChanged(object sender, EventArgs e)
		{
			if(! m_comboPolynia.ContainsFocus)
			{

				CheckBox checkBox = (CheckBox) sender;			

				if(sender == dataIdentity.checkBox)
				{
					polyniaData[m_iPolynia].iPolyniaID.Flag = dataIdentity.overrideChecked;
					polyniaData[m_iPolynia].iPolyniaID.Value = dataIdentity.Value;
				}

				if(sender == dataX.checkBox)
				{
					polyniaData[m_iPolynia].fX.Flag = dataX.overrideChecked;
					polyniaData[m_iPolynia].fX.Value = dataX.Value;
				}

				if(sender == dataY.checkBox)
				{
					polyniaData[m_iPolynia].fY.Flag = dataY.overrideChecked;
					polyniaData[m_iPolynia].fY.Value = dataY.Value;
				}

				if(sender == dataZ.checkBox)
				{
					polyniaData[m_iPolynia].fZ.Flag = dataZ.overrideChecked;
					polyniaData[m_iPolynia].fZ.Value = dataZ.Value;
				}
				if(sender == dataOrientation.checkBox)
				{
					polyniaData[m_iPolynia].fPolyniaOrienation.Flag = dataOrientation.overrideChecked;
					polyniaData[m_iPolynia].fPolyniaOrienation.Value = dataOrientation.Value;
				}

				if(sender == dataSlotNumber.checkBox)
				{
					polyniaData[m_iPolynia].iSlotNumber.Flag = dataSlotNumber.overrideChecked;
					polyniaData[m_iPolynia].iSlotNumber.Value = dataSlotNumber.Value;
				}
			}
		}
	}
}
