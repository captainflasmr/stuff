//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiTemplatePage.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;

namespace PSCGenericBuild
{
	//-----------------------------------------------------------------------
	//The Template Page class: defines common functionality for each data Page
	//-----------------------------------------------------------------------
	public class C_guiTemplatePage : System.Windows.Forms.Form
	{
		protected C_gui.page       ePage;
		protected C_gui            ptrGui;
		protected C_gui.page       m_eType;
		protected C_guiDataItem [] m_dataItem ;

		protected bool m_initialised;

		public C_gui.page pageType
		{
			get
			{
				return m_eType;
			}
			set
			{
				m_eType = value;
			}
		}

		public C_gui  ptrGUI
		{
			get
			{
				return ptrGui;
			}
			set
			{
				ptrGui = value;
			}
		}

		public C_guiTemplatePage()
		{
			this.pageType = C_gui.page.NONE;

			m_initialised = false;
		}

		public virtual void updateIncomingData()
		{
		}

		public virtual void updateOutgoingData()
		{
		}

		public virtual void setOverride(bool bEnabled)
		{
			if(m_dataItem == null) 
				return ;

			for(int i=0; i < m_dataItem.Length; i++)
			{
				m_dataItem[i].setOverride(bEnabled);
			}
		}

		public void OverrideSelect(bool bSelect)
		{
			if(bSelect)
			{              
				if(ptrGui.numberOfOverrides == 0)
				{
					//
					//Highlight the override global button 
					//
					ptrGui.globalButtons.setOverridesSelected(true);
				}
				ptrGui.numberOfOverrides ++;
			}
			else
			{
				ptrGui.numberOfOverrides --;
			
				if(ptrGui.numberOfOverrides == 0)
				{
					//
					//Deselect the override global button.
					//
					ptrGui.globalButtons.setOverridesSelected(false);
				}
			}
		}

		public virtual void enableOverrides(bool bOnOff)
		{
			if(m_dataItem == null) 
				return;

			for(int i=0; i < m_dataItem.Length ; i++)
			{
				if(m_dataItem[i] == null)
				{
					return;
				}

				m_dataItem[i].enableOverride(bOnOff);
			}
		}

		protected override void OnActivated(EventArgs e)
		{
			MenuItem menuItem;
			//When the page is displayed, display a check beside the appropriate menu item
			if(this.pageType == C_gui.page.PIP_TARGETS)
				menuItem = this.ptrGui.mainMenu.getMenuItem(this.pageType, 0);
			else if(this.pageType == C_gui.page.PIG_TARGETS)
				menuItem = this.ptrGui.mainMenu.getMenuItem(this.pageType, 0);
			else
				menuItem = this.ptrGui.mainMenu.getMenuItem(this.pageType, 0);

			if(menuItem != null) 
				menuItem.Checked = true;

			base.OnActivated (e);
		}

		protected override void Dispose(bool disposing)
		{
			//Uncheck the appropriate menu item.
			MenuItem menuItem = this.ptrGui.mainMenu.getMenuItem(this.pageType, 0);
			if(menuItem != null) 
				menuItem.Checked = false;
			
			//Hide the page.
			this.Hide();
		}

		public void integerKeyPress(object source, KeyPressEventArgs e)
		{ 
			//ComboBox sourceObj = (ComboBox) source;

			if((e.KeyChar == (char) '0') || 
				(e.KeyChar == (char) '1') || 
				(e.KeyChar == (char) '2') || 
				(e.KeyChar == (char) '3') || 
				(e.KeyChar == (char) '4') || 
				(e.KeyChar == (char) '5') || 
				(e.KeyChar == (char) '6') || 
				(e.KeyChar == (char) '7') || 
				(e.KeyChar == (char) '8') || 
				(e.KeyChar == (char) '9') ||
				(e.KeyChar == (char)  8)) //Delete Key
			{
				//int i = Int32.Parse(sourceObj.Text);

				e.Handled = false;
			}
			else
			{
				e.Handled = true;
			}
		}



	}
}
