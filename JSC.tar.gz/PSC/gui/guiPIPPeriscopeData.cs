//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiPIPPeriscopeData.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Drawing;

namespace PSCGenericBuild
{

	//-----------------------------------------------------------------------
	//The PIP Periscope Page Class.
	//-----------------------------------------------------------------------
	public class C_guiPIPPeriscopeData : C_guiTemplatePage
	{

		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		//protected C_guiDataItem [] dataItem;
		protected string     [] strDescription;
		protected PIPPeriscopeData   m_InData;
		public PIGPeriscopeData oPIGPeriscopePacket;

		public C_guiDataItemBoolean  dataInstControl;
		public C_guiDataItemBoolean  dataMastPosition;
		public C_guiDataItemBoolean  dataTIHotControl;
		public C_guiDataItemBoolean  dataMag;
		public C_guiDataItemByte  dataPeriDrainDown;
		public C_guiDataItemByte  dataLLTVGain;
		public C_guiDataItemByte  dataTIGain;
		public C_guiDataItemFloat dataPeriRelBrg;
		public C_guiDataItemFloat dataPeriRelElev;


		//-----------------------------------------------------------------------
		//Class Properties
		//-----------------------------------------------------------------------

		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		/************************************************************************
		  FUNCTION      : C_guiPIPPeriscopeData()
		  DESCRIPTION   : The Constructor for PIP Periscope Data Page. 
		  PARAMETERS    : parentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the PIP Periscope Data Page.
		 ************************************************************************/
		public C_guiPIPPeriscopeData (C_gui parentForm)
		{
			this.ptrGui = parentForm;
			//this.ptrPSC = parentForm.psc;

			this.Text      = "PIP Data - Periscope Data";
			this.pageType  = C_gui.page.PIP_PERISCOPE;

			m_InData = this.ptrGui.m_InPIPData.oPeriscope;

			//-----------------------------------------------------
			//Declare the data items.
			//-----------------------------------------------------
			m_dataItem = new C_guiDataItem[9];

			strDescription = new String[9];          

			//-----------------------------------------------------
			//Initialise each component.
			//-----------------------------------------------------
			strDescription[0] = "Instructor Periscope Control (Off / On)";
			strDescription[1] =	"Mast Position (Down / Up)";
			strDescription[2] =	"TI Hot control (Black / White)";
			strDescription[3] =	"Magnification (Low / High)";
			strDescription[4] = "Periscope Drain-Down Time ("      + ")";
			strDescription[5] = "LLTV Gain("                       +  ")";
			strDescription[6] = "TI Gain("                         + ")";
			strDescription[7] = "Periscope Relative Bearing("      + ")";
			strDescription[8] = "Periscope Relative Elevation("    + ")";

			dataInstControl  = new C_guiDataItemBoolean( "Instructor Control",   "PIP_PERISCOPE_INSTRUCTOR_CONTROL",50,  10, this, strDescription[0]);
			dataMastPosition  = new C_guiDataItemBoolean( "Mast Position",        "PIP_PERISCOPE_MAST_POSITION",     50,  40, this, strDescription[1]);
			dataTIHotControl  = new C_guiDataItemBoolean( "TI hot Control",       "PIP_PERISCOPE_TI_CONTROL",        50,  70, this, strDescription[2]);
			dataMag  = new C_guiDataItemBoolean( "Magnification" ,       "PIP_PERISCOPE_MAGNIFICATION",     50, 100, this, strDescription[3]);
			dataPeriDrainDown  = new C_guiDataItemByte( "Draindown Time ",      "PIP_PERISCOPE_DRAINDOWN_TIME",    50, 130, this, strDescription[4]);
			dataLLTVGain  = new C_guiDataItemByte( "LLTV Gain ",           "PIP_PERISCOPE_LLTV_GAIN",         50, 160, this, strDescription[5]);
			dataTIGain  = new C_guiDataItemByte( "TI Gain ",             "PIP_PERISCOPE_TI_GAIN",           50, 190, this, strDescription[6]);
			dataPeriRelBrg  = new C_guiDataItemFloat( "Relative Bearing",     "PIP_PERISCOPE_REL_BRG",           50, 220, this, strDescription[7]);
			dataPeriRelElev  = new C_guiDataItemFloat( "Relative Elevation",   "PIP_PERISCOPE_REL_ELEV",          50, 250, this, strDescription[8]);

			string [] strOffOn      = {"Off",  "On"};
			string [] strDownUp     = {"Down", "Up"};
			string [] strBlackWhite = {"Black","White"};
			string [] strLowHigh    = {"Low",  "High"};

			dataInstControl.setListEntries(strOffOn);
			dataMastPosition.setListEntries(strDownUp);
			dataTIHotControl.setListEntries(strBlackWhite);
			dataMag.setListEntries(strLowHigh);
			dataPeriDrainDown.setDecimalPlaces(0);
			dataLLTVGain.setDecimalPlaces(0);
			dataTIGain.setDecimalPlaces(0);

			this.Controls.Add(dataInstControl);
			this.Controls.Add(dataMastPosition);
			this.Controls.Add(dataTIHotControl);
			this.Controls.Add(dataMag);
			this.Controls.Add(dataPeriDrainDown);
			this.Controls.Add(dataLLTVGain);
			this.Controls.Add(dataTIGain);
			this.Controls.Add(dataPeriRelBrg);
			this.Controls.Add(dataPeriRelElev);

			this.Size        = new Size( 700, 290);
			this.ClientSize  = new Size( 700, 290);
			this.MinimumSize = new Size( 700, 290);

			//this.ControlBox = false;

			this.MdiParent = parentForm;
			//this.WindowState = FormWindowState.Maximized;

			m_initialised = true; 
		}

		public override void updateIncomingData()
		{
			if(!m_initialised) 
				return;

			this.dataInstControl.Value =  m_InData.bInstructor.Value;
			this.dataMastPosition.Value = m_InData.bMast.Value;
			this.dataTIHotControl.Value = m_InData.bTiHotControl.Value;
			this.dataMag.Value = m_InData.bMagnification.Value;

			this.dataPeriDrainDown.Value = m_InData.bDrainDownTime.Value;
			this.dataLLTVGain.Value = m_InData.bLLTVGain.Value;
			this.dataTIGain.Value = m_InData.bTIGain.Value;
			this.dataPeriRelBrg.Value = m_InData.fRelBrg.Value;
			this.dataPeriRelElev.Value = m_InData.fElevation.Value;

		}

		public override void updateOutgoingData()
		{
			if(!m_initialised) 
				return;


			this.ptrGui.m_OutPIPData.oPeriscope.bInstructor.Value =  dataInstControl.Value;
			this.ptrGui.m_OutPIPData.oPeriscope.bMast.Value = dataMastPosition.Value;
			this.ptrGui.m_OutPIPData.oPeriscope.bTiHotControl.Value = dataTIHotControl.Value;
			this.ptrGui.m_OutPIPData.oPeriscope.bMagnification.Value = dataMag.Value;

			this.ptrGui.m_OutPIPData.oPeriscope.bDrainDownTime.Value  = dataPeriDrainDown.Value;
			this.ptrGui.m_OutPIPData.oPeriscope.bLLTVGain.Value = dataLLTVGain.Value;
			this.ptrGui.m_OutPIPData.oPeriscope.bTIGain.Value  = dataTIGain.Value;
			this.ptrGui.m_OutPIPData.oPeriscope.fRelBrg.Value  = dataPeriRelBrg.Value;
			this.ptrGui.m_OutPIPData.oPeriscope.fElevation.Value = dataPeriRelElev.Value;

			this.ptrGui.m_OutPIPData.oPeriscope.bInstructor.Flag =  dataInstControl.overrideChecked;
			this.ptrGui.m_OutPIPData.oPeriscope.bMast.Flag = dataMastPosition.overrideChecked;
			this.ptrGui.m_OutPIPData.oPeriscope.bTiHotControl.Flag = dataTIHotControl.overrideChecked;
			this.ptrGui.m_OutPIPData.oPeriscope.bMagnification.Flag = dataMag.overrideChecked;
	
			this.ptrGui.m_OutPIPData.oPeriscope.bDrainDownTime.Flag  = dataPeriDrainDown.overrideChecked;
			this.ptrGui.m_OutPIPData.oPeriscope.bLLTVGain.Flag = dataLLTVGain.overrideChecked;
			this.ptrGui.m_OutPIPData.oPeriscope.bTIGain.Flag  = dataTIGain.overrideChecked;
			this.ptrGui.m_OutPIPData.oPeriscope.fRelBrg.Flag  = dataPeriRelBrg.overrideChecked;
			this.ptrGui.m_OutPIPData.oPeriscope.fElevation.Flag = dataPeriRelElev.overrideChecked;
		}

		public override void setOverride(bool bEnabled)
		{
			if(!m_initialised) 
				return;

			dataInstControl.setOverride(bEnabled);
			dataMastPosition.setOverride(bEnabled);
			dataTIHotControl.setOverride(bEnabled);
			dataMag.setOverride(bEnabled);
			dataPeriDrainDown.setOverride(bEnabled);
			dataLLTVGain.setOverride(bEnabled);
			dataTIGain.setOverride(bEnabled);
			dataPeriRelBrg.setOverride(bEnabled);
			dataPeriRelElev.setOverride(bEnabled);
		}

		public override void enableOverrides(bool bOnOff)
		{
			dataInstControl.enableOverride(bOnOff);
			dataMastPosition.enableOverride(bOnOff);
			dataTIHotControl.enableOverride(bOnOff);
			dataMag.enableOverride(bOnOff);
			dataPeriDrainDown.enableOverride(bOnOff);
			dataLLTVGain.enableOverride(bOnOff);
			dataTIGain.enableOverride(bOnOff);
			dataPeriRelBrg.enableOverride(bOnOff);
			dataPeriRelElev.enableOverride(bOnOff);
		}
	}
}
