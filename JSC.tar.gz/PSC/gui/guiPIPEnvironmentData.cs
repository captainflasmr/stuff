//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiPIPEnvironmentData.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Drawing;

namespace PSCGenericBuild
{
	
	//-----------------------------------------------------------------------
	//The PIP Environment Data Page Class.
	//-----------------------------------------------------------------------
	public class C_guiPIPEnvironmentData : C_guiTemplatePage
	{
		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		protected String     [] strDescription;

		//-----------------------------------------------------------------------
		//Class Properties
		//-----------------------------------------------------------------------
		protected PIPEnvironmentData   m_InData;

		public C_guiDataItemBoolean  dataMoon;
		public C_guiDataItemBoolean  dataCoastLights;
		public C_guiDataItemBoolean  dataIceEdge;
		public C_guiDataItemBoolean  dataSun;
		public C_guiDataItemByte  dataWeather;
		public C_guiDataItemByte  dataCoastline;
		public C_guiDataItemByte  dataSeaState;
		public C_guiDataItemFloat dataMoonBrg;
		public C_guiDataItemFloat dataMoonElev;
		public C_guiDataItemFloat dataVisibleRange;
		public C_guiDataItemFloat dataUWVisibleRange;
		public C_guiDataItemFloat dataIRVisibleRange;
		public C_guiDataItemFloat dataWindSpeed;
		public C_guiDataItemFloat dataWindDirection;
		public C_guiDataItemFloat dataIceEdgeLat;
		public C_guiDataItemFloat dataIceEdgeLon;
		public C_guiDataItemFloat dataIceEdgeOrient;
		public C_guiDataItemFloat dataSunBrg;
		public C_guiDataItemFloat dataSunElev;


		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		/************************************************************************
		  FUNCTION      : C_guiPIPEnvironmentData()
		  DESCRIPTION   : The Constructor for Environment Data Page. 
		  PARAMETERS    : parentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the Environment Data Page.
		 ************************************************************************/
		public C_guiPIPEnvironmentData (C_gui parentForm)
		{
			this.MdiParent = parentForm;
			this.ptrGui   = parentForm;

			this.Text     = "PIP Data - Environment Data";
			this.pageType = C_gui.page.PIP_ENVIRONMENT;

            m_InData = this.ptrGui.m_InPIPData.oEnvironment;

			//-----------------------------------------------------
			//Declare the data items.
			//-----------------------------------------------------
			m_dataItem     = new C_guiDataItem[19];
			strDescription = new String[19]; 

			strDescription[ 0] = "Draw moon at stated position (On/Off)";
			strDescription[ 1] = "Enable navigation lights on coastline models(On/Off)";
			strDescription[ 2] = "Draw ice-edge and ice-floe at stated position(On/Off)";
			strDescription[ 3] = "Position sun at stated location overriding internal model (On/Off)";
			strDescription[ 4] = "General weather conditions (Clear/Cloudy/Overcast/Fog/Rain)";
			strDescription[ 5] = "Coastline identification (Open Sea/Clyde)";
			strDescription[ 6] = "Surface sea state ("           + 1       + ".." + 1      + ")";
			strDescription[ 7] = "Moon bearing ("                + 1    + ".." + 1   + ")";
			strDescription[ 8] = "Moon altitude ("               + 1   + ".." + 1  + ")";
			strDescription[ 9] = "Visible range ("               + 1  + ".."  + 1  + ")";
			strDescription[10] = "Underwater visible range ("    + 1  + ".." + 1 + ")";
			strDescription[11] = "Thermal image visible range (" + 1   + ".." + 1  + ")";
			strDescription[12] = "Wind speed ("                  + 1      + ".." + 1     + "m-per-s)";
			strDescription[13] = "Wind direction (from) ("       + 1  + ".." + 1 + ")";
			strDescription[14] = "Ice-edge pivot latitude ("     + 1    + ".." + 1   + ")";
			strDescription[15] = "Ice-edge pivot longitude ("    + 1   + ".." + 1  + ")";
			strDescription[16] = "Ice-floe orientation ("        + 1 +".." + 1 + ")";
			strDescription[17] = "Sun bearing ("                 + 1     + ".." + 1    + ")";
			strDescription[18] = "Sun altitude ("                + 1    + ".." + 1   + ")";


			//-----------------------------------------------------
			//Initialise each component.
			//-----------------------------------------------------
			dataMoon = new C_guiDataItemBoolean( "Moon"         ,        "PIP_ENVIRONMENT_REMOTE_MOON",          50,  10, this, strDescription[0]);
			dataCoastLights = new C_guiDataItemBoolean( "Coast Lights" ,        "PIP_ENVIRONMENT_COAST_LIGHTS",         50,  40, this, strDescription[1]);
			dataIceEdge = new C_guiDataItemBoolean( "Ice Edge"     ,        "PIP_ENVIRONMENT_ICE_EDGE",             50,  70, this, strDescription[2]);
			dataSun = new C_guiDataItemBoolean( "Remote Sun "  ,        "PIP_ENVIRONMENT_REMOTE_SUN",           50, 100, this, strDescription[3]);
			dataWeather = new C_guiDataItemByte( "Weather"      ,        "PIP_ENVIRONMENT_WEATHER",              50, 130, this, strDescription[4]);
			dataCoastline = new C_guiDataItemByte( "Coastline"    ,        "PIP_ENVIRONMENT_COASTLINE",            50, 160, this, strDescription[5]);
			dataSeaState = new C_guiDataItemByte( "Sea State"    ,        "PIP_ENVIRONMENT_SEA_STATE",            50, 190, this, strDescription[6]);
			dataMoonBrg = new C_guiDataItemFloat( "Moon Bearing",         "PIP_ENVIRONMENT_MOON_BEARING",         50, 220, this, strDescription[7]);
			dataMoonElev = new C_guiDataItemFloat( "Moon Altitude",        "PIP_ENVIRONMENT_MOON_ALTITUDE",        50, 250, this, strDescription[8]);
			dataVisibleRange = new C_guiDataItemFloat( "Visible Range",        "PIP_ENVIRONMENT_VISIBLE_RANGE",        50, 280, this, strDescription[9]);
			dataUWVisibleRange = new C_guiDataItemFloat( "Underwater Vis",       "PIP_ENVIRONMENT_UNDERWATER_VIS",       50, 310, this, strDescription[10]);
			dataIRVisibleRange = new C_guiDataItemFloat( "Thermal Range",        "PIP_ENVIRONMENT_THERMAL_RANGE",        50, 340, this, strDescription[11]);
			dataWindSpeed = new C_guiDataItemFloat( "Wind Speed",           "PIP_ENVIRONMENT_WIND_SPEED",           50, 370, this, strDescription[12]);
			dataWindDirection = new C_guiDataItemFloat( "Wind Direction",       "PIP_ENVIRONMENT_WIND_DIRECTION",       50, 400, this, strDescription[13]);
			dataIceEdgeLat = new C_guiDataItemFloat( "Ice Edge Lat",         "PIP_ENVIRONMENT_ICE_EDGE_LAT",         50, 430, this, strDescription[14]);
			dataIceEdgeLon = new C_guiDataItemFloat( "Ice Edge Long",        "PIP_ENVIRONMENT_ICE_EDGE_LONG",        50, 460, this, strDescription[15]);			
			dataIceEdgeOrient = new C_guiDataItemFloat( "Ice Floe Orientation", "PIP_ENVIRONMENT_ICE_EDGE_ORIENT",      50, 490, this, strDescription[16]);
			dataSunBrg = new C_guiDataItemFloat( "Sun Bearing",          "PIP_ENVIRONMENT_SUN_BEARING",          50, 520, this, strDescription[17]);
			dataSunElev = new C_guiDataItemFloat( "Sun Altitude",         "PIP_ENVIRONMENT_SUN_ALTITUDE",         50, 550, this, strDescription[18]);

			string [] strOnOff     = {"Off", "On"};
			string [] strWeather   = {"Clear", "Cloudy", "Overcast", "Fog", "Rain"};
			string [] strCoastline = {"Open Sea", "Clyde"};
			string [] strSeaState  = {"0", "1", "2", "3", "4", "5", "6"};

			dataMoon.setListEntries(strOnOff);
			dataCoastLights.setListEntries(strOnOff);
			dataIceEdge.setListEntries(strOnOff);
			dataSun.setListEntries(strOnOff);

			dataWeather.setListEntries(strWeather);
			dataCoastline.setListEntries(strCoastline);
			dataSeaState.setListEntries(strSeaState);

			this.Controls.Add(dataMoon);
			this.Controls.Add(dataCoastLights);
			this.Controls.Add(dataIceEdge);
			this.Controls.Add(dataSun);
			this.Controls.Add(dataWeather);
			this.Controls.Add(dataCoastline);
			this.Controls.Add(dataSeaState);
			this.Controls.Add(dataMoonBrg);
			this.Controls.Add(dataMoonElev);
			this.Controls.Add(dataVisibleRange);
			this.Controls.Add(dataUWVisibleRange);
			this.Controls.Add(dataIRVisibleRange);
			this.Controls.Add(dataWindSpeed);
			this.Controls.Add(dataWindDirection);
			this.Controls.Add(dataIceEdgeLat);
			this.Controls.Add(dataIceEdgeLon);
			this.Controls.Add(dataIceEdgeOrient);
			this.Controls.Add(dataSunBrg);
			this.Controls.Add(dataSunElev);

			//
			//Set the size of the form.
			//
			this.Size = new Size(860, 620);

			m_initialised = true;

		}

		public override void updateIncomingData()
		{
			if(!m_initialised)
				return;
			
			dataMoon.Value = m_InData.bMoon.Value;     
			dataCoastLights.Value = m_InData.bCoastLights.Value;
			dataIceEdge.Value = m_InData.bIceEdge.Value;    
			dataSun.Value = m_InData.bRemoteSun.Value; 
			dataWeather.Value = m_InData.bVisibility.Value;
			dataCoastline.Value = m_InData.bCoastline.Value;
			dataSeaState.Value = m_InData.bSeaState.Value;
			dataMoonBrg.Value = m_InData.fMoonBearing.Value;
			dataMoonElev.Value = m_InData.fMoonElevation.Value;
			dataVisibleRange.Value = m_InData.fVisualRange.Value;
			dataIRVisibleRange.Value = m_InData.fTIRange.Value;
			dataUWVisibleRange.Value = m_InData.fUWVisualRange.Value;
			dataWindSpeed.Value = m_InData.fWindSpeed.Value;
			dataWindDirection.Value = m_InData.fWindHeading.Value;
			dataIceEdgeLat.Value = m_InData.fIceLat.Value;
			dataIceEdgeLon.Value = m_InData.fIceLong.Value;
			dataIceEdgeOrient.Value = m_InData.fIceOrientation.Value;
			dataSunBrg.Value = m_InData.fSunBearing.Value;
			dataSunElev.Value = m_InData.fSunElevation.Value;

		}



		public override void updateOutgoingData()
		{
			if(!m_initialised) return;

			this.ptrGui.m_OutPIPData.oEnvironment.bMoon.Value  = dataMoon.Value;
			this.ptrGui.m_OutPIPData.oEnvironment.bCoastLights.Value = dataCoastLights.Value;
			this.ptrGui.m_OutPIPData.oEnvironment.bIceEdge.Value  = dataIceEdge.Value;
			this.ptrGui.m_OutPIPData.oEnvironment.bRemoteSun.Value  = dataSun.Value;

			this.ptrGui.m_OutPIPData.oEnvironment.bVisibility.Value  = dataWeather.Value;
			this.ptrGui.m_OutPIPData.oEnvironment.bCoastline.Value = dataCoastline.Value;
			this.ptrGui.m_OutPIPData.oEnvironment.bSeaState.Value  = dataSeaState.Value;
			this.ptrGui.m_OutPIPData.oEnvironment.fMoonBearing.Value  = dataMoonBrg.Value;
			this.ptrGui.m_OutPIPData.oEnvironment.fMoonElevation.Value = dataMoonElev.Value;

			this.ptrGui.m_OutPIPData.oEnvironment.fVisualRange.Value  = dataVisibleRange.Value;
			this.ptrGui.m_OutPIPData.oEnvironment.fUWVisualRange.Value = dataUWVisibleRange.Value;
			this.ptrGui.m_OutPIPData.oEnvironment.fTIRange.Value  = dataIRVisibleRange.Value;
			this.ptrGui.m_OutPIPData.oEnvironment.fWindSpeed.Value  = dataWindSpeed.Value;
			this.ptrGui.m_OutPIPData.oEnvironment.fWindHeading.Value = dataWindDirection.Value;

			this.ptrGui.m_OutPIPData.oEnvironment.fIceLat.Value  = dataIceEdgeLat.Value;
			this.ptrGui.m_OutPIPData.oEnvironment.fIceLong.Value = dataIceEdgeLon.Value;
			this.ptrGui.m_OutPIPData.oEnvironment.fIceOrientation.Value  = dataIceEdgeOrient.Value;
			this.ptrGui.m_OutPIPData.oEnvironment.fSunBearing.Value  = dataSunBrg.Value;
			this.ptrGui.m_OutPIPData.oEnvironment.fSunElevation.Value = dataSunElev.Value;

			this.ptrGui.m_OutPIPData.oEnvironment.bMoon.Flag = dataMoon.overrideChecked;
			this.ptrGui.m_OutPIPData.oEnvironment.bCoastLights.Flag = dataCoastLights.overrideChecked;
			this.ptrGui.m_OutPIPData.oEnvironment.bIceEdge.Flag = dataIceEdge.overrideChecked;
			this.ptrGui.m_OutPIPData.oEnvironment.bRemoteSun.Flag = dataSun.overrideChecked;

			this.ptrGui.m_OutPIPData.oEnvironment.bVisibility.Flag  = dataWeather.overrideChecked;
			this.ptrGui.m_OutPIPData.oEnvironment.bCoastline.Flag = dataCoastline.overrideChecked;
			this.ptrGui.m_OutPIPData.oEnvironment.bSeaState.Flag  = dataSeaState.overrideChecked;
			this.ptrGui.m_OutPIPData.oEnvironment.fMoonBearing.Flag  = dataMoonBrg.overrideChecked;
			this.ptrGui.m_OutPIPData.oEnvironment.fMoonElevation.Flag = dataMoonElev.overrideChecked;

			this.ptrGui.m_OutPIPData.oEnvironment.fVisualRange.Flag  = dataVisibleRange.overrideChecked;
			this.ptrGui.m_OutPIPData.oEnvironment.fUWVisualRange.Flag = dataUWVisibleRange.overrideChecked;
			this.ptrGui.m_OutPIPData.oEnvironment.fTIRange.Flag  = dataIRVisibleRange.overrideChecked;
			this.ptrGui.m_OutPIPData.oEnvironment.fWindSpeed.Flag  = dataWindSpeed.overrideChecked;
			this.ptrGui.m_OutPIPData.oEnvironment.fWindHeading.Flag = dataWindDirection.overrideChecked;

			this.ptrGui.m_OutPIPData.oEnvironment.fIceLat.Flag  = dataIceEdgeLat.overrideChecked;
			this.ptrGui.m_OutPIPData.oEnvironment.fIceLong.Flag = dataIceEdgeLon.overrideChecked;
			this.ptrGui.m_OutPIPData.oEnvironment.fIceOrientation.Flag  = dataIceEdgeOrient.overrideChecked;
			this.ptrGui.m_OutPIPData.oEnvironment.fSunBearing.Flag  = dataSunBrg.overrideChecked;
			this.ptrGui.m_OutPIPData.oEnvironment.fSunElevation.Flag = dataSunElev.overrideChecked;
		}

		public override void enableOverrides(bool bOnOff)
		{
			dataMoon.enableOverride(bOnOff);
			dataCoastLights.enableOverride(bOnOff);
			dataIceEdge.enableOverride(bOnOff);
			dataSun.enableOverride(bOnOff);
			dataWeather.enableOverride(bOnOff);
			dataCoastline.enableOverride(bOnOff);
			dataSeaState.enableOverride(bOnOff);
			dataMoonBrg.enableOverride(bOnOff);
			dataMoonElev.enableOverride(bOnOff);
			dataVisibleRange.enableOverride(bOnOff);
			dataUWVisibleRange.enableOverride(bOnOff);
			dataIRVisibleRange.enableOverride(bOnOff);
			dataWindSpeed.enableOverride(bOnOff);
			dataWindDirection.enableOverride(bOnOff);
			dataIceEdgeLat.enableOverride(bOnOff);
			dataIceEdgeLon.enableOverride(bOnOff);
			dataIceEdgeOrient.enableOverride(bOnOff);
			dataSunBrg.enableOverride(bOnOff);
			dataSunElev.enableOverride(bOnOff);
		}
	}
}
