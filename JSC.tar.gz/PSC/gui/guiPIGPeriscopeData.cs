//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiPIGPeriscopeData.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Drawing;

namespace PSCGenericBuild
{
	
	//-----------------------------------------------------------------------
	//The Periscope Data Page Class.
	//-----------------------------------------------------------------------
	public class C_guiPIGPeriscopeData : C_guiTemplatePage
	{

		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		//protected C_guiDataItem [] dataItem;
		protected string     [] strDescription;
		public PIGPeriscopeData   m_InData;

		public PIGPeriscopeData oPIGPeriscopePacket;

		public C_guiDataItemByte  dataType;	
		public C_guiDataItemByte  dataMag;	
		public C_guiDataItemByte  dataSensorGain;	
		public C_guiDataItemByte  dataSensorContrast;	
		public C_guiDataItemByte  dataGratInt;	
		public C_guiDataItemByte  dataPeriDrainDown;	
		public C_guiDataItemFloat dataPeriRelBrg;	
		public C_guiDataItemFloat dataPeriElev;	
		public C_guiDataItemFloat dataStadElev;	


		//-----------------------------------------------------------------------
		//Class Properties
		//-----------------------------------------------------------------------

		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		/************************************************************************
		  FUNCTION      : C_guiPIGPeriscopeData()
		  DESCRIPTION   : The Constructor for Periscope Data Page. 
		  PARAMETERS    : parentForm : the mdi (main) form.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Initialises the Periscope Data Page.
		 ************************************************************************/
		public C_guiPIGPeriscopeData (C_gui parentForm)
		{
			this.ptrGui    = parentForm;
			//this.ptrPSC    = parentForm.psc;

			this.Text      = "PIG Data - Periscope Data";
			this.pageType  = C_gui.page.PIG_PERISCOPE;

            m_InData  = this.ptrGui.m_InPIGData.oPIGPeriscope;

			//-----------------------------------------------------
			//Declare the data items.
			//-----------------------------------------------------
			m_dataItem = new C_guiDataItem[9];

			strDescription = new String[9];          

			//-----------------------------------------------------
			//Initialise each component.
			//-----------------------------------------------------

			strDescription[0] = "Type of sensor at sight (Optical/WHIR/BHIR/LLTV)";
			strDescription[1] =	"Magnification level ()";
			strDescription[2] = "Sensor gain ("                    + " %)";
			strDescription[3] = "Sensor contrast ("                + " %)";
			strDescription[4] = "Graticule intensity ("            +  " %)";
			strDescription[5] = "Periscope drain-down time ("      +  ")";
			strDescription[6] = "Periscope relative to bearing ("  +  ")";
			strDescription[7] = "Periscope elevation ("            +  ")";
			strDescription[8] = "Stadiameter elevation ("          +  ")";

			dataType           = new C_guiDataItemByte( "Sensor Type",          "PIG_PERISCOPE_SENSOR_TYPE",     50,  10, this, strDescription[0]);
			dataMag            = new C_guiDataItemByte( "Magnification",        "PIG_PERISCOPE_MAGNIFICATION",   50,  50, this, strDescription[1]);
			dataSensorGain     = new C_guiDataItemByte( "Sensor Gain",          "PIG_PERISCOPE_SENSOR_GAIN",     50,  90, this, strDescription[2]);
			dataSensorContrast = new C_guiDataItemByte( "Sensor Contrast" ,     "PIG_PERISCOPE_SENSOR_CONTRAST", 50, 130, this, strDescription[3]);
			dataGratInt        = new C_guiDataItemByte( "Graticule Intensity",  "PIG_PERISCOPE_GRAT_INTENSITY",  50, 170, this, strDescription[4]);
			dataPeriDrainDown  = new C_guiDataItemByte( "Draindown Time ",      "PIG_PERISCOPE_DRAINDOWN_TIME",  50, 210, this, strDescription[5]);
			dataPeriRelBrg     = new C_guiDataItemFloat( "Relative Bearing",     "PIG_PERISCOPE_REL_BRG",         50, 250, this, strDescription[6]);
			dataPeriElev       = new C_guiDataItemFloat( "Elevation",            "PIG_PERISCOPE_REL_ELEV",        50, 290, this, strDescription[7]);
			dataStadElev       = new C_guiDataItemFloat( "Stadiameter Elev",     "PIG_PERISCOPE_STADIAMETER_ELEV",50, 330, this, strDescription[8]);

			string [] strSensorType = {"Optical", "WHIR", "BHIR", "LLTV"};

			dataType.setListEntries(strSensorType);

			dataStadElev.setDecimalPlaces(2);

			this.Controls.Add(dataType);
			this.Controls.Add(dataMag);
			this.Controls.Add(dataSensorGain);
			this.Controls.Add(dataSensorContrast);
			this.Controls.Add(dataGratInt);
			this.Controls.Add(dataPeriDrainDown);
			this.Controls.Add(dataPeriRelBrg);
			this.Controls.Add(dataPeriElev);
			this.Controls.Add(dataStadElev);

			this.Size        = new Size( 700, 360);
			this.ClientSize  = new Size( 700, 360);
			this.MinimumSize = new Size( 700, 360);


			//this.ControlBox = false;

			this.MdiParent = parentForm;
			//this.WindowState = FormWindowState.Maximized;

			m_initialised = true;

		}

		public override void updateIncomingData()
		{
			this.dataType.Value = m_InData.bSensorType.Value;
			this.dataMag.Value = m_InData.bMagnification.Value;
			this.dataSensorGain.Value = m_InData.bSensorGain.Value;
			this.dataSensorContrast.Value = m_InData.bSensorContrast.Value;
			this.dataGratInt.Value = m_InData.bGraticuleInt.Value;
			this.dataPeriDrainDown.Value = m_InData.bDraindownTime.Value;
			this.dataPeriRelBrg.Value = m_InData.fRelativeBearing.Value;
			this.dataPeriElev.Value = m_InData.fElevation.Value;
			this.dataStadElev.Value = m_InData.fStadElev.Value;

		}

		public override void updateOutgoingData()
		{
            this.ptrGui.m_OutPIGData.oPIGPeriscope.bSensorType.Value      = dataType.Value;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.bMagnification.Value   = dataMag.Value;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.bSensorGain.Value      = dataSensorGain.Value;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.bSensorContrast.Value  = dataSensorContrast.Value;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.bGraticuleInt.Value    = dataGratInt.Value;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.bDraindownTime.Value   = dataPeriDrainDown.Value;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.fRelativeBearing.Value = dataPeriRelBrg.Value;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.fElevation.Value       = dataPeriElev.Value;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.fStadElev.Value        = dataStadElev.Value;

			this.ptrGui.m_OutPIGData.oPIGPeriscope.bSensorType.Flag      = dataType.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.bMagnification.Flag   = dataMag.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.bSensorGain.Flag      = dataSensorGain.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.bSensorContrast.Flag  = dataSensorContrast.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.bGraticuleInt.Flag    = dataGratInt.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.bDraindownTime.Flag   = dataPeriDrainDown.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.fRelativeBearing.Flag = dataPeriRelBrg.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.fElevation.Flag       = dataPeriElev.overrideChecked;
			this.ptrGui.m_OutPIGData.oPIGPeriscope.fStadElev.Flag        = dataStadElev.overrideChecked;

			//this.ptrMain.ptrNetwork.send();
		}

		public override void setOverride(bool bEnabled)
		{
			if(!m_initialised) 
				return;

			dataType.setOverride(bEnabled);
			dataMag.setOverride(bEnabled);
			dataSensorGain.setOverride(bEnabled);
			dataSensorContrast.setOverride(bEnabled);
			dataGratInt.setOverride(bEnabled);
			dataPeriDrainDown.setOverride(bEnabled);
			dataPeriRelBrg.setOverride(bEnabled);
			dataPeriElev.setOverride(bEnabled);
			dataStadElev.setOverride(bEnabled);
		}

	}
}
