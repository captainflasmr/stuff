//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiNetworkStatus.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;
using System.Drawing;
using System.Threading;

namespace PSCGenericBuild
{
	//-----------------------------------------------------------------------
	//The Network Status Data Page Class.
	//-----------------------------------------------------------------------
	public class C_guiNetworkStatus : C_guiTemplatePage
	{
		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		protected Button     m_NetworkMonitoring;
		protected Pen        m_blackPen;
		protected Pen        m_blackDashedPen;
		protected SolidBrush m_greyBrush;
		protected SolidBrush m_blackBrush;
		protected SolidBrush m_defaultBrush;
		protected Font       m_font;

		protected Button          m_ClearErrorLog;
		protected ColumnHeader [] m_columnHeader;
		protected ListView        m_ErrorLog;
		protected ErrorLogData    m_errorLog;
		protected ErrorLogData    m_dataStoreErrorLog;

		protected C_NetworkStatusText PSC_PIP_text;
		protected C_NetworkStatusText PSC_PIG_text;
		protected C_NetworkStatusText PIP_PSC_text;
		protected C_NetworkStatusText PIG_PSC_text;
		public static Label m_BH_text;

		public const int m_nBoxWidth  = 120;
		public const int m_nBoxHeight = 150;

		public bool m_bNetworkMonitoring; //Are we currently monitoring the network.

		protected bool mouseDown;
		protected int m_ioStatus;

		public enum E_direction
		{
			LEFT,
			RIGHT
		};


		//-----------------------------------------------------------------------
		//Class Methods
		//-----------------------------------------------------------------------

		//public C_guiNetworkStatus(PSC parentForm)
		public C_guiNetworkStatus(C_gui parentForm)
		{
			this.ptrGui = parentForm;
			//this.ptrPSC = parentForm.psc;

			this.Text      = "Network Status";
			this.MdiParent = parentForm;
			this.Size      = new Size(1100, 510);
			this.pageType  = C_gui.page.NETWORK_STATUS;
			//
			//Create the 'Network Monitoring' Button.
			//
			m_NetworkMonitoring = new Button();
			m_NetworkMonitoring.Location  = new Point( 20, 20);
			m_NetworkMonitoring.Width     = 90;
			m_NetworkMonitoring.Height    = 35;
			m_NetworkMonitoring.Click    += new EventHandler(networkMonitoringHandler);
			m_NetworkMonitoring.Text      = "Network\nMonitoring";
			Controls.Add(m_NetworkMonitoring);

			// BH  -- /////////////////////////////////////////////////////
			m_BH_text = new Label();
			m_BH_text.Location = new Point(10, 440);
			m_BH_text.Text = "Bob was here";
			m_BH_text.Height = 40;
			m_BH_text.Width = 700;
			m_BH_text.Visible = true;
			//BH_text.BringToFront = true;
			m_BH_text.BackColor = Color.AliceBlue;
			Controls.Add(m_BH_text);
			////////////////////////////////////////////////////////////   BH

			//
			//Create the 'Clear Error Log' button
			//
			m_ClearErrorLog          = new Button();
			m_ClearErrorLog.Location = new Point( 720, 20);
			m_ClearErrorLog.Width    = 90;
			m_ClearErrorLog.Height   = 35;
			m_ClearErrorLog.Text     = "Clear Error\nLog";
			m_ClearErrorLog.Enabled  = false;
			m_ClearErrorLog.Click   +=new EventHandler(ClearErrorLogHandler);
			this.Controls.Add(m_ClearErrorLog);

			//
			//Create the Error Log list area.
			//
			m_columnHeader = new ColumnHeader[3];
			for(int i = 0; i < 3; i++)
			{
				m_columnHeader[i] = new ColumnHeader();
			}

			m_columnHeader[0].Text = "Time of Error";
			m_columnHeader[1].Text = "Error Type";
			m_columnHeader[2].Text = "Error Source";

			m_columnHeader[0].Width = 118;
			m_columnHeader[1].Width = 119;
			m_columnHeader[2].Width = 119;

			m_ErrorLog               = new ListView();
			m_ErrorLog.Location      = new Point(720, 100);
			m_ErrorLog.Size          = new Size (360, 360);
			m_ErrorLog.View          = View.Details;
			m_ErrorLog.MultiSelect   = false;
			m_ErrorLog.FullRowSelect = true;
			//m_ErrorLog.Enabled       = false;
			m_ErrorLog.Columns.AddRange(m_columnHeader);
//            m_ErrorLog.MouseUp += new MouseEventHandler(m_ErrorLog_MouseUp);
//			m_ErrorLog.MouseUp += new MouseEventHandler(m_ErrorLog_MouseDown);
			Controls.Add(m_ErrorLog);


			m_bNetworkMonitoring = true; //By default we are not monitoring the network.

			//
			//Create the Pens for drawing the lines on the form.
			//
			m_blackPen     = new Pen(Color.Black);
			m_blackBrush   = new SolidBrush(Color.Black);
			m_greyBrush    = new SolidBrush(Color.LightGray);
			m_defaultBrush = new SolidBrush(this.BackColor);
			m_font         = new Font("Arial", 12);

			m_blackDashedPen = new Pen(Color.Black);
			m_blackDashedPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;

			//
			//Create the network status text.
			//
			PSC_PIP_text = new C_NetworkStatusText(170, 230, 90, 50);
			PSC_PIG_text = new C_NetworkStatusText(420,  80, 90, 50);
			PIP_PSC_text = new C_NetworkStatusText(170,  80, 90, 50);
			PIG_PSC_text = new C_NetworkStatusText(420, 230, 90, 50);

			//
			//Add the labels to the form.
			//
			Controls.Add(PSC_PIP_text.label);
			Controls.Add(PSC_PIG_text.label);
			Controls.Add(PIP_PSC_text.label);
			Controls.Add(PIG_PSC_text.label);
			//
			//Error Log data. Create a local copy and point to the data from the data store.
			//
			m_errorLog = new ErrorLogData();
			m_dataStoreErrorLog = ptrGui.m_ErrorLog;

			m_ioStatus = -1;

			//
			//Hide the labels if we are not in network monitoring mode.
			//
			refreshNetworkStatusText();
		}

		public static string txtv
		{
			get {return  m_BH_text.Text;}
			set{m_BH_text.Text = value;}
		}

		protected override void OnCreateControl()
		{
			base.OnCreateControl ();
		}


		/************************************************************************
		  FUNCTION      : onPaint()
		  DESCRIPTION   : By overriding this method graphics can be drawn on the form.
		  PARAMETERS    : PaintEventArgs eventArgs: default arguments.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : As read.
		 ************************************************************************/
		protected override void OnPaint (PaintEventArgs eventArgs)
		{
			Graphics g = eventArgs.Graphics;

			//
			//Set the window to be double buffered.
			SetStyle (ControlStyles.UserPaint, true);
			SetStyle (ControlStyles.AllPaintingInWmPaint, true);
			SetStyle (ControlStyles.DoubleBuffer, true);

			//
			//Draw the boxes on the window.
			//
			g.FillRectangle(m_greyBrush,20, 100,  m_nBoxWidth, m_nBoxHeight);
			g.DrawRectangle(m_blackPen, 20, 100,  m_nBoxWidth, m_nBoxHeight);

			g.FillRectangle(m_greyBrush,270, 100, m_nBoxWidth, m_nBoxHeight);
			g.DrawRectangle(m_blackPen, 270, 100, m_nBoxWidth, m_nBoxHeight);

			g.FillRectangle(m_greyBrush,530, 100, m_nBoxWidth, m_nBoxHeight);
			g.DrawRectangle(m_blackPen, 530, 100, m_nBoxWidth, m_nBoxHeight);

			g.FillRectangle(m_greyBrush,270, 380, m_nBoxWidth, 50);
			g.DrawRectangle(m_blackPen, 270, 380, m_nBoxWidth, 50);

			g.DrawString("PIP", m_font, m_blackBrush,  65, 160);
			g.DrawString("PSC", m_font, m_blackBrush, 310, 160);
			g.DrawString("PIG", m_font, m_blackBrush, 570, 160);
			g.DrawString("IO",  m_font, m_blackBrush, 320, 400);


			//
			//Draw the arrowed lines (if currently monitoring the network)
			//
			if(	m_bNetworkMonitoring )
			{

				if(ptrGui.IOEmulation)
				{
					g.DrawLine (m_blackDashedPen, 330, 250, 330, 380);
					g.FillRectangle( m_defaultBrush, 300, 300, 65, 20);
					g.DrawString("Emulated", m_font, m_blackBrush,  295, 300);
				}
				else
				{
					 string strStatus = "Emulated";

					// switch(ptrGui.m_InIOData.m_status)
					// {
					// 	case IOComms.IO_EMULATION: strStatus = "Emulated";
					// 		    break;
					// 	case IOComms.IO_UNKNOWN: strStatus = "Unknown";
					// 		break;
					// 	case IOComms.IO_OPERATIONAL: strStatus = "Operational";
					// 		break;
					// 	case IOComms.IO_OVERRIDE: strStatus = "Override";
					// 		break;
					// 	case IOComms.IO_FAULT: strStatus = "   Fault   ";
					// 		break;

					// 	default: strStatus = "Error (" + ptrGui.m_InIOData.m_status.ToString() + ")";
					// 		     break;
					// }

					g.DrawLine (m_blackPen, 330, 250, 330, 380);
					g.FillRectangle( m_defaultBrush, 300, 300, 65, 20);
					g.DrawString(strStatus, m_font, m_blackBrush,  295, 300);
				}

				if(ptrGui.PIPEmulation)
				{
					g.DrawLine (m_blackDashedPen, 140, 170, 270, 170);
					g.DrawString("emulated", m_font, m_blackBrush,  170, 145);
				}
				else
				{
					drawArrow(140, 130, 270, 130, 10, 10, g);
					drawArrow(270, 210, 141, 210, 10, 10, g);
				}

				if(ptrGui.PIGEmulation)
				{
					g.DrawLine (m_blackDashedPen, 390, 170, 530, 170);
					g.DrawString("emulated", m_font, m_blackBrush,  420, 145);
				}
				else
				{
					drawArrow(390, 130, 530, 130, 10, 10, g);
					drawArrow(530, 210, 391, 210, 10, 10, g);
				}


			}
		}

		protected void drawArrow(int x1, int y1, int x2, int y2, int iArrowWidth, int iArrowHeight, Graphics g)
		{
			E_direction direction;
			g.DrawLine (m_blackPen, x1, y1, x2, y2);

			if(x1 < x2)
			{
				direction = E_direction.RIGHT;
				drawArrowHead(x2 - iArrowWidth, y2, iArrowWidth, iArrowHeight, direction, g);
			}
			else
			{
				direction = E_direction.LEFT;
				drawArrowHead(x2 + iArrowWidth, y2, iArrowWidth, iArrowHeight, direction, g);
			}
		}

		protected void drawArrowHead(int x, int y, int width, int height, E_direction direction, Graphics g)
		{
			Point [] arrowHead;
			arrowHead = new Point[3];

			arrowHead[0] = new Point(x, y - height);
			if(direction == E_direction.RIGHT)
				arrowHead[1] = new Point(x + width, y);
			else
				arrowHead[1] = new Point(x - width, y);
			arrowHead[2] = new Point(x, y + height);

			g.FillPolygon(m_blackBrush, arrowHead);
		}

		private void networkMonitoringHandler(object sender, EventArgs e)
		{
			Button pressed = (Button)sender;
			if(pressed.BackColor == Color.Red)
			{
				pressed.BackColor    = Color.Empty;
				m_bNetworkMonitoring = false;

				m_ClearErrorLog.Enabled = false;
				//m_ErrorLog.Enabled      = false;

				//
				//Disable the Main Menu and Global Buttons.
				//
				ptrGui.mainMenu.enableGuiMenu(false);
				ptrGui.globalButtons.enableGlobalButtons(false);

				//Close any open pages
				ptrGui.closeOpenPages();

			}
			else
			{
				pressed.BackColor       = Color.Red;
				m_bNetworkMonitoring    = true;
				m_ClearErrorLog.Enabled = true;

				//
				//Enable the Main Menu and Global Buttons.
				//
				ptrGui.mainMenu.enableGuiMenu(true);
				ptrGui.globalButtons.enableGlobalButtons(true);

			}

			//Hide/Show the network status text.
			//refreshNetworkStatusText();

			//Repaint the form.
			this.Refresh();
		}

		private void refreshNetworkStatusText()
		{
			if(m_bNetworkMonitoring)
			{
				if(!ptrGui.PIPEmulation)
				{
					//PSC_PIP_text.label.Visible = true;
                    PSC_PIP_text.setLabelVisibility(true);
                    //PIP_PSC_text.label.Visible = true;
                    PIP_PSC_text.setLabelVisibility(true);
				}
				else
				{
                    //PSC_PIP_text.label.Visible = true;
                    PSC_PIP_text.setLabelVisibility(true);
                    //PIP_PSC_text.label.Visible = true;
                    PIP_PSC_text.setLabelVisibility(true);
				}

				if(!ptrGui.PIGEmulation)
                {
                    //PSC_PIG_text.label.Visible = true;
                    PSC_PIG_text.setLabelVisibility(true);
                    //PIG_PSC_text.label.Visible = true;
                    PIG_PSC_text.setLabelVisibility(true);
				}
				else
				{
                    //PSC_PIG_text.label.Visible = true;
                    PSC_PIG_text.setLabelVisibility(true);
                    //PIG_PSC_text.label.Visible = true;
                    PIG_PSC_text.setLabelVisibility(true);
				}
			}
			else
			{
                //PSC_PIP_text.label.Visible = true;
                PSC_PIP_text.setLabelVisibility(true);
                //PSC_PIG_text.label.Visible = true;
                PSC_PIG_text.setLabelVisibility(true);
                //PIP_PSC_text.label.Visible = true;
                PIP_PSC_text.setLabelVisibility(true);
                //PIG_PSC_text.label.Visible = true;
                PIG_PSC_text.setLabelVisibility(true);
			}
		}

		public void update()
		{
			//
			//Update the NetworkStatus text
			//
			updateNetworkText();

			//
			//Update the contents of the error log.
			//
			updateErrorLog();

			//
			//Update the ioStatus.
			//
			//updateIOStatus();
		}

		public void updateIOStatus()
		{
			if(m_ioStatus != ptrGui.m_InIOData.m_status)
			{
				//Repaint the form.
				this.Refresh();

				m_ioStatus = ptrGui.m_InIOData.m_status;
			}
		}

		public void updateNetworkText()
		{
			//
			//Update the Network Status Text from the network data.
			//
			// PSC_PIP_text.updateData(this.ptrGui.m_OutPIPData.oNetworkStatus);
			// PSC_PIG_text.updateData(this.ptrGui.m_OutPIGData.oNetworkStatus);
			// PIP_PSC_text.updateData(this.ptrGui.m_InPIPData.oNetworkStatus);
			// PIG_PSC_text.updateData(this.ptrGui.m_InPIGData.oNetworkStatus);
		}

		public void updateErrorLog()
		{
			//
			//Check to see if an error log clear has been signalled.
			//
			if(!m_errorLog.m_ErrorLogClear && m_dataStoreErrorLog.m_ErrorLogClear)
			{
				//
				//Clear the error log.
				//
				ClearErrorLog();

				m_errorLog.m_ErrorLogClear = true;
			}

			//
			//Update the Contents of the error log (when network monitoring).
			//
			if(m_bNetworkMonitoring)
			{
				//
				//If the data for the local error log index does not match the values stored in the data store
				//The error log has to be updated.
				//
				if((m_errorLog.m_ErrorLogIndex != m_dataStoreErrorLog.m_ErrorLogIndex) ||
					(m_errorLog.m_ErrorLog[m_errorLog.m_ErrorLogIndex].m_ErrorTime != m_dataStoreErrorLog.m_ErrorLog[m_dataStoreErrorLog.m_ErrorLogIndex].m_ErrorTime))
				{
					//
					//Where the local index is < the value from the data store, simply add the missing entries
					//to the log.
					//
					if(m_errorLog.m_ErrorLogIndex < m_dataStoreErrorLog.m_ErrorLogIndex)
					{
						for(int i = m_errorLog.m_ErrorLogIndex; i < m_dataStoreErrorLog.m_ErrorLogIndex; i++)
						{
							LogError(m_dataStoreErrorLog.m_ErrorLog[i]);
						}
					}
					else
					{
						//
						//There are 50 values stored in the buffer and the index wraps around the value 49.
						//Consider this example, the local index is '48', but the data store index is '2'.
						//In this instance the entries for {48,49,0,1,2} need to be entered into the log.
						//
						int iIndex = m_errorLog.m_ErrorLogIndex;
						while(iIndex > m_dataStoreErrorLog.m_ErrorLogIndex)
						{
							LogError(m_dataStoreErrorLog.m_ErrorLog[iIndex]);


							if(iIndex == SIMControl.SIM_ERRORLOG_SIZE - 1)
							{
								iIndex = 0;
							}
						}
						for(int i = iIndex; i < m_dataStoreErrorLog.m_ErrorLogIndex; i++)
						{
							LogError(m_dataStoreErrorLog.m_ErrorLog[i]);
						}
					}
					m_errorLog.m_ErrorLogIndex = m_dataStoreErrorLog.m_ErrorLogIndex;
				}
			}
			//
			//When not data logging the local index is updated so that the old messages which where
			//not captured are not entered into the log at a later date.
			//
			else
				m_errorLog.m_ErrorLogIndex = m_dataStoreErrorLog.m_ErrorLogIndex;

		}

        delegate void RefreshCallback();

		public override void Refresh()
		{
            if (this.InvokeRequired) {
                RefreshCallback d = new RefreshCallback(Refresh);
                this.Invoke(d);
            }
            else
            {
                refreshNetworkStatusText();
            }
			base.Refresh ();
		}

		protected void ClearErrorLogHandler(object sender, EventArgs e)
		{
			ClearErrorLog();
		}

		protected void ClearErrorLog()
		{
			//
			//Clear the error log entries from the list.
			//
			m_ErrorLog.Items.Clear();

			//
			//Reset the values stored in the error log.
			//
			for(int i=0 ; i < SIMControl.SIM_ERRORLOG_SIZE; i++)
			{
				m_errorLog.m_ErrorLog[i].m_ErrorTime = "";
				m_errorLog.m_ErrorLog[i].m_ErrorSource = "";
				m_errorLog.m_ErrorLog[i].m_ErrorType = "";
			}
		}

        delegate void LogErrorCallback(ErrorLogMessage errorLogMessage);

		protected void LogError(ErrorLogMessage errorLogMessage)
		{
            if (this.m_ErrorLog.InvokeRequired) {
                LogErrorCallback d = new LogErrorCallback(LogError);
                this.Invoke(d, new Object[] { errorLogMessage });
            }
            else
            {
                //Create the list view item.
                ListViewItem errorLogItem = new ListViewItem(errorLogMessage.m_ErrorTime);

                //Add the message to the log.
                ListViewItem.ListViewSubItem item1 = new ListViewItem.ListViewSubItem(errorLogItem, errorLogMessage.m_ErrorType);
                ListViewItem.ListViewSubItem item2 = new ListViewItem.ListViewSubItem(errorLogItem, errorLogMessage.m_ErrorSource);

                errorLogItem.SubItems.Add(item1);
                errorLogItem.SubItems.Add(item2);

                //			if(!mouseDown)
                //			{
                //m_ErrorLog.BeginUpdate();
                //Maintain a fixed buffer size of error log items.

                if (m_ErrorLog.Items.Count > SIMControl.SIM_ERRORLOG_SIZE)
                    if (m_ErrorLog.Items[SIMControl.SIM_ERRORLOG_SIZE] != null)
                    {
                        m_ErrorLog.Items.RemoveAt(SIMControl.SIM_ERRORLOG_SIZE);
                    }
                    else
                    {
                        Console.WriteLine("Error Index Already Null!");
                    }

                m_ErrorLog.Items.Insert(0, errorLogItem);
            }
				//m_ErrorLog.EndUpdate();
//			}


		}




		private void m_ErrorLog_MouseUp(object sender, MouseEventArgs e)
		{
			mouseDown = false;
			m_ErrorLog.Refresh();
		}

		private void InitializeComponent()
		{
			//
			// C_guiNetworkStatus
			//
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Name = "C_guiNetworkStatus";

		}

		private void m_ErrorLog_MouseDown(object sender, MouseEventArgs e)
		{
			mouseDown = true;
		}

	}

	//
	//Network Status Text class.
	//
	public class C_NetworkStatusText
	{
		protected int   m_nMessageCount;
		protected float m_fUpdateFreq;
		protected int   m_nByteCount;
		protected Label m_label;

		public C_NetworkStatusText(int x, int y, int iWidth, int iHeight)
		{
			m_nMessageCount = 0;
			m_fUpdateFreq   = 0.0f;
			m_nByteCount    = 0;

			//
			//Create the text label.
			//
			m_label          = new Label();
            m_label.Location = new Point(x, y);
            //m_label.Text     = getNetworkStatusText();
            setLabelText(getNetworkStatusText());
			m_label.Height   = iHeight;
			m_label.Width    = iWidth;

		}

		public void updateData(NetworkStatusData messageData)
		{
			//Update the network status data..
			m_nMessageCount = messageData.m_MessageCount;
			m_fUpdateFreq   = messageData.m_AverageTime;
			m_nByteCount    = messageData.m_Bytes;

			//m_label.Text    = getNetworkStatusText();
            setLabelText(getNetworkStatusText());
		}

		public string getNetworkStatusText()
		{
			string strNetworkStatus;

			strNetworkStatus = String.Format("message {0}\n{1}ms\n{2} bytes", m_nMessageCount, m_fUpdateFreq, m_nByteCount);

			return strNetworkStatus;
		}

		public Label label
		{
			get
			{
				return m_label;
			}
		}

        delegate void setLabelTextCallback(string text);

        public void setLabelText(string text)
        {
            if (this.m_label.InvokeRequired)
            {
                //Console.WriteLine("Invoked from other thread!");
                setLabelTextCallback d = new setLabelTextCallback(setLabelText);
                this.m_label.Invoke(d, new object[] { text });
            }
            else
            {
                //Console.WriteLine("Invoked from this thread!");
                this.m_label.Text = text;
            }
        }

        delegate void setLabelVisibilityCallback(bool visible);

        public void setLabelVisibility(bool visible)
        {
            if (this.m_label.InvokeRequired)
            {
                //Console.WriteLine("Invoked from other thread!");
                setLabelVisibilityCallback d = new setLabelVisibilityCallback(setLabelVisibility);
                this.m_label.Invoke(d, new object[] { visible });
            }
            else
            {
                //Console.WriteLine("Invoked from this thread!");
                this.m_label.Visible = visible;
            }
        }

	}

}
