//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiMainMenu.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;
using System.Collections;

namespace PSCGenericBuild
{

	public class xExitDialog : Form
	{
		public ListBox  m_lbox;

		public xExitDialog()
		{

			m_lbox = new ListBox();

			this.Text = "All Targets";
			//this.StartPosition = Manual; TODO

			this.Size = new System.Drawing.Size(200, 650);
			this.Location = new System.Drawing.Point(10,10);

			//this.Size = new Size(100, 470);
			//this.Location = new Point(500, 30);
			m_lbox.Height = 620;

			for (int i = 1; i < 56 ; i++)
				m_lbox.Items.Add("Target " + i.ToString());

			Controls.Add(m_lbox);
		}

	}
	//-----------------------------------------------------------------------
	//The GUI Main Menu Class.
	//
	//This class captures the functionality for the GUI main menu.
	//The windows MainMenu class is used as a base class.
	//-----------------------------------------------------------------------
	public class C_guiMainMenu : MainMenu
	{
		protected C_gui      m_ptrGui;

		protected ArrayList  m_mainMenuList;

						xExitDialog xexitDialog = new xExitDialog();

		//-----------------------------------------------------------------------
		//Class Members
		//-----------------------------------------------------------------------
		protected MenuItem   m_FileMenu;
		protected MenuItem   m_ExitMenu;
		protected MenuItem   m_DisplayMenu;

		protected MenuItem   m_IODataMenu;
		protected MenuItem   m_PIPDataMenu;
		protected MenuItem   m_PIGDataMenu;
		protected MenuItem   m_NetworkStatusMenu;
		protected MenuItem   m_IOStatusMenu;
		protected MenuItem   m_ScenariosMenu;

		protected MenuItem   m_PIG_ExerciseMenu;
		protected MenuItem   m_PIG_EnvironmentMenu;
		protected MenuItem   m_PIG_OwnshipMenu;
		protected MenuItem   m_PIG_PeriscopeMenu;
		protected MenuItem   m_PIG_TargetsMenu;
		protected MenuItem   m_PIG_Return;
		protected MenuItem[] m_PIG_Targets;

		protected MenuItem   m_PIP_ExerciseMenu;
		protected MenuItem   m_PIP_EnvironmentMenu;
		protected MenuItem   m_PIP_OwnshipMenu;
		protected MenuItem   m_PIP_PeriscopeMenu;
		protected MenuItem   m_PIP_TargetsMenu;
		protected MenuItem   m_PIP_Return;
		protected MenuItem[] m_PIP_Targets;

		public ArrayList mainMenuList
		{
			get
			{
				return m_mainMenuList;
			}
		}

		public C_guiMainMenu(C_gui ptrGui)
		{
			m_mainMenuList     = new ArrayList();

			m_ptrGui  = ptrGui;

			//
			//Create the Menu Structure.
			//
			m_FileMenu            = new MenuItem();
			m_DisplayMenu         = new MenuItem();
			m_ExitMenu            = new MenuItem();
			m_IODataMenu          = new MenuItem();
			m_PIPDataMenu         = new MenuItem();
			m_PIGDataMenu         = new MenuItem();
			m_NetworkStatusMenu   = new MenuItem();
			m_IOStatusMenu        = new MenuItem();
			m_ScenariosMenu       = new MenuItem();
			m_PIG_ExerciseMenu    = new MenuItem();
			m_PIG_EnvironmentMenu = new MenuItem();
			m_PIG_OwnshipMenu     = new MenuItem();
			m_PIG_PeriscopeMenu   = new MenuItem();
			m_PIG_TargetsMenu     = new MenuItem();
			m_PIG_Return          = new MenuItem();

			m_PIP_ExerciseMenu    = new MenuItem();
			m_PIP_EnvironmentMenu = new MenuItem();
			m_PIP_OwnshipMenu     = new MenuItem();
			m_PIP_PeriscopeMenu   = new MenuItem();
			m_PIP_TargetsMenu     = new MenuItem();
			m_PIP_Return          = new MenuItem();

			//
			//Initialise the text for each Menu Item.
			//
			m_FileMenu.Text            = "File";
			m_DisplayMenu.Text         = "Display";
			m_ExitMenu.Text            = "Exit";
			m_IODataMenu.Text          = "IO Data";
			m_PIPDataMenu.Text         = "PIP Data";
			m_PIGDataMenu.Text         = "PIG Data";
			m_NetworkStatusMenu.Text   = "Network Status";
			m_IOStatusMenu.Text        = "IO Status";
			m_ScenariosMenu.Text       = "Scenarios";
			m_PIG_ExerciseMenu.Text    = "PIG Exercise";
			m_PIG_EnvironmentMenu.Text = "PIG Environment";
			m_PIG_OwnshipMenu.Text     = "PIG Ownship";
			m_PIG_PeriscopeMenu.Text   = "PIG Periscope";
			m_PIG_TargetsMenu.Text     = "PIG Targets";
			m_PIG_Return.Text          = "PIG Return";

			m_PIP_ExerciseMenu.Text    = "PIP Exercise";
			m_PIP_EnvironmentMenu.Text = "PIP Environment";
			m_PIP_OwnshipMenu.Text     = "PIP Ownship";
			m_PIP_PeriscopeMenu.Text   = "PIP Periscope";
			m_PIP_TargetsMenu.Text     = "PIP Targets";
			m_PIP_Return.Text          = "PIP Return";

			//
			//Define Event Handlers for each menu item.
			//
			m_ExitMenu.Click            += new EventHandler(Exit_Click);
			m_IODataMenu.Click          += new EventHandler(ShowGuiPage);
			m_PIPDataMenu.Click         += new EventHandler(ShowGuiPage);
			m_PIGDataMenu.Click         += new EventHandler(ShowGuiPage);
			m_NetworkStatusMenu.Click   += new EventHandler(ShowGuiPage);
			m_IOStatusMenu.Click        += new EventHandler(ShowGuiPage);
			m_ScenariosMenu.Click       += new EventHandler(ShowGuiPage);
			m_PIG_ExerciseMenu.Click    += new EventHandler(ShowGuiPage);
			m_PIG_EnvironmentMenu.Click += new EventHandler(ShowGuiPage);
			m_PIG_OwnshipMenu.Click     += new EventHandler(ShowGuiPage);
			m_PIG_PeriscopeMenu.Click   += new EventHandler(ShowGuiPage);
			m_PIG_Return.Click          += new EventHandler(ShowGuiPage);

			m_PIP_ExerciseMenu.Click    += new EventHandler(ShowGuiPage);
			m_PIP_EnvironmentMenu.Click += new EventHandler(ShowGuiPage);
			m_PIP_OwnshipMenu.Click     += new EventHandler(ShowGuiPage);
			m_PIP_PeriscopeMenu.Click   += new EventHandler(ShowGuiPage);
			m_PIP_TargetsMenu.Click     += new EventHandler(ShowGuiPage);

			m_PIP_Return.Click          += new EventHandler(ShowGuiPage);
			xexitDialog.m_lbox.Click	+= new EventHandler(ShowNumber);

			//Create the menu structure for each Target.
			//
			m_PIG_Targets = new MenuItem[SIMControl.NUM_PERI_TARGETS];
			for(int i=0; i < SIMControl.NUM_PERI_TARGETS; i++)
			{
				m_PIG_Targets[i]        = new MenuItem();
				m_PIG_Targets[i].Text   = "PIG Target " + (i+1).ToString();
				m_PIG_Targets[i].Click +=new EventHandler(ShowGuiPage);
			}
			m_PIP_Targets = new MenuItem[SIMControl.NUM_PERI_TARGETS];
			for(int i=0; i < SIMControl.NUM_PERI_TARGETS; i++)
			{
				m_PIP_Targets[i]        = new MenuItem();
				m_PIP_Targets[i].Text   = "PIP Target " + (i+1).ToString();
				m_PIP_Targets[i].Click +=new EventHandler(ShowGuiPage);
			}

			//
			//Construct the menu structure.
			//

			//Add the 'exit' menu to the 'file' menu.
			m_FileMenu.MenuItems.Add(m_ExitMenu);

			//Add the 'File' and 'Display' Menus to the main menu.
			this.MenuItems.Add(m_FileMenu);
			this.MenuItems.Add(m_DisplayMenu);

			//Create the 'Targets' menu structure.
			for(int i=0; i < SIMControl.NUM_PERI_TARGETS; i++)
			{
				m_PIG_TargetsMenu.MenuItems.Add(m_PIG_Targets[i]);
			}

			for(int i=0; i < SIMControl.NUM_PERI_TARGETS; i++)
			{
				m_PIP_TargetsMenu.MenuItems.Add(m_PIP_Targets[i]);
			}



			//
			//By default the main menu options are disabled.
			//
			enableGuiMenu(true);
		}

		public void ShowNumber(object sender, EventArgs e)
		{
			int plusIndex =0;
			plusIndex = xexitDialog.m_lbox.SelectedIndex + 1;
			C_guiNetworkStatus.txtv = plusIndex.ToString();

		}

		/************************************************************************
		  FUNCTION      : ShowPage()
		  DESCRIPTION   : Event Handler to show a gui page when a menu item has
						  been selected.
		  PARAMETERS    : None.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : As read.
		 ************************************************************************/
		public void ShowGuiPage(object sender, EventArgs e)
		{
			//Determine which menu item has been selected.
			MenuItem selectedItem = (MenuItem) sender;

			//Show the appropriate page.
			if(selectedItem == m_IODataMenu)
				m_ptrGui.ShowPage( C_gui.page.IO_DATA_AS1117, 0);

			else if(selectedItem == m_PIPDataMenu)
				m_ptrGui.ShowPage( C_gui.page.PIP_DATA, 0);

			else if(selectedItem == m_NetworkStatusMenu)
				m_ptrGui.ShowPage( C_gui.page.NETWORK_STATUS, 0);

			else if(selectedItem == m_IOStatusMenu)
				m_ptrGui.ShowPage( C_gui.page.IO_STATUS, 0);

			else if(selectedItem == m_ScenariosMenu)
				m_ptrGui.ShowPage( C_gui.page.SCENARIOS, 0);

			//
			//PIG Data
			//
			else if(selectedItem == m_PIG_ExerciseMenu)
				m_ptrGui.ShowPage( C_gui.page.PIG_EXERCISE, 0);

			else if(selectedItem == m_PIG_EnvironmentMenu)
				m_ptrGui.ShowPage( C_gui.page.PIG_ENVIRONMENT, 0);

			else if(selectedItem == m_PIG_OwnshipMenu)
				m_ptrGui.ShowPage( C_gui.page.PIG_OWNSHIP, 0);

			else if(selectedItem == m_PIG_Return)
				m_ptrGui.ShowPage( C_gui.page.PIG_RETURN, 0);

			else if(selectedItem == m_PIG_PeriscopeMenu)
				m_ptrGui.ShowPage( C_gui.page.PIG_PERISCOPE, 0);

			//
			//PIP Data
			//
			else if(selectedItem == m_PIP_ExerciseMenu)
				m_ptrGui.ShowPage( C_gui.page.PIP_EXERCISE, 0);

			else if(selectedItem == m_PIP_EnvironmentMenu)
				m_ptrGui.ShowPage( C_gui.page.PIP_ENVIRONMENT, 0);

			else if(selectedItem == m_PIP_OwnshipMenu)
				m_ptrGui.ShowPage( C_gui.page.PIP_OWNSHIP, 0);

			else if(selectedItem == m_PIP_PeriscopeMenu)
				m_ptrGui.ShowPage( C_gui.page.PIP_PERISCOPE, 0);

			else if(selectedItem == m_PIP_Return)
				m_ptrGui.ShowPage( C_gui.page.PIP_RETURN, 0);
			else
			{
				// Check for PIG or PIP target
				for(int i=0; i < SIMControl.NUM_PERI_TARGETS; i++)
				{
					if(selectedItem == m_PIG_Targets[i])
						m_ptrGui.ShowPage( C_gui.page.PIG_TARGETS, i);
					else if(selectedItem == m_PIP_Targets[i])
						m_ptrGui.ShowPage( C_gui.page.PIP_TARGETS, i);
				}
			}
		}

		public void enableGuiMenu(bool bEnable)
		{
			if(bEnable)
			{
				m_IODataMenu.Enabled          = true;
				m_PIPDataMenu.Enabled         = true;
				m_PIGDataMenu.Enabled         = true;
 				m_IOStatusMenu.Enabled        = true;
				m_ScenariosMenu.Enabled       = true;
				m_PIG_ExerciseMenu.Enabled    = true;
				m_PIG_EnvironmentMenu.Enabled = true;
				m_PIG_OwnshipMenu.Enabled     = true;
				m_PIG_PeriscopeMenu.Enabled   = true;
				m_PIG_TargetsMenu.Enabled     = true;
				m_PIG_Return.Enabled          = true;
				m_PIP_ExerciseMenu.Enabled    = true;
				m_PIP_EnvironmentMenu.Enabled = true;
				m_PIP_OwnshipMenu.Enabled     = true;
				m_PIP_PeriscopeMenu.Enabled   = true;
				m_PIP_TargetsMenu.Enabled     = true;
				m_PIP_Return.Enabled          = true;
			}
			else
			{
				m_IODataMenu.Enabled          = false;
				m_PIPDataMenu.Enabled         = false;
				m_PIGDataMenu.Enabled         = false;
				m_IOStatusMenu.Enabled        = false;
				m_ScenariosMenu.Enabled       = false;
				m_PIG_ExerciseMenu.Enabled    = false;
				m_PIG_EnvironmentMenu.Enabled = false;
				m_PIG_OwnshipMenu.Enabled     = false;
				m_PIG_PeriscopeMenu.Enabled   = false;
				m_PIG_TargetsMenu.Enabled     = false;
				m_PIG_Return.Enabled          = false;
				m_PIP_ExerciseMenu.Enabled    = false;
				m_PIP_EnvironmentMenu.Enabled = false;
				m_PIP_OwnshipMenu.Enabled     = false;
				m_PIP_PeriscopeMenu.Enabled   = false;
				m_PIP_TargetsMenu.Enabled     = false;
				m_PIP_Return.Enabled          = false;
			}
		}

		/************************************************************************
		  FUNCTION      : Exit_Click
		  DESCRIPTION   : The Event handler to close the application on selection
						  of the 'Exit' menu item.
		  PARAMETERS    : None.
		  RETURNS       : Nothing.
		  GLOBALS USED  : None
		  METHOD USED   : Event Handler
		 ************************************************************************/
		private void Exit_Click(object sender,EventArgs e)
		{
			//
			//Dispose the application. Note: Will launch the exit dialog.
			//
			m_ptrGui.Dispose();
		}

		public MenuItem getMenuItem(C_gui.page ePageNumber, int targetnumber)
		{
			MenuItem menuItem;

			switch(ePageNumber)
			{
				case C_gui.page.IO_DATA_AS1117:
				case C_gui.page.IO_DATA_AS1082:
					menuItem = m_IODataMenu;
					break;

				case C_gui.page.NETWORK_STATUS: menuItem = m_NetworkStatusMenu;
					break;
				case C_gui.page.SCENARIOS:      menuItem = m_ScenariosMenu;
					break;
				case C_gui.page.PIG_ENVIRONMENT:menuItem = m_PIG_EnvironmentMenu;
					break;
				case C_gui.page.PIG_EXERCISE:   menuItem = m_PIG_ExerciseMenu;
					break;
				case C_gui.page.PIG_OWNSHIP:    menuItem = m_PIG_OwnshipMenu;
					break;
				case C_gui.page.PIG_PERISCOPE:  menuItem = m_PIG_PeriscopeMenu;
					break;
				case C_gui.page.PIG_RETURN:     menuItem = m_PIG_Return;
					break;
				case C_gui.page.PIG_TARGETS:    menuItem = m_PIG_Targets[targetnumber];
					break;
				case C_gui.page.PIP_TARGETS:    menuItem = m_PIP_Targets[targetnumber];
					break;
				case C_gui.page.PIP_ENVIRONMENT:menuItem = m_PIP_EnvironmentMenu;
					break;
				case C_gui.page.PIP_EXERCISE:   menuItem = m_PIP_ExerciseMenu;
					break;
				case C_gui.page.PIP_OWNSHIP:    menuItem = m_PIP_OwnshipMenu;
					break;
				case C_gui.page.PIP_PERISCOPE:  menuItem = m_PIP_PeriscopeMenu;
					break;
				case C_gui.page.PIP_RETURN:     menuItem = m_PIP_Return;
					break;
				default:                 menuItem = null;
					break;
			}

			return menuItem;
		}

		public void addMenuOption(string strMenu, string strMenuOption)
		{
			if(strMenu       == null) return;
			if(strMenuOption == null) return;

			if(strMenu.Equals("DISPLAY_MENU"))
			{
				if(strMenuOption.Equals("IO_DATA"))
					m_DisplayMenu.MenuItems.Add(m_IODataMenu);
				else if (strMenuOption.Equals("PIG_DATA"))
					m_DisplayMenu.MenuItems.Add(m_PIGDataMenu);
				else if (strMenuOption.Equals("PIP_DATA"))
					m_DisplayMenu.MenuItems.Add(m_PIPDataMenu);
				else if (strMenuOption.Equals("NETWORK_STATUS"))
					m_DisplayMenu.MenuItems.Add(m_NetworkStatusMenu);
				else if (strMenuOption.Equals("SCENARIOS"))
					m_DisplayMenu.MenuItems.Add(m_ScenariosMenu);
			}
			else if(strMenu.Equals("PIG_SUB_MENU"))
			{
				if(strMenuOption.Equals("EXERCISE"))
					m_PIGDataMenu.MenuItems.Add(m_PIG_ExerciseMenu);
				else if (strMenuOption.Equals("ENVIRONMENT"))
					m_PIGDataMenu.MenuItems.Add(m_PIG_EnvironmentMenu);
				else if (strMenuOption.Equals("OWNSHIP"))
					m_PIGDataMenu.MenuItems.Add(m_PIG_OwnshipMenu);
				else if (strMenuOption.Equals("PERISCOPE"))
					m_PIGDataMenu.MenuItems.Add(m_PIG_PeriscopeMenu);
				else if (strMenuOption.Equals("TARGETS"))
					m_PIGDataMenu.MenuItems.Add(m_PIG_TargetsMenu);
				else if (strMenuOption.Equals("RETURN"))
					m_PIGDataMenu.MenuItems.Add(m_PIG_Return);
			}
			else if(strMenu.Equals("PIP_SUB_MENU"))
			{
				if(strMenuOption.Equals("EXERCISE"))
					m_PIPDataMenu.MenuItems.Add(m_PIP_ExerciseMenu);
				else if (strMenuOption.Equals("ENVIRONMENT"))
					m_PIPDataMenu.MenuItems.Add(m_PIP_EnvironmentMenu);
				else if (strMenuOption.Equals("OWNSHIP"))
					m_PIPDataMenu.MenuItems.Add(m_PIP_OwnshipMenu);
				else if (strMenuOption.Equals("PERISCOPE"))
					m_PIPDataMenu.MenuItems.Add(m_PIP_PeriscopeMenu);
				else if (strMenuOption.Equals("TARGETS"))
					m_PIPDataMenu.MenuItems.Add(m_PIP_TargetsMenu);
				else if (strMenuOption.Equals("RETURN"))
					m_PIPDataMenu.MenuItems.Add(m_PIP_Return);
			}
		}

		public void configureMenu()
		{
			//
			//Create the main menu structure
			//
			for(int i = 0; i < m_mainMenuList.Count; i++)
			{
				MenuOption ptrMenuOption = (MenuOption)m_mainMenuList[i];
				addMenuOption(ptrMenuOption.menu, ptrMenuOption.menuItem);
			}
		}

	}

}
