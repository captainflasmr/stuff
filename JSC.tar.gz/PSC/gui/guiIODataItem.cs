//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiIODataItem.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Drawing;


namespace PSCGenericBuild
{
	//-----------------------------------------------------------------------
	//The IODataItem Class, a refinement of the Data Item class, containing
	//an additional gui element the io status field.
	//-----------------------------------------------------------------------
	public class C_IODataItem : C_guiDataItem
	{
	//	public enum E_ioStatus {unknown, operational, fault};

		protected Label          m_ioStatus;
		//protected E_ioStatus     m_ioStatusField;
		protected int     m_ioStatusField;

		//public E_ioStatus ioStatus
		public int ioStatus
		{
			get
			{
				return m_ioStatusField;
			}
			set
			{
				switch(value)
				{
					// case IOComms.IO_EMULATION:
					// 	m_ioStatus.Text      = "Emulation";
					// 	m_ioStatus.ForeColor = Color.Black;
					// 	break;

					// case IOComms.IO_UNKNOWN:
					// 	m_ioStatus.Text      = "Unknown";
					// 	m_ioStatus.ForeColor = Color.Black;
					// 	break;

					// case IOComms.IO_OPERATIONAL:
					// 	m_ioStatus.Text      = "Operational";
					// 	m_ioStatus.ForeColor = Color.Green;
					// 	break;

					// case IOComms.IO_OVERRIDE:
					// 	m_ioStatus.Text      = "Override";
					// 	m_ioStatus.ForeColor = Color.Black;
					// 	break;

					// case IOComms.IO_FAULT:
					// 	m_ioStatus.Text      = "Fault";
					// 	m_ioStatus.ForeColor = Color.Red;
					// 	break;

					// case IOComms.IO_NOTUSED:
					// 	m_ioStatus.Text      = "Error N/A";
					// 	m_ioStatus.ForeColor = Color.Black;
					// 	break;

					default:
						m_ioStatus.Text      = "Unknown";
						m_ioStatus.ForeColor = Color.Black;
						break;
				}
			}
		}



		public C_IODataItem()
		{
		}

		public C_IODataItem(string strLabel, string strHashTableKey, int iLeft, int iTop, C_guiTemplatePage parent, string strDescription)
		{
			initDataItem(strLabel, strHashTableKey,  iLeft, iTop, parent, strDescription);

			// this.ioStatus = IOComms.IO_FAULT;

			//Create the size of the panel.
			this.Size      = new Size(520 + m_Description.Width, 30);

		}

		protected override void initDataItem(string strLabel, string strHashTableKey, int iLeft, int iTop, C_guiTemplatePage parent, string strDescription)
		{
			m_ioStatus = new Label();
			m_ioStatus = new Label();

			// ioStatus   = IOComms.IO_OPERATIONAL;

			m_ioStatus.Width = 80;
			this.Controls.Add( m_ioStatus );     			//Add the label to the form.

			base.initDataItem(strLabel, strHashTableKey,  iLeft, iTop, parent, strDescription);

			this.Size      = new Size(750, 30);
		}

		protected override void positionDataItems()
		{
			m_TextBox.Location     = new Point(130, 0);
			m_ioStatus.Location    = new Point(250, 0);
			m_CheckBox.Location    = new Point(330, 0);
			m_Numeric.Location     = new Point(380, 0);
			m_Description.Location = new Point(530, 0);
		}
	}
}
