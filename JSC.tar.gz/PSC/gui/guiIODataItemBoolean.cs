//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//						 The software is supplied by BAE Systems Ltd on the express terms
//						 that it is to be treated as confidential, and that it may not
//						 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : guiIODataItemBoolean.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Drawing;

namespace PSCGenericBuild
{
	/// <summary>
	/// Summary description for guiDataItemInt.
	/// </summary>
	public class C_guiIODataItemBoolean : C_IODataItem
	{
		protected bool m_iMaxValue ;
		protected bool m_iMinValue ;
		protected bool m_iDefaultValue ;

		protected bool m_overrideValue;

		public C_guiIODataItemBoolean()
		{
			m_iMaxValue     = true;
			m_iMinValue     = false;
		}

		public C_guiIODataItemBoolean(string strLabel, string strHashTableKey, int iLeft, int iTop, C_guiTemplatePage parent, string strDescription)
		{
			m_iMaxValue     = true;
			m_iMinValue     = false;
			m_iDefaultValue = false;

			//
			//Retrieve the data from the config hash table
			//
			if(strHashTableKey == null)
				return;

			//
			//Initialise the data item by creating the various components.
			//
			initDataItem(strLabel, strHashTableKey, iLeft, iTop, parent, strDescription);

			CurrentValue  = m_iDefaultValue;
			OverrideValue = m_iDefaultValue;

			setDecimalPlaces(0);

		}

		protected override void setData(DataFields data)
		{
			if(data != null)
			{
				if(data.fDefault == 1.0f)
					m_iDefaultValue  = true;
				else
					m_iDefaultValue  = false;

				m_Description.Text  = data.strDescription;
				m_Description.Width = data.strDescription.Length * 7;
				this.Width += m_Description.Width;

				//m_Numeric.Maximum = (decimal) m_iMaxValue;
				//m_Numeric.Minimum = (decimal) m_iMinValue;
				m_Numeric.Maximum = 1;
				m_Numeric.Minimum = 0;

			}
			else
			{
				m_Description.Width = m_Description.Text.Length * 7;
				this.Width += m_Description.Width;
			}

		}

		public override void setDefaultValues()
		{
			//placeholder for the defaultValues
			CurrentValue  = m_iDefaultValue;
			OverrideValue = m_iDefaultValue;
		}

		public bool CurrentValue
		{
			get
			{
				if(m_overrideControl == m_Numeric)
				{
					if(m_TextBox.Text == "1")
						return true;
					else
						return false;
				}
				else
				{
					int i = m_ComboBox.FindString(m_TextBox.Text);

					if(i == 1) 
						return true;
					else
						return false;
				}
			}
			set
			{
                if (!guiPage.IsDisposed)
                {
                    if (m_overrideControl == m_Numeric)
                    {
                        if (value == true)
                            m_TextBox.Text = "1";
                        else
                            m_TextBox.Text = "0";
                    }
                    else
                    {
                        //
                        //If the value is a combo box set the text to the enumerated value if it is in
                        //bounds, otherwise show the text "Undefined" and the value which was out of bounds.
                        //
                        if (m_ComboBox.Items.Count == 2)
                        {
                            int i;
                            if (value == true)
                                i = 1;
                            else
                                i = 0;

                            m_TextBox.Text = m_ComboBox.Items[i].ToString();
                        }
                        else
                        {
                            m_TextBox.Text = "Undefined";
                        }
                    }
                }
			}
		}

		/************************************************************************
		  PROPERTY      : OverrideValue
		  TYPE          : int
		  GET           : Returns the floating point value for the numeric override value
						  or, the enumerated value if a combobox entry.
		  SET           : Sets the text in the override value text box to a value if
						  a numeric override value, or a string if it is a string.
		 ************************************************************************/
		public bool OverrideValue
		{
			get
			{
				return m_overrideValue;
			}
			set
			{
				m_overrideValue = value;
                if (!guiPage.IsDisposed)
                {
                    if (m_overrideControl == m_Numeric)
                    {
                        if (value == true)
                            m_Numeric.Text = "1";
                        else
                            m_Numeric.Text = "0";
                    }
                    else
                    {
                        //
                        //If the value is a combo box set the text to the enumerated value if it is in
                        //bounds, otherwise show the text "Undefined" and the value which was out of bounds.
                        //
                        if (m_ComboBox.Items.Count == 2)
                        {
                            int i;
                            if (value == true)
                                i = 1;
                            else
                                i = 0;

                            m_ComboBox.SelectedIndex = i;
                        }
                    }
                }
			}
		}

		/************************************************************************
		  PROPERTY      : Value
		  TYPE          : float
		  GET           : If the override check is checked returns the override value
						  otherwise returns the current value.
		  SET           : Sets the text in the override value text box to a value if
						  a numeric override value, or a string if it is a string.
		 ************************************************************************/
		public bool Value
		{
			get
			{
				//
				//If the Override box is checked return the override value otherwise return the 
				//value supplied by the pip.
				//
				if(m_CheckBox.Checked)
				{			
					return OverrideValue;
				}
				else
				{
					return CurrentValue;
				}
			}
			set
			{
                if (!guiPage.IsDisposed)
                {
                    if (m_overrideControl == m_Numeric)
                    {
                        m_TextBox.Text = value.ToString();
                    }
                    else
                    {
                        //
                        //If the value is a combo box set the text to the enumerated value if it is in
                        //bounds, otherwise show the text "Undefined" and the value which was out of bounds.
                        //
                        if (m_ComboBox.Items.Count == 2)
                        {
                            int i;
                            if (value == true)
                                i = 1;
                            else
                                i = 0;

                            m_TextBox.Text = m_ComboBox.Items[i].ToString();
                        }
                        else
                        {
                            m_TextBox.Text = "Undefined";
                        }
                    }
                }
			}
		}

		public override void enableOverride(bool bOnOff)
		{
			if(bOnOff)
			{
				this.OverrideValue = this.m_iDefaultValue;
			}

			base.enableOverride(bOnOff);
		}


		protected override void OverrideValueChanged(object sender, EventArgs eArgs)
		{
			if(sender == m_Numeric)
			{
				if(m_Numeric.Value == 1)
					OverrideValue = true;
				else
					OverrideValue = false;
			}
			else
			{
				int i = m_ComboBox.Items.IndexOf(m_ComboBox.Text);
				if(i == 0)
					OverrideValue = false;
				else
					OverrideValue = true;
			}
			
			//
			//Update the PIG Data (and send the packet to the PIG).
			//		
			guiPage.updateOutgoingData();
		}
	}
}
