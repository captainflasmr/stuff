//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//                 The software is supplied by BAE Systems Ltd on the express terms
//                 that it is to be treated as confidential, and that it may not
//                 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Gui
// Module Title        : ConfigFile.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

using System;
using System.IO;
using System.Collections;

namespace PSCGenericBuild
{
    /// <summary>
    /// Summary description for DataItemMaxMinValues.
    /// </summary>
    ///

    public class MenuOption
    {
        protected string m_strMenu;
        protected string m_strMenuItem;

        public MenuOption(string strMenu, string strMenuItem)
        {
            m_strMenu     = strMenu;
            m_strMenuItem = strMenuItem;
        }

        public string menu
        {
            get
            {
                return m_strMenu;
            }
        }

        public string menuItem
        {
            get
            {
                return m_strMenuItem;
            }
        }

    }
    public class DataFields
    {
        public string token;
        public float  fMin;
        public float  fMax;
        public float  fDefault;
        public string strDescription;

        public DataFields(string strToken)
        {
            token    = strToken;
            fMin     = 0.0f;
            fMax     = 0.0f;
            fDefault = 0.0f;
        }
    }

    public struct ScenarioData
    {
        public string strName;
        public string strDescription;
        public int    iIndex;
    }

    public class ConfigFile
    {
        //PSC   thePSC;
        C_gui theGUI;


        public ConfigFile(C_gui theGUIClass)
        {
            //
            // TODO: Add constructor logic here
            //
            theGUI = theGUIClass;

            //thePSC = theGUIClass.psc;
        }

        /************************************************************************
     FUNCTION      : readConfigFile
     DESCRIPTION   : Reads the configuration file for the gui.
     PARAMETERS    : string strFilename: the name of the configuation file
     RETURNS       : bool : Success or Failure
     GLOBALS USED  : None
     METHOD USED   : Calls to the System.IO.File class.
        ************************************************************************/
        public bool readConfigFile(string strFilename)
        {
            string strText;
            StreamReader reader;
            if(strFilename == null) return false;

            //
            //If the file doesnt exist then we cant read the file, so return (false)
            //
            if(! System.IO.File.Exists(strFilename))
                return false;

            //
            //Open the File.
            //
            reader = new StreamReader(strFilename);

            //
            //Read each line of the file in turn parsing as we go.
            //
            do
            {
                strText = reader.ReadLine();
                parseLine(strText, reader);
            }
            while(strText != null);

            //
            //Close the File.
            //
            reader.Close();

            return true;
        }

        /************************************************************************
     FUNCTION      : parseLine
     DESCRIPTION   : Parses a line which was read in from the file.
     PARAMETERS    : string       strText: the line to parse.
                     StreamReader reader : The file stream.
     RETURNS       : None
     GLOBALS USED  : None
     METHOD USED   : Match the string against a set pattern.
        ************************************************************************/
        protected void parseLine(string strText, StreamReader reader)
        {

            DataFields [] PIG_environmentData = {
                new DataFields("REMOTE_MOON")    ,
                new DataFields("COAST_LIGHTS")   ,
                new DataFields("REMOTE_SUN")     ,
                new DataFields("ICE_EDGE")       ,
                new DataFields("HOURS")          ,
                new DataFields("MINUTES")        ,
                new DataFields("SECONDS")        ,
                new DataFields("DAY")            ,
                new DataFields("MONTH")          ,
                new DataFields("YEAR")           ,
                new DataFields("WEATHER")        ,
                new DataFields("COASTLINE")      ,
                new DataFields("SEA_STATE")      ,
                new DataFields("VISIBLE_RANGE")  ,
                new DataFields("THERMAL_RANGE")  ,
                new DataFields("UNDERWATER_VIS") ,
                new DataFields("WIND_SPEED")     ,
                new DataFields("WIND_DIRECTION") ,
                new DataFields("MOON_BEARING")   ,
                new DataFields("MOON_ALTITUDE")  ,
                new DataFields("SUN_BEARING")    ,
                new DataFields("SUN_ALTITUDE")   ,
                new DataFields("ICE_EDGE_LAT")   ,
                new DataFields("ICE_EDGE_LONG")  ,
                new DataFields("ICE_EDGE_ORIENT")};

            DataFields [] PIG_exerciseData    = {new DataFields("SYSTEM_ID"),
                new DataFields("RUN_MODE")};

            DataFields [] PIG_ownshipData = {   new DataFields("TYPE")          ,
                new DataFields("SMOKE")         ,
                new DataFields("LATITUDE")      ,
                new DataFields("LONGITUDE")     ,
                new DataFields("X")             ,
                new DataFields("Y")             ,
                new DataFields("DEPTH")         ,
                new DataFields("HEADING")       ,
                new DataFields("ROLL")          ,
                new DataFields("PITCH")         ,
                new DataFields("SPEED")         ,
                new DataFields("MAST_0_HEIGHT") ,
                new DataFields("MAST_1_HEIGHT") ,
                new DataFields("MAST_2_HEIGHT") ,
                new DataFields("MAST_3_HEIGHT") ,
                new DataFields("MAST_4_HEIGHT") ,
                new DataFields("MAST_5_HEIGHT") ,
                new DataFields("MAST_6_HEIGHT") ,
                new DataFields("MAST_7_HEIGHT") ,
                new DataFields("MAST_8_HEIGHT") ,
                new DataFields("MAST_9_HEIGHT") };

            DataFields [] PIG_periscopeData = {new DataFields("SENSOR_TYPE"),
                new DataFields("MAGNIFICATION"),
                new DataFields("SENSOR_GAIN"),
                new DataFields("SENSOR_CONTRAST"),
                new DataFields("GRAT_INTENSITY"),
                new DataFields("DRAINDOWN_TIME"),
                new DataFields("REL_BRG"),
                new DataFields("REL_ELEV"),
                new DataFields("STADIAMETER_ELEV")};

            DataFields [] PIG_targetData = {new DataFields("MODEL_ID"),
                new DataFields("TARGET_NUM"),
                new DataFields("X"),
                new DataFields("Y"),
                new DataFields("HEIGHT"),
                new DataFields("HEADING"),
                new DataFields("ROLL"),
                new DataFields("PITCH"),
                new DataFields("SPEED"),
                new DataFields("ACCELERATION"),
                new DataFields("VISIBLE"),
                new DataFields("NAV_LIGHTS"),
                new DataFields("MISSILE_IMPACT"),
                new DataFields("TORPEDO_IMPACT"),
                new DataFields("SINKING"),
                new DataFields("SONAR_DIP"),
                new DataFields("TLAM_LAUNCH"),
                new DataFields("EXPLOSION"),
                new DataFields("DIESEL_SMOKE"),
                new DataFields("MISSILE_LAUNCH"),
                new DataFields("FISHING_LIGHTS"),
                new DataFields("FISHING_SPOTS")
            };

            DataFields [] PIP_environmentData = {
                new DataFields("REMOTE_MOON")    ,
                new DataFields("COAST_LIGHTS")   ,
                new DataFields("REMOTE_SUN")     ,
                new DataFields("ICE_EDGE")       ,
                new DataFields("HOURS")          ,
                new DataFields("MINUTES")        ,
                new DataFields("SECONDS")        ,
                new DataFields("DAY")            ,
                new DataFields("MONTH")          ,
                new DataFields("YEAR")           ,
                new DataFields("WEATHER")        ,
                new DataFields("COASTLINE")      ,
                new DataFields("SEA_STATE")      ,
                new DataFields("VISIBLE_RANGE")  ,
                new DataFields("THERMAL_RANGE")  ,
                new DataFields("UNDERWATER_VIS") ,
                new DataFields("WIND_SPEED")     ,
                new DataFields("WIND_DIRECTION") ,
                new DataFields("MOON_BEARING")   ,
                new DataFields("MOON_ALTITUDE")  ,
                new DataFields("SUN_BEARING")    ,
                new DataFields("SUN_ALTITUDE")   ,
                new DataFields("ICE_EDGE_LAT")   ,
                new DataFields("ICE_EDGE_LONG")  ,
                new DataFields("ICE_EDGE_ORIENT")};

            DataFields [] PIP_exerciseData = {new DataFields("RUN_MODE"),
                new DataFields("HOURS"),
                new DataFields("MINUTES"),
                new DataFields("SECONDS"),
                new DataFields("DAY"),
                new DataFields("MONTH"),
                new DataFields("YEAR")};

            DataFields [] PIP_periscopeData = {new DataFields("INSTRUCTOR_CONTROL"),
                new DataFields("MAST_POSITION"),
                new DataFields("TI_CONTROL"),
                new DataFields("MAGNIFICATION"),
                new DataFields("DRAINDOWN_TIME"),
                new DataFields("LLTV_GAIN"),
                new DataFields("TI_GAIN"),
                new DataFields("REL_BRG"),
                new DataFields("REL_ELEV")};

            DataFields [] PIP_ownshipData =    {new DataFields("LATITUDE"),
                new DataFields("LONGITUDE"),
                new DataFields("DEPTH"),
                new DataFields("CLIMB_RATE"),
                new DataFields("TURN_RATE"),
                new DataFields("PITCH"),
                new DataFields("HEADING"),
                new DataFields("DRIFT_COURSE"),
                new DataFields("SPEED"),
                new DataFields("DRIFT_SPEED"),
                new DataFields("WHIP_AERIAL"),
                new DataFields("EMERGENCY_LGT"),
                new DataFields("DIESEL_SMOKE"),
                new DataFields("RESM"),
                new DataFields("WT_COMMS"),
                new DataFields("CESM"),
                new DataFields("ATTACK_PERI"),
                new DataFields("RADAR"),
                new DataFields("SNORT_IND"),
                new DataFields("SNORT_EX"),
                new DataFields("TYPE")};

            DataFields [] PIP_targetData =    {new DataFields("MODEL_ID"),
                new DataFields("X"),
                new DataFields("Y"),
                new DataFields("HEIGHT"),
                new DataFields("CLIMB_RATE"),
                new DataFields("TURN_RATE"),
                new DataFields("PITCH"),
                new DataFields("HEADING"),
                new DataFields("DRIFT_COURSE"),
                new DataFields("SPEED"),
                new DataFields("DRIFT_SPEED"),
                new DataFields("VISIBLE"),
                new DataFields("EXPLOSION"),
                new DataFields("MISSILE_IMPACT"),
                new DataFields("TORPEDO_IMPACT"),
                new DataFields("SINKING"),
                new DataFields("NAV_LIGHTS"),
                new DataFields("SONAR_DIP"),
                new DataFields("TLAM_LAUNCH"),
                new DataFields("DUNKING_SONAR"),
                new DataFields("FISHING_LIGHTS"),
                new DataFields("FISHING_SPOTS"),
                new DataFields("DIESEL_SMOKE"),
                new DataFields("MISSILE_LAUNCH")};

            DataFields [] PIP_returnData =    {new DataFields("MAST_POSITION"),
                new DataFields("TI_CONTROL"),
                new DataFields("MAGNIFICATION"),
                new DataFields("LLTV_GAIN"),
                new DataFields("TI_GAIN"),
                new DataFields("WSDB"),
                new DataFields("REL_BRG"),
                new DataFields("ELEVATION"),
                new DataFields("AUTO_SUN_BRG"),
                new DataFields("AUTO_SUN_ELEV"),
                new DataFields("ERROR_STRING"),
                new DataFields("ERROR_NUMBER"),
                new DataFields("NUM_POLYNIA"),
                new DataFields("POLYNIA_ID"),
                new DataFields("POLYNIA_ICE_FIELD"),
                new DataFields("POLYNIA_X"),
                new DataFields("POLYNIA_Y"),
                new DataFields("POLYNIA_Z"),
                new DataFields("POLYNIA_ORIENTATION"),
                new DataFields("PERI_TRUE_BRG"),
                new DataFields("TARGET_TRUE_BRG"),
                new DataFields("TARGET_TRUE_BRG_CUT"),
                new DataFields("TARGET_RANGE"),
                new DataFields("TARGET_RANGE_CUT"),
                new DataFields("ELAPSED_TIME"),
                new DataFields("ELAPSED_TIME_CUT")
            };

            DataFields [] PIG_returnData =    {new DataFields("PROC_STATUS"),
                new DataFields("MODEL_STATUS"),
                new DataFields("CONTACTS"),
                new DataFields("IDENTITY"),
                new DataFields("X"),
                new DataFields("Y"),
                new DataFields("Z"),
                new DataFields("ORIENTATION"),
                new DataFields("SLOT_NUM")};

            DataFields [] ioAS1117Data =    {new DataFields("BEARING"),
                new DataFields("RANGE_CUT"),
                new DataFields("BEARING_CUT"),
                new DataFields("PTT"),
                new DataFields("HANDLES_DOWN"),
                new DataFields("MODE_SELECT"),
                new DataFields("DATA_OVERLAY"),
                new DataFields("TI_ON"),
                new DataFields("ELEVATION_CONTROL"),
                new DataFields("STADIAMETRIC"),
                new DataFields("MAGNIFICATION"),
                new DataFields("TI_BLACK_LEVEL"),
                new DataFields("TI_SENSITIVITY"),
                new DataFields("TI_GRATICULE"),
                new DataFields("REAR_DISPLAY_STAD_ANGLE"),
                new DataFields("REAR_DISPLAY_TRUE_BRG"),
                new DataFields("REAR_DISPLAY_REL_BRG"),
                new DataFields("BEARING_DISPLAY"),
                new DataFields("ELEVATION_DISPLAY")};

            DataFields [] ioAS1082Data =    {new DataFields("BEARING"),
                new DataFields("RANGE_CUT"),
                new DataFields("BEARING_CUT"),
                new DataFields("PTT"),
                new DataFields("HANDLES_DOWN"),
                new DataFields("ELEVATION_CONTROL"),
                new DataFields("STADIAMETRIC"),
                new DataFields("MAGNIFICATION"),
                new DataFields("REAR_DISPLAY_STAD_ANGLE"),
                new DataFields("REAR_DISPLAY_TRUE_BRG"),
                new DataFields("REAR_DISPLAY_REL_BRG"),
                new DataFields("TARGET_HEIGHT"),
                new DataFields("TARGET_DISPLAY"),
                new DataFields("BECKMAN_TRUE"),
                new DataFields("BECKMAN_REL")};

            //
            //If the line to parse is null then return.
            //
            if(strText == null)
                return;

            //
            //Trim whitespace from the head and tail of the string.
            //
            strText = strText.Trim();

            //
            //If the line is a comment then no further processing is required.
            //
            if(parseComment(strText))
            {
                return;
            }

            //
            //If a menu option is found, parse the line.
            //
            else if(parseMenuOption(strText, reader))
            {
                return;
            }

            //
            //If a global button is found, parse the line.
            //
            else if(parseGlobalButton(strText, reader))
            {
                return;
            }

            //
            //If an "IO_DATA" command is found, parse the line.
            //
            else if (parseIODataPage(strText, reader))
            {
                return;
            }


            //
            //Otherwise parse the data if a command is found.
            //

            //
            //PIG Data
            //
            else if(parseCommand("PIG_ENVIRONMENT", strText, reader))
                parseData(reader, PIG_environmentData, "PIG_ENVIRONMENT");
            else if(parseCommand("PIG_EXERCISE", strText, reader))
                parseData(reader, PIG_exerciseData, "PIG_EXERCISE");
            else if(parseCommand("PIG_OWNSHIP", strText, reader))
                parseData(reader, PIG_ownshipData, "PIG_OWNSHIP");
            else if(parseCommand("PIG_PERISCOPE", strText, reader))
                parseData(reader, PIG_periscopeData, "PIG_PERISCOPE");
            else if(parseCommand("PIG_TARGET", strText, reader))
                parseData(reader, PIG_targetData, "PIG_TARGET");
            else if(parseCommand("PIG_RETURN", strText, reader))
                parseData(reader, PIG_returnData, "PIG_RETURN");
            //
            //PIP Data.
            //
            else if(parseCommand("PIP_EXERCISE", strText, reader))
                parseData(reader, PIP_exerciseData, "PIP_EXERCISE");
            else if(parseCommand("PIP_ENVIRONMENT", strText, reader))
                parseData(reader, PIP_environmentData, "PIP_ENVIRONMENT");
            else if(parseCommand("PIP_OWNSHIP", strText, reader))
                parseData(reader, PIP_ownshipData, "PIP_OWNSHIP");
            else if(parseCommand("PIP_PERISCOPE", strText, reader))
                parseData(reader, PIP_periscopeData, "PIP_PERISCOPE");
            else if(parseCommand("PIP_TARGET", strText, reader))
                parseData(reader, PIP_targetData, "PIP_TARGET");
            else if(parseCommand("PIP_RETURN", strText, reader))
                parseData(reader, PIP_returnData, "PIP_RETURN");
            //
            //IO Data.
            //
            else if(parseCommand("IO_DATA_AS1117", strText, reader))
                parseData(reader, ioAS1117Data, "IO_DATA_AS1117");
            else if(parseCommand("IO_DATA_AS1082", strText, reader))
                parseData(reader, ioAS1082Data, "IO_DATA_AS1082");

            //
            //Scenario Data
            //
            else if(parseScenarioData(strText, reader))
            {
                return;
            }

        }

        /************************************************************************
     FUNCTION      : parseGlobalButton
     DESCRIPTION   : Parses a global button
     PARAMETERS    : string       strLine    : the line read in from the file.
                 StreamReader reader     : the file stream.
     RETURNS       : true : if the line matches a global button.
     GLOBALS USED  : None
     METHOD USED   : Match the string against a set pattern.
        ************************************************************************/
        protected bool parseGlobalButton(string strLine, StreamReader reader)
        {
            string strToken;

            //
            //Match the line against the 'Menu' structure.
            //
            if(strLine == null) return false;

            strToken = firstWord(strLine);

            //
            //Check the first word read against the commands.
            //
            if(strToken.Equals("GLOBAL_BUTTON"))
            {
                strLine  = strLine.TrimStart(strToken.ToCharArray());
                strLine  = strLine.Trim();
                strToken = firstWord(strLine);

                theGUI.globalButtonList.Add(strToken);
                return true;
            }
            else
                return false;

        }

        /************************************************************************
     FUNCTION      : parseMenuOption
     DESCRIPTION   : Parses a menu option
     PARAMETERS    : string       strLine    : the line read in from the file.
                 StreamReader reader     : the file stream.
     RETURNS       : true : if the line matches a menu option.
     GLOBALS USED  : None
     METHOD USED   : Match the string against a set pattern.
        ************************************************************************/
        protected bool parseMenuOption(string strLine, StreamReader reader)
        {
            string strToken;

            //
            //Match the line against the 'Menu' structure.
            //
            if(strLine == null) return false;

            strToken = firstWord(strLine);

            //
            //Check the first word read against the commands.
            //
            if(strToken.Equals("MENU_OPTION"))
            {
                strLine = strLine.TrimStart(strToken.ToCharArray());
                strLine = strLine.Trim();
                strToken = firstWord(strLine);
                theGUI.mainMenu.mainMenuList.Add(new MenuOption("DISPLAY_MENU", strToken));

                return true;
            }
            else if(strToken.Equals("PIG_DATA_SUB_MENU"))
            {
                strLine = strLine.TrimStart(strToken.ToCharArray());
                strLine = strLine.Trim();
                strToken = firstWord(strLine);
                theGUI.mainMenu.mainMenuList.Add(new MenuOption("PIG_SUB_MENU", strToken));
                return true;
            }
            else if(strToken.Equals("PIP_DATA_SUB_MENU"))
            {
                strLine = strLine.TrimStart(strToken.ToCharArray());
                strLine = strLine.Trim();
                strToken = firstWord(strLine);
                theGUI.mainMenu.mainMenuList.Add(new MenuOption("PIP_SUB_MENU", strToken));
                return true;
            }
            return false;

        }

        /************************************************************************
     FUNCTION      : parseIODataPage
     DESCRIPTION   : Parses a IO Data page command
     PARAMETERS    : string       strLine    : the line read in from the file.
                 StreamReader reader     : the file stream.
     RETURNS       : true : if the line matches the "IO_DATA" command
     GLOBALS USED  : None
     METHOD USED   : Match the string against a set pattern.
        ************************************************************************/
        protected bool parseIODataPage(string strLine, StreamReader reader)
        {
            string strToken;

            //
            //Match the line against the 'IO_DATA' structure.
            //
            if(strLine == null) return false;

            strToken = firstWord(strLine);

            //
            //Check the first word read against the commands.
            //
            if(strToken.Equals("IO_DATA"))
            {
                strLine = strLine.TrimStart(strToken.ToCharArray());
                strLine = strLine.Trim();
                strToken = firstWord(strLine);

                if(strToken.Equals("AS1117") || (strToken.Equals("AS1118")))
                {
                    theGUI.ioDataPage = C_gui.page.IO_DATA_AS1117;
                }
                else if(strToken.Equals("AS1082"))
                {
                    theGUI.ioDataPage = C_gui.page.IO_DATA_AS1082;
                }
                return true;
            }
            else
                return false;
        }

        /************************************************************************
     FUNCTION      : parseCommand
     DESCRIPTION   : Parses a command structure such as "PIG_ENVIRONMENT"
     PARAMETERS    : string       strCommand : the command to check against
                 string       strLine    : the line read in from the file.
                 StreamReader reader     : the file stream.
     RETURNS       : true : if the line matches the command type.
     GLOBALS USED  : None
     METHOD USED   : Match the string against a set pattern.
        ************************************************************************/
        protected bool parseCommand(string strCommand, string strLine, StreamReader reader)
        {
            string strNextLine;

            //
            //Match the command 'strCommand' to the current line.
            //
            if(strLine.Equals(strCommand))
            {

                //
                //The line following the command should be an open brace '}'
                //
                strNextLine = reader.ReadLine();
                if(strNextLine == null)
                    return false;

                else if(strNextLine.Equals("{"))
                {
                    return true;
                }
            }

            return false;
        }

        /************************************************************************
     FUNCTION      : parseComment
     DESCRIPTION   : Parses a comment line.
     PARAMETERS    : string strLine : the line read in from the file.
     RETURNS       : true  : if the line is a comment
                     false : if the line isnt.
     GLOBALS USED  : None
     METHOD USED   : Determines if the first character is '#'.
        ************************************************************************/
        protected bool parseComment(string strLine)
        {
            //
            //A comment is a line starting with a '#' character.
            //
            if(strLine.Length > 0)
            {
                if(strLine.ToCharArray()[0] == '#')
                    return true; //The line is a comment, return true.
            }
            return false;
        }

        /************************************************************************
     FUNCTION      : parseData
     DESCRIPTION   : Parses a generic data block.
                     Each datablock consists of entries with a set pattern:
                 'TOKEN <min_value> <max_value> <default_value>'
     PARAMETERS    : StreamReader  reader     : The file stream.
                     DataFields [] dataBlock  : The datablock, contains a list of strings which are
                                            matched against the file. e.g. "WEATHER"
                 string        strDataPage: The gui page the data block belongs to
     RETURNS       : bool : Success or failure of data parse.
     GLOBALS USED  : None
     METHOD USED   : Matches the file against a list of tokens. If the token is found
                     the data (max,min,default values etc) are entered into a hashtable
                 with the token as the key.
        ************************************************************************/
        protected bool parseData(StreamReader reader, DataFields [] dataFields, string strDataPage)
        {
            string strText;
            bool   match = false;
            string fWord = "";

            strText = reader.ReadLine();

            //
            //No line has been read, so return false.
            //
            if(strText == null)
                return false;

            do
            {
                //
                //Skip blank lines.
                //
                if(strText == null)
                    continue;

                //
                //Trim whitespace from the head and tail of the string.
                //
                strText = strText.Trim();

                //If this line is a comment then parse the next line.
                if(parseComment(strText))
                {
                }
                else
                {
                    //
                    //Find the first word on the line. E.g. "WEATHER 1 2 3" would return "WEATHER"
                    //
                    match = false;
                    fWord = firstWord(strText);

                    //
                    //Match each line against the data block. If the line is matched against a data block entry
                    //the data is stored in a hash table with the token (e.g. 'PIG_ENVIRONMENT_WEATHER') as the key.
                    //
                    for(int i = 0; i < dataFields.Length ; i++)
                    {
                        if(fWord.Equals(dataFields[i].token))
                        {
                            string strValues;
                            string strError = "";
                            string strHashKey;
                            object [] values = new object[4];

                            //
                            //A token match has been made, now look for the data values.
                            //
                            match     = true;
                            strValues = strText.TrimStart(dataFields[i].token.ToCharArray());

                            if(!parseValues(strValues, ref strError, ref values))
                            {
                                System.Console.WriteLine("Error: Reading Values for {0}", dataFields[i].token);
                                System.Console.WriteLine("       " + strError);
                            }
                            else
                            {
                                //
                                //Store the data values.
                                //
                                dataFields[i].fMin           = Single.Parse(values[0].ToString());
                                dataFields[i].fMax           = Single.Parse(values[1].ToString());
                                dataFields[i].fDefault       = Single.Parse(values[2].ToString());
                                dataFields[i].strDescription = values[3].ToString();

                                strHashKey = strDataPage + "_" + dataFields[i].token;
                                theGUI.hashtable.Add(strHashKey, dataFields[i]);

                            }
                        }
                    }

                    //
                    //If no match has been made with a data field then the token is either a closing brace '}'
                    //or an error in the data file.
                    //
                    if(!match)
                    {
                        if(strText.Equals("}"))
                            return true;
                        else if (strText.Equals (""))
                        {
                            //Ignore blank lines.
                        }
                        else
                        {
                            System.Console.WriteLine("Invalid line in {0} Data : '{1}'", strDataPage, strText);
                            System.Console.WriteLine("Perhaps you are missing a closing brace '}' ?");
                            return false;
                        }
                    }
                }
                strText = reader.ReadLine();
            }
            while(strText != null);

            return true;
        }

        /************************************************************************
     FUNCTION      : parseValues
     DESCRIPTION   :
     PARAMETERS    : string strLine    :  the line read in from the file.
                     string strError   : (ref) string to return an error message
                 object [] oValues : (ref) to return the values upon successful read.
     RETURNS       : bool : success / failure or parse.
     GLOBALS USED  : None
     METHOD USED   :
        ************************************************************************/
        protected bool parseValues( string strText , ref string strError, ref object [] oValues)
        {
            char   [] chars = {' ', '\t'};
            char   [] newlineChars = {'\\', 'n'};
            string [] substrings;
            int iIndex;

            //
            //Expecting three values seperated by whitespace.
            //
            for(int i = 0 ; i < 3 ; i++)
            {
                //
                //If no values have been read then return.
                //
                if(strText == null)
                {
                    createErrorMessage(ref strError, i, false);
                    return false;
                }

                //
                //Trim whitespace from the tail and end of the string.
                //
                strText = strText.Trim();

                //
                //Split the string at the first occurence of whitespace.
                //
                substrings = strText.Split(chars, 2);

                //If there were no values to split then simply return.
                if(substrings.Length == 0)
                {
                    createErrorMessage(ref strError, i, false);
                    return false;
                }

                //
                //Otherwise, parse the value which was found.
                //
                if(substrings.Length == 1)
                {
                    try
                    {
                        oValues[i]  = Single.Parse(substrings[0]);
                    }
                    catch(FormatException)
                    {
                        createErrorMessage(ref strError, i, true);
                        return false;
                    }

                    strText    = "";
                }
                else
                {
                    try
                    {
                        oValues[i]  = Single.Parse(substrings[0]);
                    }
                    catch(FormatException)
                    {
                        createErrorMessage(ref strError, i, true);
                        return false;
                    }
                    strText    = substrings[1];
                    strText    = strText.Trim();
                }
            }

            //
            //Determine if there is a description string.
            //
            if(strText != null)
            {

                //Determine if the text is split over more than one line
                iIndex = strText.IndexOf("\\n",0);

                if(iIndex > 0)
                {
                    string strSub1;
                    string strSub2;

                    strSub1 = strText.Substring(0, iIndex);
                    strSub2 = strText.Substring(iIndex, strText.Length - iIndex );
                    strSub2 = strSub2.TrimStart(newlineChars);
                    strText = strSub1 + "\n" + strSub2;
                }

                //save the string.
                oValues[3] = strText;
            }

            //The values were read sucessfully.
            return true;
        }

        /************************************************************************
     FUNCTION      : parseScenarioData
     DESCRIPTION   : Parses scenario data
     PARAMETERS    : string       strLine    : the line read in from the file.
                 StreamReader reader     : the file stream.
     RETURNS       : true : if the line matches a global button.
     GLOBALS USED  : None
     METHOD USED   : Match the string against a set pattern.
        ************************************************************************/
        protected bool parseScenarioData(string strLine, StreamReader reader)
        {
            string strToken;

            string strName;
            string strDescription;
            string strIndex;

            ScenarioData scenarioData = new ScenarioData();

            //
            //Match the line against the 'Menu' structure.
            //
            if(strLine == null) return false;

            strToken = firstWord(strLine);

            //
            //Check the first word read against the commands.
            //
            if(strToken.Equals("SCENARIO"))
            {
                strLine  = strLine.TrimStart(strToken.ToCharArray());
                strLine  = strLine.Trim();
                strName = findString(strLine);

                //Trim the name from the string
                strLine  = strLine.TrimStart("\"".ToCharArray());
                strLine  = strLine.Trim();
                strLine  = strLine.TrimStart(strName.ToCharArray());
                strLine  = strLine.Trim();
                strLine  = strLine.TrimStart("\"".ToCharArray());
                strLine  = strLine.Trim();

                //Trim the description from the string
                strDescription = findString(strLine);
                strLine  = strLine.TrimStart("\"".ToCharArray());
                strLine  = strLine.Trim();
                strLine  = strLine.TrimStart(strDescription.ToCharArray());
                strLine  = strLine.Trim();
                strLine  = strLine.TrimStart("\"".ToCharArray());
                strLine  = strLine.Trim();

                strIndex = findString(strLine);

                scenarioData.strName = strName;
                scenarioData.strDescription = strDescription;

                try
                {
                    scenarioData.iIndex = Int32.Parse(strIndex);
                    theGUI.scenariosList.Add(scenarioData);
                }
                catch(FormatException e)
                {
                    System.Console.WriteLine("Index is not a valid integer {0}", e);
                    return false;
                }

                return true;
            }
            else
                return false;

        }

        void createErrorMessage(ref string strError, int i, bool exception)
        {
            if(exception)
            {
                switch(i)
                {
                    case 0:
                        strError = "The first value is not a number";
                        break;
                    case 1:
                        strError = "The second value is not a number";
                        break;
                    case 2:
                        strError = "The third value is not a number";
                        break;
                }
            }
            else
            {
                switch(i)
                {
                    case 0:
                        strError = "Error Reading the first value";
                        break;
                    case 1:
                        strError = "Error Reading the second value";
                        break;
                    case 2:
                        strError = "Error Reading the third value";
                        break;
                }
            }
        }

        public string findString(string strText)
        {
            char   [] chars = {'"'};
            string [] substrings;

            //
            //If the search string is null then return null.
            //
            if(strText == null)
                return null;

            //
            //Remove the opening brace from the head of the name string.
            //
            strText = strText.TrimStart(chars);

            //Split the string at the first occurence of '"'.
            substrings = strText.Split(chars, 2);

            //If there were no values to split then simply return (null).
            if(substrings.Length == 0)
            {
                System.Console.WriteLine("Error Missing opening or closing quotation mark (\") ");
                return null;
            }

            //
            //Otherwise, return the substring before the split.
            //
            return substrings[0];
        }


        public string firstWord(string strText)
        {
            char   [] chars = {' ', '\t'};
            string [] substrings;

            //
            //If the search string is null then return null.
            //
            if(strText == null)
                return null;

            //
            //Trim whitespace from the tail and end of the string.
            //
            strText = strText.Trim();

            //Split the string at the first occurence of whitespace.
            substrings = strText.Split(chars, 2);

            //If there were no values to split then simply return (null).
            if(substrings.Length == 0)
                return null;

            //
            //Otherwise, return the substring before the split.
            //
            return substrings[0];
        }

    }
}
