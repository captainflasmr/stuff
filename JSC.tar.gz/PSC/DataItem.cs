//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//                 The software is supplied by BAE Systems Ltd on the express terms
//                 that it is to be treated as confidential, and that it may not
//                 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Simulation Control
// Module Title        : DataItem.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

// ------------------
// Using directives
// ------------------
// System packages

namespace PSCGenericBuild
{
    /// <summary>
    /// These are the DataItem classes that are used to declare any Sim Control data items
    /// Classes are for different types: byte, float, short, int, double, bool
    /// </summary>
    ///


    // -----------------
    // DataItem BYTE
    // -----------------
    public class DataItemByte
    {
        // ------------
        // Constructor
        // ------------
        public DataItemByte()
        {
        }

        // ----------------
        // Set Raw Value
        // ----------------
        public void SetRawValue(byte data)
        {
            m_RawValue = data;
        }


        // -----------------
        // Get Raw Value
        // -----------------
        public byte GetRawValue()
        {
            return (m_RawValue);
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(C_DataStoreItemByte data)
        {
            m_OverRideFlag = data.Flag;
            m_OverRideValue = data.Value;
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(DataItemByte data)
        {
            m_OverRideFlag = data.m_OverRideFlag;
            m_OverRideValue = data.m_OverRideValue;
        }

        // ------------------
        // Set Status Value
        // ------------------
        public void SetStatus(int data)
        {
            m_StatusFlag = true;
            m_StatusValue = data;
        }

        // ------------------
        // Get Status Value
        // ------------------
        public int GetStatus()
        {
            int result;

            if (m_StatusFlag)
            {
                // if (m_OverRideFlag)
                // result = IOComms.IO_OVERRIDE;
                // else
                result = m_StatusValue;
            }
            // else
            // {
            // result = IOComms.IO_UNKNOWN;
            // }

            return 1;
        }


        // --------------------
        // Get Resultant Value
        // --------------------
        public byte GetResultValue()
        {
            byte result;

            // The result value depends on whether or not the override is set
            if (m_OverRideFlag == false)
                result = m_RawValue;
            else
                result = m_OverRideValue;

            return (result);
        }

        // -------------------------
        // Private Data and Methods
        // -------------------------

        private bool   m_OverRideFlag;

        private byte   m_RawValue;
        private byte   m_OverRideValue;

        private bool   m_StatusFlag;
        private int    m_StatusValue;

    }


    // -----------------
    // DataItem FLOAT
    // -----------------
    public class DataItemFloat
    {
        // ------------
        // Constructor
        // ------------
        public DataItemFloat()
        {
        }

        // ----------------
        // Set Raw Value
        // ----------------
        public void SetRawValue(float data)
        {
            m_RawValue = data;
        }


        // ----------------
        // Set Raw Value
        // ----------------
        public void SetRawValue(double data)
        {
            m_RawValue = (float) data;
        }

        // -----------------
        // Get Raw Value
        // -----------------
        public float GetRawValue()
        {
            return (m_RawValue);
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(C_DataStoreItemFloat data)
        {
            m_OverRideFlag = data.Flag;
            m_OverRideValue = data.Value;
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(DataItemFloat data)
        {
            m_OverRideFlag = data.m_OverRideFlag;
            m_OverRideValue = data.m_OverRideValue;
        }

        // ------------------
        // Set Status Value
        // ------------------
        public void SetStatus(int data)
        {
            m_StatusFlag = true;
            m_StatusValue = data;
        }

        // ------------------
        // Get Status Value
        // ------------------
        public int GetStatus()
        {
            int result;

            if (m_StatusFlag)
            {
                // if (m_OverRideFlag)
                // result = IOComms.IO_OVERRIDE;
                // else
                result = m_StatusValue;
            }
            // else
            // {
            // result = IOComms.IO_UNKNOWN;
            // }

            return 1;
        }

        // --------------------
        // Get Resultant Value
        // --------------------
        public float GetResultValue()
        {
            float result;

            // The result value depends on whether or not the override is set
            if (m_OverRideFlag == false)
                result = m_RawValue;
            else
                result = m_OverRideValue;

            return (result);
        }

        // -------------------------
        // Private Data and Methods
        // -------------------------

        private bool   m_OverRideFlag;

        private float  m_RawValue;
        private float  m_OverRideValue;

        private bool   m_StatusFlag;
        private int    m_StatusValue;

    }


    // -----------------
    // DataItem SHORT
    // -----------------
    public class DataItemShort
    {
        // ------------
        // Constructor
        // ------------
        public DataItemShort()
        {
        }

        // ----------------
        // Set Raw Value
        // ----------------
        public void SetRawValue(short data)
        {
            m_RawValue = data;
        }

        // -----------------
        // Get Raw Value
        // -----------------
        public short GetRawValue()
        {
            return (m_RawValue);
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(C_DataStoreItemShort data)
        {
            m_OverRideFlag = data.Flag;
            m_OverRideValue = data.Value;
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(DataItemShort data)
        {
            m_OverRideFlag = data.m_OverRideFlag;
            m_OverRideValue = data.m_OverRideValue;
        }

        // ------------------
        // Set Status Value
        // ------------------
        public void SetStatus(int data)
        {
            m_StatusFlag = true;
            m_StatusValue = data;
        }

        // ------------------
        // Get Status Value
        // ------------------
        public int GetStatus()
        {
            int result;

            if (m_StatusFlag)
            {
                // if (m_OverRideFlag)
                // result = IOComms.IO_OVERRIDE;
                // else
                result = m_StatusValue;
            }
            // else
            // {
            // result = IOComms.IO_UNKNOWN;
            // }

            return 1;

        }


        // --------------------
        // Get Resultant Value
        // --------------------
        public short GetResultValue()
        {
            short result;

            // The result value depends on whether or not the override is set
            if (m_OverRideFlag == false)
                result = m_RawValue;
            else
                result = m_OverRideValue;

            return (result);
        }

        // -------------------------
        // Private Data and Methods
        // -------------------------

        private bool   m_OverRideFlag;

        private short  m_RawValue;
        private short  m_OverRideValue;

        private bool   m_StatusFlag;
        private int    m_StatusValue;

    }

    // -----------------
    // DataItem LONG
    // -----------------
    public class DataItemLong
    {
        // ------------
        // Constructor
        // ------------
        public DataItemLong()
        {
        }

        // ----------------
        // Set Raw Value
        // ----------------
        public void SetRawValue(long data)
        {
            m_RawValue = data;
        }


        // -----------------
        // Get Raw Value
        // -----------------
        public long GetRawValue()
        {
            return (m_RawValue);
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(C_DataStoreItemLong data)
        {
            m_OverRideFlag = data.Flag;
            m_OverRideValue = data.Value;
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(DataItemLong data)
        {
            m_OverRideFlag = data.m_OverRideFlag;
            m_OverRideValue = data.m_OverRideValue;
        }

        // ------------------
        // Set Status Value
        // ------------------
        public void SetStatus(int data)
        {
            m_StatusFlag = true;
            m_StatusValue = data;
        }

        // ------------------
        // Get Status Value
        // ------------------
        public int GetStatus()
        {
            int result;

            if (m_StatusFlag)
            {
                // if (m_OverRideFlag)
                // result = IOComms.IO_OVERRIDE;
                // else
                result = m_StatusValue;
            }
            // else
            // {
            // result = IOComms.IO_UNKNOWN;
            // }

            return 1;

        }


        // --------------------
        // Get Resultant Value
        // --------------------
        public long GetResultValue()
        {
            long result;

            // The result value depends on whether or not the override is set
            if (m_OverRideFlag == false)
                result = m_RawValue;
            else
                result = m_OverRideValue;

            return (result);
        }

        // -------------------------
        // Private Data and Methods
        // -------------------------

        private bool   m_OverRideFlag;

        private long   m_RawValue;
        private long   m_OverRideValue;

        private bool   m_StatusFlag;
        private int    m_StatusValue;

    }

    // -----------------
    // DataItem INT
    // -----------------
    public class DataItemInt
    {
        // ------------
        // Constructor
        // ------------
        public DataItemInt()
        {
        }

        // ----------------
        // Set Raw Value
        // ----------------
        public void SetRawValue(int data)
        {
            m_RawValue = data;
        }


        // -----------------
        // Get Raw Value
        // -----------------
        public int GetRawValue()
        {
            return (m_RawValue);
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(C_DataStoreItemInt data)
        {
            m_OverRideFlag = data.Flag;
            m_OverRideValue = data.Value;
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(DataItemInt data)
        {
            m_OverRideFlag = data.m_OverRideFlag;
            m_OverRideValue = data.m_OverRideValue;
        }

        // ------------------
        // Set Status Value
        // ------------------
        public void SetStatus(int data)
        {
            m_StatusFlag = true;
            m_StatusValue = data;
        }

        // ------------------
        // Get Status Value
        // ------------------
        public int GetStatus()
        {
            int result;

            if (m_StatusFlag)
            {
                // if (m_OverRideFlag)
                // result = IOComms.IO_OVERRIDE;
                // else
                result = m_StatusValue;
            }
            // else
            // {
            // result = IOComms.IO_UNKNOWN;
            // }

            return 1;

        }


        // --------------------
        // Get Resultant Value
        // --------------------
        public int GetResultValue()
        {
            int result;

            // The result value depends on whether or not the override is set
            if (m_OverRideFlag == false)
                result = m_RawValue;
            else
                result = m_OverRideValue;

            return (result);
        }

        // -------------------------
        // Private Data and Methods
        // -------------------------

        private bool   m_OverRideFlag;

        private int    m_RawValue;
        private int    m_OverRideValue;

        private bool   m_StatusFlag;
        private int    m_StatusValue;

    }

    // -----------------
    // DataItem DOUBLE
    // -----------------
    public class DataItemDouble
    {
        // ------------
        // Constructor
        // ------------
        public DataItemDouble()
        {
        }

        // ----------------
        // Set Raw Value
        // ----------------
        public void SetRawValue(double data)
        {
            m_RawValue = data;
        }


        // -----------------
        // Get Raw Value
        // -----------------
        public double GetRawValue()
        {
            return (m_RawValue);
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(C_DataStoreItemDouble data)
        {
            m_OverRideFlag = data.Flag;
            m_OverRideValue = data.Value;
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(DataItemDouble data)
        {
            m_OverRideFlag = data.m_OverRideFlag;
            m_OverRideValue = data.m_OverRideValue;
        }


        // ------------------
        // Set Status Value
        // ------------------
        public void SetStatus(int data)
        {
            m_StatusFlag = true;
            m_StatusValue = data;
        }

        // ------------------
        // Get Status Value
        // ------------------
        public int GetStatus()
        {
            int result;

            if (m_StatusFlag)
            {
                // if (m_OverRideFlag)
                // result = IOComms.IO_OVERRIDE;
                // else
                result = m_StatusValue;
            }
            // else
            // {
            // result = IOComms.IO_UNKNOWN;
            // }

            return 1;

        }


        // --------------------
        // Get Resultant Value
        // --------------------
        public double GetResultValue()
        {
            double result;

            // The result value depends on whether or not the override is set
            if (m_OverRideFlag == false)
                result = m_RawValue;
            else
                result = m_OverRideValue;

            return (result);
        }

        // -------------------------
        // Private Data and Methods
        // -------------------------

        private bool   m_OverRideFlag;

        private double m_RawValue;
        private double m_OverRideValue;

        private bool   m_StatusFlag;
        private int    m_StatusValue;

    }

    // -----------------
    // DataItem BOOL
    // -----------------
    public class DataItemBool
    {
        // ------------
        // Constructor
        // ------------
        public DataItemBool()
        {
        }

        // ----------------
        // Set Raw Value
        // ----------------
        public void SetRawValue(bool data)
        {
            m_RawValue = data;
        }


        // -----------------
        // Get Raw Value
        // -----------------
        public bool GetRawValue()
        {
            return (m_RawValue);
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(C_DataStoreItemBool data)
        {
            m_OverRideFlag = data.Flag;
            m_OverRideValue = data.Value;
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(DataItemBool data)
        {
            m_OverRideFlag = data.m_OverRideFlag;
            m_OverRideValue = data.m_OverRideValue;
        }

        // ------------------
        // Set Status Value
        // ------------------
        public void SetStatus(int data)
        {
            m_StatusFlag = true;
            m_StatusValue = data;
        }

        // ------------------
        // Get Status Value
        // ------------------
        public int GetStatus()
        {
            int result;

            if (m_StatusFlag)
            {
                // if (m_OverRideFlag)
                // result = IOComms.IO_OVERRIDE;
                // else
                result = m_StatusValue;
            }
            // else
            // {
            // result = IOComms.IO_UNKNOWN;
            // }

            return 1;

        }


        // --------------------
        // Get Resultant Value
        // --------------------
        public bool GetResultValue()
        {
            bool result;

            // The result value depends on whether or not the override is set
            if (m_OverRideFlag == false)
                result = m_RawValue;
            else
                result = m_OverRideValue;

            return (result);
        }

        // -------------------------
        // Private Data and Methods
        // -------------------------

        private bool   m_OverRideFlag;

        private bool   m_RawValue;
        private bool   m_OverRideValue;

        private bool   m_StatusFlag;
        private int    m_StatusValue;

    }


    // -----------------
    // DataItem STRING
    // -----------------
    public class DataItemString
    {
        // ------------
        // Constructor
        // ------------
        public DataItemString()
        {
        }

        // ----------------
        // Set Raw Value
        // ----------------
        public void SetRawValue(string data)
        {
            m_RawValue = data;
        }


        // -----------------
        // Get Raw Value
        // -----------------
        public string GetRawValue()
        {
            return (m_RawValue);
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(C_DataStoreItemString data)
        {
            m_OverRideFlag = data.Flag;
            m_OverRideValue = data.Value;
        }

        // ----------------------------
        // Set Override Flag and Value
        // ----------------------------
        public void SetOverride(DataItemString data)
        {
            m_OverRideFlag = data.m_OverRideFlag;
            m_OverRideValue = data.m_OverRideValue;
        }

        // ------------------
        // Set Status Value
        // ------------------
        public void SetStatus(int data)
        {
            m_StatusFlag = true;
            m_StatusValue = data;
        }

        // ------------------
        // Get Status Value
        // ------------------
        public int GetStatus()
        {
            int result;

            if (m_StatusFlag)
            {
                // if (m_OverRideFlag)
                // result = IOComms.IO_OVERRIDE;
                // else
                result = m_StatusValue;
            }
            // else
            // {
            // result = IOComms.IO_UNKNOWN;
            // }

            return 1;

        }


        // --------------------
        // Get Resultant Value
        // --------------------
        public string GetResultValue()
        {
            string result;

            // The result value depends on whether or not the override is set
            if (m_OverRideFlag == false)
                result = m_RawValue;
            else
                result = m_OverRideValue;

            return (result);
        }

        // -------------------------
        // Private Data and Methods
        // -------------------------

        private bool   m_OverRideFlag;

        private string m_RawValue;
        private string m_OverRideValue;

        private bool   m_StatusFlag;
        private int    m_StatusValue;

    }
}
