//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//                    The software is supplied by BAE Systems Ltd on the express terms
//                    that it is to be treated as confidential, and that it may not
//                    be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Simulation Control
// Module Title        : SIMControl.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

// ------------------
// Using directives
// ------------------
// System packages
using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Collections;
using System.Collections.Generic;
using System.Xml;

// ------------------
// Class declaration
// ------------------

namespace PSCGenericBuild
{

    /// <summary>
    /// Simulation Control Class
    /// This is the main application class.
    /// It creates and controls the top-level objects:
    /// SIM Control, PIP Comms, PIG Comms, IO Comms and GUI Thread.
    /// </summary>
    public class SIMControl
    {
        static bool ftt = true;
        static public SIMControl SimControl;
        static public SimCIGI m_SimCIGI;
        static Mutex mutexData;

[DllImport("Kernel32.dll")]
public static extern bool QueryPerformanceCounter(out long value);

[DllImport("Kernel32.dll")]
public static extern bool QueryPerformanceFrequency(out long value);
        public const int NUM_PERI_TARGETS = 156;
        public const int NUM_POLYNIA_TARGETS = 10;

        /// <summary>
        /// This is the main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main(string[] args)
        {
            //
            // Create Sim Control object
            //
            SimControl = new SIMControl();

            m_SimCIGI = new SimCIGI(SimControl);

            //
            // Create mutex for shared data between the Main Thread and
            // the GUI Thread
            //
            mutexData = new Mutex(false, "mutexData");

            //
            // Create high-performance timer for controlling
            // the Main Thread iteration
            //
            // long delta = 0;
            long freqUpdate;
            long timeStamp1;
            long timeStamp2;

            QueryPerformanceFrequency(out SimControl.m_TimerFreq);
            QueryPerformanceCounter(out timeStamp1);
            QueryPerformanceCounter(out timeStamp2);
            freqUpdate = (long)(((double)SimControl.m_TimerFreq / 1000.0) * (1000.0 / SimControl.m_AppIterationRate));

            //
            // Main run loop
            //
            while (SimControl.m_SIMRunApp)
            {
                //
                // Update the high-performance timer
                //
                // QueryPerformanceCounter(out timeStamp1);
                // delta += (timeStamp1 - timeStamp2);
                // timeStamp2 = timeStamp1;

                //
                // Perform update at correct time
                //
                // if (delta >= freqUpdate)
                // {
                // Calculate the iteration delta time
                // SimControl.m_DeltaTime = ((double)delta / (double)(SimControl.m_TimerFreq));

                // Reset delta
                // delta = 0;

                Console.WriteLine("Tick");
                // Call SimControl Update which then updates other top-level objects
                SimControl.Update();
                // }

                Thread.Sleep(500);
            }


            //
            // Shutdown Application
            //
            SimControl.Shutdown();

        }

        public int count = 0;

        // -------------
        // Constructor
        // -------------
        public SIMControl()
        {
            int i;
            int j;

            //
            // Initialise data values
            //

            m_SIMRunApp = true;
            m_SIMOriginSet = false;

            m_PIPBytesIn = 0;
            m_PIPBytesOut = 0;
            m_PIPMessageCountIn = 0;
            m_PIPMessageCountOut = 0;
            m_PIPAverageTimeIn = 0.0f;
            m_PIPAverageTimeOut = 0.0f;

            m_PIGBytesIn = 0;
            m_PIGBytesOut = 0;
            m_PIGMessageCountIn = 0;
            m_PIGMessageCountOut = 0;
            m_PIGAverageTimeIn = 0.0f;
            m_PIGAverageTimeOut = 0.0f;

            m_PIPArrayTimesIn = new long[10];
            m_PIPArrayTimesOut = new long[10];
            m_PIGArrayTimesIn = new long[10];
            m_PIGArrayTimesOut = new long[10];

            for ( i = 0; i < 10 ; i++)
            {
                m_PIPArrayTimesIn[i] = 0;
                m_PIGArrayTimesIn[i] = 0;
            }

            for ( i = 0; i < 10 ; i++)
            {
                m_PIPArrayTimesOut[i] = 0;
                m_PIGArrayTimesOut[i] = 0;
            }


            m_SIMNewExData = false;
            m_SIMNewEnvData = false;
            m_SIMNewOwnData = false;
            m_SIMNewTarData = false;

            m_SIMOwnMastHeight = new float[10];

            m_SIMTarInitialised = false;
            m_SIMTargets = new SIMTargetData[SIM_NUMBER_TARGETS];

            for (i = 0; i < SIM_NUMBER_TARGETS; i++)
                m_SIMTargets[i].m_SIMTarStatus = SIM_TARGET_NOT_PRESENT;

            // Elevation limits
            m_SIMElevationMin = -15.0f;
            m_SIMElevationMax = 60.0f;

            // Thermal controls
            m_ThermalControls = true;


            // These should be overridden by the network config file
            m_AppIterationRate = 60;
            m_IterationTime = 1.0f / m_AppIterationRate;
            m_PrintTimings = false;
            m_PrintTWSHBits = false;
            m_IPAddressPIPNet = IPAddress.Parse("192.9.218.2");
            m_PortPIPNet = 7500;
            m_IPAddressPIPNet = IPAddress.Parse("141.196.32.122");
            m_PortPIPNet = 7710;

            //
            // Initialise Error Log (fixed size buffer)
            //
            m_SIMErrorLogIndex = 0;

            m_SIMErrorLog = new ErrorLog[SIM_ERRORLOG_SIZE];

            for (i = 0; i < SIM_ERRORLOG_SIZE; i++)
            {
                m_SIMErrorLog[i].m_ErrorTime = "";
                m_SIMErrorLog[i].m_ErrorType = "";
                m_SIMErrorLog[i].m_ErrorSource = "";
            }

            //
            // Configure mast data
            //
            m_SIMOwnMastMaxExt = new float[2,10];
            m_SIMOwnMastSpeed = new float[2,10];

            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 10; j++)
                {
                    m_SIMOwnMastMaxExt[i,j] = 10.0f;
                    m_SIMOwnMastSpeed[i,j] = 1.0f;
                }
            }

            ConfigureMastData();


            //
            // Configure model database
            //
            m_Models = new ModelDatabase[SIM_MAX_MODELS];

            for (i = 0; i < SIM_MAX_MODELS; i++)
            {
                m_Models[i].m_Name = "Undefined";
                m_Models[i].m_Width = 100.0f;
                m_Models[i].m_Height = 100.0f;
                m_Models[i].m_Length = 100.0f;
            }

            ConfigureModelDatabase();

            bool printModels = true;

            if (printModels)
            {
                for (i = 0; i < SIM_MAX_MODELS; i++)
                {
                    if (m_Models[i].m_Name != "Undefined")
                    {
                        Console.Write("{0}: {1}", i, m_Models[i].m_Name);

                        if (m_Models[i].m_Name.Length < 11)
                            Console.Write("\t");

                        Console.Write("\tW:{0}, \tL:{1}, \tH:{2}\n", m_Models[i].m_Width, m_Models[i].m_Length, m_Models[i].m_Height);
                    }
                }
            }


            //
            // Create data items for SIMControl
            //
            CreatePIGDataItems();
            CreatePIPDataItems();
            CreateIODataItems();
            CreateGUIDataItems();


            //
            // Configure the network settings by reading the network configuration File
            // and creating the required Comms Objects
            //
            ConfigureNetwork();

            // Set the update time for PIP input data
            m_PIPDeltaTime = m_PIPRateIn * m_IterationTime;


            //
            // Create the IO Comms
            //
            // m_IOComms = new IOComms(this);


            //
            // Create and start the GUI Thread
            //
            m_GUI = new C_gui(this);
            m_GUI.initialise();
            m_GUIThread = new Thread(new ThreadStart(m_GUI.start));
            m_GUIThread.Start();

            //
            // Write comfirmation of initialisation
            //
            Console.WriteLine("Sim Control: Sim Control Initialised.");

        }



        // ------------------
        // Shutdown Method
        // ------------------
        public void Shutdown()
        {

            // Print shutdown message
            Console.WriteLine("");
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("");
            Console.WriteLine("Sim Control: Shutdown in process...please wait");
            Console.WriteLine("");
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("");

            // Shutdown Comms Objects
            m_PIGComms = null;
            m_PIPComms = null;
            // m_IOComms = null;

            // Garbage Collection
            GC.Collect();
            GC.WaitForPendingFinalizers();

            // Shutdown Simulation Control
            Console.WriteLine("Sim Control: Sim Control Shutdown.");

        }



        // --------------------
        // Update Method
        // --------------------
        public void Update()
        {
            double deltaTime;
            double totalTime;


            //
            // Update SimControl logic processing
            //

            // Set SimControl TimeStamp 1
            QueryPerformanceCounter(out m_SIMTimeStamp1);

            // Call Process Methods
            ProcessExercise();
            ProcessEnvironment();
            // ProcessOwnboat();
            // ProcessPeriscope();
            // ProcessTargets();
            // ProcessCuts();
            // ProcessPolynia();
            // ProcessPIPReturn();
            // ProcessIO();
            // ProcessErrorLog();
            // ProcessNetworkTiming();
            m_SimCIGI.ProcessCIGI();


            // Set SimControl TimeStamp 2
            QueryPerformanceCounter(out m_SIMTimeStamp2);


            //
            // Update PIG Comms
            //
            if (m_PIGComms != null)
            {
                // Set PIGComms TimeStamp 1
                QueryPerformanceCounter(out m_PIGTimeStamp1);

                // Call Update
                m_PIGComms.Update();

                // Set PIGComms TimeStamp 2
                QueryPerformanceCounter(out m_PIGTimeStamp2);
            }


            //
            // Update PIP Comms
            //
            if (m_PIPComms != null)
            {
                // Set PIPComms TimeStamp 1
                QueryPerformanceCounter(out m_PIPTimeStamp1);

                // Call Update
                m_PIPComms.Update();

                // Set PIPComms TimeStamp 2
                QueryPerformanceCounter(out m_PIPTimeStamp2);
            }


            //
            // Update IO Comms
            //
            // if (m_IOComms != null)
            // {
            //    // Set IOComms TimeStamp 1
            //    QueryPerformanceCounter(out m_IOTimeStamp1);

            //    // Call Update
            //    m_IOComms.Update();

            //    // Set IOComms TimeStamp 2
            //    QueryPerformanceCounter(out m_IOTimeStamp2);
            // }

            //
            // Calculate and print out the measured update times
            //
            if (m_PrintTimings == true)
            {
                totalTime = 0.0;

                Console.WriteLine("");
                Console.WriteLine("Timings (ms)...");

                m_SIMDelta = (m_SIMTimeStamp2 - m_SIMTimeStamp1);
                deltaTime = ((double)m_SIMDelta / (double)(m_TimerFreq));
                totalTime += deltaTime;
                Console.WriteLine("SIM \t: {0}", deltaTime*1000.0);

                if (m_PIPComms != null)
                {
                    m_PIPDelta = (m_PIPTimeStamp2 - m_PIPTimeStamp1);
                    deltaTime = ((double)m_PIPDelta / (double)(m_TimerFreq));
                    totalTime += deltaTime;
                    Console.WriteLine("PIP \t: {0}", deltaTime*1000.0);
                }

                if (m_PIGComms != null)
                {
                    m_PIGDelta = (m_PIGTimeStamp2 - m_PIGTimeStamp1);
                    deltaTime = ((double)m_PIGDelta / (double)(m_TimerFreq));
                    totalTime += deltaTime;
                    Console.WriteLine("PIG \t: {0}", deltaTime*1000.0);
                }

                // if (m_IOComms != null)
                // {
                //   m_IODelta = (m_IOTimeStamp2 - m_IOTimeStamp1);
                //   deltaTime = ((double)m_IODelta / (double)(m_TimerFreq));
                //   totalTime += deltaTime;
                //   Console.WriteLine("IO \t: {0}", deltaTime * 1000.0);
                // }

                Console.WriteLine("TOTAL \t: {0}", totalTime * 1000.0);
                Console.WriteLine("UPDATE \t: {0}", m_DeltaTime * 1000.0);
                Console.WriteLine("");
            }

            //
            // Update the GUI data
            //
            UpdateGUIData();
        }

        // ----------------------------------------
        // Normalise an angle to the range 0 to 360
        // ----------------------------------------
        private double NormalisedAngle (double angle)
        {
            double result;

            result = Math.IEEERemainder(angle, 360.0);

            if (result < 0.0) result += 360.0;

            return result;
        }


        // ---------------------------------
        // Configure the Network Method
        // ---------------------------------
        private void ConfigureNetwork()
        {
            String   filename = "NetworkConfig.txt";

            Encoding fileEncoding = Encoding.UTF8;

            try
            {
                // Attempt to open the input file for read-only access
                FileStream fsIn = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read);
                StreamReader sr = new StreamReader(fsIn, fileEncoding, true);

                // Process every line in the file
                for (String Line = sr.ReadLine(); Line != null; Line = sr.ReadLine())
                {
                    ProcessLine(Line);
                }

                // Explicitly close the StreamReader to properly flush all buffers
                sr.Close(); // This also closes the FileStream (fsIn)
            }
            catch (FileNotFoundException)
            {
                // The specified input file could not be opened
                Console.WriteLine("{0} file not found!", filename);
            }
        }



        // ---------------------------------
        // Process a line in the text file
        // ---------------------------------
        private void ProcessLine(String Line)
        {

            int i;

            // Ignore lines starting with #
            if (Line.StartsWith("#"))
                return;

            // Ensure uppercase
            Line = Line.ToUpper();

            // Split line into words
            String[] Words = Line.Split(null);

            // Remove any spaces
            int numWord = 0;
            for (i = 0; i < Words.Length; i++)
            {
                if (Words[i] != "")
                {
                    Words[numWord] = Words[i];
                    numWord++;
                }
            }

            if (Words.Length < 2)
                return;

            // Process depending on the words
            switch (Words[1])
            {
                case "ITERATION_RATE":
                    m_AppIterationRate = System.Convert.ToInt32(Words[2]);
                    m_IterationTime = 1.0f / m_AppIterationRate;
                    break;
                case "PRINT_TIMINGS":
                    if (Words[2].Equals("TRUE"))
                        m_PrintTimings = true;
                    break;
                case "PRINT_TWSH_BITS":
                    if (Words[2].Equals("TRUE"))
                        m_PrintTWSHBits = true;
                    break;
                case "ADDRESS_PIP_NET":
                    m_IPAddressPIPNet = IPAddress.Parse(Words[2]);
                    break;
                case "PORT_PIP_NET":
                    m_PortPIPNet = System.Convert.ToInt32(Words[2]);
                    break;
                case "ADDRESS_PIG_NET":
                    m_IPAddressPIGNet = IPAddress.Parse(Words[2]);
                    break;
                case "PORT_PIG_NET":
                    m_PortPIGNet = System.Convert.ToInt32(Words[2]);
                    break;
                case "ADDRESS":
                    ipAddress = Words[2];
                    break;
                case "PORT":
                    port = Words[2];
                    break;
                case "RATE_OUT":
                    rateOut = Words[2];
                    break;
                case "RATE_IN":
                    if (Words[0] == "PIP")
                        m_PIPRateIn = System.Convert.ToSingle(Words[2]);
                    else if (Words[0] == "PIG")
                        m_PIGRateIn = System.Convert.ToSingle(Words[2]);
                    break;
                case "SWAP":
                    swapBytes = Words[2];
                    break;

                case "CREATE_SOCKET":
                    // Create the Comms Object depending on the name
                    name = Words[0];

                    // if (name.StartsWith("PIG"))
                    //     m_PIGComms = new PIGComms(name, ipAddress, port, rateOut, swapBytes, this);
                    // else if (name.StartsWith("PIP"))
                    //     m_PIPComms = new PIPComms(name, ipAddress, port, rateOut, swapBytes, this);

                    // Reset data
                    name = "Not Assigned";
                    ipAddress = "Not Assigned";
                    port = "Not Assigned";
                    rateOut = "Not Assigned";
                    swapBytes = "No";

                    break;
            }

        }



        // ------------------------
        // Configure the Mast data
        // ------------------------
        private void ConfigureMastData()
        {
            String   filename = "MastConfig.txt";

            Encoding fileEncoding = Encoding.UTF8;

            try
            {
                // Attempt to open the input file for read-only access
                FileStream fsIn = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read);
                StreamReader sr = new StreamReader(fsIn, fileEncoding, true);

                // Process every line in the file
                for (String Line = sr.ReadLine(); Line != null; Line = sr.ReadLine())
                {
                    ProcessMastLine(Line);
                }

                // Explicitly close the StreamReader to properly flush all buffers
                sr.Close(); // This also closes the FileStream (fsIn)
            }
            catch (FileNotFoundException)
            {
                // The specified input file could not be opened
                Console.WriteLine("{0} file not found!", filename);
            }
        }



        // -------------------------------------
        // Process a line in the mast text file
        // -------------------------------------
        private void ProcessMastLine(String Line)
        {

            int i;
            int boatId = 0;
            int mastId = 0;
            float maxExt = 10.0f;
            float raiseTime = 10.0f;

            // Ignore lines starting with #
            if (Line.StartsWith("#"))
                return;

            // Ensure uppercase
            Line = Line.ToUpper();

            // Split line into words
            String[] Words = Line.Split(null);

            // Remove any spaces
            int numWord = 0;
            for (i = 0; i < Words.Length; i++)
            {
                if (Words[i] != "")
                {
                    Words[numWord] = Words[i];
                    numWord++;
                }
            }

            if (Words.Length != 4)
                return;

            // Word [0] is the boat id
            switch (Words[0])
            {
                case "SWIFTSURE":
                    boatId = 0;
                    break;
                case "TRAFALGAR":
                    boatId = 1;
                    break;
            }

            // Word [1] is the mast id
            mastId = System.Convert.ToInt32(Words[1]);

            // Word [2] is the maximum extension
            maxExt = System.Convert.ToSingle(Words[2]);

            // Word [3] is the raise time
            raiseTime = System.Convert.ToSingle(Words[3]);

            // Set the mast data
            m_SIMOwnMastMaxExt[boatId, mastId] = maxExt;
            m_SIMOwnMastSpeed[boatId, mastId] = maxExt/raiseTime;

        }



        // ------------------------------
        // Configure the Model database
        // ------------------------------
        private void ConfigureModelDatabase()
        {
            String   filename = "OIG_Target.def";

            Encoding fileEncoding = Encoding.UTF8;

            try
            {
                // Attempt to open the input file for read-only access
                FileStream fsIn = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read);
                StreamReader sr = new StreamReader(fsIn, fileEncoding, true);

                // Process every line in the file
                for (String Line = sr.ReadLine(); Line != null; Line = sr.ReadLine())
                {
                    ProcessModelLine(Line);
                }

                // Explicitly close the StreamReader to properly flush all buffers
                sr.Close(); // This also closes the FileStream (fsIn)
            }
            catch (FileNotFoundException)
            {
                // The specified input file could not be opened
                Console.WriteLine("{0} file not found!", filename);
            }
        }



        // --------------------------------------------------
        // Process a line in the model (OIG_Target.def) file
        // --------------------------------------------------
        private void ProcessModelLine(String Line)
        {

            int i;
            float width = 0.0f;
            float length = 0.0f;
            float height = 0.0f;

            // Ignore lines starting with #
            if (Line.StartsWith("#"))
                return;

            // Ensure uppercase
            Line = Line.ToUpper();

            // Split line into words
            String[] Words = Line.Split(null);

            // Remove any spaces
            int numWord = 0;
            for (i = 0; i < Words.Length; i++)
            {
                if (Words[i] != "")
                {
                    Words[numWord] = Words[i];
                    numWord++;
                }
            }

            // Process IS command
            if ((Words[0] == "TARGET") && (Words[2] == "IS"))
            {
                if (Words.Length >= 4)
                {
                    int id = Convert.ToInt32(Words[3], 10);
                    m_Models[id].m_Name = Words[1];
                }
            }

            // Process EXTENTS command
            if ((Words[0] == "TARGET") && (Words[2] == "EXTENTS"))
            {
                // Calculate the dimensions
                if (Words.Length >= 9)
                {
                    float Xmin = Convert.ToSingle(Words[3]);
                    float Xmax = Convert.ToSingle(Words[6]);

                    float Ymin = Convert.ToSingle(Words[4]);
                    float Ymax = Convert.ToSingle(Words[7]);

                    float Zmin = Convert.ToSingle(Words[5]);
                    float Zmax = Convert.ToSingle(Words[8]);

                    width = Math.Abs(Xmax - Xmin);
                    length = Math.Abs(Ymax - Ymin);
                    height = Math.Abs(Zmax - Zmin);

                    // Ensure length is longest dimension
                    if (length < width)
                    {
                        float temp = width;
                        width = length;
                        length = temp;
                    }

                }

                //   Find the array entry
                int id = 0;
                bool found = false;
                while((found == false) && (id < 1000))
                {
                    if (m_Models[id].m_Name == Words[1])
                        found = true;
                    else
                        id++;
                }

                if (found)
                {
                    m_Models[id].m_Width = width;
                    m_Models[id].m_Height = height;
                    m_Models[id].m_Length = length;
                }
            }
        }



        // -----------------------
        // Create PIG data items
        // -----------------------
        private void CreatePIGDataItems()
        {
            int i;

            m_PIGExSystemID = new DataItemInt();
            m_PIGExRunMode = new DataItemInt();

            m_PIGEnvMoonOverride = new DataItemBool();
            m_PIGEnvCoastLights = new DataItemBool();
            m_PIGEnvIceEdgeOn = new DataItemBool();
            m_PIGEnvSunOverride = new DataItemBool();

            m_PIGEnvHours = new DataItemByte();
            m_PIGEnvMins = new DataItemByte();
            m_PIGEnvSecs = new DataItemByte();
            m_PIGEnvDay = new DataItemByte();
            m_PIGEnvMonth = new DataItemByte();
            m_PIGEnvYear = new DataItemByte();
            m_PIGEnvWeather = new DataItemByte();
            m_PIGEnvCoastline = new DataItemByte();
            m_PIGEnvSeaState = new DataItemByte();
            m_PIGEnvVisualRange = new DataItemFloat();
            m_PIGEnvThermalRange = new DataItemFloat();
            m_PIGEnvUnderWaterRange = new DataItemFloat();
            m_PIGEnvWindSpeed = new DataItemFloat();
            m_PIGEnvWindDirn = new DataItemFloat();
            m_PIGEnvMoonBrgOverRide = new DataItemFloat();
            m_PIGEnvMoonElevOverRide = new DataItemFloat();
            m_PIGEnvSunBrgOverRide = new DataItemFloat();
            m_PIGEnvSunElevOverRide = new DataItemFloat();
            m_PIGEnvIceEdgeLat = new DataItemFloat();
            m_PIGEnvIceEdgeLon = new DataItemFloat();
            m_PIGEnvIceEdgeOrien = new DataItemFloat();

            m_PIGOwnType = new DataItemByte();
            m_PIGOwnSmoke = new DataItemByte();
            m_PIGOwnLatitude = new DataItemFloat();
            m_PIGOwnLongitude = new DataItemFloat();
            m_PIGOwnX = new DataItemFloat();
            m_PIGOwnY = new DataItemFloat();
            m_PIGOwnDepth = new DataItemFloat();
            m_PIGOwnHeading = new DataItemFloat();
            m_PIGOwnRoll = new DataItemFloat();
            m_PIGOwnPitch = new DataItemFloat();
            m_PIGOwnSpeed = new DataItemFloat();
            m_PIGOwnMast = new DataItemFloat[10];

            for(i = 0; i < 10 ; i++)
                m_PIGOwnMast[i] = new DataItemFloat();

            m_PIGPeriSensor = new DataItemByte();
            m_PIGPeriMagnification = new DataItemByte();
            m_PIGPeriGain = new DataItemByte();
            m_PIGPeriContrast = new DataItemByte();
            m_PIGPeriGratIntensity = new DataItemByte();
            m_PIGPeriDraindown = new DataItemByte();
            m_PIGPeriRelBrg = new DataItemFloat();
            m_PIGPeriElevation = new DataItemFloat();
            m_PIGPeriStadAngle = new DataItemFloat();

            m_PIGTargets = new PIGTargetData[PIG_NUMBER_TARGETS];

            for(i = 0; i < PIG_NUMBER_TARGETS; i++)
            {
                m_PIGTargets[i].m_PIGTarPresent = new DataItemBool();
                m_PIGTargets[i].m_PIGTarNavLights = new DataItemBool();
                m_PIGTargets[i].m_PIGTarMissileHit = new DataItemBool();
                m_PIGTargets[i].m_PIGTarTorpedoHit = new DataItemBool();
                m_PIGTargets[i].m_PIGTarSinking = new DataItemBool();
                m_PIGTargets[i].m_PIGTarDunkingSonar = new DataItemBool();
                m_PIGTargets[i].m_PIGTarTLAM = new DataItemBool();
                m_PIGTargets[i].m_PIGTarFlames = new DataItemBool();
                m_PIGTargets[i].m_PIGTarDieselSmoke = new DataItemBool();
                m_PIGTargets[i].m_PIGTarFireMissile = new DataItemBool();

                m_PIGTargets[i].m_PIGTarModelID = new DataItemShort();
                m_PIGTargets[i].m_PIGTarSlotNum = new DataItemShort();
                m_PIGTargets[i].m_PIGTarSpotConfig = new DataItemByte();
                m_PIGTargets[i].m_PIGTarLightConfig = new DataItemByte();
                m_PIGTargets[i].m_PIGTarX = new DataItemFloat();
                m_PIGTargets[i].m_PIGTarY = new DataItemFloat();
                m_PIGTargets[i].m_PIGTarHeight = new DataItemFloat();
                m_PIGTargets[i].m_PIGTarHeading = new DataItemFloat();
                m_PIGTargets[i].m_PIGTarRoll = new DataItemFloat();
                m_PIGTargets[i].m_PIGTarPitch = new DataItemFloat();
                m_PIGTargets[i].m_PIGTarSpeed = new DataItemFloat();
                m_PIGTargets[i].m_PIGTarAccel = new DataItemFloat();
                m_PIGTargets[i].m_PIGTarHitPoint = new DataItemInt();
            }

            m_PIGRetProcStat = new DataItemLong();
            m_PIGRetModelStat = new DataItemLong();
            m_PIGRetPolyniaNum = new DataItemLong();

            m_PIGRetPolynia = new PIGRetPolyniaData[NUM_POLYNIA_TARGETS];

            for(i = 0; i < NUM_POLYNIA_TARGETS ; i++)
            {
                m_PIGRetPolynia[i].m_PIGRetPolIdentity = new DataItemLong();
                m_PIGRetPolynia[i].m_PIGRetPolX = new DataItemFloat();
                m_PIGRetPolynia[i].m_PIGRetPolY = new DataItemFloat();
                m_PIGRetPolynia[i].m_PIGRetPolZ = new DataItemFloat();
                m_PIGRetPolynia[i].m_PIGRetPolOrien = new DataItemFloat();
                m_PIGRetPolynia[i].m_PIGRetPolSlotNum = new DataItemLong();
            }
        }



        // -----------------------
        // Create PIP data items
        // -----------------------
        private void CreatePIPDataItems()
        {
            int i;

            m_PIPExRunMode = new DataItemByte();
            m_PIPExHours = new DataItemByte();
            m_PIPExMins = new DataItemByte();
            m_PIPExSecs = new DataItemByte();
            m_PIPExDay = new DataItemByte();
            m_PIPExMonth = new DataItemByte();
            m_PIPExYear = new DataItemByte();

            m_PIPPeriInstructCtrl = new DataItemBool();
            m_PIPPeriSearchUp = new DataItemBool();
            m_PIPPeriPolarityWhite = new DataItemBool();
            m_PIPPeriHighMag = new DataItemBool();
            m_PIPPeriDraindown = new DataItemByte();
            m_PIPPeriLLTVGain = new DataItemByte();
            m_PIPPeriThermalGain = new DataItemByte();
            m_PIPPeriRelBearing = new DataItemFloat();
            m_PIPPeriElevation = new DataItemFloat();

            m_PIPEnvMoonOverride = new DataItemBool();
            m_PIPEnvCoastLights = new DataItemBool();
            m_PIPEnvIceEdgeOn = new DataItemBool();
            m_PIPEnvSunOverride = new DataItemBool();

            m_PIPEnvWeather = new DataItemByte();
            m_PIPEnvCoastline = new DataItemByte();
            m_PIPEnvSeaState = new DataItemByte();
            m_PIPEnvMoonBrg = new DataItemFloat();
            m_PIPEnvMoonElev = new DataItemFloat();
            m_PIPEnvVisualRange = new DataItemFloat();
            m_PIPEnvUnderWaterRange = new DataItemFloat();
            m_PIPEnvThermalRange = new DataItemFloat();
            m_PIPEnvWindSpeed = new DataItemFloat();
            m_PIPEnvWindHeading = new DataItemFloat();
            m_PIPEnvIceLat = new DataItemFloat();
            m_PIPEnvIceLon = new DataItemFloat();
            m_PIPEnvIceOrien = new DataItemFloat();
            m_PIPEnvSunBrg = new DataItemFloat();
            m_PIPEnvSunElev = new DataItemFloat();

            m_PIPOwnLat = new DataItemDouble();
            m_PIPOwnLon = new DataItemDouble();
            m_PIPOwnDepth = new DataItemFloat();
            m_PIPOwnClimbRate = new DataItemFloat();
            m_PIPOwnTurnRate = new DataItemFloat();
            m_PIPOwnPitch = new DataItemFloat();
            m_PIPOwnHeading = new DataItemFloat();
            m_PIPOwnDriftCourse = new DataItemFloat();
            m_PIPOwnSpeed = new DataItemFloat();
            m_PIPOwnDriftSpeed = new DataItemFloat();
            m_PIPOwnWhipAerialUp = new DataItemBool();
            m_PIPOwnEmerLightUp = new DataItemBool();
            m_PIPOwnDieselSmoke = new DataItemBool();
            m_PIPOwnMastRESM = new DataItemByte();
            m_PIPOwnMastWTComms = new DataItemByte();
            m_PIPOwnMastHFDF = new DataItemByte();
            m_PIPOwnMastAttack = new DataItemByte();
            m_PIPOwnMastRadar = new DataItemByte();
            m_PIPOwnMastSnortInd = new DataItemByte();
            m_PIPOwnMastSnortExh = new DataItemByte();
            m_PIPOwnType = new DataItemByte();

            m_PIPTargets = new PIPTargetData[SIM_NUMBER_TARGETS];

            for(i = 0; i < SIM_NUMBER_TARGETS ; i++)
            {
                m_PIPTargets[i].m_PIPTarPresent = new DataItemBool();
                m_PIPTargets[i].m_PIPTarFlames = new DataItemBool();
                m_PIPTargets[i].m_PIPTarMissileHit = new DataItemBool();
                m_PIPTargets[i].m_PIPTarTorpedoHit = new DataItemBool();
                m_PIPTargets[i].m_PIPTarSinking = new DataItemBool();
                m_PIPTargets[i].m_PIPTarNavLights = new DataItemBool();
                m_PIPTargets[i].m_PIPTarDunkingSonar = new DataItemBool();
                m_PIPTargets[i].m_PIPTarFireMissile = new DataItemBool();
                m_PIPTargets[i].m_PIPTarTLAMFaulty = new DataItemBool();
                m_PIPTargets[i].m_PIPTarDunkingData = new DataItemByte();
                m_PIPTargets[i].m_PIPTarLightConfig = new DataItemByte();
                m_PIPTargets[i].m_PIPTarSpotConfig = new DataItemByte();
                m_PIPTargets[i].m_PIPTarModelID = new DataItemInt();
                m_PIPTargets[i].m_PIPTarSlotID = new DataItemInt();
                m_PIPTargets[i].m_PIPTarX = new DataItemFloat();
                m_PIPTargets[i].m_PIPTarY = new DataItemFloat();
                m_PIPTargets[i].m_PIPTarHeight = new DataItemFloat();
                m_PIPTargets[i].m_PIPTarClimbRate = new DataItemFloat();
                m_PIPTargets[i].m_PIPTarTurnRate = new DataItemFloat();
                m_PIPTargets[i].m_PIPTarPitch = new DataItemFloat();
                m_PIPTargets[i].m_PIPTarHeading = new DataItemFloat();
                m_PIPTargets[i].m_PIPTarDriftCourse = new DataItemFloat();
                m_PIPTargets[i].m_PIPTarSpeed = new DataItemFloat();
                m_PIPTargets[i].m_PIPTarDriftSpeed = new DataItemFloat();
                m_PIPTargets[i].m_PIPTarDieselSmoke = new DataItemBool();
            }

            m_PIPCheckSum = new DataItemInt();

            // PIP Return Data
            m_PIPRetSearchUp = new DataItemBool();
            m_PIPRetPolarityWhite = new DataItemBool();
            m_PIPRetHighMag = new DataItemBool();
            m_PIPRetHandlesUp = new DataItemBool();

            m_PIPRetPeriLLTVGain = new DataItemByte();
            m_PIPRetPeriTIGain = new DataItemByte();

            m_PIPRetTWSHPeriTrueBrg = new DataItemFloat();
            m_PIPRetTWSHTarTrueBrg = new DataItemFloat();
            m_PIPRetTWSHTarRange = new DataItemFloat();
            m_PIPRetTWSHTarElpsdTime = new DataItemFloat();
            m_PIPRetTWSHTarTrueBrgCut = new DataItemBool();
            m_PIPRetTWSHTarRangeCut = new DataItemBool();
            m_PIPRetTWSHTarElpsdTimeCut = new DataItemBool();

            m_PIPRetPeriRelBrg = new DataItemFloat();
            m_PIPRetPeriElev = new DataItemFloat();
            m_PIPRetPeriSunBrg = new DataItemFloat();
            m_PIPRetPeriSunElev = new DataItemFloat();

            m_PIPRetPeriErrorNo = new DataItemInt();
            m_PIPRetPeriErrorString = new DataItemString();

            m_PIPRetNumPolynia = new DataItemInt();

            m_PIPRetPolynia = new PIPRetPolyniaData[NUM_POLYNIA_TARGETS];

            for(i = 0; i < NUM_POLYNIA_TARGETS ; i++)
            {
                m_PIPRetPolynia[i].m_PIPRetPolIdentity = new DataItemInt();
                m_PIPRetPolynia[i].m_PIPRetPolPresent = new DataItemByte();
                m_PIPRetPolynia[i].m_PIPRetPolX = new DataItemFloat();
                m_PIPRetPolynia[i].m_PIPRetPolY = new DataItemFloat();
                m_PIPRetPolynia[i].m_PIPRetPolZ = new DataItemFloat();
                m_PIPRetPolynia[i].m_PIPRetPolOrientation = new DataItemFloat();
            }

            m_PIPRetCheckSum = new DataItemInt();
        }



        // -----------------------
        // Create IO data items
        // -----------------------
        private void CreateIODataItems()
        {
            m_IOBearing = new DataItemFloat();
            m_IOElevation = new DataItemFloat();
            m_IOStadAngle = new DataItemFloat();
            m_IOTiBlackLevel = new DataItemFloat();
            m_IOTiSensitivity = new DataItemFloat();
            m_IOTiGratIllum = new DataItemFloat();

            m_IORearStadAngle = new DataItemFloat();
            m_IORearTrueBrg = new DataItemFloat();
            m_IORearRelBrg = new DataItemFloat();

            m_IODisplayBrg = new DataItemFloat();
            m_IODisplayElev = new DataItemFloat();
            m_IODisplayTar = new DataItemFloat();
            m_IOBeckmanTrue = new DataItemFloat();
            m_IOBeckmanRel = new DataItemFloat();

            m_IOHandlesDown = new DataItemBool();
            m_IOHighMag = new DataItemBool();
            m_IORangeCut = new DataItemBool();
            m_IOBearingCut = new DataItemBool();
            m_IOPushToTalk = new DataItemBool();

            m_IOModeSelect = new DataItemInt();
            m_IODataOverlay = new DataItemBool();
            m_IOTiOnIndicator = new DataItemBool();
            m_IOTarHeight = new DataItemInt();

        }


        // -----------------------
        // Create GUI data items
        // -----------------------
        private void CreateGUIDataItems()
        {
            int i;

            // PIG Data
            m_GUIData.m_PIGExSystemID = new DataItemInt();
            m_GUIData.m_PIGExRunMode = new DataItemInt();

            m_GUIData.m_PIGEnvMoonOverride = new DataItemBool();
            m_GUIData.m_PIGEnvCoastLights = new DataItemBool();
            m_GUIData.m_PIGEnvIceEdgeOn = new DataItemBool();
            m_GUIData.m_PIGEnvSunOverride = new DataItemBool();
            m_GUIData.m_PIGEnvHours = new DataItemByte();
            m_GUIData.m_PIGEnvMins = new DataItemByte();
            m_GUIData.m_PIGEnvSecs = new DataItemByte();
            m_GUIData.m_PIGEnvDay = new DataItemByte();
            m_GUIData.m_PIGEnvMonth = new DataItemByte();
            m_GUIData.m_PIGEnvYear = new DataItemByte();
            m_GUIData.m_PIGEnvWeather = new DataItemByte();
            m_GUIData.m_PIGEnvCoastline = new DataItemByte();
            m_GUIData.m_PIGEnvSeaState = new DataItemByte();
            m_GUIData.m_PIGEnvVisualRange = new DataItemFloat();
            m_GUIData.m_PIGEnvThermalRange = new DataItemFloat();
            m_GUIData.m_PIGEnvUnderWaterRange = new DataItemFloat();
            m_GUIData.m_PIGEnvWindSpeed = new DataItemFloat();
            m_GUIData.m_PIGEnvWindDirn = new DataItemFloat();
            m_GUIData.m_PIGEnvMoonBrgOverRide = new DataItemFloat();
            m_GUIData.m_PIGEnvMoonElevOverRide = new DataItemFloat();
            m_GUIData.m_PIGEnvSunBrgOverRide = new DataItemFloat();
            m_GUIData.m_PIGEnvSunElevOverRide = new DataItemFloat();
            m_GUIData.m_PIGEnvIceEdgeLat = new DataItemFloat();
            m_GUIData.m_PIGEnvIceEdgeLon = new DataItemFloat();
            m_GUIData.m_PIGEnvIceEdgeOrien = new DataItemFloat();

            m_GUIData.m_PIGOwnType = new DataItemByte();
            m_GUIData.m_PIGOwnSmoke = new DataItemByte();
            m_GUIData.m_PIGOwnLatitude = new DataItemFloat();
            m_GUIData.m_PIGOwnLongitude = new DataItemFloat();
            m_GUIData.m_PIGOwnX = new DataItemFloat();
            m_GUIData.m_PIGOwnY = new DataItemFloat();
            m_GUIData.m_PIGOwnDepth = new DataItemFloat();
            m_GUIData.m_PIGOwnHeading = new DataItemFloat();
            m_GUIData.m_PIGOwnRoll = new DataItemFloat();
            m_GUIData.m_PIGOwnPitch = new DataItemFloat();
            m_GUIData.m_PIGOwnSpeed = new DataItemFloat();

            m_GUIData.m_PIGOwnMast = new DataItemFloat[10];

            for (i = 0; i < 10; i++)
                m_GUIData.m_PIGOwnMast[i] = new DataItemFloat();

            m_GUIData.m_PIGPeriSensor = new DataItemByte();
            m_GUIData.m_PIGPeriMagnification = new DataItemByte();
            m_GUIData.m_PIGPeriGain = new DataItemByte();
            m_GUIData.m_PIGPeriContrast = new DataItemByte();
            m_GUIData.m_PIGPeriGratIntensity = new DataItemByte();
            m_GUIData.m_PIGPeriDraindown = new DataItemByte();
            m_GUIData.m_PIGPeriRelBrg = new DataItemFloat();
            m_GUIData.m_PIGPeriElevation = new DataItemFloat();
            m_GUIData.m_PIGPeriStadAngle = new DataItemFloat();

            m_GUIData.m_PIGTargets = new PIGTargetData[NUM_PERI_TARGETS];

            for ( i = 0; i < NUM_PERI_TARGETS ; i++)
            {
                m_GUIData.m_PIGTargets[i].m_PIGTarPresent = new DataItemBool();
                m_GUIData.m_PIGTargets[i].m_PIGTarNavLights = new DataItemBool();
                m_GUIData.m_PIGTargets[i].m_PIGTarMissileHit = new DataItemBool();
                m_GUIData.m_PIGTargets[i].m_PIGTarTorpedoHit = new DataItemBool();
                m_GUIData.m_PIGTargets[i].m_PIGTarSinking = new DataItemBool();
                m_GUIData.m_PIGTargets[i].m_PIGTarDunkingSonar = new DataItemBool();
                m_GUIData.m_PIGTargets[i].m_PIGTarTLAM = new DataItemBool();
                m_GUIData.m_PIGTargets[i].m_PIGTarFlames = new DataItemBool();
                m_GUIData.m_PIGTargets[i].m_PIGTarDieselSmoke = new DataItemBool();
                m_GUIData.m_PIGTargets[i].m_PIGTarFireMissile = new DataItemBool();

                m_GUIData.m_PIGTargets[i].m_PIGTarModelID = new DataItemShort();
                m_GUIData.m_PIGTargets[i].m_PIGTarSlotNum = new DataItemShort();
                m_GUIData.m_PIGTargets[i].m_PIGTarLightConfig = new DataItemByte();
                m_GUIData.m_PIGTargets[i].m_PIGTarSpotConfig = new DataItemByte();

                m_GUIData.m_PIGTargets[i].m_PIGTarX = new DataItemFloat();
                m_GUIData.m_PIGTargets[i].m_PIGTarY = new DataItemFloat();
                m_GUIData.m_PIGTargets[i].m_PIGTarHeight = new DataItemFloat();
                m_GUIData.m_PIGTargets[i].m_PIGTarHeading = new DataItemFloat();
                m_GUIData.m_PIGTargets[i].m_PIGTarRoll = new DataItemFloat();
                m_GUIData.m_PIGTargets[i].m_PIGTarPitch = new DataItemFloat();
                m_GUIData.m_PIGTargets[i].m_PIGTarSpeed = new DataItemFloat();
                m_GUIData.m_PIGTargets[i].m_PIGTarAccel = new DataItemFloat();
                m_GUIData.m_PIGTargets[i].m_PIGTarHitPoint = new DataItemInt();
            }

            m_GUIData.m_PIGRetProcStat = new DataItemLong();
            m_GUIData.m_PIGRetModelStat = new DataItemLong();
            m_GUIData.m_PIGRetPolyniaNum = new DataItemLong();

            m_GUIData.m_PIGRetPolynia = new PIGRetPolyniaData[NUM_POLYNIA_TARGETS];

            for (i = 0; i < NUM_POLYNIA_TARGETS; i++)
            {
                m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolIdentity = new DataItemLong();
                m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolX = new DataItemFloat();
                m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolY = new DataItemFloat();
                m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolZ = new DataItemFloat();
                m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolOrien = new DataItemFloat();
                m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolSlotNum = new DataItemLong();
            }

            // PIP Data
            m_GUIData.m_PIPExRunMode = new DataItemByte();
            m_GUIData.m_PIPExHours = new DataItemByte();
            m_GUIData.m_PIPExMins = new DataItemByte();
            m_GUIData.m_PIPExSecs = new DataItemByte();
            m_GUIData.m_PIPExDay = new DataItemByte();
            m_GUIData.m_PIPExMonth = new DataItemByte();
            m_GUIData.m_PIPExYear = new DataItemByte();

            m_GUIData.m_PIPPeriInstructCtrl = new DataItemBool();
            m_GUIData.m_PIPPeriSearchUp = new DataItemBool();
            m_GUIData.m_PIPPeriPolarityWhite = new DataItemBool();
            m_GUIData.m_PIPPeriHighMag = new DataItemBool();
            m_GUIData.m_PIPPeriDraindown = new DataItemByte();
            m_GUIData.m_PIPPeriLLTVGain = new DataItemByte();
            m_GUIData.m_PIPPeriThermalGain = new DataItemByte();
            m_GUIData.m_PIPPeriRelBearing = new DataItemFloat();
            m_GUIData.m_PIPPeriElevation = new DataItemFloat();

            m_GUIData.m_PIPEnvMoonOverride = new DataItemBool();
            m_GUIData.m_PIPEnvCoastLights = new DataItemBool();
            m_GUIData.m_PIPEnvIceEdgeOn = new DataItemBool();
            m_GUIData.m_PIPEnvSunOverride = new DataItemBool();
            m_GUIData.m_PIPEnvWeather = new DataItemByte();
            m_GUIData.m_PIPEnvCoastline = new DataItemByte();
            m_GUIData.m_PIPEnvSeaState = new DataItemByte();
            m_GUIData.m_PIPEnvMoonBrg = new DataItemFloat();
            m_GUIData.m_PIPEnvMoonElev = new DataItemFloat();
            m_GUIData.m_PIPEnvVisualRange = new DataItemFloat();
            m_GUIData.m_PIPEnvUnderWaterRange = new DataItemFloat();
            m_GUIData.m_PIPEnvThermalRange = new DataItemFloat();
            m_GUIData.m_PIPEnvWindSpeed = new DataItemFloat();
            m_GUIData.m_PIPEnvWindHeading = new DataItemFloat();
            m_GUIData.m_PIPEnvIceLat = new DataItemFloat();
            m_GUIData.m_PIPEnvIceLon = new DataItemFloat();
            m_GUIData.m_PIPEnvIceOrien = new DataItemFloat();
            m_GUIData.m_PIPEnvSunBrg = new DataItemFloat();
            m_GUIData.m_PIPEnvSunElev = new DataItemFloat();

            m_GUIData.m_PIPOwnLat = new DataItemDouble();
            m_GUIData.m_PIPOwnLon = new DataItemDouble();
            m_GUIData.m_PIPOwnDepth = new DataItemFloat();
            m_GUIData.m_PIPOwnClimbRate = new DataItemFloat();
            m_GUIData.m_PIPOwnTurnRate = new DataItemFloat();
            m_GUIData.m_PIPOwnPitch = new DataItemFloat();
            m_GUIData.m_PIPOwnHeading = new DataItemFloat();
            m_GUIData.m_PIPOwnDriftCourse = new DataItemFloat();
            m_GUIData.m_PIPOwnSpeed = new DataItemFloat();
            m_GUIData.m_PIPOwnDriftSpeed = new DataItemFloat();
            m_GUIData.m_PIPOwnWhipAerialUp = new DataItemBool();
            m_GUIData.m_PIPOwnEmerLightUp = new DataItemBool();
            m_GUIData.m_PIPOwnDieselSmoke = new DataItemBool();
            m_GUIData.m_PIPOwnMastRESM = new DataItemByte();
            m_GUIData.m_PIPOwnMastWTComms = new DataItemByte();
            m_GUIData.m_PIPOwnMastHFDF = new DataItemByte();
            m_GUIData.m_PIPOwnMastAttack = new DataItemByte();
            m_GUIData.m_PIPOwnMastRadar = new DataItemByte();
            m_GUIData.m_PIPOwnMastSnortInd = new DataItemByte();
            m_GUIData.m_PIPOwnMastSnortExh = new DataItemByte();
            m_GUIData.m_PIPOwnType = new DataItemByte();

            m_GUIData.m_PIPTargets = new PIPTargetData[NUM_PERI_TARGETS];

            for (i = 0; i < NUM_PERI_TARGETS; i++)
            {
                m_GUIData.m_PIPTargets[i].m_PIPTarPresent = new DataItemBool();
                m_GUIData.m_PIPTargets[i].m_PIPTarFlames = new DataItemBool();
                m_GUIData.m_PIPTargets[i].m_PIPTarMissileHit = new DataItemBool();
                m_GUIData.m_PIPTargets[i].m_PIPTarTorpedoHit = new DataItemBool();
                m_GUIData.m_PIPTargets[i].m_PIPTarSinking = new DataItemBool();
                m_GUIData.m_PIPTargets[i].m_PIPTarNavLights = new DataItemBool();
                m_GUIData.m_PIPTargets[i].m_PIPTarDunkingSonar = new DataItemBool();
                m_GUIData.m_PIPTargets[i].m_PIPTarTLAMFaulty = new DataItemBool();
                m_GUIData.m_PIPTargets[i].m_PIPTarFireMissile = new DataItemBool();
                m_GUIData.m_PIPTargets[i].m_PIPTarDunkingData = new DataItemByte();
                m_GUIData.m_PIPTargets[i].m_PIPTarLightConfig = new DataItemByte();
                m_GUIData.m_PIPTargets[i].m_PIPTarSpotConfig = new DataItemByte();
                m_GUIData.m_PIPTargets[i].m_PIPTarModelID = new DataItemInt();
                m_GUIData.m_PIPTargets[i].m_PIPTarSlotID = new DataItemInt();
                m_GUIData.m_PIPTargets[i].m_PIPTarX = new DataItemFloat();
                m_GUIData.m_PIPTargets[i].m_PIPTarY = new DataItemFloat();
                m_GUIData.m_PIPTargets[i].m_PIPTarHeight = new DataItemFloat();
                m_GUIData.m_PIPTargets[i].m_PIPTarClimbRate = new DataItemFloat();
                m_GUIData.m_PIPTargets[i].m_PIPTarTurnRate = new DataItemFloat();
                m_GUIData.m_PIPTargets[i].m_PIPTarPitch = new DataItemFloat();
                m_GUIData.m_PIPTargets[i].m_PIPTarHeading = new DataItemFloat();
                m_GUIData.m_PIPTargets[i].m_PIPTarDriftCourse = new DataItemFloat();
                m_GUIData.m_PIPTargets[i].m_PIPTarSpeed = new DataItemFloat();
                m_GUIData.m_PIPTargets[i].m_PIPTarDriftSpeed = new DataItemFloat();
                m_GUIData.m_PIPTargets[i].m_PIPTarDieselSmoke = new DataItemBool();
            }

            // PIP Return Data
            m_GUIData.m_PIPRetSearchUp = new DataItemBool();
            m_GUIData.m_PIPRetPolarityWhite = new DataItemBool();
            m_GUIData.m_PIPRetHighMag = new DataItemBool();
            m_GUIData.m_PIPRetHandlesUp = new DataItemBool();

            m_GUIData.m_PIPRetPeriLLTVGain = new DataItemByte();
            m_GUIData.m_PIPRetPeriTIGain = new DataItemByte();

            m_GUIData.m_PIPRetTWSHPeriTrueBrg = new DataItemFloat();
            m_GUIData.m_PIPRetTWSHTarTrueBrg = new DataItemFloat();
            m_GUIData.m_PIPRetTWSHTarRange = new DataItemFloat();
            m_GUIData.m_PIPRetTWSHTarElpsdTime = new DataItemFloat();
            m_GUIData.m_PIPRetTWSHTarTrueBrgCut = new DataItemBool();
            m_GUIData.m_PIPRetTWSHTarRangeCut = new DataItemBool();
            m_GUIData.m_PIPRetTWSHTarElpsdTimeCut = new DataItemBool();

            m_GUIData.m_PIPRetPeriRelBrg = new DataItemFloat();
            m_GUIData.m_PIPRetPeriElev = new DataItemFloat();
            m_GUIData.m_PIPRetPeriSunBrg = new DataItemFloat();
            m_GUIData.m_PIPRetPeriSunElev = new DataItemFloat();
            m_GUIData.m_PIPRetPeriErrorNo = new DataItemInt();
            m_GUIData.m_PIPRetPeriErrorString = new DataItemString();
            m_GUIData.m_PIPRetNumPolynia = new DataItemInt();

            m_GUIData.m_PIPRetPolynia = new PIPRetPolyniaData[NUM_POLYNIA_TARGETS];

            for (i = 0; i < NUM_POLYNIA_TARGETS; i++)
            {
                m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolIdentity = new DataItemInt();
                m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolPresent = new DataItemByte();
                m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolX = new DataItemFloat();
                m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolY = new DataItemFloat();
                m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolZ = new DataItemFloat();
                m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolOrientation = new DataItemFloat();
            }

            // IO data
            m_GUIData.m_IOBearing = new DataItemFloat();
            m_GUIData.m_IOElevation = new DataItemFloat();
            m_GUIData.m_IOStadAngle = new DataItemFloat();
            m_GUIData.m_IOTiBlackLevel = new DataItemFloat();
            m_GUIData.m_IOTiSensitivity = new DataItemFloat();
            m_GUIData.m_IOTiGratIllum = new DataItemFloat();

            m_GUIData.m_IORearStadAngle = new DataItemFloat();
            m_GUIData.m_IORearTrueBrg = new DataItemFloat();
            m_GUIData.m_IORearRelBrg = new DataItemFloat();

            m_GUIData.m_IODisplayBrg = new DataItemFloat();
            m_GUIData.m_IODisplayElev = new DataItemFloat();
            m_GUIData.m_IODisplayTar = new DataItemFloat();
            m_GUIData.m_IOBeckmanTrue = new DataItemFloat();
            m_GUIData.m_IOBeckmanRel = new DataItemFloat();

            m_GUIData.m_IOHandlesDown = new DataItemBool();
            m_GUIData.m_IOHighMag = new DataItemBool();
            m_GUIData.m_IORangeCut = new DataItemBool();
            m_GUIData.m_IOBearingCut = new DataItemBool();
            m_GUIData.m_IOPushToTalk = new DataItemBool();

            m_GUIData.m_IOModeSelect = new DataItemInt();
            m_GUIData.m_IODataOverlay = new DataItemBool();
            m_GUIData.m_IOTiOnIndicator = new DataItemBool();
            m_GUIData.m_IOTarHeight = new DataItemInt();

            // System data
            m_GUIData.m_SIMRunApp = true;
            m_GUIData.m_SIMEmulatingPIP = false;
            m_GUIData.m_SIMEmulatingPIG = false;
            m_GUIData.m_SIMEmulatingIO = false;


            // Model Names
            m_GUIData.m_ModelNamesSet = false;
            m_GUIData.m_ModelNames = new String[1000];


            // Error Log
            m_GUIData.m_SIMErrorLog = new ErrorLog[SIM_ERRORLOG_SIZE];

        }



        // -----------------------
        // Process EXERCISE Data
        // -----------------------
        private void ProcessExercise()
        {

            //
            // Process the EXERCISE data
            //


            //
            // Set the system id (always 4)
            //
            m_PIGExSystemID.SetRawValue(4);

            //
            // Set the SIM exercise run mode from the PIP if there is new network data
            //
            if (m_SIMNewExData == true)
            {
                m_SIMExRunMode = (int) m_PIPExRunMode.GetResultValue();

// Reset the data flag
m_SIMNewExData = false;
            }

            //
            // Set the PIG exercise run mode from the SIM (this is done every time as the SIM
            // can set a RESET if the ownboat does a big jump
            //
            switch (m_SIMExRunMode)
            {
                case SIM_FULL_FREEZE:
                    // Full simulation freeze
                    m_PIGExRunMode.SetRawValue(PIG_FREEZE);
                    break;

                case SIM_RUN:
                    // Normal run
                    m_PIGExRunMode.SetRawValue(PIG_RUN);
                    break;

                case SIM_TARGET_FREEZE:
                    // Ownboat mobile, target stationary
                    m_PIGExRunMode.SetRawValue(PIG_RUN);
                    break;

                case SIM_FAST_RUN:
                    // Normal run (with faster iteration)
                    m_PIGExRunMode.SetRawValue(PIG_RUN);
                    break;

                case SIM_RESET:
                    // Ownboat and targets reset
                    m_PIGExRunMode.SetRawValue(PIG_RESET);
                    break;

                default:
                    // Error occured
                    m_PIGExRunMode.SetRawValue(PIG_STOP);
                    break;
            }


        }



        // --------------------------
        // Process ENVIRONMENT Data
        // --------------------------
        private void ProcessEnvironment()
        {

            //
            // Process the ENVIRONMENT data
            //

            //
            // Return if there is no new data to process
            //
            if (m_SIMNewEnvData == false)
                return;


            //
            // Check for applicable sim mode and update the values
            //
            if ((m_SIMExRunMode == SIM_TARGET_FREEZE) ||
                (m_SIMExRunMode == SIM_RUN) ||
                (m_SIMExRunMode == SIM_FAST_RUN))
            {

                //
                // The PSC does no logic processing on the ENVIRONMENT data
                // (other than units conversion)
                //
                m_PIGEnvMoonOverride.SetRawValue(m_PIPEnvMoonOverride.GetResultValue());
                m_PIGEnvCoastLights.SetRawValue(m_PIPEnvCoastLights.GetResultValue());
                m_PIGEnvIceEdgeOn.SetRawValue(m_PIPEnvIceEdgeOn.GetResultValue());
                m_PIGEnvSunOverride.SetRawValue(m_PIPEnvSunOverride.GetResultValue());

                // Hours
                byte hours = m_PIPExHours.GetResultValue();

                if (hours > HOURS_MAX)
                    hours = HOURS_MIN;

                m_PIGEnvHours.SetRawValue(hours);

                // Minutes
                byte minutes = m_PIPExMins.GetResultValue();

                if (minutes > MINUTES_MAX)
                    minutes = MINUTES_MIN;

                m_PIGEnvMins.SetRawValue(minutes);

                // Seconds
                byte seconds = m_PIPExSecs.GetResultValue();

                if (seconds > SECONDS_MAX)
                    seconds = SECONDS_MIN;

                m_PIGEnvSecs.SetRawValue(seconds);

                // Day
                byte day = m_PIPExDay.GetResultValue();

                if (day > DAYS_MAX)
                    day = DAYS_MIN;

                m_PIGEnvDay.SetRawValue(day);

                // Month
                byte month = m_PIPExMonth.GetResultValue();

                if (month > MONTHS_MAX)
                    month = MONTHS_MIN;

                m_PIGEnvMonth.SetRawValue(month);

                // Year
                byte year = m_PIPExYear.GetResultValue();

                if (year > YEARS_MAX)
                    year = YEARS_MIN;

                m_PIGEnvYear.SetRawValue(year);

                // Weather
                byte weather = m_PIPEnvWeather.GetResultValue();

                if (weather > WEATHER_MAX)
                    weather = WEATHER_MIN;

                m_PIGEnvWeather.SetRawValue(weather);

                // Coastline
                byte coast = m_PIPEnvCoastline.GetResultValue();

                if (coast > COASTLINE_MAX)
                    coast = COASTLINE_MIN;

                m_PIGEnvCoastline.SetRawValue(coast);

                // Sea state
                byte seaState = m_PIPEnvSeaState.GetResultValue();

                if (seaState > SEA_STATE_MAX)
                    seaState = SEA_STATE_MIN;

                m_PIGEnvSeaState.SetRawValue(seaState);

                // Visual range
                double visualRange = m_PIPEnvVisualRange.GetResultValue() * YDS_TO_MTRS * 1000.0;

                if (visualRange < VIS_RANGE_MIN)
                    visualRange = VIS_RANGE_MIN;
                else if (visualRange > VIS_RANGE_MAX)
                    visualRange = VIS_RANGE_MAX;

                m_PIGEnvVisualRange.SetRawValue(visualRange);

                // Underwater range
                double uwRange = m_PIPEnvUnderWaterRange.GetResultValue() * YDS_TO_MTRS * 1000.0;

                if (uwRange < UW_RANGE_MIN)
                    uwRange = UW_RANGE_MIN;
                else if (uwRange > UW_RANGE_MAX)
                    uwRange = UW_RANGE_MAX;

                m_PIGEnvUnderWaterRange.SetRawValue(uwRange);

                // Thermal range
                double thermalRange = m_PIPEnvThermalRange.GetResultValue() * YDS_TO_MTRS * 1000.0;

                if (thermalRange < THERMAL_RANGE_MIN)
                    thermalRange = THERMAL_RANGE_MIN;
                else if (thermalRange > THERMAL_RANGE_MAX)
                    thermalRange = THERMAL_RANGE_MAX;

                m_PIGEnvThermalRange.SetRawValue(thermalRange);

                // Wind speed
                double windSpeed = m_PIPEnvWindSpeed.GetResultValue() * KTS_TO_MPS;

                if (windSpeed < WIND_SPEED_MIN)
                    windSpeed = WIND_SPEED_MIN;
                else if (windSpeed > WIND_SPEED_MAX)
                    windSpeed = WIND_SPEED_MAX;

                m_PIGEnvWindSpeed.SetRawValue(windSpeed);

                // Wind heading
                double windHdg = m_PIPEnvWindHeading.GetResultValue();

                if (windHdg < BRG_MIN)
                    windHdg += BRG_MAX;
                else if (windHdg > BRG_MAX)
                    windHdg -= BRG_MAX;

                m_PIGEnvWindDirn.SetRawValue(windHdg);

                // Moon bearing
                double moonBrg = m_PIPEnvMoonBrg.GetResultValue();

                if (moonBrg < BRG_MIN)
                    moonBrg += BRG_MAX;
                else if (moonBrg > BRG_MAX)
                    moonBrg -= BRG_MAX;

                m_PIGEnvMoonBrgOverRide.SetRawValue(moonBrg);

                // Moon elevation
                double moonElev = m_PIPEnvMoonElev.GetResultValue();

                if (moonElev < ELEV_MIN)
                    moonElev = ELEV_MIN;
                else if (moonElev > ELEV_MAX)
                    moonElev = ELEV_MAX;

                m_PIGEnvMoonElevOverRide.SetRawValue(moonElev);

                // Sun bearing
                double sunBrg = m_PIPEnvSunBrg.GetResultValue();

                if (sunBrg < BRG_MIN)
                    sunBrg += BRG_MAX;
                else if (sunBrg > BRG_MAX)
                    sunBrg -= BRG_MAX;

                m_PIGEnvSunBrgOverRide.SetRawValue(sunBrg);

                // Sun elevation
                double sunElev = m_PIPEnvSunElev.GetResultValue();

                if (sunElev < ELEV_MIN)
                    sunElev = ELEV_MIN;
                else if (sunElev > ELEV_MAX)
                    sunElev = ELEV_MAX;

                m_PIGEnvSunElevOverRide.SetRawValue(sunElev);

                // Ice latitude
                double iceLat = m_PIPEnvIceLat.GetResultValue();

                if (iceLat < LATITUDE_MIN)
                    iceLat = LATITUDE_MIN;
                else if (iceLat > LATITUDE_MAX)
                    iceLat = LATITUDE_MAX;

                m_PIGEnvIceEdgeLat.SetRawValue(iceLat);

                // Ice longitude
                double iceLon = m_PIPEnvIceLon.GetResultValue();

                if (iceLon < LONGITUDE_MIN)
                    iceLon = LONGITUDE_MIN;
                else if (iceLon > LONGITUDE_MAX)
                    iceLon = LONGITUDE_MAX;

                m_PIGEnvIceEdgeLon.SetRawValue(iceLon);

                // Ice orientation
                double iceHdg = m_PIPEnvIceOrien.GetResultValue();

                if (iceHdg < BRG_MIN)
                    iceHdg += BRG_MAX;
                else if (iceHdg > BRG_MAX)
                    iceHdg -= BRG_MAX;

                m_PIGEnvIceEdgeOrien.SetRawValue(iceHdg);
            }

            // Reset the data flag
            m_SIMNewEnvData = false;

        }



        // ----------------------
        // Process OWNBOAT Data
        // ----------------------
        private void ProcessOwnboat()
        {
            bool bigJump;

            //
            // Process the OWNBOAT data
            // Note that there is interpolation of PIP values to give
            // smooth movement
            //

            // Ownboat pre-processing
            OwnboatPreProcess();

            // Ownboat processing
            if (((m_SIMOriginSet == false) && (m_SIMNewOwnData == true)) ||
                (m_SIMExRunMode == SIM_RESET))
            {
                OwnboatReset();
                m_SIMNewOwnData = false;
            }
            else
            {
                if ((m_SIMOriginSet == true) &&
                    (m_SIMExRunMode != SIM_FULL_FREEZE) &&
                    (m_SIMNewOwnData == true))
                    {
                        // Check for Big Jump
                        bigJump = OwnboatCheckForBigJump();

if (bigJump)
{
    Console.WriteLine("");
    Console.WriteLine("Big Jump!");
    Console.WriteLine("");
    OwnboatReset();
}
else
{
    // Update ownboat deltas
    OwnboatUpdateDeltas();
    m_SIMNewOwnData = false;
}

                    }

                if ((m_SIMOriginSet == true) && (m_SIMExRunMode != SIM_FULL_FREEZE))
                {
                    OwnboatInterpolation();
                    OwnboatUpdateMasts();
                }
            }

            // Update PIG raw values
            OwnboatUpdatePIGValues();
        }



        // ------------------------------
        // Ownboat: Pre-process Data
        // ------------------------------
        private void OwnboatPreProcess()
        {

            //
            // Pre-process any values that need units conversion
            // or limits checks
            //

            // Ownboat latitude
            m_PIPOwnLatPro = m_PIPOwnLat.GetResultValue();

            if (m_PIPOwnLatPro < LATITUDE_MIN)
                m_PIPOwnLatPro = LATITUDE_MIN;
            else if (m_PIPOwnLatPro > LATITUDE_MAX)
                m_PIPOwnLatPro = LATITUDE_MAX;


            // Ownboat longitude
            m_PIPOwnLonPro = m_PIPOwnLon.GetResultValue();

            if (m_PIPOwnLonPro < LONGITUDE_MIN)
                m_PIPOwnLonPro = LONGITUDE_MIN;
            else if (m_PIPOwnLonPro > LONGITUDE_MAX)
                m_PIPOwnLonPro = LONGITUDE_MAX;


            // Ownboat depth
            m_PIPOwnDepthPro = (double) m_PIPOwnDepth.GetResultValue() * FT_TO_MTRS;

            if (m_PIPOwnDepthPro < OWN_DEPTH_MIN)
                m_PIPOwnDepthPro = OWN_DEPTH_MIN;
            else if (m_PIPOwnDepthPro > OWN_DEPTH_MAX)
                m_PIPOwnDepthPro = OWN_DEPTH_MAX;

            // Own pitch
            m_PIPOwnPitchPro = (double) m_PIPOwnPitch.GetResultValue();

            if (m_PIPOwnPitchPro < PITCH_MIN)
                m_PIPOwnPitchPro = PITCH_MIN;
            else if (m_PIPOwnPitchPro > PITCH_MAX)
                m_PIPOwnPitchPro = PITCH_MAX;

            // Own heading
            m_PIPOwnHeadingPro = (double) m_PIPOwnHeading.GetResultValue();

            if (m_PIPOwnHeadingPro < BRG_MIN)
                m_PIPOwnHeadingPro += BRG_MAX;
            else if (m_PIPOwnHeadingPro > BRG_MAX)
                m_PIPOwnHeadingPro -= BRG_MAX;

            // Own speed
            m_PIPOwnSpeedPro = (double) m_PIPOwnSpeed.GetResultValue() * KTS_TO_MPS;

            if (m_PIPOwnSpeedPro < OWN_SPEED_MIN)
                m_PIPOwnSpeedPro = OWN_SPEED_MIN;
            else if (m_PIPOwnSpeedPro > OWN_SPEED_MAX)
                m_PIPOwnSpeedPro = OWN_SPEED_MAX;



        }


        // ------------------------------
        // Ownboat: Reset ownboat
        // ------------------------------
        private void OwnboatReset()
        {

            switch (m_PIPOwnType.GetResultValue())
            {
                case PIP_OWN_SUBTEST:
                    // Leave as previous value
                    break;
                case PIP_OWN_SWIFTSURE:
                    m_SIMOwnTypeMast = SIM_OWN_SWIFTSURE;
                    break;
                case PIP_OWN_TRAFALGAR:
                    m_SIMOwnTypeMast = SIM_OWN_TRAFALGAR;
                    break;
            }

            m_SIMOriginLat = m_PIPOwnLatPro;
            m_SIMOriginLon = m_PIPOwnLonPro;
            m_SIMOriginSet = true;

            m_SIMOwnLat = m_PIPOwnLatPro;
            m_SIMOwnLon = m_PIPOwnLonPro;

            m_SIMOwnX = 0.0;
            m_SIMOwnY = 0.0;
            m_SIMOwnZ = m_PIPOwnDepthPro;

            m_SIMOwnHeading = m_PIPOwnHeadingPro;
            m_SIMOwnPitch = m_PIPOwnPitchPro;
            m_SIMOwnRoll = 0.0;
            m_SIMOwnSpeed = m_PIPOwnSpeedPro;

            m_SIMOwnXCorrection = 0.0;
            m_SIMOwnYCorrection = 0.0;
            m_SIMExRunMode = SIM_RESET;
            m_SIMEnvIceLat = (double) m_PIPEnvIceLat.GetResultValue();
            m_SIMEnvIceLon = (double) m_PIPEnvIceLon.GetResultValue();

        }



        // ------------------------------
        // Ownboat: Check for big jump
        // ------------------------------
        private bool OwnboatCheckForBigJump()
        {

            // Calculate big jump delta to cater for fast run (x10)
            double bigJumpDelta;
            if (this.m_SIMExRunMode != SIM_FAST_RUN)
                bigJumpDelta = OWN_BIG_JUMP;
            else
                bigJumpDelta = OWN_BIG_JUMP * 10.0;

            // Calculate delta lat and lon for ownboat
            m_SIMOwnDeltaLat = Math.Abs(m_SIMOwnLat - m_PIPOwnLatPro);
            m_SIMOwnDeltaLon = Math.Abs(m_SIMOwnLon - m_PIPOwnLonPro);

            // Calculate delta lat and lon for ice edge
            double deltaIceLat = Math.Abs(m_SIMEnvIceLat - m_PIPEnvIceLat.GetResultValue());
            double deltaIceLon = Math.Abs(m_SIMEnvIceLon - m_PIPEnvIceLon.GetResultValue());

            // Check for big jump in ownboat position
            bool result = false;
            if (m_SIMOwnDeltaLat > bigJumpDelta)
                result = true;

            if (Math.Abs(m_SIMOwnLat) < OWN_LAT_THRESH)
            {
                if (m_SIMOwnDeltaLon > (bigJumpDelta / Math.Cos(m_SIMOwnLat * DEGS_TO_RADS)))
                    result = true;
            }

            // Check for big jump in ice edge position
            if (deltaIceLat > ICE_BIG_JUMP)
                result = true;

            if (Math.Abs(m_SIMEnvIceLat) < OWN_LAT_THRESH)
            {
                if (deltaIceLon > (ICE_BIG_JUMP / Math.Cos(m_SIMEnvIceLat * DEGS_TO_RADS)))
                    result = true;
            }

            // Return the result
            return (result);
        }



        //---------------------------------
        // Ownboat: Update ownboat deltas
        // --------------------------------
        private void OwnboatUpdateDeltas()
        {
            count = 0;

            //
            // Update ownboat lat lon from PIP
            //
            m_SIMOwnLat = m_PIPOwnLatPro;
            m_SIMOwnLon = m_PIPOwnLonPro;

            //
            // Update ice edge lat lon from PIP
            //
            m_SIMEnvIceLat = (double) m_PIPEnvIceLat.GetResultValue();
            m_SIMEnvIceLon = (double) m_PIPEnvIceLon.GetResultValue();

            //
            // Convert ownboat lat lon to its XY (m)
            //
            double ownXNew = RADIUS_EARTH * (Math.Asin (Math.Sin ((m_SIMOwnLon * DEGS_TO_RADS) -
                                                                  m_SIMOriginLon * DEGS_TO_RADS) * Math.Cos(m_SIMOwnLat * DEGS_TO_RADS)));

            double ownYNew = RADIUS_EARTH * (Math.Atan (Math.Tan (m_SIMOwnLat * DEGS_TO_RADS) /
                                                        Math.Cos ((m_SIMOwnLon * DEGS_TO_RADS) - (m_SIMOriginLon * DEGS_TO_RADS))) -
                                             (m_SIMOriginLat * DEGS_TO_RADS));

            //
            // Calculate the XY corrections for lat lon positional error
            //
            if ((m_SIMOwnDeltaLat > 0.0) || (m_SIMOwnDeltaLon > 0.0))
            {
                m_SIMOwnXCorrection = (ownXNew - m_SIMOwnX) * m_PIPDeltaTime;
                m_SIMOwnYCorrection = (ownYNew - m_SIMOwnY) * m_PIPDeltaTime;
            }
            else
            {
                m_SIMOwnXCorrection = 0.0;
                m_SIMOwnYCorrection = 0.0;
            }

            //
            // Delta speed
            //

            // Target speed is the PIP value
            double targetSpeed = m_PIPOwnSpeedPro;

            // Delta speed is the interpolated value this iteration
            m_SIMOwnDeltaSpeed = (targetSpeed - m_SIMOwnSpeed) * m_PIPDeltaTime;


            //
            // Turn rate
            //
            double ownTurn = m_PIPOwnTurnRate.GetResultValue();

            if (ownTurn < OWN_TURN_MIN)
                ownTurn = OWN_TURN_MIN;
            else if (ownTurn > OWN_TURN_MAX)
                ownTurn = OWN_TURN_MAX;

            m_SIMOwnTurnRate = ownTurn;


            //
            // Delta heading
            //

            // Target heading is the PIP value (degrees)
            double targetHeading = m_PIPOwnHeadingPro;

            // Calculate the delta heading, checking for going over 360 degrees
            m_SIMOwnDeltaHeading = (m_SIMOwnTurnRate * m_IterationTime);

            if (Math.Abs(m_SIMOwnHeading - targetHeading) < 180.0)
            {
                // Not gone over 360 degrees
                m_SIMOwnDeltaHeading += ((targetHeading - m_SIMOwnHeading) * m_PIPDeltaTime);
            }
            else
            {
                // Gone over 360 dgrees
                if (m_SIMOwnHeading > targetHeading)
                {
                    // Target heading increasing over 360 degrees
                    m_SIMOwnDeltaHeading += ((360.0 - m_SIMOwnHeading) + targetHeading) * m_PIPDeltaTime;
                }
                else
                {
                    // Target heading decreasing over 360 degrees
                    m_SIMOwnDeltaHeading += ((targetHeading - 360.0) - m_SIMOwnHeading) * m_PIPDeltaTime;
                }
            }

            //    if (Math.Abs(m_SIMOwnDeltaHeading) < 0.00001)
            //       m_SIMOwnDeltaHeading = 0.0;

            //
            // Delta pitch
            //

            // Target pitch is the PIP value
            double targetPitch = m_PIPOwnPitchPro;

            // Delta pitch is the interpolated value
            m_SIMOwnDeltaPitch = (targetPitch - m_SIMOwnPitch) * m_PIPDeltaTime;


            //
            // Delta drift XY
            //

            // Drift speed is the PIP value
            double driftSpeed = (double) m_PIPOwnDriftSpeed.GetResultValue() * KTS_TO_MPS;

            if (driftSpeed < OWN_DRIFT_MIN)
                driftSpeed = OWN_DRIFT_MIN;
            else if (driftSpeed > OWN_DRIFT_MAX)
                driftSpeed = OWN_DRIFT_MAX;

            // Drift course is the PIP value (converted to radians)
            double driftCourse = (double) m_PIPOwnDriftCourse.GetResultValue() * DEGS_TO_RADS;

            if (driftCourse < BRG_MIN)
                driftCourse += BRG_MAX;
            else if (driftCourse > BRG_MAX)
                driftCourse -= BRG_MAX;

            // Drift X and Y are the amount the ownboat has moved due to drift
            m_SIMOwnDeltaDriftX = driftSpeed * Math.Sin(driftCourse) * m_IterationTime;
            m_SIMOwnDeltaDriftY = driftSpeed * Math.Cos(driftCourse) * m_IterationTime;


            //
            // Delta Z
            //

            // Target Z is the PIP value
            double targetZ = m_PIPOwnDepthPro;

            // Delta Z is the interpolated value
            m_SIMOwnDeltaZ = (targetZ - m_SIMOwnZ) * m_PIPDeltaTime;


            //
            // Delta climb
            //
            double climbRate = (double) m_PIPOwnClimbRate.GetResultValue() * FT_TO_MTRS;

            if (climbRate < OWN_CLIMB_MIN)
                climbRate = OWN_CLIMB_MIN;
            else if (climbRate > OWN_CLIMB_MAX)
                climbRate = OWN_CLIMB_MAX;

            m_SIMOwnDeltaClimb = climbRate * m_IterationTime;


            //
            // Reset data flag
            //
            m_SIMNewOwnData = false;

        }



        // ------------------------
        // Ownboat: Interpolation
        // ------------------------
        private void OwnboatInterpolation()
        {

            count++;
            //
            // Speed
            //

            m_SIMOwnSpeed += m_SIMOwnDeltaSpeed;

            // Check limits
            if (m_SIMOwnSpeed < OWN_SPEED_MIN)
                m_SIMOwnSpeed = OWN_SPEED_MIN;

            if (m_SIMOwnSpeed > OWN_SPEED_MAX)
                m_SIMOwnSpeed = OWN_SPEED_MAX;


            //
            // Heading
            //
            m_SIMOwnHeading = NormalisedAngle(m_SIMOwnHeading + m_SIMOwnDeltaHeading + 360.0);


            //
            // Periscope True Heading
            //
            m_SIMPeriTrueHeading = NormalisedAngle(m_SIMOwnHeading + (double) m_PIGPeriRelBrg.GetResultValue());


            //
            // Ownboat XY
            //

            // Update internal X position due to ownboat movement, drift and position correction
            double ownDeltaX = m_SIMOwnSpeed * Math.Sin(m_SIMOwnHeading * DEGS_TO_RADS) * m_IterationTime;

            m_SIMOwnX += ownDeltaX + m_SIMOwnDeltaDriftX + m_SIMOwnXCorrection;

            // Check limits
            if (m_SIMOwnX < OWN_X_MIN)
                m_SIMOwnX = OWN_X_MIN;

            if (m_SIMOwnX > OWN_X_MAX)
                m_SIMOwnX = OWN_X_MAX;

            // Update internal Y position due to ownboat movement, drift and position correction
            double ownDeltaY = m_SIMOwnSpeed * Math.Cos(m_SIMOwnHeading * DEGS_TO_RADS) * m_IterationTime;

            m_SIMOwnY += ownDeltaY + m_SIMOwnDeltaDriftY + m_SIMOwnYCorrection;

            // Check limits
            if (m_SIMOwnY < OWN_Y_MIN)
                m_SIMOwnY = OWN_Y_MIN;

            if (m_SIMOwnY > OWN_Y_MAX)
                m_SIMOwnY = OWN_Y_MAX;


            //
            // Update Z position (Z is eyepoint height)
            //
            m_SIMOwnZ += m_SIMOwnDeltaClimb + m_SIMOwnDeltaZ;

            // Check limits
            if (m_SIMOwnZ < OWN_Z_MIN)
                m_SIMOwnZ = OWN_Z_MIN;

            if (m_SIMOwnZ > OWN_Z_MAX)
                m_SIMOwnZ = OWN_Z_MAX;


            //
            // Update ownboat distance to horizon depending on whether eyepoint (z)
            // is above the water surface or not
            //
            if (m_SIMOwnZ > 0.0)
            {
                // Above water
                m_SIMOwnHorizon = Math.Sqrt (((RADIUS_EARTH + m_SIMOwnZ) * (RADIUS_EARTH + m_SIMOwnZ)) - (RADIUS_EARTH * RADIUS_EARTH));
            }
            else
            {
                // Under water - fix to 1000.0
                m_SIMOwnHorizon = 1000.0;
            }

            //
            // Pitch
            //
            m_SIMOwnPitch += m_SIMOwnDeltaPitch;

            // Check limits
            if (m_SIMOwnPitch < OWN_PITCH_MIN)
                m_SIMOwnPitch = OWN_PITCH_MIN;

            if (m_SIMOwnPitch > OWN_PITCH_MAX)
                m_SIMOwnPitch = OWN_PITCH_MAX;


            //
            // Roll - set to zero
            //
            m_SIMOwnRoll = 0.0;
        }



        // --------------------------------
        // Ownboat: Update ownboat masts
        // --------------------------------
        private void OwnboatUpdateMasts()
        {
            int i;
            float[] targetHeight = new float[10];

            //
            // Determine the target height for each mast
            // (using the config data for maximum extension)
            //

            // Search Mast
            if (m_PIPPeriInstructCtrl.GetResultValue() == true)
            {
                // Instructor remote control
                if (m_PIPPeriSearchUp.GetResultValue())
                    targetHeight[0] = m_SIMOwnMastMaxExt[m_SIMOwnTypeMast, 0];
                else
                    targetHeight[0] = 0.0f;
            }
            else
            {
                // Periscope local control
                if (m_IOHandlesDown.GetResultValue() == true)
                    targetHeight[0] = m_SIMOwnMastMaxExt[m_SIMOwnTypeMast, 0];
                else
                    targetHeight[0] = 0.0f;
            }

            // Attack Mast
            targetHeight[1] = (float) m_PIPOwnMastAttack.GetResultValue() * 0.01f * m_SIMOwnMastMaxExt[m_SIMOwnTypeMast, 1];

            // RESM Mast
            targetHeight[2] = (float) m_PIPOwnMastRESM.GetResultValue() * 0.01f * m_SIMOwnMastMaxExt[m_SIMOwnTypeMast, 2];

            // WT Comms Mast
            targetHeight[3] = (float) m_PIPOwnMastWTComms.GetResultValue() * 0.01f * m_SIMOwnMastMaxExt[m_SIMOwnTypeMast, 3];

            // HFDF Mast
            targetHeight[4] = (float) m_PIPOwnMastHFDF.GetResultValue() * 0.01f * m_SIMOwnMastMaxExt[m_SIMOwnTypeMast, 4];

            // Radar Mast
            targetHeight[5] = (float) m_PIPOwnMastRadar.GetResultValue() * 0.01f * m_SIMOwnMastMaxExt[m_SIMOwnTypeMast, 5];

            // Snort Induction Mast
            targetHeight[6] = (float) m_PIPOwnMastSnortInd.GetResultValue() * 0.01f * m_SIMOwnMastMaxExt[m_SIMOwnTypeMast, 6];

            // Snort Exhaust Mast
            targetHeight[7] = (float) m_PIPOwnMastSnortExh.GetResultValue() * 0.01f * m_SIMOwnMastMaxExt[m_SIMOwnTypeMast, 7];

            // Whip Aerial
            if (m_PIPOwnWhipAerialUp.GetResultValue())
                targetHeight[8] =   m_SIMOwnMastMaxExt[m_SIMOwnTypeMast, 8];
            else
                targetHeight[8] =  0.0f;

            // Emergency Light
            if (m_PIPOwnEmerLightUp.GetResultValue())
                targetHeight[9] =   m_SIMOwnMastMaxExt[m_SIMOwnTypeMast, 9];
            else
                targetHeight[9] =  0.0f;


            //
            // Calculate the sim height of each mast using the target height and the
            // config setting for mast speed.
            //

            for (i = 0; i < 10; i++)
            {
                // Does the mast need to be raised?
                if (m_SIMOwnMastHeight[i] < targetHeight[i])
                {
                    // Raise the mast
                    m_SIMOwnMastHeight[i] += (m_SIMOwnMastSpeed[m_SIMOwnTypeMast, i] * (float) m_DeltaTime);

                    // Check if gone beyond target height
                    if (m_SIMOwnMastHeight[i] > targetHeight[i])
                        m_SIMOwnMastHeight[i] = targetHeight[i];
                }

                // Does the mast need to be lowered?
                if (m_SIMOwnMastHeight[i] > targetHeight[i])
                {
                    // Lower the mast
                    m_SIMOwnMastHeight[i] -= (m_SIMOwnMastSpeed[m_SIMOwnTypeMast, i] * (float) m_DeltaTime);

                    // Check if gone beyond target height
                    if (m_SIMOwnMastHeight[i] < targetHeight[i])
                        m_SIMOwnMastHeight[i] = targetHeight[i];
                }
            }

        }



        // ---------------------------
        // Ownboat: Update PIG Values
        // ---------------------------
        private void OwnboatUpdatePIGValues()
        {
            int i;

            //
            // Set the PIG raw values
            //

            m_PIGOwnType.SetRawValue((byte)m_SIMOwnTypeMast);

            if (m_PIPOwnDieselSmoke.GetResultValue())
                m_PIGOwnSmoke.SetRawValue((byte) 1);
            else
                m_PIGOwnSmoke.SetRawValue((byte) 0);

            m_PIGOwnLatitude.SetRawValue((float) m_SIMOwnLat);
            m_PIGOwnLongitude.SetRawValue((float) m_SIMOwnLon);
            m_PIGOwnX.SetRawValue(m_SIMOwnX);
            m_PIGOwnY.SetRawValue(m_SIMOwnY);

            // PIG depth is minus search mast height
            m_PIGOwnDepth.SetRawValue(m_SIMOwnZ - m_SIMOwnMastHeight[0]);

            m_PIGOwnHeading.SetRawValue(m_SIMOwnHeading);
            m_PIGOwnPitch.SetRawValue(m_SIMOwnPitch);
            m_PIGOwnRoll.SetRawValue(m_SIMOwnRoll);

            m_PIGOwnSpeed.SetRawValue(m_SIMOwnSpeed);

            for (i = 0; i < 10; i++)
                m_PIGOwnMast[i].SetRawValue(m_SIMOwnMastHeight[i]);

        }



        // ------------------------
        // Process PERISCOPE Data
        // ------------------------
        private void ProcessPeriscope()
        {

            int periSensor = SENSOR_OPTICAL;
            int periGain;

            //
            // Process the PERISCOPE data
            // Note there is no interpolation of periscope values.
            //

            //
            // Set the local instructor control flag from the PIP
            //
            bool instructorControl = m_PIPPeriInstructCtrl.GetResultValue();

            //
            // Draindown - only set by the PIP
            //
            m_PIGPeriDraindown.SetRawValue(m_PIPPeriDraindown.GetResultValue());

            // Draindown time
            byte drain = m_PIPPeriDraindown.GetResultValue();

            if (drain > DRAINDOWN_MAX)
                drain = DRAINDOWN_MIN;

            m_PIGPeriDraindown.SetRawValue(drain);


            //
            // Sensor type and gain - depends on instructor control and thermal controls
            //
            if ((instructorControl) || (m_ThermalControls == false))
            {
                // Set the values from the PIP

                // Convert gains to percent (PIP value has max of 6, 100/6 = 16.6667)
                int gainLLTV = (int) ((float) m_PIPPeriLLTVGain.GetResultValue() * 16.667f);
                int gainThermal = (int) ((float) m_PIPPeriThermalGain.GetResultValue() * 16.667f);

                // Ensure only the highest gain is set
                if (gainLLTV > gainThermal)
                    gainThermal = 0;

                if (gainThermal > gainLLTV)
                    gainLLTV = 0;

                // Determine sensor type from maximum gain value
                if (gainLLTV > 0)
                {
                    // LLTV
                    periSensor = SENSOR_LLTV;
                    periGain = gainLLTV;
                }
                else if (gainThermal > 0)
                {
                    // Thermal
                    if (m_PIPPeriPolarityWhite.GetResultValue() == true)
                        periSensor = SENSOR_WHIR;
                    else
                        periSensor = SENSOR_BHIR;

                    periGain = gainThermal;
                }
                else
                {
                    // Optical
                    periSensor = SENSOR_OPTICAL;
                    periGain = 0;
                }

                // Set the values
                m_PIGPeriSensor.SetRawValue((byte) periSensor);
                m_PIGPeriGain.SetRawValue((byte) periGain);
            }
            else
            {
                // Set the values from the IO
                int ioSensor = m_IOModeSelect.GetResultValue();

                // switch (ioSensor)
                // {
                //   case IOComms.MODE_SELECT_OPTICAL:
                //      periSensor = SENSOR_OPTICAL;
                //      break;
                //   case IOComms.MODE_SELECT_THERMAL:
                //      // IO can only select Thermal so set WH/BH from PIP
                //      if (m_PIPPeriPolarityWhite.GetResultValue() == true)
                //         periSensor = SENSOR_WHIR;
                //      else
                //         periSensor = SENSOR_BHIR;
                //      break;
                //   case IOComms.MODE_SELECT_LLTV:
                //      periSensor = SENSOR_LLTV;
                //      break;
                // }

                m_PIGPeriSensor.SetRawValue((byte) periSensor);
                m_PIGPeriGain.SetRawValue((byte) m_IOTiSensitivity.GetResultValue());
            }

            int sensor  = (int) m_PIGPeriSensor.GetRawValue();


            //
            // Graticule intensity - depends on thermal controls
            //
            if (m_ThermalControls)
            {
                // Depends on Data Overlay switch
                if (m_IODataOverlay.GetResultValue())
                {
                    // Set as per TI Graticule Illumination control
                    m_PIGPeriGratIntensity.SetRawValue((byte) m_IOTiGratIllum.GetResultValue());
                }
                else
                {
                    // Set to off
                    m_PIGPeriGratIntensity.SetRawValue((byte) 0);
                }
            }
            else
            {
                // No thermal controls so default to 100%
                m_PIGPeriGratIntensity.SetRawValue((byte) 100);
            }


            //
            // Magnification - depends on instructor control
            //
            if (instructorControl)
            {
                // Set the value from the PIP
                if (m_PIPPeriHighMag.GetResultValue())
                    m_PIGPeriMagnification.SetRawValue((byte) PIG_HIGH_MAG_FOV);
                else
                    m_PIGPeriMagnification.SetRawValue((byte) PIG_LOW_MAG_FOV);
            }
            else
            {
                // Set the value from the IO
                if (m_IOHighMag.GetResultValue())
                    m_PIGPeriMagnification.SetRawValue((byte) PIG_HIGH_MAG_FOV);
                else
                    m_PIGPeriMagnification.SetRawValue((byte) PIG_LOW_MAG_FOV);
            }


            //
            // Stadiametric Angle - only set by the IO
            //
            float stadAngle = m_IOStadAngle.GetResultValue();

            // Multiply by magnification factor
            //if (m_PIGPeriMagnification.GetResultValue() == PIG_LOW_MAG_FOV)
            //    stadAngle *= 4.0f;

            m_PIGPeriStadAngle.SetRawValue(stadAngle);


            //
            // Contrast - depends on thermal controls
            //
            if (m_ThermalControls == false)
            {
                // Default to high
                m_PIGPeriContrast.SetRawValue((byte) 100.0f);
            }
            else
            {
                // Set the value from the IO
                m_PIGPeriContrast.SetRawValue((byte) m_IOTiBlackLevel.GetResultValue());

            }


            //
            // Relative Bearing - depends on instructor control
            //
            double relBrg;

            if (instructorControl)
            {
                // Set the value from the PIP
                relBrg = m_PIPPeriRelBearing.GetResultValue();
            }
            else
            {
                // Set the value from the IO
                relBrg = m_IOBearing.GetResultValue();
            }

            // Check limits
            if (relBrg < BRG_MIN)
                relBrg += BRG_MAX;
            else if (relBrg > BRG_MAX)
                relBrg -= BRG_MAX;

            // Set value
            m_PIGPeriRelBrg.SetRawValue(relBrg);


            //
            // Elevation - depends on instructor control
            //
            double elevation;

            if (instructorControl)
            {
                // Set the value from the PIP
                elevation = m_PIPPeriElevation.GetResultValue();
            }
            else
            {
                // Set the value from the IO
                elevation = m_IOElevation.GetResultValue();
            }

            // Check limits
            if (elevation < m_SIMElevationMin)
                elevation = m_SIMElevationMin;
            else if (elevation > m_SIMElevationMax)
                elevation = m_SIMElevationMax;

            // Set value
            m_PIGPeriElevation.SetRawValue(elevation);


        }



        // ------------------------
        // Process TARGET Data
        // ------------------------
        private void ProcessTargets()
        {
            int i;

            int PIGTargetsVisible = 0;
            int PIGTargetsBurning = 0;
            int PIGTargetsTotal = 0;

            //
            // Process the TARGET data
            // Note that there is interpolation of PIP values to give
            // smooth movement of targets
            //

            // Target pre-processing
            TargetPreProcess();

            //
            // Return if origin not defined
            //
            if (m_SIMOriginSet == false)
                return;


            //
            // ProcessTargets
            //
            if (((m_SIMNewTarData == true) && (m_SIMTarInitialised == false)) ||
                (m_SIMExRunMode == SIM_RESET))
            {
                //
                // Reset each target at initialisation or on reset
                //
                for (i = 0; i < SIM_NUMBER_TARGETS; i++)
                    TargetInitialise(i);

                m_SIMTarInitialised = true;
            }
            else if ((m_SIMNewTarData == true) && (m_SIMExRunMode != SIM_RESET))
            {
                //
                // Update each target according to its status
                //
                for (i = 0; i < SIM_NUMBER_TARGETS; i++)
                {
                    if (m_SIMTargets[i].m_SIMTarStatus == SIM_TARGET_NOT_PRESENT)
                    {
                        // Target is not present - if it should be initialise it
                        if (m_PIPTargets[i].m_PIPTarPresentPro)
                        {
                            TargetInitialise(i);
                            m_SIMTargets[i].m_SIMTarStatus = SIM_TARGET_PRESENT;
                        }
                    }

                    if (m_SIMTargets[i].m_SIMTarStatus == SIM_TARGET_PRESENT)
                    {
                        // Target is present
                        if (m_PIPTargets[i].m_PIPTarPresentPro)
                        {
                            // Target should be present so update its data from PIP
                            m_SIMTargets[i].m_SIMTarModelID = m_PIPTargets[i].m_PIPTarModelIDPro;
                            m_SIMTargets[i].m_SIMTarSlotID = m_PIPTargets[i].m_PIPTarSlotIDPro;
                            m_SIMTargets[i].m_SIMTarPresent = m_PIPTargets[i].m_PIPTarPresentPro;
                            m_SIMTargets[i].m_SIMTarFlames = m_PIPTargets[i].m_PIPTarFlames.GetResultValue();
                            m_SIMTargets[i].m_SIMTarMissileHit = m_PIPTargets[i].m_PIPTarMissileHit.GetResultValue();
                            m_SIMTargets[i].m_SIMTarTorpedoHit = m_PIPTargets[i].m_PIPTarTorpedoHit.GetResultValue();
                            m_SIMTargets[i].m_SIMTarSinking = m_PIPTargets[i].m_PIPTarSinking.GetResultValue();
                            m_SIMTargets[i].m_SIMTarNavLights = m_PIPTargets[i].m_PIPTarNavLights.GetResultValue();
                            m_SIMTargets[i].m_SIMTarDunkingSonar = m_PIPTargets[i].m_PIPTarDunkingSonar.GetResultValue();
                            m_SIMTargets[i].m_SIMTarTLAM = m_PIPTargets[i].m_PIPTarTLAMFaulty.GetResultValue();
                            m_SIMTargets[i].m_SIMTarDieselSmoke = m_PIPTargets[i].m_PIPTarDieselSmoke.GetResultValue();
                            m_SIMTargets[i].m_SIMTarFireMissile = m_PIPTargets[i].m_PIPTarFireMissile.GetResultValue();
                            m_SIMTargets[i].m_SIMTarLightConfig = m_PIPTargets[i].m_PIPTarLightConfigPro;
                            m_SIMTargets[i].m_SIMTarSpotConfig = m_PIPTargets[i].m_PIPTarSpotConfigPro;


                            // Set the hitpoint depending on the type of hit
                            // (default hitpoints at present - for future expansion)
                            if (m_SIMTargets[i].m_SIMTarMissileHit)
                                m_SIMTargets[i].m_SIMTarHitPoint = 1;   // Middle

                            if (m_SIMTargets[i].m_SIMTarTorpedoHit)
                                m_SIMTargets[i].m_SIMTarHitPoint = 0;   // Back

                            if (m_SIMTargets[i].m_SIMTarSinking)
                                m_SIMTargets[i].m_SIMTarStatus = SIM_TARGET_SINKING;
                        }
                        else
                        {
                            // Target should not be present so start to get rid of it
                            Console.WriteLine("Setting to SIM_TARGET_BEING_REMOVED: {0} slot {1}", i.ToString(), m_SIMTargets[i].m_SIMTarSlotID);
                            m_SIMTargets[i].m_SIMTarStatus = SIM_TARGET_BEING_REMOVED;
                            TargetClear(i);
                        }
                    }
                    else if ((m_SIMTargets[i].m_SIMTarStatus == SIM_TARGET_SUNK) ||
                             (m_SIMTargets[i].m_SIMTarStatus == SIM_TARGET_BEING_REMOVED))
                    {
                        // Target should not be present so start to get rid of it
                        TargetClear(i);
                        m_SIMTargets[i].m_SIMTarStatus = SIM_TARGET_NOT_PRESENT;

                    }
                    else if (m_SIMTargets[i].m_SIMTarStatus == SIM_TARGET_SINKING)
                    {
                        // Keep target present during sinking
                        m_SIMTargets[i].m_SIMTarPresent = true;
                    }

                    // If the current target is present and not sinking, update the deltas
                    if ((m_SIMTargets[i].m_SIMTarStatus != SIM_TARGET_SINKING) && (m_SIMTargets[i].m_SIMTarPresent))
                    {
                        TargetUpdateDeltas(i);
                    }

                    // Check if any of the position deltas are greater than the maximum.
                    // If they are then a reposition is being attempted so initialise the
                    // target data
                    if ((Math.Abs(m_SIMTargets[i].m_SIMTarDeltaX) > TAR_DELTA_MAX) ||
                        (Math.Abs(m_SIMTargets[i].m_SIMTarDeltaY) > TAR_DELTA_MAX) ||
                        (Math.Abs(m_SIMTargets[i].m_SIMTarDeltaZ) > TAR_DELTA_MAX))
                    {
                        TargetInitialise(i);
                    }
                }

m_SIMNewTarData = false;
            }

            //
            // Interpolate the targets
            //
            if (m_SIMExRunMode != SIM_RESET)
            {
                for (i = 0; i < SIM_NUMBER_TARGETS; i++)
                {
                    if ((m_SIMTargets[i].m_SIMTarPresent) || (m_SIMTargets[i].m_SIMTarSinking))
                    {
                        TargetInterpolation(i);
                    }
                }
            }

            //
            // Determine PIG Targets
            //
            if ((m_SIMExRunMode == SIM_RUN) || (m_SIMExRunMode == SIM_TARGET_FREEZE) || (m_SIMExRunMode == SIM_FAST_RUN))
            {

                //
                // Determine the fov limits
                // (use PIG result values to cater for overrides)
                //
                float periTrueHeading = (float) NormalisedAngle(m_PIGOwnHeading.GetResultValue() +
                                                                m_PIGPeriRelBrg.GetResultValue());

                float periElevation = m_PIGPeriElevation.GetResultValue();

                float periFOV = m_PIGPeriMagnification.GetResultValue();

                float periPitch = m_PIGOwnPitch.GetResultValue();

                m_SIMFOVLeft = periTrueHeading - (periFOV * 0.5f);
                m_SIMFOVRight = periTrueHeading + (periFOV * 0.5f);
                m_SIMFOVUpper = periPitch + periElevation + (periFOV * 0.5f);
                m_SIMFOVLower = periPitch + periElevation - (periFOV * 0.5f);

                m_SIMLookingNorth = false;

                if (m_SIMFOVLeft < 0.0f)
                {
                    m_SIMFOVLeft += 360.0f;
                    m_SIMLookingNorth = true;
                }
                else if (m_SIMFOVRight > 360.0f)
                {
                    m_SIMFOVRight -= 360.0f;
                    m_SIMLookingNorth = true;
                }

                //
                // Check for visible (and sonar) targets
                //
                for (i = 0; i < SIM_NUMBER_TARGETS; i++)
                {
                    // Default display to off
                    m_SIMTargets[i].m_SIMTarPIGDisplay = false;

                    // Process if there are still spaces
                    if (PIGTargetsVisible < PIG_NUMBER_TARGETS)
                    {
                        switch (m_SIMTargets[i].m_SIMTarStatus)
                        {
                            case SIM_TARGET_PRESENT:
                                // Check if target should be displayed
                                if (TargetInCloseProximity(i))
                                {
                                    // Target is in close proximity
                                    m_SIMTargets[i].m_SIMTarPIGDisplay = true;
                                    PIGTargetsVisible++;
                                }
                                else if (TargetInVisualRange(i) &&
                                         TargetInHorizontalFOV(i))
                                {
                                    // Target is in the fov
                                    m_SIMTargets[i].m_SIMTarPIGDisplay = true;
                                    PIGTargetsVisible++;
                                }
                                else if (TargetIsSonar(i))
                                {
                                    // Sonar target - always 'display'
                                    m_SIMTargets[i].m_SIMTarPIGDisplay = true;
                                    PIGTargetsVisible++;
                                }
                                break;

                            case SIM_TARGET_SINKING:
                                m_SIMTargets[i].m_SIMTarPIGDisplay = true;
                                PIGTargetsVisible++;
                                break;
                            case SIM_TARGET_BEING_REMOVED:
                                m_SIMTargets[i].m_SIMTarPIGDisplay = true;
                                PIGTargetsVisible++;
                                break;
                            case SIM_TARGET_NOT_PRESENT:
                                m_SIMTargets[i].m_SIMTarPIGDisplay = false;
                                break;
                            case SIM_TARGET_SUNK:
                                m_SIMTargets[i].m_SIMTarPIGDisplay = false;
                                break;
                        }
                    }
                }
            }

            //
            // Check for any burning targets
            //
            for (i = 0; i < SIM_NUMBER_TARGETS; i++)
            {
                // Process if there are still spaces
                if (PIGTargetsVisible + PIGTargetsBurning < PIG_NUMBER_TARGETS)
                {
                    // If the target is burning and it is not already being displayed then
                    // set it to be displayed and update the burning counter
                    if (TargetIsBurning(i) && (m_SIMTargets[i].m_SIMTarPIGDisplay == false))
                    {
                        m_SIMTargets[i].m_SIMTarPIGDisplay = true;
                        PIGTargetsBurning++;
                    }
                }
            }

            //
            // Update the total number of targets for the PIG to display
            //
            PIGTargetsTotal = PIGTargetsVisible + PIGTargetsBurning;

            //
            // Set the PIG data
            //
            TargetSetPIGData();
        }



        // -------------------------
        // Target: Pre-process Data
        // -------------------------
        private void TargetPreProcess()
        {

            int i;

            //
            // Pre-process target data to check for valid targets, perform
            // units conversion and check limts
            //

            for (i = 0; i < SIM_NUMBER_TARGETS; i++)
            {
                // Target present
                m_PIPTargets[i].m_PIPTarPresentPro = m_PIPTargets[i].m_PIPTarPresent.GetResultValue();

                if (m_PIPTargets[i].m_PIPTarPresentPro)
                {
                    // Model ID
                    m_PIPTargets[i].m_PIPTarModelIDPro = m_PIPTargets[i].m_PIPTarModelID.GetResultValue();

                    m_PIPTargets[i].m_PIPTarSlotIDPro = m_PIPTargets[i].m_PIPTarSlotID.GetResultValue();
                    //Console.WriteLine("SIM target {0} slot {1}", i, m_PIPTargets[i].m_PIPTarSlotIDPro);
                }

                // Check that target is present and valid
                bool present = m_PIPTargets[i].m_PIPTarPresentPro;
                bool valid = CheckTargetModel(m_PIPTargets[i].m_PIPTarModelIDPro);

                // Only update present and valid targets
                if ((present == false) || (valid == false))
                {
                    m_PIPTargets[i].m_PIPTarPresentPro = false;
                    m_PIPTargets[i].m_PIPTarModelIDPro = MODEL_ID_MIN;
                }
                else
                {
                    // Dunking data
                    m_PIPTargets[i].m_PIPTarDunkingDataPro = m_PIPTargets[i].m_PIPTarDunkingData.GetResultValue();

                    if (m_PIPTargets[i].m_PIPTarDunkingDataPro > SONAR_DEPTH_MAX)
                        m_PIPTargets[i].m_PIPTarDunkingDataPro = SONAR_DEPTH_MAX;

                    // Light config
                    m_PIPTargets[i].m_PIPTarLightConfigPro = m_PIPTargets[i].m_PIPTarLightConfig.GetResultValue();

                    if (m_PIPTargets[i].m_PIPTarLightConfigPro > LIGHT_CONFIG_MAX)
                        m_PIPTargets[i].m_PIPTarLightConfigPro = LIGHT_CONFIG_MAX;

                    // Spotlight config
                    m_PIPTargets[i].m_PIPTarSpotConfigPro = m_PIPTargets[i].m_PIPTarSpotConfig.GetResultValue();

                    if (m_PIPTargets[i].m_PIPTarSpotConfigPro > SPOT_CONFIG_MAX)
                        m_PIPTargets[i].m_PIPTarSpotConfigPro = SPOT_CONFIG_MAX;

                    // Target X
                    m_PIPTargets[i].m_PIPTarXPro = m_PIPTargets[i].m_PIPTarX.GetResultValue() * 1000.0f * YDS_TO_MTRS;

                    if (m_PIPTargets[i].m_PIPTarXPro < TAR_X_MIN)
                        m_PIPTargets[i].m_PIPTarXPro = TAR_X_MIN;
                    else if (m_PIPTargets[i].m_PIPTarXPro > TAR_X_MAX)
                        m_PIPTargets[i].m_PIPTarXPro = TAR_X_MAX;

                    // Target Y
                    m_PIPTargets[i].m_PIPTarYPro = m_PIPTargets[i].m_PIPTarY.GetResultValue() * 1000.0f * YDS_TO_MTRS;

                    if (m_PIPTargets[i].m_PIPTarYPro < TAR_Y_MIN)
                        m_PIPTargets[i].m_PIPTarYPro = TAR_Y_MIN;
                    else if (m_PIPTargets[i].m_PIPTarYPro > TAR_Y_MAX)
                        m_PIPTargets[i].m_PIPTarYPro = TAR_Y_MAX;

                    // Target height
                    m_PIPTargets[i].m_PIPTarHeightPro = m_PIPTargets[i].m_PIPTarHeight.GetResultValue() * FT_TO_MTRS;

                    if (m_PIPTargets[i].m_PIPTarHeightPro < TAR_HEIGHT_MIN)
                        m_PIPTargets[i].m_PIPTarHeightPro = TAR_HEIGHT_MIN;
                    else if (m_PIPTargets[i].m_PIPTarHeightPro > TAR_HEIGHT_MAX)
                        m_PIPTargets[i].m_PIPTarHeightPro = TAR_HEIGHT_MAX;

                    // Target climb rate
                    m_PIPTargets[i].m_PIPTarClimbRatePro = m_PIPTargets[i].m_PIPTarClimbRate.GetResultValue() * FT_TO_MTRS;

                    if (m_PIPTargets[i].m_PIPTarClimbRatePro < TAR_CLIMB_MIN)
                        m_PIPTargets[i].m_PIPTarClimbRatePro = TAR_CLIMB_MIN;
                    else if (m_PIPTargets[i].m_PIPTarClimbRatePro > TAR_CLIMB_MAX)
                        m_PIPTargets[i].m_PIPTarClimbRatePro = TAR_CLIMB_MAX;

                    // Target turn rate
                    m_PIPTargets[i].m_PIPTarTurnRatePro = m_PIPTargets[i].m_PIPTarTurnRate.GetResultValue();

                    if (m_PIPTargets[i].m_PIPTarTurnRatePro < TAR_TURN_MIN)
                        m_PIPTargets[i].m_PIPTarTurnRatePro = TAR_TURN_MIN;
                    else if (m_PIPTargets[i].m_PIPTarTurnRatePro > TAR_TURN_MAX)
                        m_PIPTargets[i].m_PIPTarTurnRatePro = TAR_TURN_MAX;

                    // Target pitch
                    m_PIPTargets[i].m_PIPTarPitchPro = m_PIPTargets[i].m_PIPTarPitch.GetResultValue();

                    if (m_PIPTargets[i].m_PIPTarPitchPro < TAR_PITCH_MIN)
                        m_PIPTargets[i].m_PIPTarPitchPro = TAR_PITCH_MIN;
                    else if (m_PIPTargets[i].m_PIPTarPitchPro > TAR_PITCH_MAX)
                        m_PIPTargets[i].m_PIPTarPitchPro = TAR_PITCH_MAX;

                    // Target heading
                    m_PIPTargets[i].m_PIPTarHeadingPro = m_PIPTargets[i].m_PIPTarHeading.GetResultValue();

                    if (m_PIPTargets[i].m_PIPTarHeadingPro < BRG_MIN)
                        m_PIPTargets[i].m_PIPTarHeadingPro += BRG_MAX;
                    else if (m_PIPTargets[i].m_PIPTarHeadingPro > BRG_MAX)
                        m_PIPTargets[i].m_PIPTarHeadingPro -= BRG_MAX;

                    // Target drift course
                    m_PIPTargets[i].m_PIPTarDriftCoursePro = m_PIPTargets[i].m_PIPTarDriftCourse.GetResultValue();

                    if (m_PIPTargets[i].m_PIPTarDriftCoursePro < BRG_MIN)
                        m_PIPTargets[i].m_PIPTarDriftCoursePro += BRG_MAX;
                    else if (m_PIPTargets[i].m_PIPTarDriftCoursePro > BRG_MAX)
                        m_PIPTargets[i].m_PIPTarDriftCoursePro -= BRG_MAX;

                    // Target speed
                    m_PIPTargets[i].m_PIPTarSpeedPro = m_PIPTargets[i].m_PIPTarSpeed.GetResultValue() * KTS_TO_MPS;

                    if (m_PIPTargets[i].m_PIPTarSpeedPro < TAR_SPEED_MIN)
                        m_PIPTargets[i].m_PIPTarSpeedPro = TAR_SPEED_MIN;
                    else if (m_PIPTargets[i].m_PIPTarSpeedPro > TAR_SPEED_MAX)
                        m_PIPTargets[i].m_PIPTarSpeedPro = TAR_SPEED_MAX;

                    // Target drift speed
                    m_PIPTargets[i].m_PIPTarDriftSpeedPro = m_PIPTargets[i].m_PIPTarDriftSpeed.GetResultValue() * KTS_TO_MPS;

                    if (m_PIPTargets[i].m_PIPTarDriftSpeedPro < TAR_DRIFT_MIN)
                        m_PIPTargets[i].m_PIPTarDriftSpeedPro = TAR_DRIFT_MIN;
                    else if (m_PIPTargets[i].m_PIPTarDriftSpeedPro > TAR_DRIFT_MAX)
                        m_PIPTargets[i].m_PIPTarDriftSpeedPro = TAR_DRIFT_MAX;
                }
            }
        }


        // ------------------------------
        // Check target model is valid
        // -------------------------------
        private bool CheckTargetModel(int modelId)
        {
            bool result = false;

            if ((modelId < MODEL_ID_MIN) || (modelId > MODEL_ID_MAX))
            {
                result = false;
            }
            else
            {
                // Check model database
                if (m_Models[modelId].m_Name == "Undefined")
                    result = false;
                else
                    result = true;
            }
            return (result);
        }


        // -------------------
        // Target: Initialise
        // -------------------
        private void TargetInitialise(int tarId)
        {
            // Set data from PIP
            m_SIMTargets[tarId].m_SIMTarPresent = m_PIPTargets[tarId].m_PIPTarPresentPro;
            m_SIMTargets[tarId].m_SIMTarNavLights = m_PIPTargets[tarId].m_PIPTarNavLights.GetResultValue();
            m_SIMTargets[tarId].m_SIMTarMissileHit = m_PIPTargets[tarId].m_PIPTarMissileHit.GetResultValue();
            m_SIMTargets[tarId].m_SIMTarTorpedoHit = m_PIPTargets[tarId].m_PIPTarTorpedoHit.GetResultValue();
            m_SIMTargets[tarId].m_SIMTarSinking = m_PIPTargets[tarId].m_PIPTarSinking.GetResultValue();
            m_SIMTargets[tarId].m_SIMTarDunkingSonar = m_PIPTargets[tarId].m_PIPTarDunkingSonar.GetResultValue();
            m_SIMTargets[tarId].m_SIMTarTLAM = m_PIPTargets[tarId].m_PIPTarTLAMFaulty.GetResultValue();
            m_SIMTargets[tarId].m_SIMTarFlames = m_PIPTargets[tarId].m_PIPTarFlames.GetResultValue();
            m_SIMTargets[tarId].m_SIMTarDieselSmoke = m_PIPTargets[tarId].m_PIPTarDieselSmoke.GetResultValue();
            m_SIMTargets[tarId].m_SIMTarFireMissile = m_PIPTargets[tarId].m_PIPTarFireMissile.GetResultValue();

            m_SIMTargets[tarId].m_SIMTarModelID = m_PIPTargets[tarId].m_PIPTarModelIDPro;
            m_SIMTargets[tarId].m_SIMTarSlotID = m_PIPTargets[tarId].m_PIPTarSlotIDPro;
            m_SIMTargets[tarId].m_SIMTarLightConfig = m_PIPTargets[tarId].m_PIPTarLightConfigPro;
            m_SIMTargets[tarId].m_SIMTarSpotConfig = m_PIPTargets[tarId].m_PIPTarSpotConfigPro;
            m_SIMTargets[tarId].m_SIMTarX = m_PIPTargets[tarId].m_PIPTarXPro;
            m_SIMTargets[tarId].m_SIMTarY = m_PIPTargets[tarId].m_PIPTarYPro;
            m_SIMTargets[tarId].m_SIMTarHeight = m_PIPTargets[tarId].m_PIPTarHeightPro;
            m_SIMTargets[tarId].m_SIMTarHeading = m_PIPTargets[tarId].m_PIPTarHeadingPro;
            m_SIMTargets[tarId].m_SIMTarPitch = m_PIPTargets[tarId].m_PIPTarPitchPro;
            m_SIMTargets[tarId].m_SIMTarSpeed = m_PIPTargets[tarId].m_PIPTarSpeedPro;
            m_SIMTargets[tarId].m_SIMTarClimbRate = m_PIPTargets[tarId].m_PIPTarClimbRatePro;
            m_SIMTargets[tarId].m_SIMTarTurnRate = m_PIPTargets[tarId].m_PIPTarTurnRatePro;
            m_SIMTargets[tarId].m_SIMTarDriftCourse = m_PIPTargets[tarId].m_PIPTarDriftCoursePro;
            m_SIMTargets[tarId].m_SIMTarDriftSpeed = m_PIPTargets[tarId].m_PIPTarDriftSpeedPro;

            // Default data not sent by PIP
            m_SIMTargets[tarId].m_SIMTarRoll = 0.0f;
            m_SIMTargets[tarId].m_SIMTarAccel = 0.0f;
            m_SIMTargets[tarId].m_SIMTarAccelVert = 0.0f;
            m_SIMTargets[tarId].m_SIMTarHitPoint = 0;
            m_SIMTargets[tarId].m_SIMTarSlotNum = tarId;


            // Default deltas
            m_SIMTargets[tarId].m_SIMTarDeltaHdg = m_SIMTargets[tarId].m_SIMTarTurnRate * m_IterationTime;

            m_SIMTargets[tarId].m_SIMTarDeltaX = m_SIMTargets[tarId].m_SIMTarDriftSpeed * m_IterationTime *
                (float) Math.Sin(m_SIMTargets[tarId].m_SIMTarDriftCourse * DEGS_TO_RADS);

            m_SIMTargets[tarId].m_SIMTarDeltaY = m_SIMTargets[tarId].m_SIMTarDriftSpeed * m_IterationTime *
                (float) Math.Cos(m_SIMTargets[tarId].m_SIMTarDriftCourse * DEGS_TO_RADS);

            m_SIMTargets[tarId].m_SIMTarDeltaZ = m_SIMTargets[tarId].m_SIMTarClimbRate * m_IterationTime;

            m_SIMTargets[tarId].m_SIMTarDeltaSpd = 0.0f;
            m_SIMTargets[tarId].m_SIMTarDeltaPtch = 0.0f;
            m_SIMTargets[tarId].m_SIMTarDeltaTurn = 0.0f;
        }



        // ----------------------
        // Target: Clear target
        // ----------------------
        private void TargetClear(int tarId)
        {

            // Default target data
            m_SIMTargets[tarId].m_SIMTarPresent = false;
            m_SIMTargets[tarId].m_SIMTarNavLights = false;
            m_SIMTargets[tarId].m_SIMTarMissileHit = false;
            m_SIMTargets[tarId].m_SIMTarTorpedoHit = false;
            m_SIMTargets[tarId].m_SIMTarSinking = false;
            m_SIMTargets[tarId].m_SIMTarDunkingSonar = false;
            m_SIMTargets[tarId].m_SIMTarTLAM = false;
            m_SIMTargets[tarId].m_SIMTarFlames = false;
            m_SIMTargets[tarId].m_SIMTarDieselSmoke = false;
            m_SIMTargets[tarId].m_SIMTarFireMissile = false;

            m_SIMTargets[tarId].m_SIMTarModelID = 0;
            m_SIMTargets[tarId].m_SIMTarSlotID = 0;
            m_SIMTargets[tarId].m_SIMTarLightConfig = 0;
            m_SIMTargets[tarId].m_SIMTarSpotConfig = 0;
            m_SIMTargets[tarId].m_SIMTarX = 0.0f;
            m_SIMTargets[tarId].m_SIMTarY = 0.0f;
            m_SIMTargets[tarId].m_SIMTarHeight = 0.0f;
            m_SIMTargets[tarId].m_SIMTarHeading = 0.0f;
            m_SIMTargets[tarId].m_SIMTarPitch = 0.0f;
            m_SIMTargets[tarId].m_SIMTarSpeed = 0.0f;
            m_SIMTargets[tarId].m_SIMTarClimbRate = 0.0f;
            m_SIMTargets[tarId].m_SIMTarTurnRate = 0.0f;
            m_SIMTargets[tarId].m_SIMTarDriftCourse = 0.0f;
            m_SIMTargets[tarId].m_SIMTarDriftSpeed = 0.0f;

            m_SIMTargets[tarId].m_SIMTarRoll = 0.0f;
            m_SIMTargets[tarId].m_SIMTarAccel = 0.0f;
            m_SIMTargets[tarId].m_SIMTarAccelVert = 0.0f;
            m_SIMTargets[tarId].m_SIMTarHitPoint = 0;
            m_SIMTargets[tarId].m_SIMTarSlotNum = tarId;

            m_SIMTargets[tarId].m_SIMTarDeltaHdg = 0.0f;
            m_SIMTargets[tarId].m_SIMTarDeltaX = 0.0f;
            m_SIMTargets[tarId].m_SIMTarDeltaY = 0.0f;
            m_SIMTargets[tarId].m_SIMTarDeltaZ = 0.0f;
            m_SIMTargets[tarId].m_SIMTarDeltaSpd = 0.0f;
            m_SIMTargets[tarId].m_SIMTarDeltaPtch = 0.0f;
            m_SIMTargets[tarId].m_SIMTarDeltaTurn = 0.0f;
        }



        // -----------------------
        // Target: Update Deltas
        // -----------------------
        private void TargetUpdateDeltas(int tarId)
        {

            //
            // Delta turn
            //
            m_SIMTargets[tarId].m_SIMTarDeltaTurn = (m_PIPTargets[tarId].m_PIPTarTurnRatePro -
                                                     m_SIMTargets[tarId].m_SIMTarTurnRate) * m_PIPDeltaTime;


            //
            // Delta heading (accounting for going over 360 degrees)
            //
            double goalHeading = m_PIPTargets[tarId].m_PIPTarHeadingPro;
            double turnRate = m_PIPTargets[tarId].m_PIPTarTurnRatePro;

            double deltaHeading = turnRate * m_IterationTime;

            if (Math.Abs(m_SIMTargets[tarId].m_SIMTarHeading - goalHeading) < 180.0)
            {
                deltaHeading += (goalHeading - m_SIMTargets[tarId].m_SIMTarHeading) * m_PIPDeltaTime;
            }
            else
            {
                if (m_SIMTargets[tarId].m_SIMTarHeading > goalHeading)
                {
                    deltaHeading += ((360.0 - m_SIMTargets[tarId].m_SIMTarHeading) + goalHeading) * m_PIPDeltaTime;
                }
                else
                {
                    deltaHeading += ((goalHeading - 360.0) - m_SIMTargets[tarId].m_SIMTarHeading) * m_PIPDeltaTime;
                }
            }

            m_SIMTargets[tarId].m_SIMTarDeltaHdg = deltaHeading;


            //
            // Delta drift XY
            //
            double driftSpeed = m_PIPTargets[tarId].m_PIPTarDriftSpeedPro;
            double driftCourse = m_PIPTargets[tarId].m_PIPTarDriftCoursePro * DEGS_TO_RADS;

            double deltaDriftX = driftSpeed * Math.Sin(driftCourse) * m_IterationTime;
            double deltaDriftY = driftSpeed * Math.Cos(driftCourse) * m_IterationTime;


            //
            // Delta XY
            //
            double goalX = m_PIPTargets[tarId].m_PIPTarXPro;
            m_SIMTargets[tarId].m_SIMTarDeltaX = deltaDriftX + ((goalX - m_SIMTargets[tarId].m_SIMTarX) * m_PIPDeltaTime);

            double goalY = m_PIPTargets[tarId].m_PIPTarYPro;
            m_SIMTargets[tarId].m_SIMTarDeltaY = deltaDriftY + ((goalY - m_SIMTargets[tarId].m_SIMTarY) * m_PIPDeltaTime);


            //
            // Climb rate
            //
            m_SIMTargets[tarId].m_SIMTarClimbRate = m_PIPTargets[tarId].m_PIPTarClimbRatePro;


            //
            // Delta Z (height)
            //
            m_SIMTargets[tarId].m_SIMTarDeltaZ = (m_SIMTargets[tarId].m_SIMTarClimbRate * m_IterationTime) +
                (((m_PIPTargets[tarId].m_PIPTarHeightPro) - m_SIMTargets[tarId].m_SIMTarHeight) * m_PIPDeltaTime);


            //
            // Delta Speed
            //
            m_SIMTargets[tarId].m_SIMTarDeltaSpd = ((m_PIPTargets[tarId].m_PIPTarSpeedPro) - m_SIMTargets[tarId].m_SIMTarSpeed) * m_PIPDeltaTime;


            // Acceleration

            m_SIMTargets[tarId].m_SIMTarAccel = ((m_PIPTargets[tarId].m_PIPTarSpeedPro) - m_SIMTargets[tarId].m_SIMTarSpeed) * m_PIPRateIn;

            // Check limits
            if (m_SIMTargets[tarId].m_SIMTarAccel < TAR_ACCEL_MIN)
                m_SIMTargets[tarId].m_SIMTarAccel = TAR_ACCEL_MIN;

            if (m_SIMTargets[tarId].m_SIMTarAccel > TAR_ACCEL_MAX)
                m_SIMTargets[tarId].m_SIMTarAccel = TAR_ACCEL_MAX;


            //
            // Delta pitch
            //
            m_SIMTargets[tarId].m_SIMTarDeltaPtch = (m_PIPTargets[tarId].m_PIPTarPitchPro - m_SIMTargets[tarId].m_SIMTarPitch) * m_PIPDeltaTime;

        }



        // -----------------------
        // Target: Interpolation
        // -----------------------
        private void TargetInterpolation(int tarId)
        {

            //
            // Get the model data
            //
            double modelHeight = m_Models[m_SIMTargets[tarId].m_SIMTarModelID].m_Height;
            double modelLength = m_Models[m_SIMTargets[tarId].m_SIMTarModelID].m_Length;
            double modelWidth = m_Models[m_SIMTargets[tarId].m_SIMTarModelID].m_Width;


            //
            // Interpolate heading
            //
            m_SIMTargets[tarId].m_SIMTarHeading = (float) NormalisedAngle
                (m_SIMTargets[tarId].m_SIMTarHeading +
                 m_SIMTargets[tarId].m_SIMTarDeltaHdg + 360.0f);


            //
            // Interpolate speed
            //
            m_SIMTargets[tarId].m_SIMTarSpeed += m_SIMTargets[tarId].m_SIMTarDeltaSpd;

            // Check limits
            if (m_SIMTargets[tarId].m_SIMTarSpeed < TAR_SPEED_MIN)
                m_SIMTargets[tarId].m_SIMTarSpeed = TAR_SPEED_MIN;

            if (m_SIMTargets[tarId].m_SIMTarSpeed > TAR_SPEED_MAX)
                m_SIMTargets[tarId].m_SIMTarSpeed = TAR_SPEED_MAX;


            //
            // Interpolate X
            //
            m_SIMTargets[tarId].m_SIMTarX += (m_SIMTargets[tarId].m_SIMTarSpeed *
                                              (float) Math.Sin(m_SIMTargets[tarId].m_SIMTarHeading * DEGS_TO_RADS) * m_IterationTime) +
                m_SIMTargets[tarId].m_SIMTarDeltaX;

            if (m_SIMTargets[tarId].m_SIMTarX < TAR_X_MIN)
                m_SIMTargets[tarId].m_SIMTarX = TAR_X_MIN;

            if (m_SIMTargets[tarId].m_SIMTarX > TAR_X_MAX)
                m_SIMTargets[tarId].m_SIMTarX = TAR_X_MAX;


            //
            // Interpolate Y
            //
            m_SIMTargets[tarId].m_SIMTarY += (m_SIMTargets[tarId].m_SIMTarSpeed *
                                              (float) Math.Cos(m_SIMTargets[tarId].m_SIMTarHeading * DEGS_TO_RADS) * m_IterationTime) +
                m_SIMTargets[tarId].m_SIMTarDeltaY;

            if (m_SIMTargets[tarId].m_SIMTarY < TAR_Y_MIN)
                m_SIMTargets[tarId].m_SIMTarY = TAR_Y_MIN;

            if (m_SIMTargets[tarId].m_SIMTarY > TAR_Y_MAX)
                m_SIMTargets[tarId].m_SIMTarY = TAR_Y_MAX;


            //
            // Interpolate turn rate
            //
            m_SIMTargets[tarId].m_SIMTarTurnRate += m_SIMTargets[tarId].m_SIMTarDeltaTurn;


            //
            // Update sinking targets
            //
            if (m_SIMTargets[tarId].m_SIMTarStatus == SIM_TARGET_SINKING)
                TargetSink(tarId);


            //
            // Interpolate height (Z)
            //
            m_SIMTargets[tarId].m_SIMTarHeight += m_SIMTargets[tarId].m_SIMTarDeltaZ;

            if (m_SIMTargets[tarId].m_SIMTarHeight < TAR_Z_MIN)
                m_SIMTargets[tarId].m_SIMTarHeight = TAR_Z_MIN;

            if (m_SIMTargets[tarId].m_SIMTarHeight > TAR_Z_MAX)
                m_SIMTargets[tarId].m_SIMTarHeight = TAR_Z_MAX;


            //
            // Calculate target horizon distance
            //
            if ((m_SIMTargets[tarId].m_SIMTarHeight + modelHeight) > 0.0f)
            {
                // Set the target above sea bool
                m_SIMTargets[tarId].m_SIMTarAboveSea = true;

                // Set the target horizon distance
                double horizonSqd = ((RADIUS_EARTH + m_SIMTargets[tarId].m_SIMTarHeight + modelHeight) *
                                     (RADIUS_EARTH + m_SIMTargets[tarId].m_SIMTarHeight + modelHeight)) - (RADIUS_EARTH * RADIUS_EARTH);

                m_SIMTargets[tarId].m_SIMTarHorizonDist = Math.Sqrt(horizonSqd);
            }
            else
            {
                // Set the target above sea bool
                m_SIMTargets[tarId].m_SIMTarAboveSea = false;

                // Set the target horizon distance
                m_SIMTargets[tarId].m_SIMTarHorizonDist = m_PIPEnvUnderWaterRange.GetResultValue();
            }


            //
            // Enhance target movement
            //
            if (m_SIMTargets[tarId].m_SIMTarSinking == false)
            {
                if (m_SIMTargets[tarId].m_SIMTarHeight > 0.0f)
                {
                    // Airbourne target roll
                    m_SIMTargets[tarId].m_SIMTarRoll = TAR_AIR_ROLL * m_SIMTargets[tarId].m_SIMTarTurnRate *
                        (float) Math.Sqrt(m_SIMTargets[tarId].m_SIMTarSpeed);
                }
                else
                {
                    // Surface target roll (heel)
                    m_SIMTargets[tarId].m_SIMTarRoll = TAR_SEA_ROLL * m_SIMTargets[tarId].m_SIMTarTurnRate *
                        (float) Math.Sqrt(m_SIMTargets[tarId].m_SIMTarSpeed);
                }
            }

            if (m_SIMTargets[tarId].m_SIMTarRoll < TAR_ROLL_MIN)
                m_SIMTargets[tarId].m_SIMTarRoll = TAR_ROLL_MIN;

            if (m_SIMTargets[tarId].m_SIMTarRoll > TAR_ROLL_MAX)
                m_SIMTargets[tarId].m_SIMTarRoll = TAR_ROLL_MAX;


            //
            // Interpolate height
            //
            m_SIMTargets[tarId].m_SIMTarPitch += m_SIMTargets[tarId].m_SIMTarDeltaPtch;

            if (m_SIMTargets[tarId].m_SIMTarPitch < TAR_PITCH_MIN)
                m_SIMTargets[tarId].m_SIMTarPitch = TAR_PITCH_MIN;

            if (m_SIMTargets[tarId].m_SIMTarPitch > TAR_PITCH_MAX)
                m_SIMTargets[tarId].m_SIMTarPitch = TAR_PITCH_MAX;


            //
            // Calculate target horizontal and true range
            //
            double xVal = (double) m_SIMTargets[tarId].m_SIMTarX;
            double yVal = (double) m_SIMTargets[tarId].m_SIMTarY;
            double zVal = (double) m_SIMTargets[tarId].m_SIMTarHeight;

            double rangeHorSqd = (xVal * xVal) + (yVal * yVal);

            m_SIMTargets[tarId].m_SIMTarRangeHorizontal = Math.Sqrt(rangeHorSqd);

            m_SIMTargets[tarId].m_SIMTarRangeTrue = Math.Sqrt(rangeHorSqd + (zVal * zVal));

            // Check limts (to avoid divide-by-zero errors)
            if (m_SIMTargets[tarId].m_SIMTarRangeHorizontal < 0.1f)
                m_SIMTargets[tarId].m_SIMTarRangeHorizontal = 0.1f;

            if (m_SIMTargets[tarId].m_SIMTarRangeTrue < 0.1f)
                m_SIMTargets[tarId].m_SIMTarRangeTrue = 0.1f;


            //
            // Calculate target bearing (from ownboat)
            //
            m_SIMTargets[tarId].m_SIMTarBrgFromOwnboat = (float) Math.Asin(m_SIMTargets[tarId].m_SIMTarX / m_SIMTargets[tarId].m_SIMTarRangeHorizontal) * RADS_TO_DEGS;

            if (m_SIMTargets[tarId].m_SIMTarY < 0.0f)
                m_SIMTargets[tarId].m_SIMTarBrgFromOwnboat = 180.0f - m_SIMTargets[tarId].m_SIMTarBrgFromOwnboat;

            else if (m_SIMTargets[tarId].m_SIMTarX < 0.0f)
                m_SIMTargets[tarId].m_SIMTarBrgFromOwnboat =
                    360.0f +
                    m_SIMTargets[tarId].m_SIMTarBrgFromOwnboat;


            //
            // Calculate target elevation (from ownboat)
            //
            m_SIMTargets[tarId].m_SIMTarElevFromOwnboat = (float) Math.Atan((m_SIMTargets[tarId].m_SIMTarHeight - m_SIMOwnZ) /
                                                                            m_SIMTargets[tarId].m_SIMTarRangeHorizontal) * RADS_TO_DEGS;


            //
            // Calculate target effective horizontal angle
            // (for use in fov checks)
            //
            m_SIMTargets[tarId].m_SIMTarAngleHor = (float) Math.Atan((modelLength + modelWidth) /
                                                                     m_SIMTargets[tarId].m_SIMTarRangeHorizontal) * RADS_TO_DEGS;


            //
            // Calculate target effective vertical angle
            // (for use in fov checks)
            // Add the current stadiametric angle in case the target is just below
            // the visible fov and we're currently ranging
            //
            m_SIMTargets[tarId].m_SIMTarAngleVert = ((float) Math.Atan(modelHeight /
                                                                       m_SIMTargets[tarId].m_SIMTarRangeTrue) * RADS_TO_DEGS) + m_PIGPeriStadAngle.GetResultValue();

        }



        // ------------------------
        // Target: Sink target
        // ------------------------
        private void TargetSink(int tarId)
        {
            //
            // Get the model data
            //
            double modelHeight = m_Models[m_SIMTargets[tarId].m_SIMTarModelID].m_Height;

            //
            // Process target sinking
            //
            if (m_SIMTargets[tarId].m_SIMTarSinkInitialised == false)
            {
                // Initialise target sinking
                double drop = m_SIMTargets[tarId].m_SIMTarHeight + modelHeight;

                // If target is airbourne give it a fast drop rate
                // otherwise calculate the drop rate
                if (m_SIMTargets[tarId].m_SIMTarHeight > 0.0)
                    m_SIMTargets[tarId].m_SIMTarAccelVert = -3.0;
                else
                    m_SIMTargets[tarId].m_SIMTarAccelVert = (-2.0 * (drop +
                                                                     (m_SIMTargets[tarId].m_SIMTarClimbRate * TAR_SINK_PERIOD))) /
                        (TAR_SINK_PERIOD * TAR_SINK_PERIOD);

                m_SIMTargets[tarId].m_SIMTarSinking = true;
                m_SIMTargets[tarId].m_SIMTarSinkInitialised = true;
                m_SIMTargets[tarId].m_SIMTarSinkTime = 0.0;
            }
            else
            {
                // Increment the sink timer
                m_SIMTargets[tarId].m_SIMTarSinkTime += m_IterationTime;

                // Has the sink period expired?
                if (m_SIMTargets[tarId].m_SIMTarSinkTime > TAR_SINK_PERIOD)
                {
                    // Yes, reset the data
                    m_SIMTargets[tarId].m_SIMTarStatus = SIM_TARGET_SUNK;
                    m_SIMTargets[tarId].m_SIMTarSinking = false;
                    m_SIMTargets[tarId].m_SIMTarSinkInitialised = false;
                    m_SIMTargets[tarId].m_SIMTarSinkTime = 0.0f;
                }
                else
                {
                    // No, calculate the target delta z
                    m_SIMTargets[tarId].m_SIMTarDeltaZ = (m_SIMTargets[tarId].m_SIMTarClimbRate * m_IterationTime) +
                        (0.5f * m_SIMTargets[tarId].m_SIMTarAccelVert * m_IterationTime * m_IterationTime);

                    if (m_SIMTargets[tarId].m_SIMTarDeltaZ > TAR_DELTA_MAX)
                        m_SIMTargets[tarId].m_SIMTarDeltaZ = TAR_DELTA_MAX;

                    if (m_SIMTargets[tarId].m_SIMTarDeltaZ < TAR_DELTA_MIN)
                        m_SIMTargets[tarId].m_SIMTarDeltaZ = TAR_DELTA_MIN;

                    // Update the target climb rate
                    m_SIMTargets[tarId].m_SIMTarClimbRate += m_SIMTargets[tarId].m_SIMTarAccelVert * m_IterationTime;

                    // Give the target some roll as it sinks
                    m_SIMTargets[tarId].m_SIMTarRoll -= 0.03f;
                }
            }
        }



        // -------------------------
        // Target: In visual range?
        // -------------------------
        private bool TargetInVisualRange(int tarId)
        {
            bool result;

            // Does the target appear above the horizon
            if (m_SIMTargets[tarId].m_SIMTarRangeHorizontal >
                (m_SIMOwnHorizon + m_SIMTargets[tarId].m_SIMTarHorizonDist))
                result = false;
            else
                result = true;

            return (result);
        }



        // ----------------------------
        // Target: In horizontal FOV?
        // ----------------------------
        private bool TargetInHorizontalFOV(int tarId)
        {
            bool result;

            // Calculate target limits
            float limitLeft = (float) NormalisedAngle((m_SIMTargets[tarId].m_SIMTarBrgFromOwnboat -
                                                       (m_SIMTargets[tarId].m_SIMTarAngleHor * 0.5f)) + 360.0f);

            float limitRight = (float) NormalisedAngle((m_SIMTargets[tarId].m_SIMTarBrgFromOwnboat +
                                                        (m_SIMTargets[tarId].m_SIMTarAngleHor * 0.5f))
                                                       + 360.0f);

            if (m_SIMLookingNorth)
            {
                // Line of zero bearing bisects the horizontal field of view
                if ((limitLeft < m_SIMFOVRight) ||
                    (limitRight < m_SIMFOVRight) ||
                    (limitLeft > m_SIMFOVLeft) ||
                    (limitRight > m_SIMFOVLeft) ||
                    (m_SIMTargets[tarId].m_SIMTarAngleHor > m_PIGPeriMagnification.GetResultValue()))
                    // Target is in the horizontal FOV
                    result = true;
                else
                    // Target is not in the horizontal FOV
                    result = false;
            }
            else
            {
                // Line of zero bearing does not bisect the horizontal field of view
                if (((limitRight < m_SIMFOVRight) &&
                     (limitRight > m_SIMFOVLeft)) ||
                    ((limitLeft < m_SIMFOVRight) &&
                     (limitLeft > m_SIMFOVLeft)) ||
                    (m_SIMTargets[tarId].m_SIMTarAngleHor > m_PIGPeriMagnification.GetResultValue()))
                    // Target is in the horizontal FOV
                    result = true;
                else
                    // Target is not in the horizontal FOV
                    result = false;
            }

            return (result);
        }



        // ----------------------------
        // Target: In vertical FOV?
        // ----------------------------
        private bool TargetInVerticalFOV(int tarId)
        {
            bool result;

            // Calculate target limits
            double limitUpper = m_SIMTargets[tarId].m_SIMTarElevFromOwnboat + m_SIMTargets[tarId].m_SIMTarAngleVert;
            double limitLower = m_SIMTargets[tarId].m_SIMTarElevFromOwnboat - m_SIMTargets[tarId].m_SIMTarAngleVert;

            // Is the target (or part of it) directly in the vertical FOV?
            if ((m_SIMFOVLower < limitUpper) &&
                (m_SIMFOVUpper > limitLower))
                result = true;
            else
                result = false;

            return (result);
        }



        // -----------------------------
        // Target: In close proximity?
        // -----------------------------
        private bool TargetInCloseProximity(int tarId)
        {
            bool result;

            // Is the target in close proximity?
            if (m_SIMTargets[tarId].m_SIMTarRangeHorizontal < TAR_CLOSE_PROXIMITY)
                result = true;
            else
                result = false;

            return (result);
        }



        // ---------------------------
        // Target: Is sonar contact?
        // ---------------------------
        private bool TargetIsSonar(int tarId)
        {
            bool result;

            // Determine whether target is a sonar target by checking the model name -
            // sonar targets begin with "Polynia"
            if (m_Models[m_SIMTargets[tarId].m_SIMTarModelID].m_Name.StartsWith("Polynia"))
                result = true;
            else
                result = false;

            return (result);
        }



        // ---------------------
        // Target: Is burning?
        // ---------------------
        private bool TargetIsBurning(int tarId)
        {
            bool result;

            // Check the missile, torpedo and smoke flags
            if (m_SIMTargets[tarId].m_SIMTarMissileHit ||
                m_SIMTargets[tarId].m_SIMTarTorpedoHit ||
                m_SIMTargets[tarId].m_SIMTarFlames)
            {
                result = true;
            }
            else
            {
                result = false;
            }

            return (result);
        }


        // ----------------------
        // Target: Set PIG data
        // ----------------------
        private void TargetSetPIGData()
        {
            int i;
            int j;
            int pigId;

            //
            // Process each SIM target
            //
            for (i = 0; i < SIM_NUMBER_TARGETS; i++)
            {
                if (m_SIMTargets[i].m_SIMTarPIGDisplay)
                {
                    //
                    // The target should be displayed on the PIG
                    //
                    if (m_SIMTargets[i].m_SIMTarPIGSelected == false)
                    {
                        // Target was not selected for display last frame so
                        // find a spare target slot in the PIG network packet
                        for (j = 0; j < PIG_NUMBER_TARGETS; j++)
                        {
                            if (m_PIGTargets[j].m_PIGTarActive == false)
                            {
                                m_SIMTargets[i].m_SIMTarPIGSelected = true;
                                m_SIMTargets[i].m_SIMTarPIGSlotNum = j;
                                m_PIGTargets[j].m_PIGTarActive = true;
                                break;
                            }
                        }
                    }
                }
                else
                {
                    //
                    // The target should NOT be displayed
                    //
                    if (m_SIMTargets[i].m_SIMTarPIGSelected == true)
                    {
                        // Target was selected for display last frame so
                        // default the data in the slot
                        m_SIMTargets[i].m_SIMTarPIGSelected = false;

                        pigId = m_SIMTargets[i].m_SIMTarPIGSlotNum;

                        m_PIGTargets[pigId].m_PIGTarActive = false;

                        m_PIGTargets[pigId].m_PIGTarPresent.SetRawValue(false);
                        m_PIGTargets[pigId].m_PIGTarNavLights.SetRawValue(false);
                        m_PIGTargets[pigId].m_PIGTarMissileHit.SetRawValue(false);
                        m_PIGTargets[pigId].m_PIGTarTorpedoHit.SetRawValue(false);
                        m_PIGTargets[pigId].m_PIGTarSinking.SetRawValue(false);
                        m_PIGTargets[pigId].m_PIGTarDunkingSonar.SetRawValue(false);
                        m_PIGTargets[pigId].m_PIGTarTLAM.SetRawValue(false);
                        m_PIGTargets[pigId].m_PIGTarFlames.SetRawValue(false);
                        m_PIGTargets[pigId].m_PIGTarDieselSmoke.SetRawValue(false);
                        m_PIGTargets[pigId].m_PIGTarFireMissile.SetRawValue(false);
                        m_PIGTargets[pigId].m_PIGTarSlotNum.SetRawValue((short) i);
                        m_PIGTargets[pigId].m_PIGTarLightConfig.SetRawValue(0);
                        m_PIGTargets[pigId].m_PIGTarSpotConfig.SetRawValue(0);
                        m_PIGTargets[pigId].m_PIGTarX.SetRawValue(0.0f);
                        m_PIGTargets[pigId].m_PIGTarY.SetRawValue(0.0f);
                        m_PIGTargets[pigId].m_PIGTarHeight.SetRawValue(0.0f);
                        m_PIGTargets[pigId].m_PIGTarHeading.SetRawValue(0.0f);
                        m_PIGTargets[pigId].m_PIGTarRoll.SetRawValue(0.0f);
                        m_PIGTargets[pigId].m_PIGTarPitch.SetRawValue(0.0f);
                        m_PIGTargets[pigId].m_PIGTarSpeed.SetRawValue(0.0f);
                        m_PIGTargets[pigId].m_PIGTarAccel.SetRawValue(0.0f);
                        m_PIGTargets[pigId].m_PIGTarHitPoint.SetRawValue(0);

                        if (m_SIMTargets[i].m_SIMTarStatus == SIM_TARGET_NOT_PRESENT)
                        {
                            // The model is to be deleted, send a default model id
                            m_PIGTargets[pigId].m_PIGTarModelID.SetRawValue(0);
                        }
                        else
                        {
                            // The model is to be updated, send original model id
                            m_PIGTargets[pigId].m_PIGTarModelID.SetRawValue((short) m_SIMTargets[i].m_SIMTarModelID);
                        }
                    }
                }

                //
                // If the target is selected then set the PIG data
                //
                if (m_SIMTargets[i].m_SIMTarPIGSelected)
                {
                    pigId = m_SIMTargets[i].m_SIMTarPIGSlotNum;

                    m_PIGTargets[pigId].m_PIGTarModelID.SetRawValue((short) m_SIMTargets[i].m_SIMTarModelID);
                    m_PIGTargets[pigId].m_PIGTarSlotNum.SetRawValue((short) m_SIMTargets[i].m_SIMTarSlotNum);
                    m_PIGTargets[pigId].m_PIGTarPresent.SetRawValue(m_SIMTargets[i].m_SIMTarPresent);
                    m_PIGTargets[pigId].m_PIGTarNavLights.SetRawValue(m_SIMTargets[i].m_SIMTarNavLights);
                    m_PIGTargets[pigId].m_PIGTarMissileHit.SetRawValue(m_SIMTargets[i].m_SIMTarMissileHit);
                    m_PIGTargets[pigId].m_PIGTarTorpedoHit.SetRawValue(m_SIMTargets[i].m_SIMTarTorpedoHit);
                    m_PIGTargets[pigId].m_PIGTarSinking.SetRawValue(m_SIMTargets[i].m_SIMTarSinking);
                    m_PIGTargets[pigId].m_PIGTarDunkingSonar.SetRawValue(m_SIMTargets[i].m_SIMTarDunkingSonar);
                    m_PIGTargets[pigId].m_PIGTarTLAM.SetRawValue(m_SIMTargets[i].m_SIMTarTLAM);
                    m_PIGTargets[pigId].m_PIGTarFlames.SetRawValue(m_SIMTargets[i].m_SIMTarFlames);
                    m_PIGTargets[pigId].m_PIGTarDieselSmoke.SetRawValue(m_SIMTargets[i].m_SIMTarDieselSmoke);
                    m_PIGTargets[pigId].m_PIGTarFireMissile.SetRawValue(m_SIMTargets[i].m_SIMTarFireMissile);
                    m_PIGTargets[pigId].m_PIGTarLightConfig.SetRawValue((byte) m_SIMTargets[i].m_SIMTarLightConfig);
                    m_PIGTargets[pigId].m_PIGTarSpotConfig.SetRawValue((byte) m_SIMTargets[i].m_SIMTarSpotConfig);
                    m_PIGTargets[pigId].m_PIGTarHeading.SetRawValue(m_SIMTargets[i].m_SIMTarHeading);
                    m_PIGTargets[pigId].m_PIGTarRoll.SetRawValue(m_SIMTargets[i].m_SIMTarRoll);
                    m_PIGTargets[pigId].m_PIGTarPitch.SetRawValue(m_SIMTargets[i].m_SIMTarPitch);
                    m_PIGTargets[pigId].m_PIGTarAccel.SetRawValue(m_SIMTargets[i].m_SIMTarAccel);
                    m_PIGTargets[pigId].m_PIGTarHitPoint.SetRawValue(m_SIMTargets[i].m_SIMTarHitPoint);

                    // Set the speed (depending on run mode)
                    if ((m_SIMExRunMode == SIM_TARGET_FREEZE) || (m_SIMExRunMode == SIM_FULL_FREEZE))
                        m_PIGTargets[pigId].m_PIGTarSpeed.SetRawValue(0.0f);
                    else
                        m_PIGTargets[pigId].m_PIGTarSpeed.SetRawValue(m_SIMTargets[i].m_SIMTarSpeed);

                    // Set the XYZ (depending on whether present)
                    if (m_SIMTargets[i].m_SIMTarPresent)
                    {
                        // Calculate the target XY from the ownboat
                        // use PIG result to cater for overrides
                        m_PIGTargets[pigId].m_PIGTarX.SetRawValue(m_PIGOwnX.GetResultValue() + m_SIMTargets[i].m_SIMTarX);
                        m_PIGTargets[pigId].m_PIGTarY.SetRawValue(m_PIGOwnY.GetResultValue() + m_SIMTargets[i].m_SIMTarY);
                        m_PIGTargets[pigId].m_PIGTarHeight.SetRawValue(m_SIMTargets[i].m_SIMTarHeight);
                    }
                    else
                    {
                        m_PIGTargets[pigId].m_PIGTarX.SetRawValue(0.0f);
                        m_PIGTargets[pigId].m_PIGTarY.SetRawValue(0.0f);
                        m_PIGTargets[pigId].m_PIGTarHeight.SetRawValue(0.0f);
                    }
                }
            }
        }



        // ------------------------
        // Process CUT Data
        // ------------------------
        private void ProcessCuts()
        {
            //
            // Process Cuts to the PIP
            //

            //
            // Cuts must be synchronised with the PIPComms
            //
            if (m_PIPComms != null)
            {
                if (m_PIPComms.m_CountOut != m_PIPComms.m_IterateOut)
                    return;
            }

            //
            // Periscope continuous bearing
            //
            m_PIPRetTWSHPeriTrueBrg.SetRawValue((float) m_SIMPeriTrueHeading);


            //
            // Bearing cuts
            //
            bool bearingCut = m_IOBearingCut.GetResultValue();

            // A cut can only be performed if the cut flag is set and a cut
            // hasn't already been performed recently
            if ((bearingCut == true) && !m_bearingCutSend)
            {
                // Set the bearing cut and data
                m_PIPRetTWSHTarTrueBrgCut.SetRawValue(true);
                m_PIPRetTWSHTarTrueBrg.SetRawValue((float) m_SIMPeriTrueHeading);

                //Set the flag to avoid sending multiple cuts.
                m_bearingCutSend = true;
            }
            else
            {
                // Clear the bearing cut and data
                m_PIPRetTWSHTarTrueBrgCut.SetRawValue(false);
                m_PIPRetTWSHTarTrueBrg.SetRawValue(0.0f);

                //
                //Clear the flag when the cut button has been released, to avoide sending multiple cuts.
                //
                if(!bearingCut)
                {
                    m_bearingCutSend = false;
                }
            }


            //
            // Range cuts
            //
            bool rangeCut = m_IORangeCut.GetResultValue();

            // A cut can only be performed if the cut flag is set and a cut
            // hasn't already been performed recently
            if ((rangeCut == true) && !m_rangeCutSend )
            {

                // A range cut also sets the bearing cut
                m_PIPRetTWSHTarTrueBrgCut.SetRawValue(true);
                m_PIPRetTWSHTarTrueBrg.SetRawValue(m_SIMPeriTrueHeading);

                // A range cut also sets the elapsed time cut
                // Note that the elapsed time is defaulted as it cannot be set
                // by the PSC (historical: RDEP removed)
                m_PIPRetTWSHTarElpsdTimeCut.SetRawValue(true);
                m_PIPRetTWSHTarElpsdTime.SetRawValue(0.0f);

                // Set the range cut and data
                m_PIPRetTWSHTarRangeCut.SetRawValue(true);
                m_PIPRetTWSHTarRange.SetRawValue((float) m_IOTarHeight.GetResultValue());

                //Set the flag to avoid sending multiple cuts.
                m_rangeCutSend = true;
            }
            else
            {

                // Clear the elapsed time cut and data
                m_PIPRetTWSHTarElpsdTimeCut.SetRawValue(false);
                m_PIPRetTWSHTarElpsdTime.SetRawValue(0.0f);

                // Clear the range cut and data
                m_PIPRetTWSHTarRangeCut.SetRawValue(false);
                m_PIPRetTWSHTarRange.SetRawValue(0.0f);

                //
                //Clear the flag when the cut button has been released, to avoide sending multiple cuts.
                //
                if(!rangeCut)
                {
                    m_rangeCutSend = false;
                }
            }
        }


        // ------------------------
        // Process Polynia Data
        // ------------------------
        private void ProcessPolynia()
        {

            int i;

            //
            // Number of polynia
            //
            int numPolynia = (int) m_PIGRetPolyniaNum.GetResultValue();

            if ((numPolynia < 0) || (numPolynia > NUM_POLYNIA_TARGETS))
                numPolynia = 0;

            m_PIPRetNumPolynia.SetRawValue(numPolynia);

            //
            // Process each polynia
            //
            long slot;
            int present;
            double Xpos;
            double Ypos;
            double Zpos;
            double orientation;

            for (i = 0 ; i < NUM_POLYNIA_TARGETS; i++)
            {
                if (i < numPolynia)
                {
                    // Slot number
                    slot = m_PIGRetPolynia[i].m_PIGRetPolSlotNum.GetResultValue();

                    // Present indicator
                    present = 1;

                    // X position
                    Xpos = m_PIGRetPolynia[i].m_PIGRetPolX.GetResultValue();

                    if (Xpos < (POLYNIA_X_MIN - ICE_CELL_SIZE))
                        Xpos = POLYNIA_X_MIN - ICE_CELL_SIZE;

                    if (Xpos > (POLYNIA_X_MAX + ICE_CELL_SIZE))
                        Xpos = POLYNIA_X_MAX + ICE_CELL_SIZE;

                    Xpos = Xpos * MTRS_TO_YDS * 0.001f;


                    // Y position (note Y = -Z)
                    Ypos = -m_PIGRetPolynia[i].m_PIGRetPolZ.GetResultValue();

                    if (Ypos < (POLYNIA_Y_MIN - ICE_CELL_SIZE))
                        Ypos = POLYNIA_Y_MIN - ICE_CELL_SIZE;

                    if (Ypos > (POLYNIA_Y_MAX + ICE_CELL_SIZE))
                        Ypos = POLYNIA_Y_MAX + ICE_CELL_SIZE;

                    Ypos = Ypos * MTRS_TO_YDS * 0.001f;;


                    // Z position (note Z = Y)
                    Zpos = m_PIGRetPolynia[i].m_PIGRetPolY.GetResultValue();

                    if (Zpos < POLYNIA_Z_MIN)
                        Zpos = POLYNIA_Z_MIN;

                    if (Zpos > POLYNIA_Z_MAX)
                        Zpos = POLYNIA_Z_MAX ;

                    Zpos = Zpos * MTRS_TO_FT;

                    // Orientation
                    orientation = m_PIGRetPolynia[i].m_PIGRetPolOrien.GetResultValue();

                    if ((orientation < ORIENTATION_MIN) || (orientation > ORIENTATION_MAX))
                        orientation = ORIENTATION_MIN;

                }
                else
                {
                    // Set default data
                    slot = 0;
                    present = 0;
                    Xpos = 0.0f;
                    Ypos = 0.0f;
                    Zpos = 0.0f;
                    orientation = 0.0f;
                }

                //
                // Set PIP values
                //
                m_PIPRetPolynia[i].m_PIPRetPolIdentity.SetRawValue(m_SIMTargets[(int) slot].m_SIMTarSlotID);
                m_PIPRetPolynia[i].m_PIPRetPolPresent.SetRawValue((byte) present);
                m_PIPRetPolynia[i].m_PIPRetPolX.SetRawValue(Xpos);
                m_PIPRetPolynia[i].m_PIPRetPolY.SetRawValue(Ypos);
                m_PIPRetPolynia[i].m_PIPRetPolZ.SetRawValue(Zpos);
                m_PIPRetPolynia[i].m_PIPRetPolOrientation.SetRawValue(orientation);

            }

        }



        // -------------------------
        // Process PIP RETURN Data
        // --------------------------
        public void ProcessPIPReturn()
        {
            //
            // Set PIP Return values
            // Note that TWSH is done in ProcessCuts.
            // Note that polynia are done in ProcessPolynia.
            //

            // Search mast up
            if (m_PIGOwnMast[0].GetResultValue() > 0.0f)
                m_PIPRetSearchUp.SetRawValue(true);
            else
                m_PIPRetSearchUp.SetRawValue(false);

            // Sensor polarity
            if (m_PIGPeriSensor.GetResultValue() == SENSOR_WHIR)
                m_PIPRetPolarityWhite.SetRawValue(true);
            else if (m_PIGPeriSensor.GetResultValue() == SENSOR_BHIR)
                m_PIPRetPolarityWhite.SetRawValue(false);

            // Sensor magnification
            if (m_PIGPeriMagnification.GetResultValue() == PIG_HIGH_MAG_FOV)
                m_PIPRetHighMag.SetRawValue(true);
            else if (m_PIGPeriMagnification.GetResultValue() == PIG_LOW_MAG_FOV)
                m_PIPRetHighMag.SetRawValue(false);

            // Pass the current
            if (m_IOHandlesDown.GetResultValue() == true)
                m_PIPRetHandlesUp.SetRawValue(false);
            else
                m_PIPRetHandlesUp.SetRawValue(true);


            // LLTV and thermal gain
            int sensor = m_PIGPeriSensor.GetResultValue();

            int gain = (int) ((float) m_PIGPeriGain.GetResultValue() / 16.6667f);

            if (gain > 6)
                gain = 6;

            if ((sensor == SENSOR_WHIR) || (sensor ==  SENSOR_BHIR))
            {
                m_PIPRetPeriLLTVGain.SetRawValue(0);
                m_PIPRetPeriTIGain.SetRawValue((byte) gain);
            }
            else if (sensor == SENSOR_LLTV)
            {
                m_PIPRetPeriLLTVGain.SetRawValue((byte) gain);
                m_PIPRetPeriTIGain.SetRawValue(0);
            }
            else
            {
                m_PIPRetPeriLLTVGain.SetRawValue(0);
                m_PIPRetPeriTIGain.SetRawValue(0);
            }

            // Relative bearing
            m_PIPRetPeriRelBrg.SetRawValue(m_PIGPeriRelBrg.GetResultValue());

            // Periscope elevation
            m_PIPRetPeriElev.SetRawValue(m_PIGPeriElevation.GetResultValue());

            // Sun bearing - for future expansion
            m_PIPRetPeriSunBrg.SetRawValue(0.0f);

            // Sun elevation - for future expansion
            m_PIPRetPeriSunElev.SetRawValue(0.0f);


            //
            // Check for errors for PIP Return data
            //

            // Default is zero - no errors
            m_PIPRetPeriErrorNo.SetRawValue(0);
            m_PIPRetPeriErrorString.SetRawValue("");

            // Check for missed transfer of message
            if (m_PIPMessageCountIn != (m_SIMPIPLastMessage + 1))
            {
                m_PIPRetPeriErrorNo.SetRawValue(1);
                m_PIPRetPeriErrorString.SetRawValue("");
            }

            // Check for error in checksum
            if (m_PIPCheckSum.GetResultValue() != m_SIMPIPCheckSum)
            {
                m_PIPRetPeriErrorNo.SetRawValue(2);
                m_PIPRetPeriErrorString.SetRawValue("");
            }

        }



        // ------------------------
        // Process ERROR LOG Data
        // ------------------------
        public void ProcessErrorLog()
        {

            //
            // Check for Error Log Clear
            //
            if (m_SIMErrorLogClear)
            {
                WriteToErrorLog("CLEAR", "CLEAR");
                m_SIMErrorLogClear = false;
            }


            // Print values
            bool printLog = false;
            if (printLog)
            {
                for (int i = 0; i < SIM_ERRORLOG_SIZE; i++)
                {
                    if (m_SIMErrorLog[i].m_ErrorType.Equals(""))
                    {
                        // Dont print
                    }
                    else
                    {
                        Console.WriteLine("{0} Time: {1}\t Type: {2}\t Source: {3}",
                                          i, m_SIMErrorLog[i].m_ErrorTime, m_SIMErrorLog[i].m_ErrorType, m_SIMErrorLog[i].m_ErrorSource);
                    }
                }
            }

        }



        // -----------------------------
        // Process NETWORK TIMING Data
        // -----------------------------
        public void ProcessNetworkTiming()
        {

            //
            // Calculate network timings
            //
            m_PIPAverageTimeIn = StatusAverageTimings(m_PIPArrayTimesIn) * 1000.0f;
            m_PIPAverageTimeOut = StatusAverageTimings(m_PIPArrayTimesOut) * 1000.0f;
            m_PIGAverageTimeIn = StatusAverageTimings(m_PIGArrayTimesIn) * 1000.0f;
            m_PIGAverageTimeOut = StatusAverageTimings(m_PIGArrayTimesOut) * 1000.0f;

            // Print values
            bool printMetrics = false;
            if (printMetrics)
            {
                Console.WriteLine("PIP Average In (ms) \t: {0}", m_PIPAverageTimeIn);
                Console.WriteLine("PIP Average Out (ms) \t: {0}", m_PIPAverageTimeOut);
                Console.WriteLine("PIG Average In (ms) \t: {0}", m_PIGAverageTimeIn);
                Console.WriteLine("PIG Average Out (ms) \t: {0}", m_PIGAverageTimeOut);
            }

        }



        // ----------------------------------
        // Status: Calculate average timings
        // ----------------------------------
        private float StatusAverageTimings(long[] measuredTimes)
        {
            int i;
            long delta;
            int numUpdates = 9;
            double deltaTime = 0.0;
            double totalTime = 0.0;
            float result = 0.0f;
            long[] arrayTimes = new long[10];

            //
            // This function calculates the average update time
            // from an array of 10 measured times (long)
            //

            // Copy the input measured times to a local array
            Array.Copy(measuredTimes, arrayTimes, 10);

            // Sort the local array (lowest to highest)
            Array.Sort(arrayTimes);


            // Calculate the time difference between an element and the previous one
            // (start at element 2 i.e. [1]), keeping a running total
            for (i = 1; i < 10; i++)
            {
                if (arrayTimes[i - 1] > 0)
                {
                    delta = arrayTimes[i] - arrayTimes[i - 1];
                    deltaTime = ((double)delta / (double)(m_TimerFreq));
                    totalTime += deltaTime;
                }
                else
                {
                    numUpdates--;
                }

            }


            // Calculate the average from the running total and
            // the number of updates (for full array 9 updates)
            if (numUpdates > 0)
                result = (float) (totalTime / numUpdates);

            return(result);
        }



        // -------------
        // Process IO
        // --------------
        public void ProcessIO()
        {
            //
            // Set the IO display values to match the PIG outputs
            //

            // Calculate the true bearing
            float trueBrg = m_PIGOwnHeading.GetResultValue() + this.m_PIGPeriRelBrg.GetResultValue();

            while (trueBrg > 360.0f)
                trueBrg -= 360.0f;

            while (trueBrg < 0.0f)
                trueBrg += 360.0f;

            // Pannier bearing display
            m_IODisplayBrg.SetRawValue(trueBrg);

            // Pannier elevation display
            m_IODisplayElev.SetRawValue(m_PIGPeriElevation.GetResultValue());

            // Rear stadiametric angle display (and target display)
            m_IORearStadAngle.SetRawValue(m_IOStadAngle.GetResultValue());
            m_IODisplayTar.SetRawValue(m_IOStadAngle.GetResultValue());

            // Rear true bearing display
            m_IORearTrueBrg.SetRawValue(trueBrg);

            // Rear relative bearing display
            m_IORearRelBrg.SetRawValue(m_PIGPeriRelBrg.GetResultValue());

            // Beckman true bearing display
            m_IOBeckmanTrue.SetRawValue(trueBrg);

            // Beckman relative bearing display
            m_IOBeckmanRel.SetRawValue(m_PIGPeriRelBrg.GetResultValue());

            // TI ON indicator (from IO settings only)
            // if (m_IOModeSelect.GetResultValue() == IOComms.MODE_SELECT_THERMAL)
            // m_IOTiOnIndicator.SetRawValue(true);
            // else
            // m_IOTiOnIndicator.SetRawValue(false);

            //
            // Set the overall IO status
            //

            // Set up status array
            int[] statusArray = new int[23];

            statusArray[0] = m_IOBearing.GetStatus();
            statusArray[1] = m_IOElevation.GetStatus();
            statusArray[2] = m_IOStadAngle.GetStatus();
            statusArray[3] = m_IOTiBlackLevel.GetStatus();
            statusArray[4] = m_IOTiSensitivity.GetStatus();
            statusArray[5] = m_IOTiGratIllum.GetStatus();

            statusArray[6] = m_IORearStadAngle.GetStatus();
            statusArray[7] = m_IORearTrueBrg.GetStatus();
            statusArray[8] = m_IORearRelBrg.GetStatus();

            statusArray[9] = m_IODisplayBrg.GetStatus();
            statusArray[10] = m_IODisplayElev.GetStatus();
            statusArray[11] = m_IODisplayTar.GetStatus();

            statusArray[12] = m_IOHandlesDown.GetStatus();
            statusArray[13] = m_IOHighMag.GetStatus();
            statusArray[14] = m_IORangeCut.GetStatus();
            statusArray[15] = m_IOBearingCut.GetStatus();
            statusArray[16] = m_IOPushToTalk.GetStatus();

            statusArray[17] = m_IOModeSelect.GetStatus();
            statusArray[18] = m_IODataOverlay.GetStatus();
            statusArray[19] = m_IOTiOnIndicator.GetStatus();
            statusArray[20] = m_IOTarHeight.GetStatus();

            statusArray[21] = m_IOBeckmanTrue.GetStatus();
            statusArray[22] = m_IOBeckmanRel.GetStatus();


            // Check the status
            // bool unknownFlag = false;
            // bool overrideFlag = false;
            // bool faultFlag = false;

            // for (int i = 0; i < 23; i++)
            // {
            //    if (statusArray[i] == IOComms.IO_UNKNOWN)
            //       unknownFlag = true;

            //    if (statusArray[i] == IOComms.IO_OVERRIDE)
            //       overrideFlag = true;

            //    if (statusArray[i] == IOComms.IO_FAULT)
            //       faultFlag = true;
            // }

            // // Set the overall status
            // int overallStatus = IOComms.IO_OPERATIONAL;

            // if (unknownFlag)
            //    overallStatus = IOComms.IO_UNKNOWN;

            // if (faultFlag)
            //    overallStatus = IOComms.IO_FAULT;

            // if (overrideFlag)
            //    overallStatus = IOComms.IO_OVERRIDE;

            // if (m_SIMEmulatingIO)
            //    overallStatus = IOComms.IO_EMULATION;

            // m_SIMStatusIO = overallStatus;
            m_SIMStatusIO = 1;

            // Print status
            // bool printStatus = false;

            // if (printStatus)
            // {
            //    switch (m_SIMStatusIO)
            //    {
            //       case IOComms.IO_OPERATIONAL:
            //          Console.WriteLine("SIM: IO Status = OPERATIONAL");
            //          break;
            //       case IOComms.IO_UNKNOWN:
            //          Console.WriteLine("SIM: IO Status = UNKNOWN");
            //          break;
            //       case IOComms.IO_FAULT:
            //          Console.WriteLine("SIM: IO Status = FAULT");
            //          break;
            //       case IOComms.IO_OVERRIDE:
            //          Console.WriteLine("SIM: IO Status = OVERRIDE");
            //          break;
            //       case IOComms.IO_EMULATION:
            //          Console.WriteLine("SIM: IO Status = EMULATION");
            //          break;
            //       default:
            //          Console.WriteLine("SIM: IO Status = Error undefined!");
            //          break;
            //    }
            // }
        }




        // ------------------------
        // Update GUI Data
        // ------------------------
        public void UpdateGUIData()
        {
            int i;

            long timeStamp1 = 0;
            long timeStamp2 = 0;

            //
            // Update the mutex-protected data that the GUI Thread uses.
            //

            // Wait for mutex availability
            mutexData.WaitOne();

            //
            // Measure the time to update (if required)
            //
            bool measureTime = false;
            if (measureTime)
            {
                QueryPerformanceCounter(out timeStamp1);
            }


            //
            // Raw data from SimControl to GUI
            //
            // PIG Data
            m_GUIData.m_PIGExSystemID.SetRawValue(m_PIGExSystemID.GetRawValue());
            m_GUIData.m_PIGExRunMode.SetRawValue(m_PIGExRunMode.GetRawValue());

            m_GUIData.m_PIGEnvMoonOverride.SetRawValue(m_PIGEnvMoonOverride.GetRawValue());
            m_GUIData.m_PIGEnvCoastLights.SetRawValue(m_PIGEnvCoastLights.GetRawValue());
            m_GUIData.m_PIGEnvIceEdgeOn.SetRawValue(m_PIGEnvIceEdgeOn.GetRawValue());
            m_GUIData.m_PIGEnvSunOverride.SetRawValue(m_PIGEnvSunOverride.GetRawValue());
            m_GUIData.m_PIGEnvHours.SetRawValue(m_PIGEnvHours.GetRawValue());
            m_GUIData.m_PIGEnvMins.SetRawValue(m_PIGEnvMins.GetRawValue());
            m_GUIData.m_PIGEnvSecs.SetRawValue(m_PIGEnvSecs.GetRawValue());
            m_GUIData.m_PIGEnvDay.SetRawValue(m_PIGEnvDay.GetRawValue());
            m_GUIData.m_PIGEnvMonth.SetRawValue(m_PIGEnvMonth.GetRawValue());
            m_GUIData.m_PIGEnvYear.SetRawValue(m_PIGEnvYear.GetRawValue());
            m_GUIData.m_PIGEnvWeather.SetRawValue(m_PIGEnvWeather.GetRawValue());
            m_GUIData.m_PIGEnvCoastline.SetRawValue(m_PIGEnvCoastline.GetRawValue());
            m_GUIData.m_PIGEnvSeaState.SetRawValue(m_PIGEnvSeaState.GetRawValue());
            m_GUIData.m_PIGEnvVisualRange.SetRawValue(m_PIGEnvVisualRange.GetRawValue());
            m_GUIData.m_PIGEnvThermalRange.SetRawValue(m_PIGEnvThermalRange.GetRawValue());
            m_GUIData.m_PIGEnvUnderWaterRange.SetRawValue(m_PIGEnvUnderWaterRange.GetRawValue());
            m_GUIData.m_PIGEnvWindSpeed.SetRawValue(m_PIGEnvWindSpeed.GetRawValue());
            m_GUIData.m_PIGEnvWindDirn.SetRawValue(m_PIGEnvWindDirn.GetRawValue());
            m_GUIData.m_PIGEnvMoonBrgOverRide.SetRawValue(m_PIGEnvMoonBrgOverRide.GetRawValue());
            m_GUIData.m_PIGEnvMoonElevOverRide.SetRawValue(m_PIGEnvMoonElevOverRide.GetRawValue());
            m_GUIData.m_PIGEnvSunBrgOverRide.SetRawValue(m_PIGEnvSunBrgOverRide.GetRawValue());
            m_GUIData.m_PIGEnvSunElevOverRide.SetRawValue(m_PIGEnvSunElevOverRide.GetRawValue());
            m_GUIData.m_PIGEnvIceEdgeLat.SetRawValue(m_PIGEnvIceEdgeLat.GetRawValue());
            m_GUIData.m_PIGEnvIceEdgeLon.SetRawValue(m_PIGEnvIceEdgeLon.GetRawValue());
            m_GUIData.m_PIGEnvIceEdgeOrien.SetRawValue(m_PIGEnvIceEdgeOrien.GetRawValue());

            m_GUIData.m_PIGOwnType.SetRawValue(m_PIGOwnType.GetRawValue());
            m_GUIData.m_PIGOwnSmoke.SetRawValue(m_PIGOwnSmoke.GetRawValue());
            m_GUIData.m_PIGOwnLatitude.SetRawValue(m_PIGOwnLatitude.GetRawValue());
            m_GUIData.m_PIGOwnLongitude.SetRawValue(m_PIGOwnLongitude.GetRawValue());
            m_GUIData.m_PIGOwnX.SetRawValue(m_PIGOwnX.GetRawValue());
            m_GUIData.m_PIGOwnY.SetRawValue(m_PIGOwnY.GetRawValue());
            m_GUIData.m_PIGOwnDepth.SetRawValue(m_PIGOwnDepth.GetRawValue());
            m_GUIData.m_PIGOwnHeading.SetRawValue(m_PIGOwnHeading.GetRawValue());
            m_GUIData.m_PIGOwnRoll.SetRawValue(m_PIGOwnRoll.GetRawValue());
            m_GUIData.m_PIGOwnPitch.SetRawValue(m_PIGOwnPitch.GetRawValue());
            m_GUIData.m_PIGOwnSpeed.SetRawValue(m_PIGOwnSpeed.GetRawValue());

            for (i = 0; i < 10; i++)
                m_GUIData.m_PIGOwnMast[i].SetRawValue(m_PIGOwnMast[i].GetRawValue());

            m_GUIData.m_PIGPeriSensor.SetRawValue(m_PIGPeriSensor.GetRawValue());
            m_GUIData.m_PIGPeriMagnification.SetRawValue(m_PIGPeriMagnification.GetRawValue());
            m_GUIData.m_PIGPeriGain.SetRawValue(m_PIGPeriGain.GetRawValue());
            m_GUIData.m_PIGPeriContrast.SetRawValue(m_PIGPeriContrast.GetRawValue());
            m_GUIData.m_PIGPeriGratIntensity.SetRawValue(m_PIGPeriGratIntensity.GetRawValue());
            m_GUIData.m_PIGPeriDraindown.SetRawValue(m_PIGPeriDraindown.GetRawValue());
            m_GUIData.m_PIGPeriRelBrg.SetRawValue(m_PIGPeriRelBrg.GetRawValue());
            m_GUIData.m_PIGPeriElevation.SetRawValue(m_PIGPeriElevation.GetRawValue());
            m_GUIData.m_PIGPeriStadAngle.SetRawValue(m_PIGPeriStadAngle.GetRawValue());

            for ( i = 0; i < NUM_PERI_TARGETS ; i++)
            {
                m_GUIData.m_PIGTargets[i].m_PIGTarPresent.SetRawValue(m_PIGTargets[i].m_PIGTarPresent.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarNavLights.SetRawValue(m_PIGTargets[i].m_PIGTarNavLights.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarMissileHit.SetRawValue(m_PIGTargets[i].m_PIGTarMissileHit.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarTorpedoHit.SetRawValue(m_PIGTargets[i].m_PIGTarTorpedoHit.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarSinking.SetRawValue(m_PIGTargets[i].m_PIGTarSinking.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarDunkingSonar.SetRawValue(m_PIGTargets[i].m_PIGTarDunkingSonar.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarTLAM.SetRawValue(m_PIGTargets[i].m_PIGTarTLAM.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarFlames.SetRawValue(m_PIGTargets[i].m_PIGTarFlames.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarDieselSmoke.SetRawValue(m_PIGTargets[i].m_PIGTarDieselSmoke.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarFireMissile.SetRawValue(m_PIGTargets[i].m_PIGTarFireMissile.GetRawValue());

                m_GUIData.m_PIGTargets[i].m_PIGTarModelID.SetRawValue(m_PIGTargets[i].m_PIGTarModelID.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarSlotNum.SetRawValue(m_PIGTargets[i].m_PIGTarSlotNum.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarLightConfig.SetRawValue(m_PIGTargets[i].m_PIGTarLightConfig.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarSpotConfig.SetRawValue(m_PIGTargets[i].m_PIGTarSpotConfig.GetRawValue());

                m_GUIData.m_PIGTargets[i].m_PIGTarX.SetRawValue(m_PIGTargets[i].m_PIGTarX.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarY.SetRawValue(m_PIGTargets[i].m_PIGTarY.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarHeight.SetRawValue(m_PIGTargets[i].m_PIGTarHeight.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarHeading.SetRawValue(m_PIGTargets[i].m_PIGTarHeading.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarRoll.SetRawValue(m_PIGTargets[i].m_PIGTarRoll.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarPitch.SetRawValue(m_PIGTargets[i].m_PIGTarPitch.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarSpeed.SetRawValue(m_PIGTargets[i].m_PIGTarSpeed.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarAccel.SetRawValue(m_PIGTargets[i].m_PIGTarAccel.GetRawValue());
                m_GUIData.m_PIGTargets[i].m_PIGTarHitPoint.SetRawValue(m_PIGTargets[i].m_PIGTarHitPoint.GetRawValue());
            }

            m_GUIData.m_PIGRetProcStat.SetRawValue(m_PIGRetProcStat.GetRawValue());
            m_GUIData.m_PIGRetModelStat.SetRawValue(m_PIGRetModelStat.GetRawValue());
            m_GUIData.m_PIGRetPolyniaNum.SetRawValue(m_PIGRetPolyniaNum.GetRawValue());

            for (i = 0; i < NUM_POLYNIA_TARGETS; i++)
            {
                m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolIdentity.SetRawValue(m_PIGRetPolynia[i].m_PIGRetPolIdentity.GetRawValue());
                m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolX.SetRawValue(m_PIGRetPolynia[i].m_PIGRetPolX.GetRawValue());
                m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolY.SetRawValue(m_PIGRetPolynia[i].m_PIGRetPolY.GetRawValue());
                m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolZ.SetRawValue(m_PIGRetPolynia[i].m_PIGRetPolZ.GetRawValue());
                m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolOrien.SetRawValue(m_PIGRetPolynia[i].m_PIGRetPolOrien.GetRawValue());
                m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolSlotNum.SetRawValue(m_PIGRetPolynia[i].m_PIGRetPolSlotNum.GetRawValue());
            }

            // PIP Data

            m_GUIData.m_PIPExRunMode.SetRawValue(m_PIPExRunMode.GetRawValue());
            m_GUIData.m_PIPExHours.SetRawValue(m_PIPExHours.GetRawValue());
            m_GUIData.m_PIPExMins.SetRawValue(m_PIPExMins.GetRawValue());
            m_GUIData.m_PIPExSecs.SetRawValue(m_PIPExSecs.GetRawValue());
            m_GUIData.m_PIPExDay.SetRawValue(m_PIPExDay.GetRawValue());
            m_GUIData.m_PIPExMonth.SetRawValue(m_PIPExMonth.GetRawValue());
            m_GUIData.m_PIPExYear.SetRawValue(m_PIPExYear.GetRawValue());

            m_GUIData.m_PIPPeriInstructCtrl.SetRawValue(m_PIPPeriInstructCtrl.GetRawValue());
            m_GUIData.m_PIPPeriSearchUp.SetRawValue(m_PIPPeriSearchUp.GetRawValue());
            m_GUIData.m_PIPPeriPolarityWhite.SetRawValue(m_PIPPeriPolarityWhite.GetRawValue());
            m_GUIData.m_PIPPeriHighMag.SetRawValue(m_PIPPeriHighMag.GetRawValue());
            m_GUIData.m_PIPPeriDraindown.SetRawValue(m_PIPPeriDraindown.GetRawValue());
            m_GUIData.m_PIPPeriLLTVGain.SetRawValue(m_PIPPeriLLTVGain.GetRawValue());
            m_GUIData.m_PIPPeriThermalGain.SetRawValue(m_PIPPeriThermalGain.GetRawValue());
            m_GUIData.m_PIPPeriRelBearing.SetRawValue(m_PIPPeriRelBearing.GetRawValue());
            m_GUIData.m_PIPPeriElevation.SetRawValue(m_PIPPeriElevation.GetRawValue());

            m_GUIData.m_PIPEnvMoonOverride.SetRawValue(m_PIPEnvMoonOverride.GetRawValue());
            m_GUIData.m_PIPEnvCoastLights.SetRawValue(m_PIPEnvCoastLights.GetRawValue());
            m_GUIData.m_PIPEnvIceEdgeOn.SetRawValue(m_PIPEnvIceEdgeOn.GetRawValue());
            m_GUIData.m_PIPEnvSunOverride.SetRawValue(m_PIPEnvSunOverride.GetRawValue());
            m_GUIData.m_PIPEnvWeather.SetRawValue(m_PIPEnvWeather.GetRawValue());
            m_GUIData.m_PIPEnvCoastline.SetRawValue(m_PIPEnvCoastline.GetRawValue());
            m_GUIData.m_PIPEnvSeaState.SetRawValue(m_PIPEnvSeaState.GetRawValue());
            m_GUIData.m_PIPEnvMoonBrg.SetRawValue(m_PIPEnvMoonBrg.GetRawValue());
            m_GUIData.m_PIPEnvMoonElev.SetRawValue(m_PIPEnvMoonElev.GetRawValue());
            m_GUIData.m_PIPEnvVisualRange.SetRawValue(m_PIPEnvVisualRange.GetRawValue());
            m_GUIData.m_PIPEnvUnderWaterRange.SetRawValue(m_PIPEnvUnderWaterRange.GetRawValue());
            m_GUIData.m_PIPEnvThermalRange.SetRawValue(m_PIPEnvThermalRange.GetRawValue());
            m_GUIData.m_PIPEnvWindSpeed.SetRawValue(m_PIPEnvWindSpeed.GetRawValue());
            m_GUIData.m_PIPEnvWindHeading.SetRawValue(m_PIPEnvWindHeading.GetRawValue());
            m_GUIData.m_PIPEnvIceLat.SetRawValue(m_PIPEnvIceLat.GetRawValue());
            m_GUIData.m_PIPEnvIceLon.SetRawValue(m_PIPEnvIceLon.GetRawValue());
            m_GUIData.m_PIPEnvIceOrien.SetRawValue(m_PIPEnvIceOrien.GetRawValue());
            m_GUIData.m_PIPEnvSunBrg.SetRawValue(m_PIPEnvSunBrg.GetRawValue());
            m_GUIData.m_PIPEnvSunElev.SetRawValue(m_PIPEnvSunElev.GetRawValue());

            m_GUIData.m_PIPOwnLat.SetRawValue(m_PIPOwnLat.GetRawValue());
            m_GUIData.m_PIPOwnLon.SetRawValue(m_PIPOwnLon.GetRawValue());
            m_GUIData.m_PIPOwnDepth.SetRawValue(m_PIPOwnDepth.GetRawValue());
            m_GUIData.m_PIPOwnClimbRate.SetRawValue(m_PIPOwnClimbRate.GetRawValue());
            m_GUIData.m_PIPOwnTurnRate.SetRawValue(m_PIPOwnTurnRate.GetRawValue());
            m_GUIData.m_PIPOwnPitch.SetRawValue(m_PIPOwnPitch.GetRawValue());
            m_GUIData.m_PIPOwnHeading.SetRawValue(m_PIPOwnHeading.GetRawValue());
            m_GUIData.m_PIPOwnDriftCourse.SetRawValue(m_PIPOwnDriftCourse.GetRawValue());
            m_GUIData.m_PIPOwnSpeed.SetRawValue(m_PIPOwnSpeed.GetRawValue());
            m_GUIData.m_PIPOwnDriftSpeed.SetRawValue(m_PIPOwnDriftSpeed.GetRawValue());
            m_GUIData.m_PIPOwnWhipAerialUp.SetRawValue(m_PIPOwnWhipAerialUp.GetRawValue());
            m_GUIData.m_PIPOwnEmerLightUp.SetRawValue(m_PIPOwnEmerLightUp.GetRawValue());
            m_GUIData.m_PIPOwnDieselSmoke.SetRawValue(m_PIPOwnDieselSmoke.GetRawValue());
            m_GUIData.m_PIPOwnMastRESM.SetRawValue(m_PIPOwnMastRESM.GetRawValue());
            m_GUIData.m_PIPOwnMastWTComms.SetRawValue(m_PIPOwnMastWTComms.GetRawValue());
            m_GUIData.m_PIPOwnMastHFDF.SetRawValue(m_PIPOwnMastHFDF.GetRawValue());
            m_GUIData.m_PIPOwnMastAttack.SetRawValue(m_PIPOwnMastAttack.GetRawValue());
            m_GUIData.m_PIPOwnMastRadar.SetRawValue(m_PIPOwnMastRadar.GetRawValue());
            m_GUIData.m_PIPOwnMastSnortInd.SetRawValue(m_PIPOwnMastSnortInd.GetRawValue());
            m_GUIData.m_PIPOwnMastSnortExh.SetRawValue(m_PIPOwnMastSnortExh.GetRawValue());
            m_GUIData.m_PIPOwnType.SetRawValue(m_PIPOwnType.GetRawValue());


            for (i = 0; i < NUM_PERI_TARGETS; i++)
            {
                m_GUIData.m_PIPTargets[i].m_PIPTarPresent.SetRawValue(m_PIPTargets[i].m_PIPTarPresent.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarFlames.SetRawValue(m_PIPTargets[i].m_PIPTarFlames.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarMissileHit.SetRawValue(m_PIPTargets[i].m_PIPTarMissileHit.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarTorpedoHit.SetRawValue(m_PIPTargets[i].m_PIPTarTorpedoHit.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarSinking.SetRawValue(m_PIPTargets[i].m_PIPTarSinking.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarNavLights.SetRawValue(m_PIPTargets[i].m_PIPTarNavLights.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarDunkingSonar.SetRawValue(m_PIPTargets[i].m_PIPTarDunkingSonar.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarTLAMFaulty.SetRawValue(m_PIPTargets[i].m_PIPTarTLAMFaulty.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarFireMissile.SetRawValue(m_PIPTargets[i].m_PIPTarFireMissile.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarDunkingData.SetRawValue(m_PIPTargets[i].m_PIPTarDunkingData.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarLightConfig.SetRawValue(m_PIPTargets[i].m_PIPTarLightConfig.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarSpotConfig.SetRawValue(m_PIPTargets[i].m_PIPTarSpotConfig.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarModelID.SetRawValue(m_PIPTargets[i].m_PIPTarModelID.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarSlotID.SetRawValue(m_PIPTargets[i].m_PIPTarSlotID.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarX.SetRawValue(m_PIPTargets[i].m_PIPTarX.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarY.SetRawValue(m_PIPTargets[i].m_PIPTarY.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarHeight.SetRawValue(m_PIPTargets[i].m_PIPTarHeight.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarClimbRate.SetRawValue(m_PIPTargets[i].m_PIPTarClimbRate.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarTurnRate.SetRawValue(m_PIPTargets[i].m_PIPTarTurnRate.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarPitch.SetRawValue(m_PIPTargets[i].m_PIPTarPitch.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarHeading.SetRawValue(m_PIPTargets[i].m_PIPTarHeading.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarDriftCourse.SetRawValue(m_PIPTargets[i].m_PIPTarDriftCourse.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarSpeed.SetRawValue(m_PIPTargets[i].m_PIPTarSpeed.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarDriftSpeed.SetRawValue(m_PIPTargets[i].m_PIPTarDriftSpeed.GetRawValue());
                m_GUIData.m_PIPTargets[i].m_PIPTarDieselSmoke.SetRawValue(m_PIPTargets[i].m_PIPTarDieselSmoke.GetRawValue());
            }


            m_GUIData.m_PIPRetSearchUp.SetRawValue(m_PIPRetSearchUp.GetRawValue());
            m_GUIData.m_PIPRetPolarityWhite.SetRawValue(m_PIPRetPolarityWhite.GetRawValue());
            m_GUIData.m_PIPRetHighMag.SetRawValue(m_PIPRetHighMag.GetRawValue());
            m_GUIData.m_PIPRetHandlesUp.SetRawValue(m_PIPRetHandlesUp.GetRawValue());

            m_GUIData.m_PIPRetPeriLLTVGain.SetRawValue(m_PIPRetPeriLLTVGain.GetRawValue());
            m_GUIData.m_PIPRetPeriTIGain.SetRawValue(m_PIPRetPeriTIGain.GetRawValue());

            m_GUIData.m_PIPRetTWSHPeriTrueBrg.SetRawValue(m_PIPRetTWSHPeriTrueBrg.GetRawValue());
            m_GUIData.m_PIPRetTWSHTarTrueBrg.SetRawValue(m_PIPRetTWSHTarTrueBrg.GetRawValue());
            m_GUIData.m_PIPRetTWSHTarRange.SetRawValue(m_PIPRetTWSHTarRange.GetRawValue());
            m_GUIData.m_PIPRetTWSHTarElpsdTime.SetRawValue(m_PIPRetTWSHTarElpsdTime.GetRawValue());
            m_GUIData.m_PIPRetTWSHTarTrueBrgCut.SetRawValue(m_PIPRetTWSHTarTrueBrgCut.GetRawValue());
            m_GUIData.m_PIPRetTWSHTarRangeCut.SetRawValue(m_PIPRetTWSHTarRangeCut.GetRawValue());
            m_GUIData.m_PIPRetTWSHTarElpsdTimeCut.SetRawValue(m_PIPRetTWSHTarElpsdTimeCut.GetRawValue());

            m_GUIData.m_PIPRetPeriRelBrg.SetRawValue(m_PIPRetPeriRelBrg.GetRawValue());
            m_GUIData.m_PIPRetPeriElev.SetRawValue(m_PIPRetPeriElev.GetRawValue());
            m_GUIData.m_PIPRetPeriSunBrg.SetRawValue(m_PIPRetPeriSunBrg.GetRawValue());
            m_GUIData.m_PIPRetPeriSunElev.SetRawValue(m_PIPRetPeriSunElev.GetRawValue());
            m_GUIData.m_PIPRetPeriErrorNo.SetRawValue(m_PIPRetPeriErrorNo.GetRawValue());
            m_GUIData.m_PIPRetPeriErrorString.SetRawValue(m_PIPRetPeriErrorString.GetRawValue());
            m_GUIData.m_PIPRetNumPolynia.SetRawValue(m_PIPRetNumPolynia.GetRawValue());


            for (i = 0; i < NUM_POLYNIA_TARGETS; i++)
            {
                m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolIdentity.SetRawValue(m_PIPRetPolynia[i].m_PIPRetPolIdentity.GetRawValue());
                m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolPresent.SetRawValue(m_PIPRetPolynia[i].m_PIPRetPolPresent.GetRawValue());
                m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolX.SetRawValue(m_PIPRetPolynia[i].m_PIPRetPolX.GetRawValue());
                m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolY.SetRawValue(m_PIPRetPolynia[i].m_PIPRetPolY.GetRawValue());
                m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolZ.SetRawValue(m_PIPRetPolynia[i].m_PIPRetPolZ.GetRawValue());
                m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolOrientation.SetRawValue(m_PIPRetPolynia[i].m_PIPRetPolOrientation.GetRawValue());
            }


            // IO Data
            m_GUIData.m_IOBearing.SetRawValue(m_IOBearing.GetRawValue());
            m_GUIData.m_IOElevation.SetRawValue(m_IOElevation.GetRawValue());
            m_GUIData.m_IOStadAngle.SetRawValue(m_IOStadAngle.GetRawValue());
            m_GUIData.m_IOTiBlackLevel.SetRawValue(m_IOTiBlackLevel.GetRawValue());
            m_GUIData.m_IOTiSensitivity.SetRawValue(m_IOTiSensitivity.GetRawValue());
            m_GUIData.m_IOTiGratIllum.SetRawValue(m_IOTiGratIllum.GetRawValue());

            m_GUIData.m_IORearStadAngle.SetRawValue(m_IORearStadAngle.GetRawValue());
            m_GUIData.m_IORearTrueBrg.SetRawValue(m_IORearTrueBrg.GetRawValue());
            m_GUIData.m_IORearRelBrg.SetRawValue(m_IORearRelBrg.GetRawValue());

            m_GUIData.m_IODisplayBrg.SetRawValue(m_IODisplayBrg.GetRawValue());
            m_GUIData.m_IODisplayElev.SetRawValue(m_IODisplayElev.GetRawValue());
            m_GUIData.m_IODisplayTar.SetRawValue(m_IODisplayTar.GetRawValue());
            m_GUIData.m_IOBeckmanTrue.SetRawValue(m_IOBeckmanTrue.GetRawValue());
            m_GUIData.m_IOBeckmanRel.SetRawValue(m_IOBeckmanRel.GetRawValue());

            m_GUIData.m_IOHandlesDown.SetRawValue(m_IOHandlesDown.GetRawValue());
            m_GUIData.m_IOHighMag.SetRawValue(m_IOHighMag.GetRawValue());
            m_GUIData.m_IORangeCut.SetRawValue(m_IORangeCut.GetRawValue());
            m_GUIData.m_IOBearingCut.SetRawValue(m_IOBearingCut.GetRawValue());
            m_GUIData.m_IOPushToTalk.SetRawValue(m_IOPushToTalk.GetRawValue());

            m_GUIData.m_IOModeSelect.SetRawValue(m_IOModeSelect.GetRawValue());
            m_GUIData.m_IODataOverlay.SetRawValue(m_IODataOverlay.GetRawValue());
            m_GUIData.m_IOTiOnIndicator.SetRawValue(m_IOTiOnIndicator.GetRawValue());
            m_GUIData.m_IOTarHeight.SetRawValue(m_IOTarHeight.GetRawValue());

            m_GUIData.m_IOBearing.SetStatus(m_IOBearing.GetStatus());
            m_GUIData.m_IOElevation.SetStatus(m_IOElevation.GetStatus());
            m_GUIData.m_IOStadAngle.SetStatus(m_IOStadAngle.GetStatus());
            m_GUIData.m_IOTiBlackLevel.SetStatus(m_IOTiBlackLevel.GetStatus());
            m_GUIData.m_IOTiSensitivity.SetStatus(m_IOTiSensitivity.GetStatus());
            m_GUIData.m_IOTiGratIllum.SetStatus(m_IOTiGratIllum.GetStatus());

            m_GUIData.m_IORearStadAngle.SetStatus(m_IORearStadAngle.GetStatus());
            m_GUIData.m_IORearTrueBrg.SetStatus(m_IORearTrueBrg.GetStatus());
            m_GUIData.m_IORearRelBrg.SetStatus(m_IORearRelBrg.GetStatus());

            m_GUIData.m_IODisplayBrg.SetStatus(m_IODisplayBrg.GetStatus());
            m_GUIData.m_IODisplayElev.SetStatus(m_IODisplayElev.GetStatus());
            m_GUIData.m_IODisplayTar.SetStatus(m_IODisplayTar.GetStatus());
            m_GUIData.m_IOBeckmanTrue.SetStatus(m_IOBeckmanTrue.GetStatus());
            m_GUIData.m_IOBeckmanRel.SetStatus(m_IOBeckmanRel.GetStatus());

            m_GUIData.m_IOHandlesDown.SetStatus(m_IOHandlesDown.GetStatus());
            m_GUIData.m_IOHighMag.SetStatus(m_IOHighMag.GetStatus());
            m_GUIData.m_IORangeCut.SetStatus(m_IORangeCut.GetStatus());
            m_GUIData.m_IOBearingCut.SetStatus(m_IOBearingCut.GetStatus());
            m_GUIData.m_IOPushToTalk.SetStatus(m_IOPushToTalk.GetStatus());

            m_GUIData.m_IOModeSelect.SetStatus(m_IOModeSelect.GetStatus());
            m_GUIData.m_IODataOverlay.SetStatus(m_IODataOverlay.GetStatus());
            m_GUIData.m_IOTiOnIndicator.SetStatus(m_IOTiOnIndicator.GetStatus());
            m_GUIData.m_IOTarHeight.SetStatus(m_IOTarHeight.GetStatus());


            //
            // Override data from GUI to SimControl
            //

            // PIG Data
            m_PIGExSystemID.SetOverride(m_GUIData.m_PIGExSystemID);
            m_PIGExRunMode.SetOverride(m_GUIData.m_PIGExRunMode);

            m_PIGEnvMoonOverride.SetOverride(m_GUIData.m_PIGEnvMoonOverride);
            m_PIGEnvCoastLights.SetOverride(m_GUIData.m_PIGEnvCoastLights);
            m_PIGEnvIceEdgeOn.SetOverride(m_GUIData.m_PIGEnvIceEdgeOn);
            m_PIGEnvSunOverride.SetOverride(m_GUIData.m_PIGEnvSunOverride);
            m_PIGEnvHours.SetOverride(m_GUIData.m_PIGEnvHours);
            m_PIGEnvMins.SetOverride(m_GUIData.m_PIGEnvMins);
            m_PIGEnvSecs.SetOverride(m_GUIData.m_PIGEnvSecs);
            m_PIGEnvDay.SetOverride(m_GUIData.m_PIGEnvDay);
            m_PIGEnvMonth.SetOverride(m_GUIData.m_PIGEnvMonth);
            m_PIGEnvYear.SetOverride(m_GUIData.m_PIGEnvYear);
            m_PIGEnvWeather.SetOverride(m_GUIData.m_PIGEnvWeather);
            m_PIGEnvCoastline.SetOverride(m_GUIData.m_PIGEnvCoastline);
            m_PIGEnvSeaState.SetOverride(m_GUIData.m_PIGEnvSeaState);
            m_PIGEnvVisualRange.SetOverride(m_GUIData.m_PIGEnvVisualRange);
            m_PIGEnvThermalRange.SetOverride(m_GUIData.m_PIGEnvThermalRange);
            m_PIGEnvUnderWaterRange.SetOverride(m_GUIData.m_PIGEnvUnderWaterRange);
            m_PIGEnvWindSpeed.SetOverride(m_GUIData.m_PIGEnvWindSpeed);
            m_PIGEnvWindDirn.SetOverride(m_GUIData.m_PIGEnvWindDirn);
            m_PIGEnvMoonBrgOverRide.SetOverride(m_GUIData.m_PIGEnvMoonBrgOverRide);
            m_PIGEnvMoonElevOverRide.SetOverride(m_GUIData.m_PIGEnvMoonElevOverRide);
            m_PIGEnvSunBrgOverRide.SetOverride(m_GUIData.m_PIGEnvSunBrgOverRide);
            m_PIGEnvSunElevOverRide.SetOverride(m_GUIData.m_PIGEnvSunElevOverRide);
            m_PIGEnvIceEdgeLat.SetOverride(m_GUIData.m_PIGEnvIceEdgeLat);
            m_PIGEnvIceEdgeLon.SetOverride(m_GUIData.m_PIGEnvIceEdgeLon);
            m_PIGEnvIceEdgeOrien.SetOverride(m_GUIData.m_PIGEnvIceEdgeOrien);

            m_PIGOwnType.SetOverride(m_GUIData.m_PIGOwnType);
            m_PIGOwnSmoke.SetOverride(m_GUIData.m_PIGOwnSmoke);
            m_PIGOwnLatitude.SetOverride(m_GUIData.m_PIGOwnLatitude);
            m_PIGOwnLongitude.SetOverride(m_GUIData.m_PIGOwnLongitude);
            m_PIGOwnX.SetOverride(m_GUIData.m_PIGOwnX);
            m_PIGOwnY.SetOverride(m_GUIData.m_PIGOwnY);
            m_PIGOwnDepth.SetOverride(m_GUIData.m_PIGOwnDepth);
            m_PIGOwnHeading.SetOverride(m_GUIData.m_PIGOwnHeading);
            m_PIGOwnRoll.SetOverride(m_GUIData.m_PIGOwnRoll);
            m_PIGOwnPitch.SetOverride(m_GUIData.m_PIGOwnPitch);
            m_PIGOwnSpeed.SetOverride(m_GUIData.m_PIGOwnSpeed);

            for (i = 0; i < 10; i++)
                m_PIGOwnMast[i].SetOverride(m_GUIData.m_PIGOwnMast[i]);

            m_PIGPeriSensor.SetOverride(m_GUIData.m_PIGPeriSensor);
            m_PIGPeriMagnification.SetOverride(m_GUIData.m_PIGPeriMagnification);
            m_PIGPeriGain.SetOverride(m_GUIData.m_PIGPeriGain);
            m_PIGPeriContrast.SetOverride(m_GUIData.m_PIGPeriContrast);
            m_PIGPeriGratIntensity.SetOverride(m_GUIData.m_PIGPeriGratIntensity);
            m_PIGPeriDraindown.SetOverride(m_GUIData.m_PIGPeriDraindown);
            m_PIGPeriRelBrg.SetOverride(m_GUIData.m_PIGPeriRelBrg);
            m_PIGPeriElevation.SetOverride(m_GUIData.m_PIGPeriElevation);
            m_PIGPeriStadAngle.SetOverride(m_GUIData.m_PIGPeriStadAngle);

            for (i = 0; i < NUM_PERI_TARGETS; i++)
            {
                m_PIGTargets[i].m_PIGTarPresent.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarPresent);
                m_PIGTargets[i].m_PIGTarNavLights.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarNavLights);
                m_PIGTargets[i].m_PIGTarMissileHit.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarMissileHit);
                m_PIGTargets[i].m_PIGTarTorpedoHit.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarTorpedoHit);
                m_PIGTargets[i].m_PIGTarSinking.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarSinking);
                m_PIGTargets[i].m_PIGTarDunkingSonar.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarDunkingSonar);
                m_PIGTargets[i].m_PIGTarTLAM.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarTLAM);
                m_PIGTargets[i].m_PIGTarFlames.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarFlames);
                m_PIGTargets[i].m_PIGTarDieselSmoke.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarDieselSmoke);
                m_PIGTargets[i].m_PIGTarFireMissile.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarFireMissile);

                m_PIGTargets[i].m_PIGTarModelID.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarModelID);
                m_PIGTargets[i].m_PIGTarSlotNum.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarSlotNum);
                m_PIGTargets[i].m_PIGTarLightConfig.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarLightConfig);
                m_PIGTargets[i].m_PIGTarSpotConfig.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarSpotConfig);

                m_PIGTargets[i].m_PIGTarX.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarX);
                m_PIGTargets[i].m_PIGTarY.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarY);
                m_PIGTargets[i].m_PIGTarHeight.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarHeight);
                m_PIGTargets[i].m_PIGTarHeading.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarHeading);
                m_PIGTargets[i].m_PIGTarRoll.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarRoll);
                m_PIGTargets[i].m_PIGTarPitch.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarPitch);
                m_PIGTargets[i].m_PIGTarSpeed.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarSpeed);
                m_PIGTargets[i].m_PIGTarAccel.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarAccel);
                m_PIGTargets[i].m_PIGTarHitPoint.SetOverride(m_GUIData.m_PIGTargets[i].m_PIGTarHitPoint);
            }

            m_PIGRetProcStat.SetOverride(m_GUIData.m_PIGRetProcStat);
            m_PIGRetModelStat.SetOverride(m_GUIData.m_PIGRetModelStat);
            m_PIGRetPolyniaNum.SetOverride(m_GUIData.m_PIGRetPolyniaNum);

            for (i = 0; i < NUM_POLYNIA_TARGETS; i++)
            {
                m_PIGRetPolynia[i].m_PIGRetPolIdentity.SetOverride(m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolIdentity);
                m_PIGRetPolynia[i].m_PIGRetPolX.SetOverride(m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolX);
                m_PIGRetPolynia[i].m_PIGRetPolY.SetOverride(m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolY);
                m_PIGRetPolynia[i].m_PIGRetPolZ.SetOverride(m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolZ);
                m_PIGRetPolynia[i].m_PIGRetPolOrien.SetOverride(m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolOrien);
                m_PIGRetPolynia[i].m_PIGRetPolSlotNum.SetOverride(m_GUIData.m_PIGRetPolynia[i].m_PIGRetPolSlotNum);
            }

            // PIP Data
            m_PIPExRunMode.SetOverride(m_GUIData.m_PIPExRunMode);
            m_PIPExHours.SetOverride(m_GUIData.m_PIPExHours);
            m_PIPExMins.SetOverride(m_GUIData.m_PIPExMins);
            m_PIPExSecs.SetOverride(m_GUIData.m_PIPExSecs);
            m_PIPExDay.SetOverride(m_GUIData.m_PIPExDay);
            m_PIPExMonth.SetOverride(m_GUIData.m_PIPExMonth);
            m_PIPExYear.SetOverride(m_GUIData.m_PIPExYear);

            m_PIPPeriInstructCtrl.SetOverride(m_GUIData.m_PIPPeriInstructCtrl);
            m_PIPPeriSearchUp.SetOverride(m_GUIData.m_PIPPeriSearchUp);
            m_PIPPeriPolarityWhite.SetOverride(m_GUIData.m_PIPPeriPolarityWhite);
            m_PIPPeriHighMag.SetOverride(m_GUIData.m_PIPPeriHighMag);
            m_PIPPeriDraindown.SetOverride(m_GUIData.m_PIPPeriDraindown);
            m_PIPPeriLLTVGain.SetOverride(m_GUIData.m_PIPPeriLLTVGain);
            m_PIPPeriThermalGain.SetOverride(m_GUIData.m_PIPPeriThermalGain);
            m_PIPPeriRelBearing.SetOverride(m_GUIData.m_PIPPeriRelBearing);
            m_PIPPeriElevation.SetOverride(m_GUIData.m_PIPPeriElevation);

            m_PIPEnvMoonOverride.SetOverride(m_GUIData.m_PIPEnvMoonOverride);
            m_PIPEnvCoastLights.SetOverride(m_GUIData.m_PIPEnvCoastLights);
            m_PIPEnvIceEdgeOn.SetOverride(m_GUIData.m_PIPEnvIceEdgeOn);
            m_PIPEnvSunOverride.SetOverride(m_GUIData.m_PIPEnvSunOverride);
            m_PIPEnvWeather.SetOverride(m_GUIData.m_PIPEnvWeather);
            m_PIPEnvCoastline.SetOverride(m_GUIData.m_PIPEnvCoastline);
            m_PIPEnvSeaState.SetOverride(m_GUIData.m_PIPEnvSeaState);
            m_PIPEnvMoonBrg.SetOverride(m_GUIData.m_PIPEnvMoonBrg);
            m_PIPEnvMoonElev.SetOverride(m_GUIData.m_PIPEnvMoonElev);
            m_PIPEnvVisualRange.SetOverride(m_GUIData.m_PIPEnvVisualRange);
            m_PIPEnvUnderWaterRange.SetOverride(m_GUIData.m_PIPEnvUnderWaterRange);
            m_PIPEnvThermalRange.SetOverride(m_GUIData.m_PIPEnvThermalRange);
            m_PIPEnvWindSpeed.SetOverride(m_GUIData.m_PIPEnvWindSpeed);
            m_PIPEnvWindHeading.SetOverride(m_GUIData.m_PIPEnvWindHeading);
            m_PIPEnvIceLat.SetOverride(m_GUIData.m_PIPEnvIceLat);
            m_PIPEnvIceLon.SetOverride(m_GUIData.m_PIPEnvIceLon);
            m_PIPEnvIceOrien.SetOverride(m_GUIData.m_PIPEnvIceOrien);
            m_PIPEnvSunBrg.SetOverride(m_GUIData.m_PIPEnvSunBrg);
            m_PIPEnvSunElev.SetOverride(m_GUIData.m_PIPEnvSunElev);

            m_PIPOwnLat.SetOverride(m_GUIData.m_PIPOwnLat);
            m_PIPOwnLon.SetOverride(m_GUIData.m_PIPOwnLon);
            m_PIPOwnDepth.SetOverride(m_GUIData.m_PIPOwnDepth);
            m_PIPOwnClimbRate.SetOverride(m_GUIData.m_PIPOwnClimbRate);
            m_PIPOwnTurnRate.SetOverride(m_GUIData.m_PIPOwnTurnRate);
            m_PIPOwnPitch.SetOverride(m_GUIData.m_PIPOwnPitch);
            m_PIPOwnHeading.SetOverride(m_GUIData.m_PIPOwnHeading);
            m_PIPOwnDriftCourse.SetOverride(m_GUIData.m_PIPOwnDriftCourse);
            m_PIPOwnSpeed.SetOverride(m_GUIData.m_PIPOwnSpeed);
            m_PIPOwnDriftSpeed.SetOverride(m_GUIData.m_PIPOwnDriftSpeed);
            m_PIPOwnWhipAerialUp.SetOverride(m_GUIData.m_PIPOwnWhipAerialUp);
            m_PIPOwnEmerLightUp.SetOverride(m_GUIData.m_PIPOwnEmerLightUp);
            m_PIPOwnDieselSmoke.SetOverride(m_GUIData.m_PIPOwnDieselSmoke);
            m_PIPOwnMastRESM.SetOverride(m_GUIData.m_PIPOwnMastRESM);
            m_PIPOwnMastWTComms.SetOverride(m_GUIData.m_PIPOwnMastWTComms);
            m_PIPOwnMastHFDF.SetOverride(m_GUIData.m_PIPOwnMastHFDF);
            m_PIPOwnMastAttack.SetOverride(m_GUIData.m_PIPOwnMastAttack);
            m_PIPOwnMastRadar.SetOverride(m_GUIData.m_PIPOwnMastRadar);
            m_PIPOwnMastSnortInd.SetOverride(m_GUIData.m_PIPOwnMastSnortInd);
            m_PIPOwnMastSnortExh.SetOverride(m_GUIData.m_PIPOwnMastSnortExh);
            m_PIPOwnType.SetOverride(m_GUIData.m_PIPOwnType);

            for (i = 0; i < NUM_PERI_TARGETS; i++)
            {
                m_PIPTargets[i].m_PIPTarPresent.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarPresent);

                m_PIPTargets[i].m_PIPTarFlames.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarFlames);
                m_PIPTargets[i].m_PIPTarMissileHit.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarMissileHit);
                m_PIPTargets[i].m_PIPTarTorpedoHit.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarTorpedoHit);
                m_PIPTargets[i].m_PIPTarSinking.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarSinking);
                m_PIPTargets[i].m_PIPTarNavLights.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarNavLights);
                m_PIPTargets[i].m_PIPTarDunkingSonar.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarDunkingSonar);
                m_PIPTargets[i].m_PIPTarTLAMFaulty.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarTLAMFaulty);
                m_PIPTargets[i].m_PIPTarFireMissile.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarFireMissile);
                m_PIPTargets[i].m_PIPTarDunkingData.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarDunkingData);
                m_PIPTargets[i].m_PIPTarLightConfig.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarLightConfig);
                m_PIPTargets[i].m_PIPTarSpotConfig.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarSpotConfig);
                m_PIPTargets[i].m_PIPTarModelID.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarModelID);
                m_PIPTargets[i].m_PIPTarSlotID.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarSlotID);
                m_PIPTargets[i].m_PIPTarX.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarX);
                m_PIPTargets[i].m_PIPTarY.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarY);
                m_PIPTargets[i].m_PIPTarHeight.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarHeight);
                m_PIPTargets[i].m_PIPTarClimbRate.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarClimbRate);
                m_PIPTargets[i].m_PIPTarTurnRate.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarTurnRate);
                m_PIPTargets[i].m_PIPTarPitch.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarPitch);
                m_PIPTargets[i].m_PIPTarHeading.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarHeading);
                m_PIPTargets[i].m_PIPTarDriftCourse.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarDriftCourse);
                m_PIPTargets[i].m_PIPTarSpeed.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarSpeed);
                m_PIPTargets[i].m_PIPTarDriftSpeed.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarDriftSpeed);
                m_PIPTargets[i].m_PIPTarDieselSmoke.SetOverride(m_GUIData.m_PIPTargets[i].m_PIPTarDieselSmoke);
            }

            m_PIPRetSearchUp.SetOverride(m_GUIData.m_PIPRetSearchUp);
            m_PIPRetPolarityWhite.SetOverride(m_GUIData.m_PIPRetPolarityWhite);
            m_PIPRetHighMag.SetOverride(m_GUIData.m_PIPRetHighMag);
            m_PIPRetHandlesUp.SetOverride(m_GUIData.m_PIPRetHandlesUp);

            m_PIPRetPeriLLTVGain.SetOverride(m_GUIData.m_PIPRetPeriLLTVGain);
            m_PIPRetPeriTIGain.SetOverride(m_GUIData.m_PIPRetPeriTIGain);

            m_PIPRetTWSHPeriTrueBrg.SetOverride(m_GUIData.m_PIPRetTWSHPeriTrueBrg);
            m_PIPRetTWSHTarTrueBrg.SetOverride(m_GUIData.m_PIPRetTWSHTarTrueBrg);
            m_PIPRetTWSHTarRange.SetOverride(m_GUIData.m_PIPRetTWSHTarRange);
            m_PIPRetTWSHTarElpsdTime.SetOverride(m_GUIData.m_PIPRetTWSHTarElpsdTime);
            m_PIPRetTWSHTarTrueBrgCut.SetOverride(m_GUIData.m_PIPRetTWSHTarTrueBrgCut);
            m_PIPRetTWSHTarRangeCut.SetOverride(m_GUIData.m_PIPRetTWSHTarRangeCut);
            m_PIPRetTWSHTarElpsdTimeCut.SetOverride(m_GUIData.m_PIPRetTWSHTarElpsdTimeCut);

            m_PIPRetPeriRelBrg.SetOverride(m_GUIData.m_PIPRetPeriRelBrg);
            m_PIPRetPeriElev.SetOverride(m_GUIData.m_PIPRetPeriElev);
            m_PIPRetPeriSunBrg.SetOverride(m_GUIData.m_PIPRetPeriSunBrg);
            m_PIPRetPeriSunElev.SetOverride(m_GUIData.m_PIPRetPeriSunElev);
            m_PIPRetPeriErrorNo.SetOverride(m_GUIData.m_PIPRetPeriErrorNo);
            m_PIPRetPeriErrorString.SetOverride(m_GUIData.m_PIPRetPeriErrorString);
            m_PIPRetNumPolynia.SetOverride(m_GUIData.m_PIPRetNumPolynia);

            for (i = 0; i < NUM_POLYNIA_TARGETS; i++)
            {
                m_PIPRetPolynia[i].m_PIPRetPolIdentity.SetOverride(m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolIdentity);
                m_PIPRetPolynia[i].m_PIPRetPolPresent.SetOverride(m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolPresent);
                m_PIPRetPolynia[i].m_PIPRetPolX.SetOverride(m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolX);
                m_PIPRetPolynia[i].m_PIPRetPolY.SetOverride(m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolY);
                m_PIPRetPolynia[i].m_PIPRetPolZ.SetOverride(m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolZ);
                m_PIPRetPolynia[i].m_PIPRetPolOrientation.SetOverride(m_GUIData.m_PIPRetPolynia[i].m_PIPRetPolOrientation);
            }

            // IO Data
            m_IOBearing.SetOverride(m_GUIData.m_IOBearing);
            m_IOElevation.SetOverride(m_GUIData.m_IOElevation);
            m_IOStadAngle.SetOverride(m_GUIData.m_IOStadAngle);
            m_IOTiBlackLevel.SetOverride(m_GUIData.m_IOTiBlackLevel);
            m_IOTiSensitivity.SetOverride(m_GUIData.m_IOTiSensitivity);
            m_IOTiGratIllum.SetOverride(m_GUIData.m_IOTiGratIllum);

            m_IORearStadAngle.SetOverride(m_GUIData.m_IORearStadAngle);
            m_IORearTrueBrg.SetOverride(m_GUIData.m_IORearTrueBrg);
            m_IORearRelBrg.SetOverride(m_GUIData.m_IORearRelBrg);

            m_IODisplayBrg.SetOverride(m_GUIData.m_IODisplayBrg);
            m_IODisplayElev.SetOverride(m_GUIData.m_IODisplayElev);
            m_IODisplayTar.SetOverride(m_GUIData.m_IODisplayTar);
            m_IOBeckmanTrue.SetOverride(m_GUIData.m_IOBeckmanTrue);
            m_IOBeckmanRel.SetOverride(m_GUIData.m_IOBeckmanRel);

            m_IOHandlesDown.SetOverride(m_GUIData.m_IOHandlesDown);
            m_IOHighMag.SetOverride(m_GUIData.m_IOHighMag);
            m_IORangeCut.SetOverride(m_GUIData.m_IORangeCut);
            m_IOBearingCut.SetOverride(m_GUIData.m_IOBearingCut);
            m_IOPushToTalk.SetOverride(m_GUIData.m_IOPushToTalk);

            m_IOModeSelect.SetOverride(m_GUIData.m_IOModeSelect);
            m_IODataOverlay.SetOverride(m_GUIData.m_IODataOverlay);
            m_IOTiOnIndicator.SetOverride(m_GUIData.m_IOTiOnIndicator);
            m_IOTarHeight.SetOverride(m_GUIData.m_IOTarHeight);


            //
            // System data
            //
            m_SIMRunApp = m_GUIData.m_SIMRunApp;
            m_SIMEmulatingPIP = m_GUIData.m_SIMEmulatingPIP;
            m_SIMEmulatingPIG = m_GUIData.m_SIMEmulatingPIG;
            m_SIMEmulatingIO = m_GUIData.m_SIMEmulatingIO;
            m_GUIData.m_SIMStatusIO = m_SIMStatusIO;


            // If Emulating PIP and time for update set the SimControl
            // data flags
            if ((m_SIMEmulatingPIP) && (m_GUIData.m_SIMPIPUpdate))
            {
                m_SIMNewExData = true;
                m_SIMNewEnvData = true;
                m_SIMNewOwnData = true;
                m_SIMNewPeriData = true;
                m_SIMNewTarData = true;

                // Reset update flag
                m_GUIData.m_SIMPIPUpdate = false;
            }

            //
            // Network data
            //
            m_GUIData.m_PIPBytesIn = m_PIPBytesIn;
            m_GUIData.m_PIPBytesOut = m_PIPBytesOut;
            m_GUIData.m_PIPMessageCountIn = m_PIPMessageCountIn;
            m_GUIData.m_PIPMessageCountOut = m_PIPMessageCountOut;
            m_GUIData.m_PIPAverageTimeIn = m_PIPAverageTimeIn;
            m_GUIData.m_PIPAverageTimeOut = m_PIPAverageTimeOut;

            m_GUIData.m_PIGBytesIn = m_PIGBytesIn;
            m_GUIData.m_PIGBytesOut = m_PIGBytesOut;
            m_GUIData.m_PIGMessageCountIn = m_PIGMessageCountIn;
            m_GUIData.m_PIGMessageCountOut = m_PIGMessageCountOut;
            m_GUIData.m_PIGAverageTimeIn = m_PIGAverageTimeIn;
            m_GUIData.m_PIGAverageTimeOut = m_PIGAverageTimeOut;
            //
            // Model Names (only need to do once)
            //
            if (m_GUIData.m_ModelNamesSet == false)
            {
                for (i = 0; i < 1000; i++)
                {
                    m_GUIData.m_ModelNames[i] = m_Models[i].m_Name;
                }

                m_GUIData.m_ModelNamesSet = true;
            }


            //
            // Error Log
            //
            m_GUIData.m_SIMErrorLogIndex = m_SIMErrorLogIndex;
            m_SIMErrorLogClear = m_GUIData.m_SIMErrorLogClear;

            for ( i = 0; i < SIM_ERRORLOG_SIZE; i++)
            {
                m_GUIData.m_SIMErrorLog[i] = m_SIMErrorLog[i];
            }


            //
            // Measure the time to update
            //
            if (measureTime)
            {
                QueryPerformanceCounter(out timeStamp2);

                long delta = (timeStamp2 - timeStamp1);
                double deltaTime = ((double)delta / (double)(m_TimerFreq));
                Console.WriteLine("SimControl: Time to update GUI data (ms): {0}", deltaTime*1000.0);
            }


            //
            // Release the mutex
            //
            mutexData.ReleaseMutex();
        }



        // --------------------
        // Write to Error Log
        // --------------------
        public void WriteToErrorLog(string type, string source)
        {

            int i;

            //
            // Check the data provided
            //
            if ((type.Equals("")) || (source.Equals("")))
            {
                // Data provided is invalid so ignore
                return;
            }
            else if ((type.Equals("CLEAR")) && (source.Equals("CLEAR")))
            {
                // Error log is to be cleared
                for (i = 0; i < SIM_ERRORLOG_SIZE; i++)
                {
                    m_SIMErrorLog[i].m_ErrorTime = "";
                    m_SIMErrorLog[i].m_ErrorType = "";
                    m_SIMErrorLog[i].m_ErrorSource = "";

                    m_SIMErrorLogIndex = 0;
                }

                return;
            }

            //
            // Write to the log
            //
            m_SIMErrorLog[m_SIMErrorLogIndex].m_ErrorTime = DateTime.Now.ToLongTimeString();
            m_SIMErrorLog[m_SIMErrorLogIndex].m_ErrorType = type;
            m_SIMErrorLog[m_SIMErrorLogIndex].m_ErrorSource = source;

            //
            // Update the log index and restart if >max
            //
            m_SIMErrorLogIndex++;

            if (m_SIMErrorLogIndex > (SIM_ERRORLOG_SIZE - 1))
                m_SIMErrorLogIndex = 0;

        }



        // -------------------------------
        // Declaration of SIMControl Data
        // -------------------------------
        public const double DEGS_TO_RADS  = 0.017453292;
        public const double RADS_TO_DEGS  = 57.295781;

        public const double RADIUS_EARTH = 6366707.0;

        public const double MTRS_TO_YDS = 1.0936;
        public const double MTRS_TO_FT = 3.2808;

        public const double FT_TO_MTRS    = 0.3048;
        public const double YDS_TO_MTRS   = 0.9144;
        public const double KTS_TO_MPS    = 0.514444;

        public const int SIM_FULL_FREEZE  = 0;
        public const int SIM_RUN          = 1;
        public const int SIM_TARGET_FREEZE   = 2;
        public const int SIM_FAST_RUN     = 3;
        public const int SIM_RESET        = 4;
        public const int SIM_STOP         = 5;

        public const int SIM_TARGET_NOT_PRESENT       = 0;
        public const int SIM_TARGET_PRESENT        = 1;
        public const int SIM_TARGET_SINKING        = 2;
        public const int SIM_TARGET_SUNK        = 3;
        public const int SIM_TARGET_BEING_REMOVED  = 4;

        public const int PIG_RUN    = 0;
        public const int PIG_STOP   = 1;
        public const int PIG_FREEZE    = 2;
        public const int PIG_RESET  = 3;

        public const int PIG_LOW_MAG_FOV  = 32;
        public const int PIG_HIGH_MAG_FOV    = 8;

        public const int SENSOR_OPTICAL      = 0;
        public const int SENSOR_WHIR      = 1;
        public const int SENSOR_BHIR      = 2;
        public const int SENSOR_LLTV      = 3;

        public const int SIM_OWN_SWIFTSURE   = 0;
        public const int SIM_OWN_TRAFALGAR   = 1;

        public const int PIP_OWN_SUBTEST  = 0;
        public const int PIP_OWN_SWIFTSURE   = 1;
        public const int PIP_OWN_TRAFALGAR   = 2;

        //     public const int PIG_OWN_SWIFTSURE  = 0;
        //     public const int PIG_OWN_TRAFALGAR  = 1;
        //     public const int PIG_OWN_VANGUARD   = 2;
        //     public const int PIG_OWN_ASTUTE     = 3;
        //     public const int PIG_OWN_VICTORIA   = 4;

        public const int SIM_ERRORLOG_SIZE   = 15;


        public const double OWN_SPEED_MIN    = 0.0;
        public const double OWN_SPEED_MAX    = 30.864;
        public const double OWN_X_MIN     = -100000.0;
        public const double OWN_X_MAX     = 100000.0;
        public const double OWN_Y_MIN     = -100000.0;
        public const double OWN_Y_MAX     = 100000.0;
        public const double OWN_Z_MIN     = -304.8;
        public const double OWN_Z_MAX     = 6096.1;
        public const double OWN_PITCH_MIN    = -90.0;
        public const double OWN_PITCH_MAX    = 90.0;

        public const double OWN_BIG_JUMP  = 0.000833333;
        public const double OWN_LAT_THRESH   = 89.999;
        public const double ICE_BIG_JUMP  = 0.0001;

        public const int PIG_NUMBER_TARGETS  = NUM_PERI_TARGETS;
        public const int SIM_NUMBER_TARGETS  = NUM_PERI_TARGETS;
        public const int SIM_MAX_MODELS = 1000;

        public const double TAR_ACCEL_MIN    = -10.0;
        public const double TAR_ACCEL_MAX    = 10.0;
        public const double TAR_DELTA_MIN    = -17.15;
        public const double TAR_DELTA_MAX    = 17.15;

        public const double TAR_SPEED_MIN    = 0.0;
        public const double TAR_SPEED_MAX    = 514.4;

        public const double TAR_X_MIN     = -100000.0;
        public const double TAR_X_MAX     = 100000.0;
        public const double TAR_Y_MIN     = -100000.0;
        public const double TAR_Y_MAX     = 100000.0;
        public const double TAR_Z_MIN     = -304.8;
        public const double TAR_Z_MAX     = 6096.1;
        public const double TAR_AIR_ROLL     = 0.6;
        public const double TAR_SEA_ROLL     = 0.13;
        public const double TAR_ROLL_MIN     = -90.0;
        public const double TAR_ROLL_MAX     = 90.0;
        public const double TAR_PITCH_MIN    = -90.0;
        public const double TAR_PITCH_MAX    = 90.0;
        public const double TAR_SINK_PERIOD  = 30.0;

        public const double TAR_CLOSE_PROXIMITY    = 1000.0;

        public const byte SECONDS_MIN  = 0;
        public const byte SECONDS_MAX  = 59;
        public const byte MINUTES_MIN  = 0;
        public const byte MINUTES_MAX  = 59;
        public const byte HOURS_MIN       = 0;
        public const byte HOURS_MAX       = 23;
        public const byte DAYS_MIN     = 1;
        public const byte DAYS_MAX     = 31;
        public const byte MONTHS_MIN   = 1;
        public const byte MONTHS_MAX   = 12;
        public const byte YEARS_MIN       = 0;
        public const byte YEARS_MAX       = 100;

        public const double BRG_MIN       = 0.0;
        public const double BRG_MAX       = 360.0;
        public const double ELEV_MIN   = -90.0;
        public const double ELEV_MAX   = 90.0;
        public const double PITCH_MIN  = -90.0;
        public const double PITCH_MAX  = 90.0;

        public const byte DRAINDOWN_MIN = 0;
        public const byte DRAINDOWN_MAX = 30;
        public const byte COASTLINE_MIN = 0;
        public const byte COASTLINE_MAX = 100;
        public const byte SEA_STATE_MIN = 0;
        public const byte SEA_STATE_MAX = 6;
        public const byte WEATHER_MIN = 0;
        public const byte WEATHER_MAX = 4;

        public const double VIS_RANGE_MIN = 9.1;
        public const double VIS_RANGE_MAX = 29261.0;
        public const double THERMAL_RANGE_MIN = 9.1;
        public const double THERMAL_RANGE_MAX = 29261.0;
        public const double UW_RANGE_MIN = 1.3;
        public const double UW_RANGE_MAX = 914.5;
        public const double WIND_SPEED_MIN = 0.0;
        public const double WIND_SPEED_MAX = 154.33;


        public const double LATITUDE_MIN = -90.0;
        public const double LATITUDE_MAX = 90.0;
        public const double LONGITUDE_MIN = -180.0;
        public const double LONGITUDE_MAX = 180.0;

        public const int MODEL_ID_MIN = 0;
        public const int MODEL_ID_MAX = 999;

        public const byte LIGHT_CONFIG_MAX = 8;
        public const byte SPOT_CONFIG_MAX = 2;
        public const byte SONAR_DEPTH_MAX = 26;

        public const double OWN_DEPTH_MIN = -304.8;
        public const double OWN_DEPTH_MAX = 6096.1;
        public const double OWN_DRIFT_MIN = 0.0;
        public const double OWN_DRIFT_MAX = 32.864;
        public const double OWN_TURN_MIN = -180.0;
        public const double OWN_TURN_MAX = 180.0;
        public const double OWN_CLIMB_MIN = -30.48;
        public const double OWN_CLIMB_MAX = 30.48;

        public const double TAR_CLIMB_MIN = -304.8;
        public const double TAR_CLIMB_MAX = 304.8;
        public const double TAR_DRIFT_MIN = 0.0;
        public const double TAR_DRIFT_MAX = 32.864;
        public const double TAR_HEIGHT_MIN = -304.8;
        public const double TAR_HEIGHT_MAX = 6096.1;
        public const double TAR_TURN_MIN = -180.0;
        public const double TAR_TURN_MAX = 180.0;

        public const double ICE_CELL_SIZE = 2000.0;
        public const double POLYNIA_X_MIN = -100000.0;
        public const double POLYNIA_X_MAX = 100000.0;
        public const double POLYNIA_Y_MIN = -100000.0;
        public const double POLYNIA_Y_MAX = 100000.0;
        public const double POLYNIA_Z_MIN = -304.8;
        public const double POLYNIA_Z_MAX = 6096.1;

        public const double ORIENTATION_MIN  = 0.0;
        public const double ORIENTATION_MAX  = 360.0;


        public bool m_SIMRunApp;
        public bool m_SIMEmulatingPIP;
        public bool m_SIMEmulatingPIG;
        public bool m_SIMEmulatingIO;


        public int m_AppIterationRate;
        public double m_IterationTime;
        public double m_DeltaTime;

        public PIGComms       m_PIGComms;
        public PIPComms       m_PIPComms;
        // public IOComms     m_IOComms;

        public C_gui       m_GUI;
        public Thread      m_GUIThread;

        public IPAddress   m_IPAddressPIPNet;
        public int         m_PortPIPNet;

        public IPAddress   m_IPAddressPIGNet;
        public int         m_PortPIGNet;

        public float       m_PIPRateIn;
        public double      m_PIPDeltaTime;
        public float       m_PIGRateIn;



        // Network status data
        public int      m_PIPBytesIn;
        public int      m_PIPBytesOut;
        public int      m_PIPMessageCountIn;
        public int      m_PIPMessageCountOut;
        public float    m_PIPAverageTimeIn;
        public float    m_PIPAverageTimeOut;
        public int      m_PIPArrayIndexIn;
        public int      m_PIPArrayIndexOut;
        public long[]   m_PIPArrayTimesIn;
        public long[]   m_PIPArrayTimesOut;

        public int      m_PIGBytesIn;
        public int      m_PIGBytesOut;
        public int      m_PIGMessageCountIn;
        public int      m_PIGMessageCountOut;
        public float    m_PIGAverageTimeIn;
        public float    m_PIGAverageTimeOut;
        public int      m_PIGArrayIndexIn;
        public int      m_PIGArrayIndexOut;
        public long[]   m_PIGArrayTimesIn;
        public long[]   m_PIGArrayTimesOut;

        private bool m_PrintTimings;
        public bool m_PrintTWSHBits;
        private long m_TimerFreq;

        public long m_SIMDelta;
        public long m_SIMTimeStamp1;
        public long m_SIMTimeStamp2;

        private long m_PIPDelta;
        private long m_PIPTimeStamp1;
        private long m_PIPTimeStamp2;

        private long m_PIGDelta;
        private long m_PIGTimeStamp1;
        private long m_PIGTimeStamp2;

        // private long m_IODelta;
        // private long m_IOTimeStamp1;
        // private long m_IOTimeStamp2;

        //     private long m_ACTS2DDelta;
        //     private long m_ACTS2DTimeStamp1;
        //     private long m_ACTS2DTimeStamp2;

        private String name = "Not Assigned";
        private String ipAddress = "Not Assigned";
        private String port = "Not Assigned";
        private String rateOut = "Not Assigned";
        private String swapBytes = "No";

        //
        // SIM data
        //
        public bool m_SIMNewExData;
        public bool m_SIMNewEnvData;
        public bool m_SIMNewOwnData;
        public bool m_SIMNewPeriData;
        public bool m_SIMNewTarData;

        public int   m_SIMPIPCheckSum;
        public int   m_SIMPIPLastMessage;

        private bool m_SIMOriginSet;
        private double m_SIMOriginLat;
        private double m_SIMOriginLon;

        private int m_SIMExRunMode;

        private double m_SIMEnvIceLat;
        private double m_SIMEnvIceLon;

        private int m_SIMOwnTypeMast;
        private double m_SIMOwnLat;
        private double m_SIMOwnLon;
        private double m_SIMOwnX;
        private double m_SIMOwnY;
        private double m_SIMOwnZ;
        private double m_SIMOwnHeading;
        private double m_SIMOwnPitch;
        private double m_SIMOwnRoll;
        private double m_SIMOwnSpeed;
        private double m_SIMOwnTurnRate;
        private double m_SIMOwnHorizon;
        private double m_SIMOwnXCorrection;
        private double m_SIMOwnYCorrection;

        private double m_SIMOwnDeltaLat;
        private double m_SIMOwnDeltaLon;
        private double m_SIMOwnDeltaSpeed;
        private double m_SIMOwnDeltaHeading;
        private double m_SIMOwnDeltaPitch;
        private double m_SIMOwnDeltaDriftX;
        private double m_SIMOwnDeltaDriftY;
        private double m_SIMOwnDeltaZ;
        private double m_SIMOwnDeltaClimb;

        private float[] m_SIMOwnMastHeight;
        private float[,] m_SIMOwnMastMaxExt;
        private float[,] m_SIMOwnMastSpeed;

        private double m_SIMPeriTrueHeading;
        private double m_SIMFOVLeft;
        private double m_SIMFOVRight;
        private double m_SIMFOVUpper;
        private double m_SIMFOVLower;
        private bool m_SIMLookingNorth;

        private bool m_SIMTarInitialised;

        public struct SIMTargetData
        {
            public int m_SIMTarStatus;
            public bool m_SIMTarPresent;
            public bool m_SIMTarNavLights;
            public bool m_SIMTarMissileHit;
            public bool m_SIMTarTorpedoHit;
            public bool m_SIMTarSinking;
            public bool m_SIMTarDunkingSonar;
            public bool m_SIMTarTLAM;
            public bool m_SIMTarFlames;
            public bool m_SIMTarDieselSmoke;
            public bool m_SIMTarFireMissile;

            public int m_SIMTarModelID;
            public int m_SIMTarSlotID;
            public int m_SIMTarSlotNum;
            public int m_SIMTarLightConfig;
            public int m_SIMTarSpotConfig;
            public int m_SIMTarHitPoint;

            public double m_SIMTarX;
            public double m_SIMTarY;
            public double m_SIMTarHeight;
            public double m_SIMTarHeading;
            public double m_SIMTarRoll;
            public double m_SIMTarPitch;
            public double m_SIMTarSpeed;
            public double m_SIMTarAccel;
            public double m_SIMTarAccelVert;

            public double m_SIMTarClimbRate;
            public double m_SIMTarTurnRate;
            public double m_SIMTarDriftCourse;
            public double m_SIMTarDriftSpeed;

            public double m_SIMTarDeltaSpd;
            public double m_SIMTarDeltaHdg;
            public double m_SIMTarDeltaX;
            public double m_SIMTarDeltaY;
            public double m_SIMTarDeltaZ;
            public double m_SIMTarDeltaPtch;
            public double m_SIMTarDeltaTurn;
            public bool m_SIMTarAboveSea;
            public double m_SIMTarHorizonDist;
            public double m_SIMTarRangeHorizontal;
            public double m_SIMTarRangeTrue;
            public double m_SIMTarBrgFromOwnboat;
            public double m_SIMTarElevFromOwnboat;
            public double m_SIMTarAngleHor;
            public double m_SIMTarAngleVert;

            public bool m_SIMTarSinkInitialised;
            public double m_SIMTarSinkTime;

            public bool m_SIMTarPIGDisplay;
            public bool m_SIMTarPIGSelected;
            public int m_SIMTarPIGSlotNum;

        }

        public static SIMTargetData[]  m_SIMTargets;

        private bool m_rangeCutSend;
        private bool m_bearingCutSend;

        private int m_SIMStatusIO;
        public double m_SIMElevationMin;
        public double m_SIMElevationMax;
        public bool m_ThermalControls;



        //
        // PIG Data Items
        //
        public DataItemInt m_PIGExSystemID;
        public DataItemInt m_PIGExRunMode;

        public DataItemBool m_PIGEnvMoonOverride;
        public DataItemBool m_PIGEnvCoastLights;
        public DataItemBool m_PIGEnvIceEdgeOn;
        public DataItemBool m_PIGEnvSunOverride;
        public DataItemByte m_PIGEnvHours;
        public DataItemByte m_PIGEnvMins;
        public DataItemByte m_PIGEnvSecs;
        public DataItemByte m_PIGEnvDay;
        public DataItemByte m_PIGEnvMonth;
        public DataItemByte m_PIGEnvYear;
        public DataItemByte m_PIGEnvWeather;
        public DataItemByte m_PIGEnvCoastline;
        public DataItemByte m_PIGEnvSeaState;
        public DataItemFloat m_PIGEnvVisualRange;
        public DataItemFloat m_PIGEnvThermalRange;
        public DataItemFloat m_PIGEnvUnderWaterRange;
        public DataItemFloat m_PIGEnvWindSpeed;
        public DataItemFloat m_PIGEnvWindDirn;
        public DataItemFloat m_PIGEnvMoonBrgOverRide;
        public DataItemFloat m_PIGEnvMoonElevOverRide;
        public DataItemFloat m_PIGEnvSunBrgOverRide;
        public DataItemFloat m_PIGEnvSunElevOverRide;
        public DataItemFloat m_PIGEnvIceEdgeLat;
        public DataItemFloat m_PIGEnvIceEdgeLon;
        public DataItemFloat m_PIGEnvIceEdgeOrien;

        public DataItemByte m_PIGOwnType;
        public DataItemByte m_PIGOwnSmoke;
        public DataItemFloat m_PIGOwnLatitude;
        public DataItemFloat m_PIGOwnLongitude;
        public DataItemFloat m_PIGOwnX;
        public DataItemFloat m_PIGOwnY;
        public DataItemFloat m_PIGOwnDepth;
        public DataItemFloat m_PIGOwnHeading;
        public DataItemFloat m_PIGOwnRoll;
        public DataItemFloat m_PIGOwnPitch;
        public DataItemFloat m_PIGOwnSpeed;
        public DataItemFloat[] m_PIGOwnMast;

        public DataItemByte m_PIGPeriSensor;
        public DataItemByte m_PIGPeriMagnification;
        public DataItemByte m_PIGPeriGain;
        public DataItemByte m_PIGPeriContrast;
        public DataItemByte m_PIGPeriGratIntensity;
        public DataItemByte m_PIGPeriDraindown;
        public DataItemFloat m_PIGPeriRelBrg;
        public DataItemFloat m_PIGPeriElevation;
        public DataItemFloat m_PIGPeriStadAngle;

        public struct PIGTargetData
        {
            public DataItemBool m_PIGTarPresent;
            public DataItemBool m_PIGTarNavLights;
            public DataItemBool m_PIGTarMissileHit;
            public DataItemBool m_PIGTarTorpedoHit;
            public DataItemBool m_PIGTarSinking;
            public DataItemBool m_PIGTarDunkingSonar;
            public DataItemBool m_PIGTarTLAM;
            public DataItemBool m_PIGTarFlames;
            public DataItemBool m_PIGTarDieselSmoke;
            public DataItemBool m_PIGTarFireMissile;

            public DataItemShort m_PIGTarModelID;
            public DataItemShort m_PIGTarSlotNum;
            public DataItemByte m_PIGTarLightConfig;
            public DataItemByte m_PIGTarSpotConfig;

            public DataItemFloat m_PIGTarX;
            public DataItemFloat m_PIGTarY;
            public DataItemFloat m_PIGTarHeight;
            public DataItemFloat m_PIGTarHeading;
            public DataItemFloat m_PIGTarRoll;
            public DataItemFloat m_PIGTarPitch;
            public DataItemFloat m_PIGTarSpeed;
            public DataItemFloat m_PIGTarAccel;

            public DataItemInt m_PIGTarHitPoint;

            public bool m_PIGTarActive;

        }

        public PIGTargetData [] m_PIGTargets;

        public DataItemLong m_PIGRetProcStat;
        public DataItemLong m_PIGRetModelStat;
        public DataItemLong m_PIGRetPolyniaNum;

        public struct PIGRetPolyniaData
        {
            public DataItemLong m_PIGRetPolIdentity;
            public DataItemFloat m_PIGRetPolX;
            public DataItemFloat m_PIGRetPolY;
            public DataItemFloat m_PIGRetPolZ;
            public DataItemFloat m_PIGRetPolOrien;
            public DataItemLong m_PIGRetPolSlotNum;
        }

        public PIGRetPolyniaData [] m_PIGRetPolynia;


        //
        // PIP Data Items
        //
        public DataItemByte m_PIPExRunMode;
        public DataItemByte m_PIPExHours;
        public DataItemByte m_PIPExMins;
        public DataItemByte m_PIPExSecs;
        public DataItemByte m_PIPExDay;
        public DataItemByte m_PIPExMonth;
        public DataItemByte m_PIPExYear;

        public DataItemBool m_PIPPeriInstructCtrl;
        public DataItemBool m_PIPPeriSearchUp;
        public DataItemBool m_PIPPeriPolarityWhite;
        public DataItemBool m_PIPPeriHighMag;
        public DataItemByte m_PIPPeriDraindown;
        public DataItemByte m_PIPPeriLLTVGain;
        public DataItemByte m_PIPPeriThermalGain;
        public DataItemFloat m_PIPPeriRelBearing;
        public DataItemFloat m_PIPPeriElevation;

        public DataItemBool m_PIPEnvMoonOverride;
        public DataItemBool m_PIPEnvCoastLights;
        public DataItemBool m_PIPEnvIceEdgeOn;
        public DataItemBool m_PIPEnvSunOverride;
        public DataItemByte m_PIPEnvWeather;
        public DataItemByte m_PIPEnvCoastline;  //OpenSea/Clyde
        public DataItemByte m_PIPEnvSeaState;
        public DataItemFloat m_PIPEnvMoonBrg;
        public DataItemFloat m_PIPEnvMoonElev;
        public DataItemFloat m_PIPEnvVisualRange;
        public DataItemFloat m_PIPEnvUnderWaterRange;
        public DataItemFloat m_PIPEnvThermalRange;
        public DataItemFloat m_PIPEnvWindSpeed;
        public DataItemFloat m_PIPEnvWindHeading;
        public DataItemFloat m_PIPEnvIceLat;
        public DataItemFloat m_PIPEnvIceLon;
        public DataItemFloat m_PIPEnvIceOrien;
        public DataItemFloat m_PIPEnvSunBrg;
        public DataItemFloat m_PIPEnvSunElev;

        public DataItemDouble m_PIPOwnLat;
        public DataItemDouble m_PIPOwnLon;
        public double m_PIPOwnLatPro;
        public double m_PIPOwnLonPro;
        public DataItemFloat m_PIPOwnDepth;
        public double m_PIPOwnDepthPro;
        public DataItemFloat m_PIPOwnClimbRate;
        public DataItemFloat m_PIPOwnTurnRate;
        public DataItemFloat m_PIPOwnPitch;
        public double m_PIPOwnPitchPro;
        public DataItemFloat m_PIPOwnHeading;
        public double m_PIPOwnHeadingPro;
        public DataItemFloat m_PIPOwnDriftCourse;
        public DataItemFloat m_PIPOwnSpeed;
        public double m_PIPOwnSpeedPro;
        public DataItemFloat m_PIPOwnDriftSpeed;
        public DataItemBool m_PIPOwnWhipAerialUp;
        public DataItemBool m_PIPOwnEmerLightUp;
        public DataItemBool m_PIPOwnDieselSmoke;
        public DataItemByte m_PIPOwnMastRESM;
        public DataItemByte m_PIPOwnMastWTComms;
        public DataItemByte m_PIPOwnMastHFDF;
        public DataItemByte m_PIPOwnMastAttack;
        public DataItemByte m_PIPOwnMastRadar;
        public DataItemByte m_PIPOwnMastSnortInd;
        public DataItemByte m_PIPOwnMastSnortExh;
        public DataItemByte m_PIPOwnType;

        public struct PIPTargetData
        {
            public DataItemBool m_PIPTarPresent;
            public bool m_PIPTarPresentPro;
            public DataItemBool m_PIPTarFlames;
            public DataItemBool m_PIPTarMissileHit;
            public DataItemBool m_PIPTarTorpedoHit;
            public DataItemBool m_PIPTarSinking;
            public DataItemBool m_PIPTarNavLights;
            public DataItemBool m_PIPTarDunkingSonar;
            public DataItemBool m_PIPTarTLAMFaulty;
            public DataItemBool m_PIPTarFireMissile;
            public DataItemByte m_PIPTarDunkingData;
            public byte m_PIPTarDunkingDataPro;
            public DataItemByte m_PIPTarLightConfig;
            public byte m_PIPTarLightConfigPro;
            public DataItemByte m_PIPTarSpotConfig;
            public byte m_PIPTarSpotConfigPro;
            public DataItemInt m_PIPTarModelID;
            public int m_PIPTarModelIDPro;
            public DataItemInt m_PIPTarSlotID;
            public int m_PIPTarSlotIDPro;
            public DataItemFloat m_PIPTarX;
            public double m_PIPTarXPro;
            public DataItemFloat m_PIPTarY;
            public double m_PIPTarYPro;
            public DataItemFloat m_PIPTarHeight;
            public double m_PIPTarHeightPro;
            public DataItemFloat m_PIPTarClimbRate;
            public double m_PIPTarClimbRatePro;
            public DataItemFloat m_PIPTarTurnRate;
            public double m_PIPTarTurnRatePro;
            public DataItemFloat m_PIPTarPitch;
            public double m_PIPTarPitchPro;
            public DataItemFloat m_PIPTarHeading;
            public double m_PIPTarHeadingPro;
            public DataItemFloat m_PIPTarDriftCourse;
            public double m_PIPTarDriftCoursePro;
            public DataItemFloat m_PIPTarSpeed;
            public double m_PIPTarSpeedPro;
            public DataItemFloat m_PIPTarDriftSpeed;
            public double m_PIPTarDriftSpeedPro;
            public DataItemBool m_PIPTarDieselSmoke;
        }

        public PIPTargetData [] m_PIPTargets;

        public DataItemInt m_PIPCheckSum;


        // PIP Return Data
        public DataItemBool m_PIPRetSearchUp;
        public DataItemBool m_PIPRetPolarityWhite;
        public DataItemBool m_PIPRetHighMag;
        public DataItemBool m_PIPRetHandlesUp;
        public DataItemByte m_PIPRetPeriLLTVGain;
        public DataItemByte m_PIPRetPeriTIGain;
        public DataItemFloat m_PIPRetTWSHPeriTrueBrg;
        public DataItemFloat m_PIPRetTWSHTarTrueBrg;
        public DataItemFloat m_PIPRetTWSHTarRange;
        public DataItemFloat m_PIPRetTWSHTarElpsdTime;
        public DataItemBool m_PIPRetTWSHTarTrueBrgCut;
        public DataItemBool m_PIPRetTWSHTarRangeCut;
        public DataItemBool m_PIPRetTWSHTarElpsdTimeCut;
        public DataItemFloat m_PIPRetPeriRelBrg;
        public DataItemFloat m_PIPRetPeriElev;
        public DataItemFloat m_PIPRetPeriSunBrg;
        public DataItemFloat m_PIPRetPeriSunElev;
        public DataItemInt m_PIPRetPeriErrorNo;
        public DataItemString m_PIPRetPeriErrorString;
        public DataItemInt m_PIPRetNumPolynia;

        public struct PIPRetPolyniaData
        {
            public DataItemInt m_PIPRetPolIdentity;
            public DataItemByte m_PIPRetPolPresent;
            public DataItemFloat m_PIPRetPolX;
            public DataItemFloat m_PIPRetPolY;
            public DataItemFloat m_PIPRetPolZ;
            public DataItemFloat m_PIPRetPolOrientation;
        }

        public PIPRetPolyniaData [] m_PIPRetPolynia;

        public DataItemInt m_PIPRetCheckSum;


        //
        // IO Data Items
        //
        public DataItemFloat  m_IOBearing;
        public DataItemFloat  m_IOElevation;
        public DataItemFloat  m_IOStadAngle;
        public DataItemFloat  m_IOTiBlackLevel;
        public DataItemFloat  m_IOTiSensitivity;
        public DataItemFloat  m_IOTiGratIllum;

        public DataItemFloat  m_IORearStadAngle;
        public DataItemFloat  m_IORearTrueBrg;
        public DataItemFloat  m_IORearRelBrg;

        public DataItemFloat  m_IODisplayBrg;
        public DataItemFloat  m_IODisplayElev;
        public DataItemFloat  m_IODisplayTar;
        public DataItemFloat  m_IOBeckmanTrue;
        public DataItemFloat  m_IOBeckmanRel;

        public DataItemBool      m_IOHandlesDown;
        public DataItemBool      m_IOHighMag;
        public DataItemBool      m_IORangeCut;
        public DataItemBool      m_IOBearingCut;
        public DataItemBool      m_IOPushToTalk;

        public DataItemInt       m_IOModeSelect;
        public DataItemBool      m_IODataOverlay;
        public DataItemBool      m_IOTiOnIndicator;
        public DataItemInt       m_IOTarHeight;

        //
        // Model Database
        //
        public struct ModelDatabase
        {
            public String  m_Name;
            public float   m_Width;
            public float   m_Height;
            public float   m_Length;
        }

        public ModelDatabase[] m_Models;

        //
        // Error Log
        //
        public struct ErrorLog
        {
            public String  m_ErrorTime;
            public String  m_ErrorType;
            public String  m_ErrorSource;
        }

        public bool m_SIMErrorLogClear;
        public int   m_SIMErrorLogIndex;
        public ErrorLog[] m_SIMErrorLog;

        //
        // GUI data (mutex-protected)
        //
        public struct GUIData
        {

            // PIG Data Items
            public DataItemInt m_PIGExSystemID;
            public DataItemInt m_PIGExRunMode;

            public DataItemBool m_PIGEnvMoonOverride;
            public DataItemBool m_PIGEnvCoastLights;
            public DataItemBool m_PIGEnvIceEdgeOn;
            public DataItemBool m_PIGEnvSunOverride;
            public DataItemByte m_PIGEnvHours;
            public DataItemByte m_PIGEnvMins;
            public DataItemByte m_PIGEnvSecs;
            public DataItemByte m_PIGEnvDay;
            public DataItemByte m_PIGEnvMonth;
            public DataItemByte m_PIGEnvYear;
            public DataItemByte m_PIGEnvWeather;
            public DataItemByte m_PIGEnvCoastline;
            public DataItemByte m_PIGEnvSeaState;
            public DataItemFloat m_PIGEnvVisualRange;
            public DataItemFloat m_PIGEnvThermalRange;
            public DataItemFloat m_PIGEnvUnderWaterRange;
            public DataItemFloat m_PIGEnvWindSpeed;
            public DataItemFloat m_PIGEnvWindDirn;
            public DataItemFloat m_PIGEnvMoonBrgOverRide;
            public DataItemFloat m_PIGEnvMoonElevOverRide;
            public DataItemFloat m_PIGEnvSunBrgOverRide;
            public DataItemFloat m_PIGEnvSunElevOverRide;
            public DataItemFloat m_PIGEnvIceEdgeLat;
            public DataItemFloat m_PIGEnvIceEdgeLon;
            public DataItemFloat m_PIGEnvIceEdgeOrien;

            public DataItemByte m_PIGOwnType;
            public DataItemByte m_PIGOwnSmoke;
            public DataItemFloat m_PIGOwnLatitude;
            public DataItemFloat m_PIGOwnLongitude;
            public DataItemFloat m_PIGOwnX;
            public DataItemFloat m_PIGOwnY;
            public DataItemFloat m_PIGOwnDepth;
            public DataItemFloat m_PIGOwnHeading;
            public DataItemFloat m_PIGOwnRoll;
            public DataItemFloat m_PIGOwnPitch;
            public DataItemFloat m_PIGOwnSpeed;
            public DataItemFloat[] m_PIGOwnMast;

            public DataItemByte m_PIGPeriSensor;
            public DataItemByte m_PIGPeriMagnification;
            public DataItemByte m_PIGPeriGain;
            public DataItemByte m_PIGPeriContrast;
            public DataItemByte m_PIGPeriGratIntensity;
            public DataItemByte m_PIGPeriDraindown;
            public DataItemFloat m_PIGPeriRelBrg;
            public DataItemFloat m_PIGPeriElevation;
            public DataItemFloat m_PIGPeriStadAngle;

            public PIGTargetData [] m_PIGTargets;

            public DataItemLong m_PIGRetProcStat;
            public DataItemLong m_PIGRetModelStat;
            public DataItemLong m_PIGRetPolyniaNum;

            public PIGRetPolyniaData [] m_PIGRetPolynia;

            // PIP Data Items
            public DataItemByte m_PIPExRunMode;
            public DataItemByte m_PIPExHours;
            public DataItemByte m_PIPExMins;
            public DataItemByte m_PIPExSecs;
            public DataItemByte m_PIPExDay;
            public DataItemByte m_PIPExMonth;
            public DataItemByte m_PIPExYear;

            public DataItemBool m_PIPPeriInstructCtrl;
            public DataItemBool m_PIPPeriSearchUp;
            public DataItemBool m_PIPPeriPolarityWhite;
            public DataItemBool m_PIPPeriHighMag;
            public DataItemByte m_PIPPeriDraindown;
            public DataItemByte m_PIPPeriLLTVGain;
            public DataItemByte m_PIPPeriThermalGain;
            public DataItemFloat m_PIPPeriRelBearing;
            public DataItemFloat m_PIPPeriElevation;

            public DataItemBool m_PIPEnvMoonOverride;
            public DataItemBool m_PIPEnvCoastLights;
            public DataItemBool m_PIPEnvIceEdgeOn;
            public DataItemBool m_PIPEnvSunOverride;
            public DataItemByte m_PIPEnvWeather;
            public DataItemByte m_PIPEnvCoastline;
            public DataItemByte m_PIPEnvSeaState;
            public DataItemFloat m_PIPEnvMoonBrg;
            public DataItemFloat m_PIPEnvMoonElev;
            public DataItemFloat m_PIPEnvVisualRange;
            public DataItemFloat m_PIPEnvUnderWaterRange;
            public DataItemFloat m_PIPEnvThermalRange;
            public DataItemFloat m_PIPEnvWindSpeed;
            public DataItemFloat m_PIPEnvWindHeading;
            public DataItemFloat m_PIPEnvIceLat;
            public DataItemFloat m_PIPEnvIceLon;
            public DataItemFloat m_PIPEnvIceOrien;
            public DataItemFloat m_PIPEnvSunBrg;
            public DataItemFloat m_PIPEnvSunElev;

            public DataItemDouble m_PIPOwnLat;
            public DataItemDouble m_PIPOwnLon;
            public DataItemFloat m_PIPOwnDepth;
            public DataItemFloat m_PIPOwnClimbRate;
            public DataItemFloat m_PIPOwnTurnRate;
            public DataItemFloat m_PIPOwnPitch;
            public DataItemFloat m_PIPOwnHeading;
            public DataItemFloat m_PIPOwnDriftCourse;
            public DataItemFloat m_PIPOwnSpeed;
            public DataItemFloat m_PIPOwnDriftSpeed;
            public DataItemBool m_PIPOwnWhipAerialUp;
            public DataItemBool m_PIPOwnEmerLightUp;
            public DataItemBool m_PIPOwnDieselSmoke;
            public DataItemByte m_PIPOwnMastRESM;
            public DataItemByte m_PIPOwnMastWTComms;
            public DataItemByte m_PIPOwnMastHFDF;
            public DataItemByte m_PIPOwnMastAttack;
            public DataItemByte m_PIPOwnMastRadar;
            public DataItemByte m_PIPOwnMastSnortInd;
            public DataItemByte m_PIPOwnMastSnortExh;
            public DataItemByte m_PIPOwnType;

            public PIPTargetData [] m_PIPTargets;

            // PIP Return Data
            public DataItemBool m_PIPRetSearchUp;
            public DataItemBool m_PIPRetPolarityWhite;
            public DataItemBool m_PIPRetHighMag;
            public DataItemBool m_PIPRetHandlesUp;
            public DataItemByte m_PIPRetPeriLLTVGain;
            public DataItemByte m_PIPRetPeriTIGain;
            public DataItemFloat m_PIPRetTWSHPeriTrueBrg;
            public DataItemFloat m_PIPRetTWSHTarTrueBrg;
            public DataItemFloat m_PIPRetTWSHTarRange;
            public DataItemFloat m_PIPRetTWSHTarElpsdTime;
            public DataItemBool m_PIPRetTWSHTarTrueBrgCut;
            public DataItemBool m_PIPRetTWSHTarRangeCut;
            public DataItemBool m_PIPRetTWSHTarElpsdTimeCut;
            public DataItemFloat m_PIPRetPeriRelBrg;
            public DataItemFloat m_PIPRetPeriElev;
            public DataItemFloat m_PIPRetPeriSunBrg;
            public DataItemFloat m_PIPRetPeriSunElev;
            public DataItemInt m_PIPRetPeriErrorNo;
            public DataItemString m_PIPRetPeriErrorString;
            public DataItemInt m_PIPRetNumPolynia;

            public PIPRetPolyniaData [] m_PIPRetPolynia;


            // IO Data
            public DataItemFloat    m_IOBearing;
            public DataItemFloat    m_IOElevation;
            public DataItemFloat    m_IOStadAngle;
            public DataItemFloat    m_IOTiBlackLevel;
            public DataItemFloat    m_IOTiSensitivity;
            public DataItemFloat    m_IOTiGratIllum;

            public DataItemFloat    m_IORearStadAngle;
            public DataItemFloat    m_IORearTrueBrg;
            public DataItemFloat    m_IORearRelBrg;

            public DataItemFloat    m_IODisplayBrg;
            public DataItemFloat    m_IODisplayElev;
            public DataItemFloat    m_IODisplayTar;
            public DataItemFloat    m_IOBeckmanTrue;
            public DataItemFloat    m_IOBeckmanRel;

            public DataItemBool     m_IOHandlesDown;
            public DataItemBool     m_IOHighMag;
            public DataItemBool     m_IORangeCut;
            public DataItemBool     m_IOBearingCut;
            public DataItemBool     m_IOPushToTalk;

            public DataItemInt      m_IOModeSelect;
            public DataItemBool     m_IODataOverlay;
            public DataItemBool     m_IOTiOnIndicator;
            public DataItemInt      m_IOTarHeight;

            // System data
            public bool m_SIMRunApp;
            public bool m_SIMEmulatingPIP;
            public bool m_SIMPIPUpdate;
            public bool m_SIMEmulatingPIG;
            public bool m_SIMEmulatingIO;

            public int m_SIMStatusIO;

            // Model Names
            public bool m_ModelNamesSet;
            public String[] m_ModelNames;

            // Error Log
            public bool m_SIMErrorLogClear;
            public int  m_SIMErrorLogIndex;
            public ErrorLog[] m_SIMErrorLog;

            // Network data
            public int     m_PIPBytesIn;
            public int     m_PIPBytesOut;
            public int     m_PIPMessageCountIn;
            public int     m_PIPMessageCountOut;
            public float   m_PIPAverageTimeIn;
            public float   m_PIPAverageTimeOut;

            public int     m_PIGBytesIn;
            public int     m_PIGBytesOut;
            public int     m_PIGMessageCountIn;
            public int     m_PIGMessageCountOut;
            public float   m_PIGAverageTimeIn;
            public float   m_PIGAverageTimeOut;

        }
        public GUIData  m_GUIData;
    }

}
