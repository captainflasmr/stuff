//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//                 The software is supplied by BAE Systems Ltd on the express terms
//                 that it is to be treated as confidential, and that it may not
//                 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : PIG Comms
// Module Title        : PIGComms.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

// ------------------
// Using directives
// ------------------
// System packages
using System;
using System.IO;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Collections;


// ------------------
// Class declaration
// ------------------

namespace PSCGenericBuild
{
    /// <summary>
    /// PIG Comms Class
    /// PSC-PIG Communications Class
    /// This class caters for the network communications between the PSC and PIG.
    /// </summary>
    public class PIGComms : Comms
    {

        //
        //    public float oldX = 0.0f;
        //    public float oldY = 0.0f;

        // ------------------
        // Class Data
        // -------------------

        // Size of PIGPolynia
        private const int PIGPOLYNIA_BYTES = 32;
        // Size of PIGPolyniaData
        private const int PIGPOLYNIADATA_BYTES = 8 + (SIMControl.NUM_POLYNIA_TARGETS * PIGPOLYNIA_BYTES);
        // Size of PIGInputPacket
        public const int PIGINPUTPACKET_BYTES = 8 + PIGPOLYNIADATA_BYTES;

        private String    m_PIGName;
        private IPAddress m_IPAddress;
        private int       m_Port;
        private int       m_RateOut;
        private SIMControl   m_SimControl;

        private Socket    m_Socket;
        private IPEndPoint   m_EndPointPIG;

        private  PIGOutputPacket m_PIGOutputPacket;
        private  PIGInputPacket  m_PIGInputPacket;

        private int m_IterateOut;
        private int m_CountOut;

        private int m_IterateError;
        private int m_CountInError;
        private int m_CountOutError;

        private byte[]     m_BufferIn;
        private byte[]    m_BufferOut;



        // ---------------------------
        // PIG Packet Data Structures
        // ---------------------------

        public struct PIGExerciseData
        {
            public int  iSystemID;
            public int  iRunMode;
        }

        public struct PIGEnvironmentData
        {
            public int   iFlags;

            public byte  bHours;
            public byte  bMinutes;
            public byte  bSeconds;
            public byte  bDay;
            public byte  bMonth;
            public byte  bYear;

            public byte  bWeather;
            public byte  bCoastline;

            public byte  bSeaState;
            public byte  bSpare1;
            public byte  bSpare2;
            public byte  bSpare3;

            public float fVisibleRange;
            public float fThermalRange;
            public float fUnderwaterVis;
            public float fWindSpeed;
            public float fWindDirection;

            public float fMoonBearing;
            public float fMoonAltitude;

            public float fSunBearing;
            public float fSunAltitude;

            public float fIceEdgeLat;
            public float fIceEdgeLong;
            public float fIceEdgeOrient;
        }

        public struct PIGOwnshipData
        {
            public byte  bType;
            public byte  bSmoke;
            public byte  bSpare1;
            public byte  bSpare2;
            public float fLatitude;
            public float fLongitude;
            public float fX;
            public float fY;
            public float fDepth;
            public float fHeading;
            public float fRoll;
            public float fPitch;
            public float fSpeed;

            public float [] mast;
        }

        public struct PIGPeriscopeData
        {
            public byte  bSensorType;
            public byte  bMagnification;
            public byte  bSensorGain;
            public byte  bSensorContrast;
            public byte  bGraticuleInt;
            public byte  bDraindownTime;
            public byte  bSpare1;
            public byte  bSpare2;
            public float fRelativeBearing;
            public float fElevation;
            public float fStadAngle;
        }

        public struct PIGTargetData
        {
            public short sFlags;
            public short sModelID;
            public short sTargetNum;
            public short sLightConfig;
            public float fX;
            public float fY;
            public float fHeight;
            public float fHeading;
            public float fRoll;
            public float fPitch;
            public float fSpeed;
            public float fAcceleration;
        }

        public struct PIGPolyniaData
        {
            public long m_contacts;
            public long m_spare;
            public PIGPolynia [] m_Polynia;
        }

        public struct PIGPolynia
        {
            public long   m_identity;
            public float m_x;
            public float m_y;
            public float m_z;
            public float m_orientation;
            public long   m_slotNumber;
            public long   spare1;
            public long   spare2;
        }

        public struct PIGOutputPacket
        {
            public PIGExerciseData     exerciseData;
            public PIGEnvironmentData  environmentData;
            public PIGPeriscopeData    periscopeData;
            public PIGOwnshipData      ownshipData;
            public PIGTargetData[]     targetData;
        }

        public struct PIGInputPacket
        {
            public long            m_procStat;
            public long            m_modelStat;
            public PIGPolyniaData  polyniaData;
        }

        // ----------------------
        //  PIGComms Constructor
        // ----------------------
        public PIGComms(String name, String ipAddress, String port, String rateOut, String swap, SIMControl simControl)
        {
            //
            // Initialise PIG network data from passed parameters
            //
            m_PIGName = name;
            m_IPAddress = IPAddress.Parse(ipAddress);
            m_Port = System.Convert.ToInt32(port);
            m_RateOut = System.Convert.ToInt32(rateOut);

            if (swap == "YES")
                m_SwapBytes = true;
            else
                m_SwapBytes = false;

            m_SimControl = simControl;


            //
            // Initialise space for arrays
            //
            m_BufferIn = new byte[PIGINPUTPACKET_BYTES];

            m_PIGOutputPacket.ownshipData.mast = new float[10];
            m_PIGOutputPacket.targetData = new PIGTargetData[SIMControl.NUM_PERI_TARGETS];
            m_PIGInputPacket.polyniaData.m_Polynia = new PIGPolynia[SIMControl.NUM_POLYNIA_TARGETS];

            //
            // Set the output iterate times.
            // This is the number of the iteration at which the output is required.
            // Must be greater than one i.e. can't output faster than application iteration rate.
            //
            m_IterateOut = m_SimControl.m_AppIterationRate / m_RateOut;

            if (m_IterateOut < 1)
                m_IterateOut = 1;

            m_CountOut = 0;


            m_IterateError = (int) ((float) (m_SimControl.m_AppIterationRate) / 0.2f);

            if (m_IterateError < 1)
                m_IterateError = 1;

            m_CountInError = 0;
            m_CountOutError = 0;


            //
            // Create the network socket
            //
            m_EndPointPIG = new IPEndPoint(m_IPAddress, m_Port);
            OpenPIGSocket();

        }


        // --------------------
        // PIGComms Destructor
        // --------------------
        ~PIGComms()
        {
            // Close the socket
            ClosePIGSocket();

            Console.WriteLine("PIG Comms: {0} Shutdown.", m_PIGName);
        }


        // ----------------------------
        // PIGComms Main Update Method
        // ----------------------------
        public void Update()
        {
            int iBytesIn = 0;
            int iBytesOut = 0;


            //
            // If emulating PIG don't do any network checks
            //
            if (m_SimControl.m_SIMEmulatingPIG)
                return;


            //
            // Perform output at RateOut
            //
            if (m_CountOut == m_IterateOut)
            {
                //
                // Update the PIG Comms data from SimControl using accessor methods
                //
                GetDataFromSimControl();

                //
                // Encode the network data into a byte buffer
                //
                EncodeBufferOut();

                //
                // Send the buffer out on the network
                //
                try
                {
                    iBytesOut = m_Socket.SendTo(m_BufferOut, m_EndPointPIG);
                    //Console.WriteLine("PIG Comms: iBytesOut: {0}", iBytesOut);

                    // Update SimControl network metrics
                    m_SimControl.m_PIGBytesOut = iBytesOut;
                    m_SimControl.m_PIGArrayTimesOut[m_SimControl.m_PIGArrayIndexOut] = m_SimControl.m_SIMTimeStamp1;
                    m_SimControl.m_PIGArrayIndexOut++;
                    if (m_SimControl.m_PIGArrayIndexOut > 9)
                        m_SimControl.m_PIGArrayIndexOut = 0;


                    // Reset error counters
                    m_CountOutError = 0;

                }
                catch(Exception e)
                {

                    // Error Log: Send failure (raise every 5 seconds)
                    if (m_CountOutError == m_IterateError)
                    {
                        Console.WriteLine("");
                        Console.WriteLine("PIG Comms: Unable to SEND data...creating new socket." + e.ToString());
                        Console.WriteLine("");

                        // Write to error log
                        m_SimControl.WriteToErrorLog("SEND_FAIL", "PIG");

                        // Close the socket and create a new one
                        ClosePIGSocket();
                        OpenPIGSocket();

                        // Reset error counter
                        m_CountOutError = 0;
                    }
                    else
                    {
                        // Update error counter
                        m_CountOutError++;
                    }

                }

                //
                // Reset the counter
                //
                m_CountOut = 0;
            }


            //
            // Check if data is available from the PIG network.
            // If it is then get it and update the PIG Comms data, then update any
            // data in the SimControl object.
            //

            if (m_Socket.Available > 0)
            {
                try
                {
                    // Get the data from the network and put it into the input byte buffer
                    EndPoint tempRemoteEP = (EndPoint)m_EndPointPIG;

                    iBytesIn = m_Socket.ReceiveFrom(m_BufferIn,  ref tempRemoteEP);
                    // Console.WriteLine("PIG Comms: iBytesIn: {0}", iBytesIn);

                    // Update SimControl network metrics
                    m_SimControl.m_PIGBytesIn = iBytesIn;
                    m_SimControl.m_PIGArrayTimesIn[m_SimControl.m_PIGArrayIndexIn] = m_SimControl.m_SIMTimeStamp1;
                    m_SimControl.m_PIGArrayIndexIn++;
                    if (m_SimControl.m_PIGArrayIndexIn > 9)
                        m_SimControl.m_PIGArrayIndexIn = 0;

                    // Error Log: Check bytes in
                    if (m_SimControl.m_PIGBytesIn != PIGINPUTPACKET_BYTES)
                        m_SimControl.WriteToErrorLog("NUMBER_BYTES", "PIG");


                    // Reset error counter
                    m_CountInError = 0;

                }
                catch(Exception e)
                {

                    // Error Log: Send failure (raise every 5 seconds)
                    if (m_CountInError == m_IterateError)
                    {

                        Console.WriteLine("");
                        Console.WriteLine("PIG Comms: Unable to RECEIVE data...creating new socket." + e.ToString());
                        Console.WriteLine("");

                        // Set the bytes in to zero
                        iBytesIn = 0;

                        // Error Log: Receive failure
                        m_SimControl.WriteToErrorLog("RECEIVE_FAIL", "PIG");

                        // Close the socket and create a new one
                        ClosePIGSocket();
                        OpenPIGSocket();

                        // Reset error counter
                        m_CountInError = 0;
                    }
                    else
                    {
                        // Update error counter
                        m_CountInError++;
                    }

                }


                if (iBytesIn > 0)
                {
                    // Decode the network byte buffer to PIG Comms data

                    DecodeBufferIn();

                    // Update the return data in SIMControl via accesor methods
                    SetDataInSimControl();
                }

            }

            //
            // Update the counter
            //
            m_CountOut++;

        }


        // ------------------------
        // Open Network Socket
        // -------------------------
        private  void OpenPIGSocket()
        {
            try
            {
                //
                // Create a new UDP socket and ensure it doesn't block.
                // UDP socket has to be bound to local endpoint
                //
                EndPoint localEP = new IPEndPoint(m_SimControl.m_IPAddressPIGNet, m_SimControl.m_PortPIGNet);
                m_Socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                m_Socket.Blocking = false;
                m_Socket.Bind(localEP);


                // Print out the data
                Console.WriteLine("");
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("PIG Comms: Creating Socket...");
                Console.WriteLine("\t Name: \t\t{0}", m_PIGName);
                Console.WriteLine("\t IPAddress: \t{0}", m_IPAddress);
                Console.WriteLine("\t Port: \t\t{0}", m_Port);
                Console.WriteLine("\t Rate Out: \t{0}", m_RateOut);
                Console.WriteLine("\t Swap Bytes: \t{0}", m_SwapBytes);
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("");
            }
            catch
            {
                // Print out error message
                Console.WriteLine("");
                Console.WriteLine("-------------ERROR-------------------");
                Console.WriteLine("PIG Comms: Could not create socket...");
                Console.WriteLine("\t Name: \t\t{0}", m_PIGName);
                Console.WriteLine("\t IPAddress: \t{0}", m_IPAddress);
                Console.WriteLine("\t Port: \t\t{0}", m_Port);
                Console.WriteLine("\t Rate Out: \t{0}", m_RateOut);
                Console.WriteLine("\t Swap Bytes: \t{0}", m_SwapBytes);
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("");
            }
        }



        // ------------------------
        // Close Network Socket
        // -------------------------
        private  void ClosePIGSocket()
        {
            //
            // Shutdown the socket for both send and receive
            // then close it to free resources
            //
            try
            {
                m_Socket.Shutdown(SocketShutdown.Both);
                m_Socket.Close();
            }
            catch
            {
                // Socket not valid anyway
            }
        }



        // ------------------------------------
        // Get Update From SimControl Method
        // ------------------------------------
        private  void GetDataFromSimControl()
        {
            int i;

            // Update message counter
            m_SimControl.m_PIGMessageCountOut++;

            m_PIGOutputPacket.exerciseData.iSystemID = m_SimControl.m_PIGExSystemID.GetResultValue();
            m_PIGOutputPacket.exerciseData.iRunMode = m_SimControl.m_PIGExRunMode.GetResultValue();

            // Combine individual bool flags into an integer value
            bool[] boolValue = new bool[4];
            boolValue[0] = m_SimControl.m_PIGEnvMoonOverride.GetResultValue();
            boolValue[1] = m_SimControl.m_PIGEnvCoastLights.GetResultValue();
            boolValue[2] = m_SimControl.m_PIGEnvIceEdgeOn.GetResultValue();
            boolValue[3] = m_SimControl.m_PIGEnvSunOverride.GetResultValue();
            BitArray bitArray = new BitArray(boolValue);
            Array intArray = Array.CreateInstance( typeof(int), 1 );
            bitArray.CopyTo( intArray, 0 );
            m_PIGOutputPacket.environmentData.iFlags = (int) intArray.GetValue(0);

            m_PIGOutputPacket.environmentData.bHours = m_SimControl.m_PIGEnvHours.GetResultValue();
            m_PIGOutputPacket.environmentData.bMinutes = m_SimControl.m_PIGEnvMins.GetResultValue();
            m_PIGOutputPacket.environmentData.bSeconds = m_SimControl.m_PIGEnvSecs.GetResultValue();
            m_PIGOutputPacket.environmentData.bDay = m_SimControl.m_PIGEnvDay.GetResultValue();
            m_PIGOutputPacket.environmentData.bMonth = m_SimControl.m_PIGEnvMonth.GetResultValue();
            m_PIGOutputPacket.environmentData.bYear = m_SimControl.m_PIGEnvYear.GetResultValue();
            m_PIGOutputPacket.environmentData.bWeather = m_SimControl.m_PIGEnvWeather.GetResultValue();
            m_PIGOutputPacket.environmentData.bCoastline = m_SimControl.m_PIGEnvCoastline.GetResultValue();
            m_PIGOutputPacket.environmentData.bSeaState = m_SimControl.m_PIGEnvSeaState.GetResultValue();
            m_PIGOutputPacket.environmentData.fVisibleRange = m_SimControl.m_PIGEnvVisualRange.GetResultValue();
            m_PIGOutputPacket.environmentData.fThermalRange = m_SimControl.m_PIGEnvThermalRange.GetResultValue();
            m_PIGOutputPacket.environmentData.fUnderwaterVis = m_SimControl.m_PIGEnvUnderWaterRange.GetResultValue();
            m_PIGOutputPacket.environmentData.fWindSpeed = m_SimControl.m_PIGEnvWindSpeed.GetResultValue();
            m_PIGOutputPacket.environmentData.fWindDirection = m_SimControl.m_PIGEnvWindDirn.GetResultValue();
            m_PIGOutputPacket.environmentData.fMoonBearing = m_SimControl.m_PIGEnvMoonBrgOverRide.GetResultValue();
            m_PIGOutputPacket.environmentData.fMoonAltitude = m_SimControl.m_PIGEnvMoonElevOverRide.GetResultValue();
            m_PIGOutputPacket.environmentData.fSunBearing = m_SimControl.m_PIGEnvSunBrgOverRide.GetResultValue();
            m_PIGOutputPacket.environmentData.fSunAltitude = m_SimControl.m_PIGEnvSunElevOverRide.GetResultValue();
            m_PIGOutputPacket.environmentData.fIceEdgeLat = m_SimControl.m_PIGEnvIceEdgeLat.GetResultValue();
            m_PIGOutputPacket.environmentData.fIceEdgeLong = m_SimControl.m_PIGEnvIceEdgeLon.GetResultValue();
            m_PIGOutputPacket.environmentData.fIceEdgeOrient = m_SimControl.m_PIGEnvIceEdgeOrien.GetResultValue();

            m_PIGOutputPacket.ownshipData.bType = m_SimControl.m_PIGOwnType.GetResultValue();
            m_PIGOutputPacket.ownshipData.bSmoke = m_SimControl.m_PIGOwnSmoke.GetResultValue();
            m_PIGOutputPacket.ownshipData.fLatitude = m_SimControl.m_PIGOwnLatitude.GetResultValue();
            m_PIGOutputPacket.ownshipData.fLongitude = m_SimControl.m_PIGOwnLongitude.GetResultValue();

            m_PIGOutputPacket.ownshipData.fX = m_SimControl.m_PIGOwnX.GetResultValue();
            m_PIGOutputPacket.ownshipData.fY = m_SimControl.m_PIGOwnY.GetResultValue();

            m_PIGOutputPacket.ownshipData.fDepth = m_SimControl.m_PIGOwnDepth.GetResultValue();
            m_PIGOutputPacket.ownshipData.fHeading = m_SimControl.m_PIGOwnHeading.GetResultValue();
            m_PIGOutputPacket.ownshipData.fRoll = m_SimControl.m_PIGOwnRoll.GetResultValue();
            m_PIGOutputPacket.ownshipData.fPitch = m_SimControl.m_PIGOwnPitch.GetResultValue();
            m_PIGOutputPacket.ownshipData.fSpeed = m_SimControl.m_PIGOwnSpeed.GetResultValue();

            for (i = 0; i < 10; i++)
                m_PIGOutputPacket.ownshipData.mast[i] = m_SimControl.m_PIGOwnMast[i].GetResultValue();

            m_PIGOutputPacket.periscopeData.bSensorType = m_SimControl.m_PIGPeriSensor.GetResultValue();
            m_PIGOutputPacket.periscopeData.bMagnification = m_SimControl.m_PIGPeriMagnification.GetResultValue();
            m_PIGOutputPacket.periscopeData.bSensorGain = m_SimControl.m_PIGPeriGain.GetResultValue();
            m_PIGOutputPacket.periscopeData.bSensorContrast = m_SimControl.m_PIGPeriContrast.GetResultValue();
            m_PIGOutputPacket.periscopeData.bGraticuleInt = m_SimControl.m_PIGPeriGratIntensity.GetResultValue();
            m_PIGOutputPacket.periscopeData.bDraindownTime = m_SimControl.m_PIGPeriDraindown.GetResultValue();
            m_PIGOutputPacket.periscopeData.fRelativeBearing = m_SimControl.m_PIGPeriRelBrg.GetResultValue();
            m_PIGOutputPacket.periscopeData.fElevation = m_SimControl.m_PIGPeriElevation.GetResultValue();
            m_PIGOutputPacket.periscopeData.fStadAngle = m_SimControl.m_PIGPeriStadAngle.GetResultValue();

            bool[] boolValTar = new bool[10];
            int dataValue;

            for(i = 0; i < SIMControl.NUM_PERI_TARGETS; i++)
            {
                // Combine individual bool flags into an integer value
                boolValTar[0] = m_SimControl.m_PIGTargets[i].m_PIGTarPresent.GetResultValue();
                boolValTar[1] = m_SimControl.m_PIGTargets[i].m_PIGTarNavLights.GetResultValue();
                boolValTar[2] = m_SimControl.m_PIGTargets[i].m_PIGTarMissileHit.GetResultValue();
                boolValTar[3] = m_SimControl.m_PIGTargets[i].m_PIGTarTorpedoHit.GetResultValue();
                boolValTar[4] = m_SimControl.m_PIGTargets[i].m_PIGTarSinking.GetResultValue();
                boolValTar[5] = m_SimControl.m_PIGTargets[i].m_PIGTarDunkingSonar.GetResultValue();
                boolValTar[6] = m_SimControl.m_PIGTargets[i].m_PIGTarTLAM.GetResultValue();
                boolValTar[7] = m_SimControl.m_PIGTargets[i].m_PIGTarFlames.GetResultValue();
                boolValTar[8] = m_SimControl.m_PIGTargets[i].m_PIGTarDieselSmoke.GetResultValue();
                boolValTar[9] = m_SimControl.m_PIGTargets[i].m_PIGTarFireMissile.GetResultValue();
                BitArray bitArrayTar = new BitArray(boolValTar);
                Array dataArrayTar = Array.CreateInstance( typeof(int), 1 );
                bitArrayTar.CopyTo( dataArrayTar, 0 );
                dataValue = (int) dataArrayTar.GetValue(0);
                m_PIGOutputPacket.targetData[i].sFlags = (short) dataValue;

                m_PIGOutputPacket.targetData[i].sModelID = m_SimControl.m_PIGTargets[i].m_PIGTarModelID.GetResultValue();
                m_PIGOutputPacket.targetData[i].sTargetNum = m_SimControl.m_PIGTargets[i].m_PIGTarSlotNum.GetResultValue();

                // Combine the two bytes for the light and spotlight config into a single short
                // via a bit array
                byte[]   bytesLight = new byte[2];
                bytesLight[0] = (byte) m_SimControl.m_PIGTargets[i].m_PIGTarLightConfig.GetResultValue();
                bytesLight[1] = (byte) m_SimControl.m_PIGTargets[i].m_PIGTarSpotConfig.GetResultValue();
                BitArray bitArrayLights = new BitArray(bytesLight);

                Array arrayLights = Array.CreateInstance( typeof(int), 1 );
                bitArrayLights.CopyTo( arrayLights, 0 );
                int lightValue = (int) arrayLights.GetValue(0);
                m_PIGOutputPacket.targetData[i].sLightConfig =  (short) lightValue;

                m_PIGOutputPacket.targetData[i].fX = m_SimControl.m_PIGTargets[i].m_PIGTarX.GetResultValue();
                m_PIGOutputPacket.targetData[i].fY = m_SimControl.m_PIGTargets[i].m_PIGTarY.GetResultValue();

                m_PIGOutputPacket.targetData[i].fHeight = m_SimControl.m_PIGTargets[i].m_PIGTarHeight.GetResultValue();
                m_PIGOutputPacket.targetData[i].fHeading = m_SimControl.m_PIGTargets[i].m_PIGTarHeading.GetResultValue();
                m_PIGOutputPacket.targetData[i].fRoll = m_SimControl.m_PIGTargets[i].m_PIGTarRoll.GetResultValue();
                m_PIGOutputPacket.targetData[i].fPitch = m_SimControl.m_PIGTargets[i].m_PIGTarPitch.GetResultValue();
                m_PIGOutputPacket.targetData[i].fSpeed = m_SimControl.m_PIGTargets[i].m_PIGTarSpeed.GetResultValue();
                m_PIGOutputPacket.targetData[i].fAcceleration = m_SimControl.m_PIGTargets[i].m_PIGTarAccel.GetResultValue();
            }
        }



        // --------------------------
        // Encode Buffer Out Method
        // --------------------------
        private void EncodeBufferOut()
        {
            int i;

            MemoryStream ms = new MemoryStream();
            BinaryWriter bw = new BinaryWriter(ms);

            //
            // Start writing bytes - must be correct order
            // Note that WriteBytes does any byte swapping required
            //
            WriteBytes(ref bw, m_PIGOutputPacket.exerciseData.iSystemID);
            WriteBytes(ref bw, m_PIGOutputPacket.exerciseData.iRunMode);

            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.iFlags);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.bHours);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.bMinutes);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.bSeconds);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.bDay);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.bMonth);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.bYear);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.bWeather);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.bCoastline);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.bSeaState);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.bSpare1);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.bSpare2);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.bSpare3);

            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.fVisibleRange);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.fThermalRange);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.fUnderwaterVis);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.fWindSpeed);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.fWindDirection);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.fMoonBearing);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.fMoonAltitude);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.fSunBearing);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.fSunAltitude);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.fIceEdgeLat);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.fIceEdgeLong);
            WriteBytes(ref bw, m_PIGOutputPacket.environmentData.fIceEdgeOrient);

            WriteBytes(ref bw, m_PIGOutputPacket.periscopeData.bSensorType);
            WriteBytes(ref bw, m_PIGOutputPacket.periscopeData.bMagnification);
            WriteBytes(ref bw, m_PIGOutputPacket.periscopeData.bSensorGain);
            WriteBytes(ref bw, m_PIGOutputPacket.periscopeData.bSensorContrast);
            WriteBytes(ref bw, m_PIGOutputPacket.periscopeData.bGraticuleInt);
            WriteBytes(ref bw, m_PIGOutputPacket.periscopeData.bDraindownTime);
            WriteBytes(ref bw, m_PIGOutputPacket.periscopeData.bSpare1);
            WriteBytes(ref bw, m_PIGOutputPacket.periscopeData.bSpare2);

            WriteBytes(ref bw, m_PIGOutputPacket.periscopeData.fRelativeBearing);
            WriteBytes(ref bw, m_PIGOutputPacket.periscopeData.fElevation);
            WriteBytes(ref bw, m_PIGOutputPacket.periscopeData.fStadAngle);

            WriteBytes(ref bw, m_PIGOutputPacket.ownshipData.bType);
            WriteBytes(ref bw, m_PIGOutputPacket.ownshipData.bSmoke);
            WriteBytes(ref bw, m_PIGOutputPacket.ownshipData.bSpare1);
            WriteBytes(ref bw, m_PIGOutputPacket.ownshipData.bSpare2);

            WriteBytes(ref bw, m_PIGOutputPacket.ownshipData.fLatitude);
            WriteBytes(ref bw, m_PIGOutputPacket.ownshipData.fLongitude);
            WriteBytes(ref bw, m_PIGOutputPacket.ownshipData.fX);
            WriteBytes(ref bw, m_PIGOutputPacket.ownshipData.fY);


            //       float diffX = m_PIGOutputPacket.ownshipData.fX - oldX;
            //       float diffY = m_PIGOutputPacket.ownshipData.fY - oldY;

            //Console.WriteLine("Diff: {0} : {1} : {2} : {3} : {4}", m_PIGOutputPacket.ownshipData.fX, m_PIGOutputPacket.ownshipData.fY, diffX, diffY, m_PIGOutputPacket.ownshipData.fHeading);
            //
            //       oldX = m_PIGOutputPacket.ownshipData.fX;
            //       oldY = m_PIGOutputPacket.ownshipData.fY;


            WriteBytes(ref bw, m_PIGOutputPacket.ownshipData.fDepth);
            WriteBytes(ref bw, m_PIGOutputPacket.ownshipData.fHeading);
            WriteBytes(ref bw, m_PIGOutputPacket.ownshipData.fRoll);
            WriteBytes(ref bw, m_PIGOutputPacket.ownshipData.fPitch);
            WriteBytes(ref bw, m_PIGOutputPacket.ownshipData.fSpeed);

            for(i = 0; i < 10; i++)
            {
                WriteBytes(ref bw, m_PIGOutputPacket.ownshipData.mast[i]);
            }

            for(i = 0; i < SIMControl.NUM_PERI_TARGETS; i++)
            {
                WriteBytes(ref bw, m_PIGOutputPacket.targetData[i].sFlags);
                WriteBytes(ref bw, m_PIGOutputPacket.targetData[i].sModelID);
                WriteBytes(ref bw, m_PIGOutputPacket.targetData[i].sTargetNum);

                WriteBytes(ref bw, m_PIGOutputPacket.targetData[i].sLightConfig);

                WriteBytes(ref bw, m_PIGOutputPacket.targetData[i].fX);
                WriteBytes(ref bw, m_PIGOutputPacket.targetData[i].fY);
                WriteBytes(ref bw, m_PIGOutputPacket.targetData[i].fHeight);
                WriteBytes(ref bw, m_PIGOutputPacket.targetData[i].fHeading);
                WriteBytes(ref bw, m_PIGOutputPacket.targetData[i].fRoll);
                WriteBytes(ref bw, m_PIGOutputPacket.targetData[i].fPitch);
                WriteBytes(ref bw, m_PIGOutputPacket.targetData[i].fSpeed);
                WriteBytes(ref bw, m_PIGOutputPacket.targetData[i].fAcceleration);
            }

            //
            // Set the output buffer
            //
            m_BufferOut = ms.ToArray();

        }



        // --------------------------
        // Decode Buffer In Method
        // --------------------------
        private  void DecodeBufferIn()
        {
            int i;

            MemoryStream ms = new MemoryStream(m_BufferIn);
            BinaryReader br = new BinaryReader(ms);
            //
            // Start reading bytes - must be correct order
            // Note that ReadBytes does any byte swapping required
            //
            m_PIGInputPacket.m_procStat = (long) ReadBytesInt(ref br);
            m_PIGInputPacket.m_modelStat = (long) ReadBytesInt(ref br);
            m_PIGInputPacket.polyniaData.m_contacts = (long) ReadBytesInt(ref br);
            m_PIGInputPacket.polyniaData.m_spare = (long) ReadBytesInt(ref br);

            for (i = 0; i < SIMControl.NUM_POLYNIA_TARGETS; i++)
            {
                m_PIGInputPacket.polyniaData.m_Polynia[i].m_identity = (long) ReadBytesInt(ref br);
                m_PIGInputPacket.polyniaData.m_Polynia[i].m_x = ReadBytesFloat(ref br);
                m_PIGInputPacket.polyniaData.m_Polynia[i].m_y = ReadBytesFloat(ref br);
                m_PIGInputPacket.polyniaData.m_Polynia[i].m_z = ReadBytesFloat(ref br);
                m_PIGInputPacket.polyniaData.m_Polynia[i].m_orientation = ReadBytesFloat(ref br);
                m_PIGInputPacket.polyniaData.m_Polynia[i].m_slotNumber = (long) ReadBytesInt(ref br);
                m_PIGInputPacket.polyniaData.m_Polynia[i].spare1 = (long) ReadBytesInt(ref br);
                m_PIGInputPacket.polyniaData.m_Polynia[i].spare2 = (long) ReadBytesInt(ref br);

            }
        }



        // -------------------------------------
        // Set Update Data In SimControl Method
        // -------------------------------------
        private void SetDataInSimControl()
        {
            int i;

            // Update message counter
            m_SimControl.m_PIGMessageCountIn++;

            m_SimControl.m_PIGRetProcStat.SetRawValue(m_PIGInputPacket.m_procStat);
            m_SimControl.m_PIGRetModelStat.SetRawValue(m_PIGInputPacket.m_modelStat);
            m_SimControl.m_PIGRetPolyniaNum.SetRawValue(m_PIGInputPacket.polyniaData.m_contacts);

            for (i = 0 ; i < SIMControl.NUM_POLYNIA_TARGETS; i++)
            {
                m_SimControl.m_PIGRetPolynia[i].m_PIGRetPolIdentity.SetRawValue(m_PIGInputPacket.polyniaData.m_Polynia[i].m_identity);
                m_SimControl.m_PIGRetPolynia[i].m_PIGRetPolX.SetRawValue(m_PIGInputPacket.polyniaData.m_Polynia[i].m_x);
                m_SimControl.m_PIGRetPolynia[i].m_PIGRetPolY.SetRawValue(m_PIGInputPacket.polyniaData.m_Polynia[i].m_y);
                m_SimControl.m_PIGRetPolynia[i].m_PIGRetPolZ.SetRawValue(m_PIGInputPacket.polyniaData.m_Polynia[i].m_z);
                m_SimControl.m_PIGRetPolynia[i].m_PIGRetPolOrien.SetRawValue(m_PIGInputPacket.polyniaData.m_Polynia[i].m_orientation);
                m_SimControl.m_PIGRetPolynia[i].m_PIGRetPolSlotNum.SetRawValue(m_PIGInputPacket.polyniaData.m_Polynia[i].m_slotNumber);
            }
        }

    }
}
