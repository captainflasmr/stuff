//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//                 The software is supplied by BAE Systems Ltd on the express terms
//                 that it is to be treated as confidential, and that it may not
//                 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Comms
// Module Title        : Comms.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

// ------------------
// Using directives
// ------------------
// System packages
using System;
using System.IO;
using System.Text;
using System.Net;
using System.Net.Sockets;


// ------------------
// Class declaration
// ------------------

namespace PSCGenericBuild
{
    /// <summary>
    /// Comms Class
    /// A virtual comms class that the top-level comms classes inherit from so
    /// that they can use some common methods
    /// </summary>
    public class Comms
    {

        public bool m_SwapBytes;


        // -------------------
        //  Comms Constructor
        // -------------------
        public Comms()
        {
        }

        // ------------------
        //  Comms Destructor
        // ------------------
        ~Comms()
        {
        }


        // -----------------
        // Write Bytes BYTE
        // -----------------
        public void WriteBytes(ref BinaryWriter bw, byte data)
        {
            // Write the bytes out
            bw.Write(data);
        }


        // -----------------
        // Write Bytes INT
        // -----------------
        public void WriteBytes(ref BinaryWriter bw, int data)
        {
            // Integer is 4 bytes
            byte[] resultByte = new byte[4];

            // Create a binary writer
            MemoryStream msResult = new MemoryStream();
            BinaryWriter bwResult = new BinaryWriter(msResult);

            // Write the data to a memory stream
            bwResult.Write(data);

            // Get the output array
            resultByte = msResult.ToArray();

            if (m_SwapBytes == true)
            {
                //Swap the bytes
                bw.Write(resultByte[3]);
                bw.Write(resultByte[2]);
                bw.Write(resultByte[1]);
                bw.Write(resultByte[0]);
            }
            else
            {
                // Don't swap the bytes
                bw.Write(resultByte[0]);
                bw.Write(resultByte[1]);
                bw.Write(resultByte[2]);
                bw.Write(resultByte[3]);
            }
        }


        // -------------------
        // Write Bytes FLOAT
        // -------------------
        public void WriteBytes(ref BinaryWriter bw, float data)
        {
            // Float is 4 bytes
            byte[] resultByte = new byte[4];

            // Create a binary writer
            MemoryStream msResult = new MemoryStream();
            BinaryWriter bwResult = new BinaryWriter(msResult);

            // Write the data to a memory stream
            bwResult.Write(data);

            // Get the output array
            resultByte = msResult.ToArray();

            if (m_SwapBytes == true)
            {
                //Swap the bytes
                bw.Write(resultByte[3]);
                bw.Write(resultByte[2]);
                bw.Write(resultByte[1]);
                bw.Write(resultByte[0]);
            }
            else
            {
                // Don't swap the bytes
                bw.Write(resultByte[0]);
                bw.Write(resultByte[1]);
                bw.Write(resultByte[2]);
                bw.Write(resultByte[3]);
            }
        }


        // --------------------
        // Write Bytes DOUBLE
        // --------------------
        public void WriteBytes(ref BinaryWriter bw, double data)
        {
            // Double is 8 bytes
            byte[] resultByte = new byte[8];

            // Create a binary writer
            MemoryStream msResult = new MemoryStream();
            BinaryWriter bwResult = new BinaryWriter(msResult);

            // Write the data to a memory stream
            bwResult.Write(data);

            // Get the output array
            resultByte = msResult.ToArray();

            if (m_SwapBytes == true)
            {
                //Swap the bytes
                bw.Write(resultByte[7]);
                bw.Write(resultByte[6]);
                bw.Write(resultByte[5]);
                bw.Write(resultByte[4]);
                bw.Write(resultByte[3]);
                bw.Write(resultByte[2]);
                bw.Write(resultByte[1]);
                bw.Write(resultByte[0]);
            }
            else
            {
                // Don't swap the bytes
                bw.Write(resultByte[0]);
                bw.Write(resultByte[1]);
                bw.Write(resultByte[2]);
                bw.Write(resultByte[3]);
                bw.Write(resultByte[4]);
                bw.Write(resultByte[5]);
                bw.Write(resultByte[6]);
                bw.Write(resultByte[7]);
            }
        }


        // -------------------
        // Write Bytes SHORT
        // -------------------
        public void WriteBytes(ref BinaryWriter bw, short data)
        {
            // Short is 2 bytes
            byte[] resultByte = new byte[2];

            // Create a binary writer
            MemoryStream msResult = new MemoryStream();
            BinaryWriter bwResult = new BinaryWriter(msResult);

            // Write the data to a memory stream
            bwResult.Write(data);

            // Get the output array
            resultByte = msResult.ToArray();

            if (m_SwapBytes == true)
            {
                //Swap the bytes
                bw.Write(resultByte[1]);
                bw.Write(resultByte[0]);
            }
            else
            {
                // Don't swap the bytes
                bw.Write(resultByte[0]);
                bw.Write(resultByte[1]);
            }
        }



        // -----------------
        // Read Bytes BYTE
        // -----------------
        public byte ReadBytesByte(ref BinaryReader br)
        {
            byte result;

            // Read the bytes
            result = br.ReadByte();

            // Return result
            return result;
        }


        // -----------------
        // Read Bytes INT
        // -----------------
        public int ReadBytesInt(ref BinaryReader br)
        {
            int result;



            // Integer is 4 bytes
            byte[] resultByte = new byte[4];
            byte[] tempByte = new byte[4];


            // Read the bytes
            resultByte[0] = br.ReadByte();
            resultByte[1] = br.ReadByte();
            resultByte[2] = br.ReadByte();
            resultByte[3] = br.ReadByte();


            if (m_SwapBytes == true)
            {
                tempByte[0] = resultByte[0];
                tempByte[1] = resultByte[1];
                tempByte[2] = resultByte[2];
                tempByte[3] = resultByte[3];

                resultByte[0] = tempByte[3];
                resultByte[1] = tempByte[2];
                resultByte[2] = tempByte[1];
                resultByte[3] = tempByte[0];
            }

            // Create a binary reader
            MemoryStream msResult = new MemoryStream(resultByte);

            BinaryReader brResult = new BinaryReader(msResult);

            // Read the result
            result = brResult.ReadInt32();

            // Return result
            return result;
        }

        // -----------------
        // Read Bytes FLOAT
        // -----------------
        public float ReadBytesFloat(ref BinaryReader br)
        {
            float result;

            // Float is 4 bytes
            byte[] resultByte = new byte[4];
            byte[] tempByte = new byte[4];

            // Read the bytes
            resultByte[0] = br.ReadByte();
            resultByte[1] = br.ReadByte();
            resultByte[2] = br.ReadByte();
            resultByte[3] = br.ReadByte();

            if (m_SwapBytes == true)
            {
                tempByte[0] = resultByte[0];
                tempByte[1] = resultByte[1];
                tempByte[2] = resultByte[2];
                tempByte[3] = resultByte[3];

                resultByte[0] = tempByte[3];
                resultByte[1] = tempByte[2];
                resultByte[2] = tempByte[1];
                resultByte[3] = tempByte[0];
            }

            // Create a binary reader
            MemoryStream msResult = new MemoryStream(resultByte);
            BinaryReader brResult = new BinaryReader(msResult);

            // Read the result
            result = brResult.ReadSingle();

            // Return result
            return result;
        }

        // -------------------
        // Read Bytes DOUBLE
        // -------------------
        public double ReadBytesDouble(ref BinaryReader br)
        {
            double result;

            // Double is 8 bytes
            byte[] resultByte = new byte[8];
            byte[] tempByte = new byte[8];

            // Read the bytes
            resultByte[0] = br.ReadByte();
            resultByte[1] = br.ReadByte();
            resultByte[2] = br.ReadByte();
            resultByte[3] = br.ReadByte();
            resultByte[4] = br.ReadByte();
            resultByte[5] = br.ReadByte();
            resultByte[6] = br.ReadByte();
            resultByte[7] = br.ReadByte();

            if (m_SwapBytes == true)
            {
                tempByte[0] = resultByte[0];
                tempByte[1] = resultByte[1];
                tempByte[2] = resultByte[2];
                tempByte[3] = resultByte[3];
                tempByte[4] = resultByte[4];
                tempByte[5] = resultByte[5];
                tempByte[6] = resultByte[6];
                tempByte[7] = resultByte[7];

                resultByte[0] = tempByte[7];
                resultByte[1] = tempByte[6];
                resultByte[2] = tempByte[5];
                resultByte[3] = tempByte[4];
                resultByte[4] = tempByte[3];
                resultByte[5] = tempByte[2];
                resultByte[6] = tempByte[1];
                resultByte[7] = tempByte[0];

            }

            // Create a binary reader
            MemoryStream msResult = new MemoryStream(resultByte);
            BinaryReader brResult = new BinaryReader(msResult);

            // Read the result
            result = brResult.ReadDouble();

            // Return result
            return result;
        }


        // ------------------
        // Read Bytes SHORT
        // ------------------
        public short ReadBytesShort(ref BinaryReader br)
        {
            short result;

            // Short is 2 bytes
            byte[] resultByte = new byte[2];
            byte[] tempByte = new byte[2];

            // Read the bytes
            resultByte[0] = br.ReadByte();
            resultByte[1] = br.ReadByte();

            if (m_SwapBytes == true)
            {
                tempByte[0] = resultByte[0];
                tempByte[1] = resultByte[1];

                resultByte[0] = tempByte[1];
                resultByte[1] = tempByte[0];
            }

            // Create a binary reader
            MemoryStream msResult = new MemoryStream(resultByte);
            BinaryReader brResult = new BinaryReader(msResult);

            // Read the result
            result = brResult.ReadInt16();

            // Return result
            return result;
        }
    }
}
