//------------------------------------------------------------------------------
// Copyright           : Copyright (c) BAE Systems Ltd, Hillend
//                       The copyright of this software is the property of BAE Systems Ltd.
//                 The software is supplied by BAE Systems Ltd on the express terms
//                 that it is to be treated as confidential, and that it may not
//                 be copied, used or disclosed to others for any purpose
//                       except as authorised in writing by this company.
//
// Project Title       : PSC Generic Build
// CSCI                : Simulation Control
// Module Title        : PIPComms.cs
// Classification      : Unclassified
// Language            : C#
// Operating System    : Windows XP
// SDA                 : Clare Egglishaw
//------------------------------------------------------------------------------

// ------------------
// Using directives
// ------------------
// System packages
using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Collections;

// ------------------
// Class declaration
// ------------------

namespace PSCGenericBuild
{
    /// <summary>
    /// PIP Comms Class
    /// PIP-PSC Communications Class
    /// This class caters for the network communications between the PIP and PSC.
    /// </summary>
    public class PIPComms : Comms
    {

        // ------------
        // Class Data
        // ------------

        // Size of PIPExerciseData
        private const int PIPEXERCISEDATA_BYTES = 8;
        // Size of NUMBEROFSENSORS
        private const int NUMBEROFSENSORS = 4;
        // Size of PIPPeriscopeData
        private const int PIPPERISCOPEDATA_BYTES = 16;
        // Size of PIPEnvironmentData
        private const int PIPENVIRONMENTDATA_BYTES = 52;
        // Size of PIPOwnboatData
        private const int PIPOWNBOATDATA_BYTES = 64;
        // Size of PIPTargetData
        private const int PIPTARGETDATA_BYTES = 56;

        // Size of PIPRetPeriscopeData
        private const int PIPRETPERISCOPEDATA_BYTES = 28;
        // Size of PIPRetPolyniaData
        private const int PIPRETPOLYNIADATA_BYTES = 24;
        // Size of PIPRETENVIRONMENTDATA
        private const int PIPRETENVIRONMENTDATA_BYTES = 116;

        // Size of input message
        // PIPInputPacket + 4 because number of targets is not read into PIPInputPacket
        public const int PIPINPUTMSG_MIN_BYTES =
            4 +                                                   // Message count
            PIPEXERCISEDATA_BYTES +                               // Exercise
            PIPPERISCOPEDATA_BYTES * NUMBEROFSENSORS +            // Periscope
            PIPENVIRONMENTDATA_BYTES +                            // Environment
            PIPOWNBOATDATA_BYTES +                                // Ownboat
            4;                                                    // Checksum

        public const int PIPINPUTMSG_MAX_BYTES =
            4 +                                                   // Message count
            PIPEXERCISEDATA_BYTES +                               // Exercise
            PIPPERISCOPEDATA_BYTES * NUMBEROFSENSORS +            // Periscope
            PIPENVIRONMENTDATA_BYTES +                            // Environment
            PIPOWNBOATDATA_BYTES +                                // Ownboat
            4 +                                                   // Number of targets
            (SIMControl.NUM_PERI_TARGETS * PIPTARGETDATA_BYTES) + // Targets
            4;                                                    // Checksum

        // Size of PIPOutputPacket
        public const int PIPOUTPUTPACKET_BYTES =
            4 +                                                   // Message count
            (PIPRETPERISCOPEDATA_BYTES * NUMBEROFSENSORS) +       // Periscope
            4 +                                                   // Number of Polynia
            (SIMControl.NUM_POLYNIA_TARGETS * PIPRETPOLYNIADATA_BYTES) + // Polynia
            PIPRETENVIRONMENTDATA_BYTES +                         // Environment
            4;                                                     // Checksum;

        public const float DEG_TO_DEC = 91.0222223f;

        private String    m_PIPName;
        private IPAddress m_IPAddress;
        private int       m_Port;
        private float     m_RateOut;
        private SIMControl   m_SimControl;

        private Socket    m_SocketOut;
        private Socket    m_SocketIn;
        private IPEndPoint   m_EndPointPIP;

        private  PIPOutputPacket m_PIPOutputPacket;
        // The data received from the PIP that needs to be reordered to match the PIG data
        private  PIPInputPacket  m_PIPInputPacket;
        // The reordered data - gets copied back into m_PIPInputPacket;
        private PIPInputPacket reordered_pip_input_packet;
        // The target slot numbers being sent to the PIG
        private int[] pig_target_slot_no;
        // Whether the target slot data has been received in the message from the PIP
        private bool[] pig_target_slot_no_updated;


        public int m_IterateOut;
        public int m_CountOut;

        private byte[]     m_BufferIn;
        private byte[]    m_BufferOut;

        // ---------------------------
        // PIP Packet Data Structures
        // ---------------------------

        public int   num_targets_from_pip;

        public struct PIPExerciseData
        {
            public byte bRunMode;
            public byte bHours;
            public byte bMinutes;
            public byte bSeconds;
            public byte bDay;
            public byte bMonth;
            public byte bYear;
            public byte bSpare;
        }

        public struct PIPPeriscopeData
        {
            public byte  bFlags;
            public byte  bMagnification;
            public byte  bDrainDownTime;
            public byte  bLLTVGain;
            public byte  bTIGain;
            public float fRelBrg;
            public float fElevation;
        }

        public struct PIPEnvironmentData
        {
            public byte  bFlags;
            public byte  bWeather;
            public byte  bCoastline;
            public byte  bSeaState;
            public float fMoonBearing;
            public float fMoonElevation;
            public float fVisualRange;
            public float fUnderWaterRange;
            public float fTIRange;
            public float fWindSpeed;
            public float fWindHeading;
            public float fIceLat;
            public float fIceLong;
            public float fIceOrientation;
            public float fSunBearing;
            public float fSunElevation;
        }

        public struct PIPOwnboatData
        {
            public double dLatitude;
            public double dLongitude;
            public float  fDepth;
            public float  fClimbRate;
            public float  fTurnRate;
            public float  fPitch;
            public float  fHeading;
            public float  fDriftCourse;
            public float  fSpeed;
            public float  fDriftSpeed;
            public byte   bFlags;
            public byte   bMastRESM;
            public byte   bMastWTComms;
            public byte   bMastHFDF;
            public byte   bMastAttack;
            public byte   bMastRadar;
            public byte   bMastSnortInd;
            public byte   bMastSnortExh;
            public byte   bOwnBoatType;
            //public byte   bSpare1;
            //public byte   bSpare2;
            //public byte   bSpare3;
        }

        public struct PIPTargetData
        {
            public byte  bFlags;
            public byte  bDunkingSonar;
            public byte  bLightConfig;
            public byte  bSpotConfig;
            public int   iModelNum;
            public int   iSlotNum;
            public float fX;
            public float fY;
            public float fDepth;
            public float fClimbRate;
            public float fTurnRate;
            public float fPitch;
            public float fHeading;
            public float fDriftCourse;
            public float fSpeed;
            public float fDriftSpeed;
            public byte  bExtraFlags;
            public byte  bSpare1;
            public byte  bSpare2;
            public byte  bSpare3;
        }


        public struct PIPRetPolyniaData
        {
            public int iRetPolIdentity;
            public byte bRetPolPresent;
            public byte bSpare1;
            public byte bSpare2;
            public byte bSpare3;
            public float fRetPolX;
            public float fRetPolY;
            public float fRetPolZ;
            public float fRetPolOrien;
        }


        public struct PIPInputPacket
        {
            public int                  iMessageCounter;
            public PIPExerciseData      exerciseData;
            public PIPPeriscopeData     periscopeData;
            public PIPEnvironmentData   environmentData;
            public PIPOwnboatData       ownboatData;
            public PIPTargetData        [] target;
            public int                  iCheckSum;
        }

        public struct PIPOutputPacket
        {
            public int      iRetMessageCounter;
            public byte    bRetPeriFlags;
            public byte    bRetPeriMagnification;
            public byte    bRetPeriLLTVGain;
            public byte    bRetPeriTIGain;
            public byte    bSpare;
            public byte[]  bRetTWSH;         // 8 entries
            public float   fRetPeriRelBrg;
            public float   fRetPeriElev;
            public float   fRetPeriSunBrg;
            public float   fRetPeriSunElev;
            public byte[]  bRetPeriError;    // 100 entries
            public int     iNumPolynia;
            public PIPRetPolyniaData [] retPolynia;
            public int iRetCheckSum;
        }




        // ----------------------
        //  PIPComms Constructor
        // ----------------------
        public PIPComms(String name, String ipAddress, String port, String rateOut, String swap, SIMControl simControl)
        {


            //
            // Initialise PIP network data from passed parameters
            //
            m_PIPName = name;
            m_IPAddress = IPAddress.Parse(ipAddress);
            m_Port = System.Convert.ToInt32(port);
            m_RateOut = System.Convert.ToSingle(rateOut);

            if (swap == "YES")
                m_SwapBytes = true;
            else
                m_SwapBytes = false;

            m_SimControl = simControl;


            //
            // Initialise space for arrays
            //
            m_BufferIn = new byte[PIPINPUTMSG_MAX_BYTES];
            m_BufferOut = new byte[PIPOUTPUTPACKET_BYTES];

            m_PIPInputPacket.target = new PIPTargetData[SIMControl.NUM_PERI_TARGETS];
            reordered_pip_input_packet.target = new PIPTargetData[SIMControl.NUM_PERI_TARGETS];
            pig_target_slot_no = new int[SIMControl.NUM_PERI_TARGETS];
            pig_target_slot_no_updated = new bool[SIMControl.NUM_PERI_TARGETS];
            m_PIPOutputPacket.bRetTWSH = new byte[8];
            m_PIPOutputPacket.bRetPeriError = new byte[100];
            m_PIPOutputPacket.retPolynia = new PIPRetPolyniaData[SIMControl.NUM_POLYNIA_TARGETS];

            // Initialize to no targets being sent to PIG
            int X;
            for (X = 0; X < SIMControl.NUM_PERI_TARGETS; X++)
            {
                pig_target_slot_no[X] = -1;
                pig_target_slot_no_updated[X] = false;
            }


            //
            // Set the output iterate times.
            // This is the number of the iteration at which the output is required.
            // Must be greater than one i.e. can't input/output faster than application iteration rate.
            //
            m_IterateOut = (int) ((float) m_SimControl.m_AppIterationRate / m_RateOut);

            if (m_IterateOut < 1)
                m_IterateOut = 1;

            m_CountOut = 0;


            //
            // Create the Output network socket - TCP/IP
            //
            m_EndPointPIP = new IPEndPoint(m_IPAddress, m_Port);
            OpenPIPOutputSocket();


            //
            // Create the Input network socket - UDP
            //
            m_EndPointPIP = new IPEndPoint(m_IPAddress, m_Port);
            OpenPIPInputSocket();

        }


        // ----------------------
        //  PIPComms Destructor
        // ----------------------
        ~PIPComms()
        {
            // Shutdown the sockets for both send and receive
            ClosePIPInputSocket();
            ClosePIPOutputSocket();

            Console.WriteLine("PIP Comms: {0} Shutdown.", m_PIPName);
        }


        // ----------------------
        //  PIPComms Update
        // ----------------------
        public void Update()
        {
            int iBytesIn = 0;
            int iBytesOut = 0;


            //
            // If emulating PIP don't do any network checks
            //
            if (m_SimControl.m_SIMEmulatingPIP)
                return;

            //
            // Perform output at RateOut
            //

            /* this only happens 1 in 15 */
            if (m_CountOut == m_IterateOut)
            {
                // Console.WriteLine("******************************************************   PIP Comms: OUTPUT");


                //
                // Update the PIP Comms data from SimControl using accessor methods
                //
                GetDataFromSimControl();
                //
                // Encode the network data into a byte buffer
                //
                EncodeBufferOut();
                //
                // Send the buffer out on the network
                //
                try
                {

                    iBytesOut = m_SocketOut.Send(m_BufferOut);

                    // Update SimControl network metrics
                    m_SimControl.m_PIPBytesOut = iBytesOut;
                    m_SimControl.m_PIPArrayTimesOut[m_SimControl.m_PIPArrayIndexOut] = m_SimControl.m_SIMTimeStamp1;
                    m_SimControl.m_PIPArrayIndexOut++;
                    if (m_SimControl.m_PIPArrayIndexOut > 9)
                        m_SimControl.m_PIPArrayIndexOut = 0;


                }
                catch(Exception e)
                {
                    Console.WriteLine("");
                    Console.WriteLine("PIP Comms: Unable to SEND data...creating new socket." + e.ToString());
                    Console.WriteLine("");

                    // Error Log: Send failure
                    m_SimControl.WriteToErrorLog("SEND_FAIL", "PIP");

                    // Close the socket and create a new one
                    ClosePIPOutputSocket();
                    OpenPIPOutputSocket();
                }

                //
                // Reset the counter
                //
                m_CountOut = 0;

            }


            //
            // Check if data is available from the PIP network.
            // If it is then get it and update the PIP Comms data, then update any
            // data in the SimControl object.
            //
            if (m_SocketIn.Available > 0)
            {
                // Get the data from the network and put it into the input byte buffer
                EndPoint tempRemoteEP = (EndPoint)m_EndPointPIP;

                try
                {
                    iBytesIn = m_SocketIn.ReceiveFrom(m_BufferIn, ref tempRemoteEP);

                    // Update SimControl network metrics
                    m_SimControl.m_PIPBytesIn = iBytesIn;
                    m_SimControl.m_PIPArrayTimesIn[m_SimControl.m_PIPArrayIndexIn] = m_SimControl.m_SIMTimeStamp1;
                    m_SimControl.m_PIPArrayIndexIn++;
                    if (m_SimControl.m_PIPArrayIndexIn > 9)
                        m_SimControl.m_PIPArrayIndexIn = 0;

                    // Error Log: Check bytes in
                    if ((m_SimControl.m_PIPBytesIn < PIPINPUTMSG_MIN_BYTES) ||
                        (m_SimControl.m_PIPBytesIn > PIPINPUTMSG_MAX_BYTES))
                        m_SimControl.WriteToErrorLog("NUMBER_BYTES", "PIP");

                }
                catch(Exception e)
                {
                    Console.WriteLine("");
                    Console.WriteLine("PIP Comms: Unable to RECEIVE data...creating new socket." + e.ToString());
                    Console.WriteLine("");

                    // Error Log: Receive failure
                    m_SimControl.WriteToErrorLog("RECEIVE_FAIL", "PIP");

                    // Close the socket and create a new one
                    ClosePIPInputSocket();
                    OpenPIPInputSocket();

                    // No point in reading anything if there was an error
                    iBytesIn = 0;

                }

                if (iBytesIn > 0)
                {
                    //Console.WriteLine("PIP BytesIn: {0}", iBytesIn);

                    // Decode the network byte buffer to PIP Comms data
                    DecodeBufferIn();

                    // Update the return data in SIMControl via accesor methods
                    SetDataInSimControl();
                }
            }



            //
            // Update the counter
            //
            m_CountOut++;

        }



        // ------------------------------------
        // Open Network Output Socket
        // ------------------------------------
        private  void OpenPIPOutputSocket()
        {
            //
            // Create a new TCP/IP socket and ensure it doesn't block
            //
            m_SocketOut = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            // Print out the data
            Console.WriteLine("");
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("PIP Comms: Creating OUTPUT Socket...");
            Console.WriteLine("\t Name: \t\t{0}", m_PIPName);
            Console.WriteLine("\t IPAddress: \t{0}", m_IPAddress);
            Console.WriteLine("\t Port: \t\t{0}", m_Port);
            Console.WriteLine("\t Rate Out: \t{0}", m_RateOut);
            Console.WriteLine("\t Swap Bytes: \t{0}", m_SwapBytes);
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("");

            try
            {
                m_SocketOut.Connect(m_EndPointPIP);
                m_SocketOut.Blocking = false;
            }
            catch
            {
                Console.WriteLine("PIP Comms: Creating OUTPUT Socket...FAILED");
            }
        }


        // ---------------------------
        // Open Network Input Socket
        // ---------------------------
        private  void OpenPIPInputSocket()
        {
            try
            {
                //
                // Create a new UDP socket and ensure it doesn't block.
                // UDP socket has to be bound to local endpoint
                //
                EndPoint localEP = new IPEndPoint(m_SimControl.m_IPAddressPIPNet, m_SimControl.m_PortPIPNet);
                m_SocketIn = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                m_SocketIn.Blocking = false;
                m_SocketIn.Bind(localEP);

                // Print out the data
                Console.WriteLine("");
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("PIP Comms: Creating INPUT Socket...");
                Console.WriteLine("\t Name: \t\t{0}", m_PIPName);
                Console.WriteLine("\t IPAddress: \t{0}", m_IPAddress);
                Console.WriteLine("\t Port: \t\t{0}", m_Port);
                Console.WriteLine("\t Swap Bytes: \t{0}", m_SwapBytes);
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("");
            }
            catch
            {
                // Print out error message
                Console.WriteLine("");
                Console.WriteLine("------------ERROR----------------");
                Console.WriteLine("PIP Comms: Could not create INPUT Socket...");
                Console.WriteLine("\t Name: \t\t{0}", m_PIPName);
                Console.WriteLine("\t IPAddress: \t{0}", m_IPAddress);
                Console.WriteLine("\t Port: \t\t{0}", m_Port);
                Console.WriteLine("\t Swap Bytes: \t{0}", m_SwapBytes);
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("");
            }
        }



        // ----------------------------
        // Close Network Output Socket
        // ----------------------------
        private  void ClosePIPOutputSocket()
        {
            //
            // Shutdown the socket for both send and receive
            // then close it to free resources
            //
            try
            {
                m_SocketOut.Shutdown(SocketShutdown.Both);
                m_SocketOut.Close();
            }
            catch
            {
                // Socket not valid anyway
            }

        }



        // ----------------------------
        // Close Network Input Socket
        // ----------------------------
        private  void ClosePIPInputSocket()
        {
            //
            // Shutdown the socket for both send and receive
            // then close it to free resources
            //
            try
            {
                m_SocketIn.Shutdown(SocketShutdown.Both);
                m_SocketIn.Close();
            }
            catch
            {
                // Socket not valid anyway
            }

        }



        // ------------------------------------
        // Get Update From SimControl Method
        // ------------------------------------
        private  void GetDataFromSimControl()
        {
            int i;

            // Update message counter
            m_SimControl.m_PIPMessageCountOut++;
            m_PIPOutputPacket.iRetMessageCounter = m_SimControl.m_PIPMessageCountOut;

            // Combine individual bool flags into an integer value
            bool[] boolValue = new bool[4];
            boolValue[0] = m_SimControl.m_PIPRetSearchUp.GetResultValue();
            boolValue[1] = m_SimControl.m_PIPRetPolarityWhite.GetResultValue();
            boolValue[2] = m_SimControl.m_PIPRetHandlesUp.GetResultValue();
            BitArray bitArray = new BitArray(boolValue);
            Array dataArray = Array.CreateInstance( typeof(byte), 1 );
            bitArray.CopyTo( dataArray, 0 );
            m_PIPOutputPacket.bRetPeriFlags = (byte) dataArray.GetValue(0);

            if (m_SimControl.m_PIPRetHighMag.GetResultValue())
                m_PIPOutputPacket.bRetPeriMagnification = (byte) 1;
            else
                m_PIPOutputPacket.bRetPeriMagnification = (byte) 0;
            m_PIPOutputPacket.bRetPeriLLTVGain = m_SimControl.m_PIPRetPeriLLTVGain.GetResultValue();
            m_PIPOutputPacket.bRetPeriTIGain = m_SimControl.m_PIPRetPeriTIGain.GetResultValue();

            // Format TWSH message

            // Copy target true bearing into a bit array of 32 bits (int)
            int[] tarTrueBrg = new int[1];
            tarTrueBrg[0] = (int) (m_SimControl.m_PIPRetTWSHTarTrueBrg.GetResultValue() * DEG_TO_DEC);
            BitArray bitTarTrueBrg = new BitArray(tarTrueBrg);

            // Copy peri true bearing into a bit array of 32 bits (int)
            int[] periTrueBrg = new int[1];
            periTrueBrg[0] = (int) (m_SimControl.m_PIPRetTWSHPeriTrueBrg.GetResultValue() * DEG_TO_DEC);
            BitArray bitPeriTrueBrg = new BitArray(periTrueBrg);

            // Copy elapsed time into a bit array of 32 bits (int)
            int[] elapsedTime = new int[1];
            elapsedTime[0] = (int) m_SimControl.m_PIPRetTWSHTarElpsdTime.GetResultValue();
            BitArray bitElapsedTime = new BitArray(elapsedTime);

            // Copy target range into a bit array of 32 bits (int)
            int[] tarRange = new int[1];
            tarRange[0] = (int) m_SimControl.m_PIPRetTWSHTarRange.GetResultValue();
            BitArray bitTarRange = new BitArray(tarRange);

            // Create a bit array of 64 bits to hold the TWSH message
            BitArray bitTWSH = new BitArray(64);

            // Bits 0-14 are target true bearing bits 0-14 (rest is discarded)
            for (i = 0; i <= 14; i++)
                bitTWSH[i] = bitTarTrueBrg[i];

            // Bit 15 is target true bearing cut
            if (m_SimControl.m_PIPRetTWSHTarTrueBrgCut.GetResultValue())
                bitTWSH[15] = true;

            // Bits 16-30 are peri true bearing bits 0-14 (rest is discarded)
            for (i = 16; i <= 30; i++)
                bitTWSH[i] = bitPeriTrueBrg[i - 16];

            // Bit 31 is always 1
            bitTWSH[31] = true;

            // Bits 32-46 are elapsed time bits 0-14 (rest is discarded)
            for (i = 32; i <= 46; i++)
                bitTWSH[i] = bitElapsedTime[i - 32];

            // Bit 47 is elapsed time cut
            if (m_SimControl.m_PIPRetTWSHTarElpsdTimeCut.GetResultValue())
                bitTWSH[47] = true;

            // Bits 48-62 are target range bits 0-14 (rest is discarded)
            for (i = 48; i <= 62; i++)
                bitTWSH[i] = bitTarRange[i - 48];

            // Bit 63 is target range cut
            if (m_SimControl.m_PIPRetTWSHTarRangeCut.GetResultValue())
                bitTWSH[63] = true;

            // Change order of bits
            BitArray bitTWSHReOrder = new BitArray(64);

            bitTWSHReOrder[0] = bitTWSH[24];
            bitTWSHReOrder[1] = bitTWSH[25];
            bitTWSHReOrder[2] = bitTWSH[26];
            bitTWSHReOrder[3] = bitTWSH[27];
            bitTWSHReOrder[4] = bitTWSH[28];
            bitTWSHReOrder[5] = bitTWSH[29];
            bitTWSHReOrder[6] = bitTWSH[30];
            bitTWSHReOrder[7] = bitTWSH[31];
            bitTWSHReOrder[8] = bitTWSH[16];
            bitTWSHReOrder[9] = bitTWSH[17];
            bitTWSHReOrder[10] = bitTWSH[18];
            bitTWSHReOrder[11] = bitTWSH[19];
            bitTWSHReOrder[12] = bitTWSH[20];
            bitTWSHReOrder[13] = bitTWSH[21];
            bitTWSHReOrder[14] = bitTWSH[22];
            bitTWSHReOrder[15] = bitTWSH[23];
            bitTWSHReOrder[16] = bitTWSH[8];
            bitTWSHReOrder[17] = bitTWSH[9];
            bitTWSHReOrder[18] = bitTWSH[10];
            bitTWSHReOrder[19] = bitTWSH[11];
            bitTWSHReOrder[20] = bitTWSH[12];
            bitTWSHReOrder[21] = bitTWSH[13];
            bitTWSHReOrder[22] = bitTWSH[14];
            bitTWSHReOrder[23] = bitTWSH[15];
            bitTWSHReOrder[24] = bitTWSH[0];
            bitTWSHReOrder[25] = bitTWSH[1];
            bitTWSHReOrder[26] = bitTWSH[2];
            bitTWSHReOrder[27] = bitTWSH[3];
            bitTWSHReOrder[28] = bitTWSH[4];
            bitTWSHReOrder[29] = bitTWSH[5];
            bitTWSHReOrder[30] = bitTWSH[6];
            bitTWSHReOrder[31] = bitTWSH[7];

            int x = 32;
            bitTWSHReOrder[0+x] = bitTWSH[24+x];
            bitTWSHReOrder[1+x] = bitTWSH[25+x];
            bitTWSHReOrder[2+x] = bitTWSH[26+x];
            bitTWSHReOrder[3+x] = bitTWSH[27+x];
            bitTWSHReOrder[4+x] = bitTWSH[28+x];
            bitTWSHReOrder[5+x] = bitTWSH[29+x];
            bitTWSHReOrder[6+x] = bitTWSH[30+x];
            bitTWSHReOrder[7+x] = bitTWSH[31+x];
            bitTWSHReOrder[8+x] = bitTWSH[16+x];
            bitTWSHReOrder[9+x] = bitTWSH[17+x];
            bitTWSHReOrder[10+x] = bitTWSH[18+x];
            bitTWSHReOrder[11+x] = bitTWSH[19+x];
            bitTWSHReOrder[12+x] = bitTWSH[20+x];
            bitTWSHReOrder[13+x] = bitTWSH[21+x];
            bitTWSHReOrder[14+x] = bitTWSH[22+x];
            bitTWSHReOrder[15+x] = bitTWSH[23+x];
            bitTWSHReOrder[16+x] = bitTWSH[8+x];
            bitTWSHReOrder[17+x] = bitTWSH[9+x];
            bitTWSHReOrder[18+x] = bitTWSH[10+x];
            bitTWSHReOrder[19+x] = bitTWSH[11+x];
            bitTWSHReOrder[20+x] = bitTWSH[12+x];
            bitTWSHReOrder[21+x] = bitTWSH[13+x];
            bitTWSHReOrder[22+x] = bitTWSH[14+x];
            bitTWSHReOrder[23+x] = bitTWSH[15+x];
            bitTWSHReOrder[24+x] = bitTWSH[0+x];
            bitTWSHReOrder[25+x] = bitTWSH[1+x];
            bitTWSHReOrder[26+x] = bitTWSH[2+x];
            bitTWSHReOrder[27+x] = bitTWSH[3+x];
            bitTWSHReOrder[28+x] = bitTWSH[4+x];
            bitTWSHReOrder[29+x] = bitTWSH[5+x];
            bitTWSHReOrder[30+x] = bitTWSH[6+x];
            bitTWSHReOrder[31+x] = bitTWSH[7+x];

            Array byteArray = Array.CreateInstance(typeof(byte), 8);
            bitTWSHReOrder.CopyTo(byteArray, 0);

            for (i = 0; i < 8; i++)
                m_PIPOutputPacket.bRetTWSH[i] = (byte) byteArray.GetValue(i);

            // Print out the TWSH bits if requested
            //if (m_SimControl.m_PrintTWSHBits)
            //{
            //for (i = 0; i < bitTWSH.Count; i++)
            //    Console.WriteLine("Bit {0}: {1}", i, bitTWSH[i]);
            //}

            if (m_SimControl.m_PrintTWSHBits)
            {
                Console.WriteLine("");

                for (i = 0; i < bitTWSHReOrder.Count; i++)
                {
                    if (bitTWSHReOrder[i] == true)
                        Console.Write("1");
                    else
                        Console.Write("0");
                }

            }

            // Reset the TWSH flags
            m_SimControl.m_PIPRetTWSHTarTrueBrgCut.SetRawValue(false);
            m_SimControl.m_PIPRetTWSHTarRangeCut.SetRawValue(false);
            m_SimControl.m_PIPRetTWSHTarElpsdTimeCut.SetRawValue(false);

            m_PIPOutputPacket.fRetPeriRelBrg = m_SimControl.m_PIPRetPeriRelBrg.GetResultValue();
            m_PIPOutputPacket.fRetPeriElev = m_SimControl.m_PIPRetPeriElev.GetResultValue();
            m_PIPOutputPacket.fRetPeriSunBrg = m_SimControl.m_PIPRetPeriSunBrg.GetResultValue();
            m_PIPOutputPacket.fRetPeriSunElev = m_SimControl.m_PIPRetPeriSunElev.GetResultValue();

            // Error message (100 bytes)
            string message = m_SimControl.m_PIPRetPeriErrorString.GetResultValue();

            int length = message.Length;

            // Check length limit
            if (length > 98)
                length = 98;

            CharEnumerator messageEnumerator = message.GetEnumerator();

            m_PIPOutputPacket.bRetPeriError[0] = (byte) m_SimControl.m_PIPRetPeriErrorNo.GetResultValue();
            m_PIPOutputPacket.bRetPeriError[1] = (byte) length;

            for (i = 2; i < length + 2; i++)
            {
                messageEnumerator.MoveNext();
                m_PIPOutputPacket.bRetPeriError[i] = (byte) messageEnumerator.Current;
            }

            m_PIPOutputPacket.iNumPolynia = m_SimControl.m_PIPRetNumPolynia.GetResultValue();

            for (i = 0; i < SIMControl.NUM_POLYNIA_TARGETS; i++)
            {
                m_PIPOutputPacket.retPolynia[i].iRetPolIdentity = m_SimControl.m_PIPRetPolynia[i].m_PIPRetPolIdentity.GetResultValue();
                m_PIPOutputPacket.retPolynia[i].bRetPolPresent = m_SimControl.m_PIPRetPolynia[i].m_PIPRetPolPresent.GetResultValue();

                m_PIPOutputPacket.retPolynia[i].fRetPolX = m_SimControl.m_PIPRetPolynia[i].m_PIPRetPolX.GetResultValue();
                m_PIPOutputPacket.retPolynia[i].fRetPolY = m_SimControl.m_PIPRetPolynia[i].m_PIPRetPolY.GetResultValue();
                m_PIPOutputPacket.retPolynia[i].fRetPolZ = m_SimControl.m_PIPRetPolynia[i].m_PIPRetPolZ.GetResultValue();
                m_PIPOutputPacket.retPolynia[i].fRetPolOrien = m_SimControl.m_PIPRetPolynia[i].m_PIPRetPolOrientation.GetResultValue();
            }

            m_PIPOutputPacket.iRetCheckSum = m_SimControl.m_PIPRetCheckSum.GetResultValue();

        }



        // --------------------------
        // Encode Buffer Out Method
        // --------------------------
        private void EncodeBufferOut()
        {
            int i;

            int checkSum = 0;
            byte[] buffOut;

            MemoryStream ms = new MemoryStream();
            BinaryWriter bw = new BinaryWriter(ms);

            //
            // Start writing bytes - must be correct order
            // Note that WriteBytes does any byte swapping required
            //
            WriteBytes(ref bw, m_PIPOutputPacket.iRetMessageCounter);

            WriteBytes(ref bw, m_PIPOutputPacket.bRetPeriFlags);
            WriteBytes(ref bw, m_PIPOutputPacket.bRetPeriMagnification);
            WriteBytes(ref bw, m_PIPOutputPacket.bRetPeriLLTVGain);
            WriteBytes(ref bw, m_PIPOutputPacket.bRetPeriTIGain);


            for (i = 0; i < 8; i++)
                WriteBytes(ref bw, m_PIPOutputPacket.bRetTWSH[i]);

            WriteBytes(ref bw, m_PIPOutputPacket.fRetPeriRelBrg);
            WriteBytes(ref bw, m_PIPOutputPacket.fRetPeriElev);
            WriteBytes(ref bw, (float) 0.0);         // Mast Extension
            WriteBytes(ref bw, (byte) 0);            // TI Black Level
            WriteBytes(ref bw, (byte) 0);            // Sensor Type
            WriteBytes(ref bw, (byte) 0);            // Spare
            WriteBytes(ref bw, (byte) 0);            // Spare
            // Output zeros for the other three Sensor Control blocks
            for (i = 0 ; i < PIPRETPERISCOPEDATA_BYTES * (NUMBEROFSENSORS - 1); i++)
                WriteBytes(ref bw, (byte) 0);

            WriteBytes(ref bw, m_PIPOutputPacket.iNumPolynia);

            for (i = 0; i < SIMControl.NUM_POLYNIA_TARGETS; i++)
            {
                WriteBytes(ref bw, m_PIPOutputPacket.retPolynia[i].iRetPolIdentity);
                WriteBytes(ref bw, m_PIPOutputPacket.retPolynia[i].bRetPolPresent);
                WriteBytes(ref bw, (byte) 0);            // Spare
                WriteBytes(ref bw, (byte) 0);            // Spare
                WriteBytes(ref bw, (byte) 0);            // Spare

                WriteBytes(ref bw, m_PIPOutputPacket.retPolynia[i].fRetPolX);
                WriteBytes(ref bw, m_PIPOutputPacket.retPolynia[i].fRetPolY);
                WriteBytes(ref bw, m_PIPOutputPacket.retPolynia[i].fRetPolZ);
                WriteBytes(ref bw, m_PIPOutputPacket.retPolynia[i].fRetPolOrien);

            }

            WriteBytes(ref bw, m_PIPOutputPacket.fRetPeriSunBrg);
            WriteBytes(ref bw, m_PIPOutputPacket.fRetPeriSunElev);
            WriteBytes(ref bw, (float) 0.0);            // Moon Bearing
            WriteBytes(ref bw, (float) 0.0);            // Moon Elevation

            for (i = 0; i < 100; i++)
                WriteBytes(ref bw, m_PIPOutputPacket.bRetPeriError[i]);

            //
            // Create a temporary buffer, calculate the checksum value and then
            // write the value back into the byte stream
            //
            buffOut = ms.ToArray();

            for (i = 0; i < buffOut.Length; i++)
            {
                checkSum += buffOut[i];
            }

            WriteBytes(ref bw, checkSum);


            //
            // Set the output buffer
            //
            m_BufferOut = ms.ToArray();

        }



        // --------------------------
        // Decode Buffer In Method
        // --------------------------
        private  void DecodeBufferIn()
        {
            int i;
            MemoryStream ms = new MemoryStream(m_BufferIn);
            BinaryReader br = new BinaryReader(ms);

            //
            // Start reading bytes - must be correct order and size
            // Byte swap as required
            //

            //C_guiNetworkStatus.txtv = BitConverter.ToString(m_BufferIn);

            m_PIPInputPacket.iMessageCounter = ReadBytesInt(ref br);
            m_PIPInputPacket.exerciseData.bRunMode = ReadBytesByte(ref br);
            m_PIPInputPacket.exerciseData.bHours = ReadBytesByte(ref br);
            m_PIPInputPacket.exerciseData.bMinutes = ReadBytesByte(ref br);
            m_PIPInputPacket.exerciseData.bSeconds = ReadBytesByte(ref br);
            m_PIPInputPacket.exerciseData.bDay = ReadBytesByte(ref br);
            m_PIPInputPacket.exerciseData.bMonth = ReadBytesByte(ref br);
            m_PIPInputPacket.exerciseData.bYear = ReadBytesByte(ref br);
            m_PIPInputPacket.exerciseData.bSpare = ReadBytesByte(ref br);

            m_PIPInputPacket.periscopeData.bFlags = ReadBytesByte(ref br);
            m_PIPInputPacket.periscopeData.bMagnification = ReadBytesByte(ref br);
            m_PIPInputPacket.periscopeData.bDrainDownTime = ReadBytesByte(ref br);
            m_PIPInputPacket.periscopeData.bLLTVGain = ReadBytesByte(ref br);
            m_PIPInputPacket.periscopeData.fRelBrg = ReadBytesFloat(ref br);
            m_PIPInputPacket.periscopeData.fElevation = ReadBytesFloat(ref br);
            ReadBytesByte(ref br); // Skip over Sensor Type
            ReadBytesByte(ref br); // Skip over TI Black Level
            m_PIPInputPacket.periscopeData.bTIGain = ReadBytesByte(ref br);
            ReadBytesByte(ref br); // Skip over Spare

            // Skip over the other three Sensor Control blocks
            for (i = 0 ; i < PIPPERISCOPEDATA_BYTES * (NUMBEROFSENSORS - 1); i++)
                ReadBytesByte(ref br);

            m_PIPInputPacket.environmentData.bFlags = ReadBytesByte(ref br);
            m_PIPInputPacket.environmentData.bWeather = ReadBytesByte(ref br);
            m_PIPInputPacket.environmentData.bCoastline = ReadBytesByte(ref br);
            m_PIPInputPacket.environmentData.bSeaState = ReadBytesByte(ref br);

            m_PIPInputPacket.environmentData.fMoonBearing = ReadBytesFloat(ref br);
            m_PIPInputPacket.environmentData.fMoonElevation = ReadBytesFloat(ref br);
            m_PIPInputPacket.environmentData.fVisualRange = ReadBytesFloat(ref br);
            m_PIPInputPacket.environmentData.fUnderWaterRange = ReadBytesFloat(ref br);
            m_PIPInputPacket.environmentData.fTIRange = ReadBytesFloat(ref br);
            m_PIPInputPacket.environmentData.fWindSpeed = ReadBytesFloat(ref br);
            m_PIPInputPacket.environmentData.fWindHeading = ReadBytesFloat(ref br);
            m_PIPInputPacket.environmentData.fIceLat = ReadBytesFloat(ref br);
            m_PIPInputPacket.environmentData.fIceLong = ReadBytesFloat(ref br);
            m_PIPInputPacket.environmentData.fIceOrientation = ReadBytesFloat(ref br);
            m_PIPInputPacket.environmentData.fSunBearing = ReadBytesFloat(ref br);
            m_PIPInputPacket.environmentData.fSunElevation = ReadBytesFloat(ref br);

            m_PIPInputPacket.ownboatData.dLatitude = ReadBytesDouble(ref br);
            m_PIPInputPacket.ownboatData.dLongitude = ReadBytesDouble(ref br);
            m_PIPInputPacket.ownboatData.fDepth = ReadBytesFloat(ref br);
            m_PIPInputPacket.ownboatData.fClimbRate = ReadBytesFloat(ref br);
            m_PIPInputPacket.ownboatData.fTurnRate = ReadBytesFloat(ref br);
            m_PIPInputPacket.ownboatData.fPitch = ReadBytesFloat(ref br);
            m_PIPInputPacket.ownboatData.fHeading = ReadBytesFloat(ref br);
            m_PIPInputPacket.ownboatData.fDriftCourse = ReadBytesFloat(ref br);
            m_PIPInputPacket.ownboatData.fSpeed = ReadBytesFloat(ref br);
            m_PIPInputPacket.ownboatData.fDriftSpeed = ReadBytesFloat(ref br);

            m_PIPInputPacket.ownboatData.bFlags = ReadBytesByte(ref br);
            m_PIPInputPacket.ownboatData.bMastRESM = ReadBytesByte(ref br);
            m_PIPInputPacket.ownboatData.bMastWTComms = ReadBytesByte(ref br);
            m_PIPInputPacket.ownboatData.bMastHFDF = ReadBytesByte(ref br);
            m_PIPInputPacket.ownboatData.bMastAttack = ReadBytesByte(ref br);
            m_PIPInputPacket.ownboatData.bMastRadar = ReadBytesByte(ref br);
            m_PIPInputPacket.ownboatData.bMastSnortInd = ReadBytesByte(ref br);
            m_PIPInputPacket.ownboatData.bMastSnortExh = ReadBytesByte(ref br);
            ReadBytesByte(ref br); // Skip over SatCom
            ReadBytesByte(ref br); // Skip over NEST
            m_PIPInputPacket.ownboatData.bOwnBoatType = ReadBytesByte(ref br);
            ReadBytesByte(ref br); // Skip over Display Configuration
            ReadBytesInt(ref br); // Skip over own boat model number

            num_targets_from_pip = ReadBytesInt(ref br);
            //Console.WriteLine("**************************  num_targets_from_pip: {0}", num_targets_from_pip);

            // Must read all the data in as the checksum is read after this
            // The message is variable length so read the number of targets reported
            for (i = 0 ; i < num_targets_from_pip; i++)
            {
                m_PIPInputPacket.target[i].bFlags = ReadBytesByte(ref br);
                m_PIPInputPacket.target[i].bDunkingSonar = ReadBytesByte(ref br);
                m_PIPInputPacket.target[i].bLightConfig = ReadBytesByte(ref br);
                m_PIPInputPacket.target[i].bSpotConfig = ReadBytesByte(ref br);
                m_PIPInputPacket.target[i].iModelNum = ReadBytesInt(ref br);
                m_PIPInputPacket.target[i].iSlotNum = ReadBytesInt(ref br);
                m_PIPInputPacket.target[i].fX = ReadBytesFloat(ref br);
                m_PIPInputPacket.target[i].fY = ReadBytesFloat(ref br);
                m_PIPInputPacket.target[i].fDepth = ReadBytesFloat(ref br);
                m_PIPInputPacket.target[i].fClimbRate = ReadBytesFloat(ref br);
                m_PIPInputPacket.target[i].fTurnRate = ReadBytesFloat(ref br);
                m_PIPInputPacket.target[i].fPitch = ReadBytesFloat(ref br);
                m_PIPInputPacket.target[i].fHeading = ReadBytesFloat(ref br);
                m_PIPInputPacket.target[i].fDriftCourse = ReadBytesFloat(ref br);
                m_PIPInputPacket.target[i].fSpeed = ReadBytesFloat(ref br);
                m_PIPInputPacket.target[i].fDriftSpeed = ReadBytesFloat(ref br);
                m_PIPInputPacket.target[i].bExtraFlags = ReadBytesByte(ref br);
                m_PIPInputPacket.target[i].bSpare1 = ReadBytesByte(ref br);
                m_PIPInputPacket.target[i].bSpare2 = ReadBytesByte(ref br);
                m_PIPInputPacket.target[i].bSpare3 = ReadBytesByte(ref br);

            }
            // The data from the PIP has to be reordered to match the data sent to the PIG - slots must match
            bool matching_slot_not_found_yet;
            bool free_slot_not_found_yet;
            int input_target_entry;
            int reordered_target_entry;
            // int R;

            // Clear out the reordered_pip_input_packet entries
            // and indicate that none have been updated
            for (reordered_target_entry = 0; reordered_target_entry < SIMControl.NUM_PERI_TARGETS; reordered_target_entry++)
            {
                pig_target_slot_no_updated[reordered_target_entry] = false;
                reordered_pip_input_packet.target[reordered_target_entry].bFlags = 0;
                reordered_pip_input_packet.target[reordered_target_entry].bDunkingSonar = 0;
                reordered_pip_input_packet.target[reordered_target_entry].bLightConfig = 0;
                reordered_pip_input_packet.target[reordered_target_entry].bSpotConfig = 0;
                reordered_pip_input_packet.target[reordered_target_entry].iModelNum = 0;
                reordered_pip_input_packet.target[reordered_target_entry].iSlotNum = 0;
                reordered_pip_input_packet.target[reordered_target_entry].fX = 0;
                reordered_pip_input_packet.target[reordered_target_entry].fY = 0;
                reordered_pip_input_packet.target[reordered_target_entry].fDepth = 0;
                reordered_pip_input_packet.target[reordered_target_entry].fClimbRate = 0;
                reordered_pip_input_packet.target[reordered_target_entry].fTurnRate = 0;
                reordered_pip_input_packet.target[reordered_target_entry].fPitch = 0;
                reordered_pip_input_packet.target[reordered_target_entry].fHeading = 0;
                reordered_pip_input_packet.target[reordered_target_entry].fDriftCourse = 0;
                reordered_pip_input_packet.target[reordered_target_entry].fSpeed = 0;
                reordered_pip_input_packet.target[reordered_target_entry].fDriftSpeed = 0;
                reordered_pip_input_packet.target[reordered_target_entry].bExtraFlags = 0;
                reordered_pip_input_packet.target[reordered_target_entry].bSpare1 = 0;
                reordered_pip_input_packet.target[reordered_target_entry].bSpare2 = 0;
                reordered_pip_input_packet.target[reordered_target_entry].bSpare3 = 0;
            }

            // Loop through the targets received from the PIP
            for (input_target_entry = 0; input_target_entry < num_targets_from_pip; input_target_entry++)
            {
                matching_slot_not_found_yet = true;
                free_slot_not_found_yet = true;
                //Console.WriteLine("Doing PIP target {0} slot {1}", input_target_entry, m_PIPInputPacket.target[input_target_entry].iSlotNum);
                // Loop looking for a slot match in the current PIG targets
                for (reordered_target_entry = 0; (reordered_target_entry < SIMControl.NUM_PERI_TARGETS && matching_slot_not_found_yet); reordered_target_entry++)
                {
                    //Console.WriteLine("Checking PIG target {0} slot {1}", reordered_target_entry, pig_target_slot_no[reordered_target_entry]);
                    if (m_PIPInputPacket.target[input_target_entry].iSlotNum == pig_target_slot_no[reordered_target_entry])
                    {
                        // Match found
                        pig_target_slot_no_updated[reordered_target_entry] = true;
                        matching_slot_not_found_yet = false;
                        reordered_pip_input_packet.target[reordered_target_entry] = m_PIPInputPacket.target[input_target_entry];
                        //Console.WriteLine("Updating PIG target {0} slot {1}", reordered_target_entry, pig_target_slot_no[reordered_target_entry]);
                    }
                }
                // If match not found, find a free entry
                if (matching_slot_not_found_yet)
                {
                    for (reordered_target_entry = 0; (reordered_target_entry < SIMControl.NUM_PERI_TARGETS && free_slot_not_found_yet); reordered_target_entry++)
                    {
                        if (pig_target_slot_no[reordered_target_entry] == -1)
                        {
                            // Free entry found
                            reordered_pip_input_packet.target[reordered_target_entry] = m_PIPInputPacket.target[input_target_entry];
                            pig_target_slot_no[reordered_target_entry] = m_PIPInputPacket.target[input_target_entry].iSlotNum;
                            pig_target_slot_no_updated[reordered_target_entry] = true;
                            free_slot_not_found_yet = false;
                            //Console.WriteLine("New PIG target {0} slot {1}", reordered_target_entry, pig_target_slot_no[reordered_target_entry]);
                        }
                    }
                }
            }

            // Clear out any targets that did not get updated by the PIP
            for (reordered_target_entry = 0; reordered_target_entry < SIMControl.NUM_PERI_TARGETS; reordered_target_entry++)
            {
                if (pig_target_slot_no_updated[reordered_target_entry] == false)
                {
                    if (pig_target_slot_no[reordered_target_entry] != -1)
                    {
                        //Console.WriteLine("Clearing target {0} slot {1}", reordered_target_entry, pig_target_slot_no[reordered_target_entry]);
                        pig_target_slot_no[reordered_target_entry] = -1;
                    }
                }
                if (pig_target_slot_no[reordered_target_entry] != -1)
                {
                    //Console.WriteLine("PIG target {0} slot {1}", reordered_target_entry, pig_target_slot_no[reordered_target_entry]);
                }
            }

            // Copy the reordered targets back into the input packet
            for (reordered_target_entry = 0; reordered_target_entry < SIMControl.NUM_PERI_TARGETS; reordered_target_entry++)
            {
                m_PIPInputPacket.target[reordered_target_entry] = reordered_pip_input_packet.target[reordered_target_entry];
            }

            m_PIPInputPacket.iCheckSum = ReadBytesInt(ref br);

            //
            // Calculate the checksum
            //
            m_SimControl.m_SIMPIPCheckSum = 0;
            byte[] buffIn;


            buffIn = ms.ToArray();
            //C_guiNetworkStatus.txtv = BitConverter.ToString(buffIn);

            for (i = 0; i < m_SimControl.m_PIPBytesIn - 4; i++)
                m_SimControl.m_SIMPIPCheckSum += buffIn[i];

        }



        // -------------------------------------
        // Set Update Data In SimControl Method
        // -------------------------------------
        private void SetDataInSimControl()
        {
            int i;
            byte[]   byteValue = new byte[1];

            //
            // Update the raw data in SimControl
            //

            // Message counter (including error logging)
            m_SimControl.m_SIMPIPLastMessage = m_SimControl.m_PIPMessageCountIn;
            m_SimControl.m_PIPMessageCountIn = m_PIPInputPacket.iMessageCounter;

            if (m_SimControl.m_PIPMessageCountIn != (m_SimControl.m_SIMPIPLastMessage + 1))
                m_SimControl.WriteToErrorLog("MESSAGE_SYNC", "PIP");

            // Exercise flag - split byte flag into individual bit values
            byteValue[0] = m_PIPInputPacket.exerciseData.bRunMode;
            BitArray bitArrayExFlag = new BitArray(byteValue);
            if (bitArrayExFlag[0])
                m_SimControl.m_PIPExRunMode.SetRawValue((byte) 0);
            else if (bitArrayExFlag[1])
                m_SimControl.m_PIPExRunMode.SetRawValue((byte) 1);
            else if (bitArrayExFlag[2])
                m_SimControl.m_PIPExRunMode.SetRawValue((byte) 2);
            else if (bitArrayExFlag[3])
                m_SimControl.m_PIPExRunMode.SetRawValue((byte) 3);
            else
                m_SimControl.m_PIPExRunMode.SetRawValue((byte) 0);

            m_SimControl.m_PIPExHours.SetRawValue(m_PIPInputPacket.exerciseData.bHours);
            m_SimControl.m_PIPExMins.SetRawValue(m_PIPInputPacket.exerciseData.bMinutes);
            m_SimControl.m_PIPExSecs.SetRawValue(m_PIPInputPacket.exerciseData.bSeconds);
            m_SimControl.m_PIPExDay.SetRawValue(m_PIPInputPacket.exerciseData.bDay);
            m_SimControl.m_PIPExMonth.SetRawValue(m_PIPInputPacket.exerciseData.bMonth);
            m_SimControl.m_PIPExYear.SetRawValue(m_PIPInputPacket.exerciseData.bYear);

            // Periscope flag - split byte flag into individual bit values
            byteValue[0] = m_PIPInputPacket.periscopeData.bFlags;
            BitArray bitArrayPeriFlag = new BitArray(byteValue);
            m_SimControl.m_PIPPeriInstructCtrl.SetRawValue(bitArrayPeriFlag[0]);
            m_SimControl.m_PIPPeriSearchUp.SetRawValue(bitArrayPeriFlag[1]);
            m_SimControl.m_PIPPeriPolarityWhite.SetRawValue(bitArrayPeriFlag[2]);
            //m_SimControl.m_PIPPeriHighMag.SetRawValue(bitArrayPeriFlag[3]);
            if (m_PIPInputPacket.periscopeData.bMagnification == 0)
                m_SimControl.m_PIPPeriHighMag.SetRawValue(false);
            else
                m_SimControl.m_PIPPeriHighMag.SetRawValue(true);

            m_SimControl.m_PIPPeriDraindown.SetRawValue(m_PIPInputPacket.periscopeData.bDrainDownTime);
            m_SimControl.m_PIPPeriLLTVGain.SetRawValue(m_PIPInputPacket.periscopeData.bLLTVGain);
            m_SimControl.m_PIPPeriThermalGain.SetRawValue(m_PIPInputPacket.periscopeData.bTIGain);
            m_SimControl.m_PIPPeriRelBearing.SetRawValue(m_PIPInputPacket.periscopeData.fRelBrg);
            m_SimControl.m_PIPPeriElevation.SetRawValue(m_PIPInputPacket.periscopeData.fElevation);

            // Environment flags - split byte flag into individual bit values
            byteValue[0] = m_PIPInputPacket.environmentData.bFlags;
            BitArray bitArrayEnvFlag = new BitArray(byteValue);
            m_SimControl.m_PIPEnvMoonOverride.SetRawValue(bitArrayEnvFlag[0]);
            m_SimControl.m_PIPEnvCoastLights.SetRawValue(bitArrayEnvFlag[1]);
            m_SimControl.m_PIPEnvIceEdgeOn.SetRawValue(bitArrayEnvFlag[2]);
            m_SimControl.m_PIPEnvSunOverride.SetRawValue(bitArrayEnvFlag[3]);

            m_SimControl.m_PIPEnvWeather.SetRawValue(m_PIPInputPacket.environmentData.bWeather);
            m_SimControl.m_PIPEnvCoastline.SetRawValue(m_PIPInputPacket.environmentData.bCoastline);
            m_SimControl.m_PIPEnvSeaState.SetRawValue(m_PIPInputPacket.environmentData.bSeaState);
            m_SimControl.m_PIPEnvMoonBrg.SetRawValue(m_PIPInputPacket.environmentData.fMoonBearing);
            m_SimControl.m_PIPEnvMoonElev.SetRawValue(m_PIPInputPacket.environmentData.fMoonElevation);
            m_SimControl.m_PIPEnvVisualRange.SetRawValue(m_PIPInputPacket.environmentData.fVisualRange);
            m_SimControl.m_PIPEnvUnderWaterRange.SetRawValue(m_PIPInputPacket.environmentData.fUnderWaterRange);
            m_SimControl.m_PIPEnvThermalRange.SetRawValue(m_PIPInputPacket.environmentData.fTIRange);
            m_SimControl.m_PIPEnvWindSpeed.SetRawValue(m_PIPInputPacket.environmentData.fWindSpeed);
            m_SimControl.m_PIPEnvWindHeading.SetRawValue(m_PIPInputPacket.environmentData.fWindHeading);
            m_SimControl.m_PIPEnvIceLat.SetRawValue(m_PIPInputPacket.environmentData.fIceLat);
            m_SimControl.m_PIPEnvIceLon.SetRawValue(m_PIPInputPacket.environmentData.fIceLong);
            m_SimControl.m_PIPEnvIceOrien.SetRawValue(m_PIPInputPacket.environmentData.fIceOrientation);
            m_SimControl.m_PIPEnvSunBrg.SetRawValue(m_PIPInputPacket.environmentData.fSunBearing);
            m_SimControl.m_PIPEnvSunElev.SetRawValue(m_PIPInputPacket.environmentData.fSunElevation);
            m_SimControl.m_PIPOwnLat.SetRawValue(m_PIPInputPacket.ownboatData.dLatitude);
            m_SimControl.m_PIPOwnLon.SetRawValue(m_PIPInputPacket.ownboatData.dLongitude);
            m_SimControl.m_PIPOwnDepth.SetRawValue(m_PIPInputPacket.ownboatData.fDepth);
            m_SimControl.m_PIPOwnClimbRate.SetRawValue(m_PIPInputPacket.ownboatData.fClimbRate);
            m_SimControl.m_PIPOwnTurnRate.SetRawValue(m_PIPInputPacket.ownboatData.fTurnRate);
            m_SimControl.m_PIPOwnPitch.SetRawValue(m_PIPInputPacket.ownboatData.fPitch);
            m_SimControl.m_PIPOwnHeading.SetRawValue(m_PIPInputPacket.ownboatData.fHeading);
            m_SimControl.m_PIPOwnDriftCourse.SetRawValue(m_PIPInputPacket.ownboatData.fDriftCourse);
            m_SimControl.m_PIPOwnSpeed.SetRawValue(m_PIPInputPacket.ownboatData.fSpeed);
            m_SimControl.m_PIPOwnDriftSpeed.SetRawValue(m_PIPInputPacket.ownboatData.fDriftSpeed);

            // Own flag - split byte flag into individual bit values
            byteValue[0] = m_PIPInputPacket.ownboatData.bFlags;
            BitArray bitArrayOwnFlag = new BitArray(byteValue);
            m_SimControl.m_PIPOwnWhipAerialUp.SetRawValue(bitArrayOwnFlag[0]);
            m_SimControl.m_PIPOwnEmerLightUp.SetRawValue(bitArrayOwnFlag[1]);
            m_SimControl.m_PIPOwnDieselSmoke.SetRawValue(bitArrayOwnFlag[2]);

            m_SimControl.m_PIPOwnMastRESM.SetRawValue(m_PIPInputPacket.ownboatData.bMastRESM);
            m_SimControl.m_PIPOwnMastWTComms.SetRawValue(m_PIPInputPacket.ownboatData.bMastWTComms);
            m_SimControl.m_PIPOwnMastHFDF.SetRawValue(m_PIPInputPacket.ownboatData.bMastHFDF);
            m_SimControl.m_PIPOwnMastAttack.SetRawValue(m_PIPInputPacket.ownboatData.bMastAttack);
            m_SimControl.m_PIPOwnMastRadar.SetRawValue(m_PIPInputPacket.ownboatData.bMastRadar);
            m_SimControl.m_PIPOwnMastSnortInd.SetRawValue(m_PIPInputPacket.ownboatData.bMastSnortInd);
            m_SimControl.m_PIPOwnMastSnortExh.SetRawValue(m_PIPInputPacket.ownboatData.bMastSnortExh);
            m_SimControl.m_PIPOwnType.SetRawValue(m_PIPInputPacket.ownboatData.bOwnBoatType);


            for (i = 0; i < SIMControl.NUM_PERI_TARGETS; i++)
            {
                //Console.WriteLine("IN THE TARGET LOOP ******* I IS : {0}", i);
                // Target flag - split byte flag into individual bit values
                byteValue[0] = m_PIPInputPacket.target[i].bFlags;
                //Console.WriteLine("Target Value: BFLAGS: {0:x2}", m_PIPInputPacket.target[i].bFlags);
                BitArray bitArrayTarFlag = new BitArray(byteValue);

                m_SimControl.m_PIPTargets[i].m_PIPTarPresent.SetRawValue(bitArrayTarFlag[0]);       // Vehicle_Present
                m_SimControl.m_PIPTargets[i].m_PIPTarFlames.SetRawValue(bitArrayTarFlag[1]);        // Explosion_Present
                m_SimControl.m_PIPTargets[i].m_PIPTarMissileHit.SetRawValue(bitArrayTarFlag[2]);    // Missile_Impcated
                m_SimControl.m_PIPTargets[i].m_PIPTarTorpedoHit.SetRawValue(bitArrayTarFlag[3]);    // Torpedo Impacted
                m_SimControl.m_PIPTargets[i].m_PIPTarSinking.SetRawValue(bitArrayTarFlag[4]);       // TGT to Sink
                m_SimControl.m_PIPTargets[i].m_PIPTarNavLights.SetRawValue(bitArrayTarFlag[5]);        // The_NavLights
                m_SimControl.m_PIPTargets[i].m_PIPTarDunkingSonar.SetRawValue(bitArrayTarFlag[6]);     // Heli_with_Dunking_Sonar
                m_SimControl.m_PIPTargets[i].m_PIPTarTLAMFaulty.SetRawValue(bitArrayTarFlag[7]);    // TLAM_Faulty_Launch

                m_SimControl.m_PIPTargets[i].m_PIPTarDunkingData.SetRawValue(m_PIPInputPacket.target[i].bDunkingSonar);     // Dunking_Sonar_Buoy_Number
                //Console.WriteLine("Target Value: DUNKING SONAR: {0:x2}", m_PIPInputPacket.target[i].bDunkingSonar);

                m_SimControl.m_PIPTargets[i].m_PIPTarLightConfig.SetRawValue(m_PIPInputPacket.target[i].bLightConfig);      // Light_Config
                //Console.WriteLine("Target Value: LIGHT CONFIG: {0:x2}", m_PIPInputPacket.target[i].bLightConfig);

                m_SimControl.m_PIPTargets[i].m_PIPTarSpotConfig.SetRawValue(m_PIPInputPacket.target[i].bSpotConfig);     // Spotlight_Config
                //Console.WriteLine("Target Value: SPOT LIGHT CONFIG: {0:x2}", m_PIPInputPacket.target[i].bSpotConfig);

                m_SimControl.m_PIPTargets[i].m_PIPTarModelID.SetRawValue(m_PIPInputPacket.target[i].iModelNum);          // The_TGT_ID
                //if (i < 10)
                //{
                // Console.WriteLine("Passing to sim {0} slot {1}", i, m_PIPInputPacket.target[i].iSlotNum);
                //}
                m_SimControl.m_PIPTargets[i].m_PIPTarSlotID.SetRawValue(m_PIPInputPacket.target[i].iSlotNum);   //       // Slot_ID
                //Console.WriteLine("Target Value: SLOT NUMBER: {0:x2}", m_PIPInputPacket.target[i].iSlotNum);

                m_SimControl.m_PIPTargets[i].m_PIPTarX.SetRawValue(m_PIPInputPacket.target[i].fX);                 // X_Coord
                //Console.WriteLine("Target Value: X COORD: {0:X2}", m_PIPInputPacket.target[i].fX.ToString("F"));

                m_SimControl.m_PIPTargets[i].m_PIPTarY.SetRawValue(m_PIPInputPacket.target[i].fY);                 // Y_Coord
                //Console.WriteLine("Target Value: Y COORD: {0:X2}", m_PIPInputPacket.target[i].fY.ToString("F"));

                m_SimControl.m_PIPTargets[i].m_PIPTarHeight.SetRawValue(m_PIPInputPacket.target[i].fDepth);           // Z_Coord
                //Console.WriteLine("Target Value: DEPTH: {0:X2}", m_PIPInputPacket.target[i].fDepth.ToString("F"));

                m_SimControl.m_PIPTargets[i].m_PIPTarClimbRate.SetRawValue(m_PIPInputPacket.target[i].fClimbRate);    // Z_Rate
                //Console.WriteLine("Target Value: CLIMB RATE: {0:X2}", m_PIPInputPacket.target[i].fClimbRate.ToString("F"));

                m_SimControl.m_PIPTargets[i].m_PIPTarTurnRate.SetRawValue(m_PIPInputPacket.target[i].fTurnRate);      // Turn_Rate
                //Console.WriteLine("Target Value: TURN RATE: {0:X2}", m_PIPInputPacket.target[i].fTurnRate.ToString("F"));

                m_SimControl.m_PIPTargets[i].m_PIPTarPitch.SetRawValue(m_PIPInputPacket.target[i].fPitch);            // Pitch
                //Console.WriteLine("Target Value: PITCH: {0:X2}", m_PIPInputPacket.target[i].fPitch.ToString("F"));

                m_SimControl.m_PIPTargets[i].m_PIPTarHeading.SetRawValue(m_PIPInputPacket.target[i].fHeading);        // Heading
                //Console.WriteLine("Target Value: HEADING: {0:X2}", m_PIPInputPacket.target[i].fHeading.ToString("F"));

                m_SimControl.m_PIPTargets[i].m_PIPTarDriftCourse.SetRawValue(m_PIPInputPacket.target[i].fDriftCourse);   // Drift_Course
                //Console.WriteLine("Target Value: DRIFT COURSE: {0:X2}", m_PIPInputPacket.target[i].fDriftCourse.ToString("F"));

                m_SimControl.m_PIPTargets[i].m_PIPTarSpeed.SetRawValue(m_PIPInputPacket.target[i].fSpeed);            // Speed
                //Console.WriteLine("Target Value: SPEED: {0:X2}", m_PIPInputPacket.target[i].fSpeed.ToString("F"));

                m_SimControl.m_PIPTargets[i].m_PIPTarDriftSpeed.SetRawValue(m_PIPInputPacket.target[i].fDriftSpeed);  // Drift_Speed
                //Console.WriteLine("Target Value: DRIFT SPEED: {0:X2}", m_PIPInputPacket.target[i].fDriftSpeed.ToString("F"));

                // Split byte flag into individual bit values
                byteValue[0] = m_PIPInputPacket.target[i].bExtraFlags;
                //Console.WriteLine("Target Value: Extra FLAGS - SMOKE / MISS LAUNCH: {0:x2}", m_PIPInputPacket.target[i].bExtraFlags);

                BitArray bitExtraFlags = new BitArray(byteValue);
                m_SimControl.m_PIPTargets[i].m_PIPTarDieselSmoke.SetRawValue(bitExtraFlags[0]);                    // Diesel_Smoke
                m_SimControl.m_PIPTargets[i].m_PIPTarFireMissile.SetRawValue(bitExtraFlags[1]);                    // Missile_Launch
                // Spare 1
                // Spare 2
                // Spare 3
            }

            m_SimControl.m_PIPCheckSum.SetRawValue(m_PIPInputPacket.iCheckSum);

            // Error Log: Check sum
            C_guiNetworkStatus.txtv = m_SimControl.m_SIMPIPCheckSum.ToString() + " -- " + m_PIPInputPacket.iCheckSum.ToString() + " -- ";

            if (m_SimControl.m_SIMPIPCheckSum != m_PIPInputPacket.iCheckSum)
            {
                m_SimControl.WriteToErrorLog("CHECK_SUM", "PIP");
                Console.WriteLine("Checksum calc {0} rx {1}", m_SimControl.m_SIMPIPCheckSum, m_PIPInputPacket.iCheckSum);
            }

            // Set new data flags
            m_SimControl.m_SIMNewExData = true;
            m_SimControl.m_SIMNewEnvData = true;
            m_SimControl.m_SIMNewOwnData = true;
            m_SimControl.m_SIMNewPeriData = true;
            m_SimControl.m_SIMNewTarData = true;
        }

    }
}
