using System;

namespace psc
{
    /// <summary>
    /// Summary description for DataItemMaxMinValues.
    /// </summary>
    public class Data
    {
        public Data()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        //PIG Environment data.
        public static int   MOON_MIN            =      0;
        public static int   MOON_MAX            =      1;
        public static int   COAST_LIGHTS_MAX    =      0;
        public static int   COAST_LIGHTS_MIN    =      1;
        public static int   ICE_EDGE_MIN        =      0;
        public static int   ICE_EDGE_MAX        =      1;
        public static int   REMOTE_SUN_MIN      =      0;
        public static int   REMOTE_SUN_MAX      =      1;
        public static int   HOURS_MIN           =      1;
        public static int   HOURS_MAX           =     24;
        public static int   MINUTES_MIN         =      1;
        public static int   MINUTES_MAX         =     60;
        public static int   SECONDS_MIN         =      1;
        public static int   SECONDS_MAX         =     60;
        public static int   DAY_MIN             =      1;
        public static int   DAY_MAX             =     31;
        public static int   MONTH_MIN           =      1;
        public static int   MONTH_MAX           =     12;
        public static int   YEAR_MIN            =      0;
        public static int   YEAR_MAX            =    100;
        public static int   WEATHER_MIN         =      0;
        public static int   WEATHER_MAX         =      4;
        public static int   COASTLINE_MIN       =      0;
        public static int   COASTLINE_MAX       =      1;
        public static int   SEA_STATE_MIN       =      0;
        public static int   SEA_STATE_MAX       =      6;
        public static int   VISIBLE_RANGE_MIN   =      0;
        public static int   VISIBLE_RANGE_MAX   =  32000;
        public static int   THERMAL_RANGE_MIN   =      0;
        public static int   THERMAL_RANGE_MAX   =  32000;
        public static int   UNDERWATER_VIS_MIN  =      0;
        public static int   UNDERWATER_VIS_MAX  =    100;
        public static int   WIND_SPEED_MIN      =      0;
        public static float WIND_SPEED_MAX      =    152.32F;
        public static int   WIND_DIRECTION_MIN  =   -360;
        public static int   WIND_DIRECTION_MAX  =    360;
        public static int   MOON_BEARING_MIN    =   -360;
        public static int   MOON_BEARING_MAX    =    360;
        public static int   MOON_ALTITUDE_MIN   =    -90;
        public static int   MOON_ALTITUDE_MAX   =     90;
        public static int   SUN_BEARING_MIN     =   -360;
        public static int   SUN_BEARING_MAX     =    360;
        public static int   SUN_ALTITUDE_MIN    =    -90;
        public static int   SUN_ALTITUDE_MAX    =     90;
        public static int   ICE_EDGE_LAT_MIN    =    -90;
        public static int   ICE_EDGE_LAT_MAX    =     90;
        public static int   ICE_EDGE_LONG_MIN   =   -180;
        public static int   ICE_EDGE_LONG_MAX   =    180;
        public static int   ICE_EDGE_ORIENT_MIN =   -360;
        public static int   ICE_EDGE_ORIENT_MAX =    360;

        //PIG Exercise Data
        public static int   SYSTEM_ID_MAX       =    100;
        public static int   SYSTEM_ID_MIN       =      0;

        //PIG Ownship Data
        public static int   OWNSHIP_TYPE_MAX      =      5;
        public static int   OWNSHIP_TYPE_MIN      =      0;
        public static int   OWNSHIP_SMOKE_MAX     =      1;
        public static int   OWNSHIP_SMOKE_MIN     =      0;
        public static int   OWNSHIP_LATITUDE_MAX  =     90;
        public static int   OWNSHIP_LATITUDE_MIN  =    -90;
        public static int   OWNSHIP_LONGITUDE_MAX =    180;
        public static int   OWNSHIP_LONGITUDE_MIN =   -180;
        public static int   OWNSHIP_X_MAX         =  10000;
        public static int   OWNSHIP_X_MIN         = -10000;
        public static int   OWNSHIP_Y_MAX         =  10000;
        public static int   OWNSHIP_Y_MIN         = -10000;
        public static int   OWNSHIP_DEPTH_MAX     =      0;
        public static int   OWNSHIP_DEPTH_MIN     = -10000;
        public static int   OWNSHIP_HEADING_MAX   =    360;
        public static int   OWNSHIP_HEADING_MIN   =      0;
        public static int   OWNSHIP_ROLL_MAX      =     90;
        public static int   OWNSHIP_ROLL_MIN      =    -90;
        public static int   OWNSHIP_PITCH_MAX     =     90;
        public static int   OWNSHIP_PITCH_MIN     =    -90;
        public static int   OWNSHIP_SPEED_MAX     =    100;
        public static int   OWNSHIP_SPEED_MIN     =      0;

        //PIG Periscope Data
        public static int   PERI_SENSOR_TYPE_MAX  =         10;
        public static int   PERI_SENSOR_TYPE_MIN  =          0;
        public static int   PERI_MAG_MAX          =         20;
        public static int   PERI_MAG_MIN          =          0;
        public static int   PERI_GAIN_MAX         =        100;
        public static int   PERI_GAIN_MIN         =          0;
        public static int   PERI_CONTRAST_MAX     =        100;
        public static int   PERI_CONTRAST_MIN     =          0;
        public static int   PERI_GRAT_INT_MAX     =        100;
        public static int   PERI_GRAT_INT_MIN     =          0;
        public static int   PERI_DRAIN_TIME_MAX   =         60;
        public static int   PERI_DRAIN_TIME_MIN   =          0;
        public static int   PERI_REL_BRG_MAX      =        180;
        public static int   PERI_REL_BRG_MIN      =       -180;
        public static int   PERI_ELEVATION_MAX    =         90;
        public static int   PERI_ELEVATION_MIN    =        -15;
        public static int   PERI_STAD_ELEV_MAX    =          4;
        public static int   PERI_STAD_ELEV_MIN    =          0;

        //PIG Targets Data
        public static int   TARGET_MODEL_ID_MAX       =    999;
        public static int   TARGET_MODEL_ID_MIN       =      1;
        public static int   TARGET_NUMBER_MAX         =     47;
        public static int   TARGET_NUMBER_MIN         =      0;
        public static int   TARGET_LIGHT_CONFIG_MAX   =     47;
        public static int   TARGET_LIGHT_CONFIG_MIN   =      0;
        public static int   TARGET_X_MAX              =  10000;
        public static int   TARGET_X_MIN              = -10000;
        public static int   TARGET_Y_MAX              =  10000;
        public static int   TARGET_Y_MIN              = -10000;
        public static int   TARGET_HEIGHT_MAX         =  10000;
        public static int   TARGET_HEIGHT_MIN         = -10000;
        public static int   TARGET_HEADING_MAX        =    360;
        public static int   TARGET_HEADING_MIN        =      0;
        public static int   TARGET_ROLL_MAX           =    360;
        public static int   TARGET_ROLL_MIN           =      0;
        public static int   TARGET_PITCH_MAX          =    360;
        public static int   TARGET_PITCH_MIN          =      0;
        public static int   TARGET_SPEED_MAX          =     90;
        public static int   TARGET_SPEED_MIN          =      0;
        public static int   TARGET_ACCEL_MAX          =    100;
        public static int   TARGET_ACCEL_MIN          =      0;
        public static int   TARGET_VISIBLE_MAX        =    360;
        public static int   TARGET_VISIBLE_MIN        =      0;
        public static int   TARGET_NAV_LIGHTS_MAX     =    360;
        public static int   TARGET_NAV_LIGHTS_MIN     =      0;
        public static int   TARGET_MISSILE_IMPACT_MAX =    360;
        public static int   TARGET_MISSILE_IMPACT_MIN =      0;
        public static int   TARGET_TORPEDO_IMPACT_MAX =     90;
        public static int   TARGET_TORPEDO_IMPACT_MIN =      0;
        public static int   TARGET_SINKING_MAX        =    100;
        public static int   TARGET_SINKING_MIN        =      0;
        public static int   TARGET_SONAR_DIP_MAX      =    360;
        public static int   TARGET_SONAR_DIP_MIN      =      0;
        public static int   TARGET_FAULTY_MISSILE_MAX =    360;
        public static int   TARGET_FAULTY_MISSILE_MIN =      0;
        public static int   TARGET_FLAMES_MAX         =    360;
        public static int   TARGET_FLAMES_MIN         =      0;
        public static int   TARGET_SMOKE_MAX          =     90;
        public static int   TARGET_SMOKE_MIN          =      0;
        public static int   TARGET_FIRE_MISSILE_MAX   =    100;
        public static int   TARGET_FIRE_MISSILE_MIN   =      0;
        public static int   TARGET_FISHING_LIGHTS_MAX =      8;
        public static int   TARGET_FISHING_LIGHTS_MIN =      0;
        public static int   TARGET_FISHING_SPOTS_MAX  =      2;
        public static int   TARGET_FISHING_SPOTS_MIN  =      0;

    }
}
