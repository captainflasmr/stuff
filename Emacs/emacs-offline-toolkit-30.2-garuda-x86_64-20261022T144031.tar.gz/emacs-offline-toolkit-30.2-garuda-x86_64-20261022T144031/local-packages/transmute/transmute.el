;;; transmute.el --- Media management utilities  -*- lexical-binding: t; -*-

;; Author: James Dyer <james@dyerdwelling.family>
;; Keywords: media, image, video, automation
;; Package-Requires: ((emacs "27.1") (cl-lib "0.5") (transient "0.3.0"))
;; Version: 0.7.3

;;; Commentary:
;; This package provides Emacs Lisp implementations for media processing
;; (Images, Video, Audio). It relies on external tools: exiftool,
;; imagemagick (magick), ffmpeg, sox, tesseract, and optionally
;; realesrgan-ncnn-vulkan or the Upscayl CLI (upscayl-bin) for AI
;; upscaling.

;;; Code:

(require 'cl-lib)
(require 'dired)
(require 'subr-x)
(require 'transient)
(require 'ucs-normalize)

(declare-function dired-image-thumbnail-get-marked "dired-image-thumbnail")
(declare-function dired-image-thumbnail--nearest-image-original-file-name "dired-image-thumbnail")
(declare-function dired-image-thumbnail-clear-preview-cache "dired-image-thumbnail")
(declare-function dired-image-thumbnail-refresh-current-display "dired-image-thumbnail")
(declare-function org-time-stamp-format "org")
(declare-function org-read-date "org")
(declare-function org-hugo-slug "ox-hugo" (title))
(declare-function outline-next-heading "outline")
(defvar image-dired-thumbnail-mode-map)
(defvar image-dired-thumbnail-buffer nil)
(defvar image-dired-display-image-buffer nil)
(defvar image-dired-display-image-mode-map nil)
(defvar org-note-abort)
(defvar org-capture-templates nil)

(defgroup transmute nil
  "Media management and conversion utilities."
  :group 'media)

(defvar transmute-active-processes nil
  "List of active transmute processes.")

(defvar transmute-batch-files nil
  "List of files processed in the current batch.")

(defvar transmute--last-renames nil
  "Alist mapping old filenames to new filenames from the last batch.")

(defvar transmute--task-registered nil
  "Dynamically bound around a batch body by `transmute-do-batch'.
`transmute--run-command-async' sets it when the body started an
asynchronous process, so the batch macro knows the sentinel, not the
macro itself, is responsible for counting the task as completed.")

(defvar transmute--inhibit-display-refresh-once nil
  "Internal flag to skip image display refresh once.")

(defvar transmute--skip-refresh-once nil
  "Internal flag to skip the post-batch refresh once.
Set by read-only batches (the duplicate scan) where no file changed and
refreshing thumbnail buffers would only bury the result buffer.")

(defvar transmute--duplicate-signatures nil
  "Hash table of pixel signature to files for the current duplicate scan.")

(defvar transmute--duplicate-targets nil
  "Files included in the current duplicate scan.")

(defvar transmute--duplicate-queue nil
  "Image files still awaiting a signature process in a duplicate scan.")

(defvar transmute--duplicate-inflight 0
  "Number of signature processes currently running in a duplicate scan.")

(defvar transmute--duplicate-finished nil
  "Non-nil once the current duplicate scan has produced its report.")

(defvar transmute-after-batch-hook nil
  "Hook run after each transmute batch operation completes.
Useful for refreshing external buffers like image-dired thumbnail views.")

(defvar transmute-total-tasks 0
  "Total number of tasks in the current batch.")

(defvar transmute-completed-tasks 0
  "Number of completed tasks in the current batch.")

(defcustom transmute-tag-list-file "~/bin/category-list-uniq.txt"
  "Path to a file of known tags, one per line, for `transmute-tag-from-list'.
When nil, fallback completion is used."
  :type '(choice (file :tag "Tag list file") (const :tag "None" nil))
  :group 'transmute)

(defvar transmute-log-buffer-name "*transmute-log*"
  "Name of the buffer for transmute conversion output.")

(defvar transmute-info-buffer-name "*transmute-info*"
  "Name of the buffer for transmute metadata output.")

(define-derived-mode transmute-info-mode special-mode "Transmute-Info"
  "Major mode for viewing media metadata."
  (setq-local font-lock-defaults
              '((("^File:.*" . 'bold)
                 ("^----.*----$" . 'font-lock-function-name-face)
                 ("^\\s-*\\(.+?\\)\\s-*:" . (1 'font-lock-variable-name-face))))))

(defun transmute--display-info (targets &rest commands)
  "Run COMMANDS for each of TARGETS and display in a dedicated buffer.
COMMANDS can be a list of strings or (label . cmd) pairs.  The
commands run one at a time in the background and their output is
appended in order, so Emacs stays responsive on large selections."
  (let ((buf (get-buffer-create transmute-info-buffer-name))
        (queue nil)
        (next nil))
    (with-current-buffer buf
      (let ((inhibit-read-only t))
        (erase-buffer)
        (transmute-info-mode)))
    ;; Flatten (file, command) pairs into a queue, remembering which
    ;; command is the first and last for its file so the file header and
    ;; separator are printed in the right place.
    (dolist (file targets)
      (let* ((specs (mapcar (lambda (cmd-spec)
                              (cons (if (listp cmd-spec) (car cmd-spec) nil)
                                    (if (listp cmd-spec) (cdr cmd-spec) cmd-spec)))
                            commands))
             (n (length specs)))
        (dotimes (i n)
          (let ((spec (nth i specs)))
            (setq queue (cons (list file (car spec) (cdr spec)
                                    (= i 0) (= i (1- n)))
                              queue))))))
    (setq queue (nreverse queue))
    (setq next
          (lambda ()
            (if (null queue)
                (with-current-buffer buf
                  (let ((inhibit-read-only t))
                    (goto-char (point-min))))
              (let* ((item (pop queue))
                     (file (nth 0 item))
                     (label (nth 1 item))
                     (cmd (nth 2 item))
                     (first (nth 3 item))
                     (last (nth 4 item))
                     (proc-buf (generate-new-buffer " *transmute-info-cmd*")))
                (with-current-buffer buf
                  (let ((inhibit-read-only t))
                    (save-excursion
                      (goto-char (point-max))
                      (when first
                        (insert (propertize (format "File: %s\n" file)
                                            'face 'bold)))
                      (when label
                        (insert (propertize (format "[%s]\n" label)
                                            'face 'font-lock-comment-face))))))
                (let ((proc (start-process-shell-command
                             "transmute-info" proc-buf
                             (format "%s %s 2>&1" cmd
                                     (shell-quote-argument file)))))
                  (set-process-query-on-exit-flag proc nil)
                  (set-process-sentinel
                   proc
                   (lambda (p _event)
                     (when (memq (process-status p) '(exit signal))
                       (let ((out (with-current-buffer proc-buf
                                    (buffer-string))))
                         (kill-buffer proc-buf)
                         (with-current-buffer buf
                           (let ((inhibit-read-only t))
                             (save-excursion
                               (goto-char (point-max))
                               (insert out)
                               (when last
                                 (insert "\n"
                                         (make-string
                                          (window-width
                                           (or (get-buffer-window buf)
                                               (selected-window)))
                                          ?=)
                                         "\n\n"))))))
                       (run-at-time 0 nil next)))))))))
    (pop-to-buffer buf)
    (funcall next)))

(defun transmute-show-log ()
  "Show the transmute log buffer."
  (interactive)
  (pop-to-buffer (get-buffer-create transmute-log-buffer-name)))

(defun transmute-stop-conversions ()
  "Stop all currently active transmute conversions."
  (interactive)
  (when transmute-active-processes
    (let ((count (length transmute-active-processes)))
      (dolist (proc transmute-active-processes)
        (when (process-live-p proc)
          (interrupt-process proc)))
      (setq transmute-active-processes nil
            transmute-total-tasks 0
            transmute-completed-tasks 0
            ;; Do not let a stopped duplicate scan start the files that
            ;; are still queued; in-flight callbacks will finish it.
            transmute--duplicate-queue nil)
      (transmute--update-progress-display)
      (transmute--log "[ABORT] Stopped %d active conversions." count)
      (message "Stopped %d active conversions." count))))

(defun transmute--log (msg &rest args)
  "Log MSG with ARGS to the transmute log buffer."
  (let ((buf (get-buffer-create transmute-log-buffer-name))
        (inhibit-read-only t))
    (with-current-buffer buf
      (unless (eq major-mode 'compilation-mode)
        (compilation-mode))
      (save-excursion
        (goto-char (point-max))
        (insert (apply #'format msg args) "\n")))))

(defun transmute-header-line-format ()
  "Return the header line format for transmute progress."
  (when (> transmute-total-tasks 0)
    (let* ((pct (if (> transmute-total-tasks 0)
                    (/ (* 100 transmute-completed-tasks) transmute-total-tasks)
                  0))
           (active (length transmute-active-processes)))
      (concat
       (propertize (format " [Transmuting: %d/%d (%d%%)] " 
                           transmute-completed-tasks 
                           transmute-total-tasks
                           pct)
                   'face '(:inherit mode-line-highlight :weight bold))
       (when (> active 0)
         (format " (%d active) " active))))))

(defvar transmute--header-line-entry '(:eval (transmute-header-line-format))
  "The entry added to `header-line-format`.")

(defun transmute--update-progress-display ()
  "Update the global header line based on active tasks."
  (when (bound-and-true-p transmute-progress-mode)
    (let ((current (default-value 'header-line-format)))
      (if transmute-active-processes
          (unless (member transmute--header-line-entry current)
            (setq-default header-line-format 
                          (if current 
                              (cons transmute--header-line-entry current)
                            (list transmute--header-line-entry))))
        (let ((new-fmt (delete transmute--header-line-entry current)))
          (setq-default header-line-format (if (or (null new-fmt) (equal new-fmt '(nil)))
                                               nil
                                             new-fmt)))
        (setq transmute-total-tasks 0
              transmute-completed-tasks 0)))
    (force-mode-line-update)))

;;;###autoload
(define-minor-mode transmute-progress-mode
  "Show transmute progress in the header line."
  :global t
  :group 'transmute
  (transmute--update-progress-display))

(defcustom transmute-trash-command "trash-put"
  "Command to use for trashing files."
  :type 'string
  :group 'transmute)

(defcustom transmute-normalise-downcase nil
  "When non-nil, `transmute-normalise-names' also lowercases filenames."
  :type 'boolean
  :group 'transmute)

(defcustom transmute-ffmpeg-threads nil
  "Number of threads to pass to ffmpeg, or nil to let ffmpeg decide.
Set an integer to cap ffmpeg's thread count; a low value helps keep
the machine responsive when several conversions run in parallel."
  :type '(choice (integer :tag "Threads") (const :tag "Automatic" nil))
  :group 'transmute)

(defcustom transmute-gif-width 1366
  "Width in pixels of GIFs produced by `transmute-video-to-gif'.
The height is scaled proportionally.  Set to nil to keep the
source resolution."
  :type '(choice (integer :tag "Width") (const :tag "Source size" nil))
  :group 'transmute)

(defcustom transmute-gif-fps 4
  "Frame rate of GIFs produced by `transmute-video-to-gif'.
Set to nil to keep the source frame rate."
  :type '(choice (number :tag "Frames per second") (const :tag "Source rate" nil))
  :group 'transmute)

(defcustom transmute-gif-dither "none"
  "Dithering used by `transmute-video-to-gif'.
`none' gives the crispest flat colours and text, and suits screen
recordings.  The error-diffusion methods (`sierra2_4a',
`floyd_steinberg') avoid banding in gradients and photographs, at
the cost of a noisier, larger GIF; `bayer' uses a regular ordered
pattern."
  :type '(choice (const :tag "None (crispest text)" "none")
                 (const :tag "Sierra 2-4A" "sierra2_4a")
                 (const :tag "Floyd-Steinberg" "floyd_steinberg")
                 (const :tag "Bayer" "bayer"))
  :group 'transmute)

(defcustom transmute-gif-colours 64
  "Maximum number of colours in GIFs produced by `transmute-video-to-gif'.
Screen recordings often look fine with 64-128 colours, which also
keeps the file smaller."
  :type '(integer :tag "Colours (2-256)")
  :group 'transmute)

(defcustom transmute-upscayl-binary nil
  "Path to the Upscayl CLI used by `transmute-picture-upscale-upscayl'.
When nil, Transmute auto-detects the first available of the
`upscayl-bin' command on `exec-path' or the binary bundled with the
Upscayl AppImage (e.g. /opt/upscayl/resources/bin/upscayl-bin)."
  :type '(choice (file :tag "Binary") (const :tag "Auto-detect" nil))
  :group 'transmute)

(defcustom transmute-upscayl-models-dir nil
  "Folder containing the Upscayl model .param/.bin files.
When nil, Transmute looks for a models folder next to the detected
binary (the Upscayl AppImage ships one at resources/models) and in a
couple of standard locations."
  :type '(choice (directory :tag "Models folder") (const :tag "Auto-detect" nil))
  :group 'transmute)

(defcustom transmute-upscayl-model "digital-art-4x"
  "Default Upscayl model used by `transmute-picture-upscale-upscayl'.
The interactive command offers every model found in the models
folder with this value as the default."
  :type 'string
  :group 'transmute)

(defcustom transmute-upscayl-edge 7632
  "Default target for the *short* edge, in pixels, of Upscayl upscales.
A 7632px short edge covers Redbubble duvets/tapestries (6480x7632)
and photographic prints XL (6096x9144) in either orientation.  The
interactive command lets you override this per run.  0 means no
resize: keep the model's native scale (usually 4x)."
  :type 'integer
  :group 'transmute)

(defcustom transmute-upscayl-format "jpg"
  "Output format used by `transmute-picture-upscale-upscayl'.
The upscaled file gets the same base name as its source with this
extension."
  :type '(choice (const :tag "JPEG (jpg)" "jpg")
                 (const :tag "PNG (png)" "png")
                 (const :tag "WebP (webp)" "webp"))
  :group 'transmute)

(defcustom transmute-upscayl-compression 0
  "Output compression (0-100) for `transmute-picture-upscale-upscayl'.
0 keeps the best quality; higher values shrink the file."
  :type 'integer
  :group 'transmute)

(defcustom transmute-upscayl-gpu nil
  "GPU id passed to upscayl-bin, or nil to let it choose automatically."
  :type '(choice (integer :tag "GPU id") (const :tag "Automatic" nil))
  :group 'transmute)

(defcustom transmute-upscayl-tile nil
  "Tile size passed to upscayl-bin, or nil for automatic tiling.
Lower tile sizes reduce VRAM use for large images; the CLI requires
a minimum of 32."
  :type '(choice (integer :tag "Tile size") (const :tag "Automatic" nil))
  :group 'transmute)

(defcustom transmute-compress-quality "85%"
  "JPEG quality level used by `transmute-picture-compress'.
Expressed as a percentage string (e.g. \"85%\" or \"50%\").  Lower
values produce smaller files at the cost of visible artefacts.
85%% is typically visually indistinguishable from the source."
  :type 'string
  :group 'transmute)

(defcustom transmute-duplicate-parallelism 4
  "Maximum number of image signature processes run at once.
`transmute-picture-find-duplicates' decodes every selected image to
compute a pixel signature; starting one process per file can exhaust
memory and freeze the machine when hundreds of images are selected.
Raise this on a machine with cores and RAM to spare."
  :type 'integer
  :group 'transmute)

(defvar transmute-image-extensions
  '("jpg" "jpeg" "png" "gif" "bmp" "tiff" "webp" "svg" "heic" "heif")
  "List of image file extensions.")

(defvar transmute-video-extensions
  '("mp4" "mkv" "avi" "mov" "wmv" "flv" "webm" "m4v" "mpg" "mpeg")
  "List of video file extensions.")

(defvar transmute-audio-extensions
  '("mp3" "wav" "flac" "ogg" "m4a" "aac" "wma")
  "List of audio file extensions.")

(defvar transmute-document-extensions
  '("docx" "doc" "odt" "rtf" "wpd")
  "List of document file extensions convertible to PDF.")

;;; Core Variables & Parsing

(defun transmute--join-name (base extension)
  "Return BASE with EXTENSION appended, or BASE when EXTENSION is nil."
  (if (and extension (not (string-empty-p extension)))
      (format "%s.%s" base extension)
    base))

(defun transmute--parse-filename (file)
  "Parse media filename YYYYMMDDHHMMSS--description__tag1@tag2.ext.
Returns an alist with keys: directory, filename, extension, no-ext,
no-tag, timestamp, label, tags-raw, tags, keywords."
  (let* ((file (expand-file-name file))
         (directory (file-name-directory file))
         (filename (file-name-nondirectory file))
         (extension (file-name-extension filename))
         (no-ext (file-name-sans-extension filename))
         ;; Split by __ to get description and tags.  Everything after
         ;; the first __ counts as tags so extra separators are not lost.
         (parts (split-string no-ext "__"))
         (desc-part (car parts))
         (tags-raw (when (cdr parts)
                     (mapconcat #'identity (cdr parts) "__")))
         ;; Split description by -- to get timestamp and label
         (desc-subparts (split-string desc-part "--"))
         ;; A bare 14-digit name is a timestamp with no label; otherwise
         ;; the timestamp must be followed by "--".
         (has-timestamp (string-match-p "\\`[0-9]\\{14\\}\\'"
                                        (car desc-subparts)))
         (timestamp (if has-timestamp (car desc-subparts) ""))
         ;; Without a timestamp the whole description is the label, so
         ;; text after a non-date "--" is not silently dropped.
         (label (if has-timestamp
                    (mapconcat #'identity (cdr desc-subparts) "--")
                  desc-part))
         (no-tag (transmute--join-name
                  (cond ((and has-timestamp (not (string-empty-p label)))
                         (format "%s--%s" timestamp label))
                        (has-timestamp timestamp)
                        (t label))
                  extension))
         ;; Parse tags
         (tags (when tags-raw
                 (replace-regexp-in-string "[-_]" " " (replace-regexp-in-string "@" " " tags-raw))))
         (keywords (when tags
                     (delete-dups (sort (split-string tags " " t) #'string<)))))
    `((directory . ,directory)
      (filename . ,filename)
      (extension . ,extension)
      (no-ext . ,no-ext)
      (no-tag . ,no-tag)
      (timestamp . ,timestamp)
      (label . ,label)
      (tags-raw . ,tags-raw)
      (tags . ,tags)
      (keywords . ,keywords))))

(defvar transmute--date-tags
  '("CreateDate" "DateTimeOriginal" "ModifyDate" "FileModifyDate")
  "EXIF date tags queried, in priority order, by `transmute-get-date'.")

(defun transmute--date-command (file)
  "Return the exiftool command string that reads date tags from FILE."
  (format "exiftool -s %s %s"
          (mapconcat (lambda (p) (concat "-" p)) transmute--date-tags " ")
          (shell-quote-argument (expand-file-name file))))

(defun transmute--parse-date-output (out)
  "Parse exiftool -s OUT and return the highest-priority (PROP VAL), or nil.
Priority follows the order of `transmute--date-tags'."
  (let ((found nil))
    (dolist (line (split-string out "\n" t))
      (when (string-match "\\`\\([A-Za-z0-9]+\\)[ \t]*:[ \t]*\\(.*\\)\\'" line)
        (let ((tag (match-string 1 line))
              (val (string-trim (match-string 2 line))))
          (when (and (member tag transmute--date-tags) (not (string-empty-p val)))
            (push (cons tag val) found)))))
    (cl-loop for prop in transmute--date-tags
             for val = (cdr (assoc prop found))
             when (and val (not (string-empty-p val)))
             return (list prop val))))

(defun transmute-get-date (file)
  "Get creation date from FILE using exiftool.
Tries the tags in `transmute--date-tags' in priority order, querying
them all in a single exiftool invocation.  Returns (PROP VAL) or nil.
See `transmute-get-date-async' for a non-blocking variant."
  (transmute--parse-date-output
   (shell-command-to-string (transmute--date-command file))))

(defun transmute-get-date-async (file callback)
  "Asynchronously read the date from FILE.
CALLBACK is called with (PROP VAL) or nil once exiftool completes.
Does not block Emacs or touch global progress state, so it is safe
to use inside `transmute-do-batch-async' bodies."
  (let* ((buf (generate-new-buffer " *transmute-date*"))
         (proc (start-process-shell-command
                "transmute-date" buf (transmute--date-command file))))
    (set-process-query-on-exit-flag proc nil)
    (set-process-sentinel
     proc
     (lambda (p _event)
       (when (memq (process-status p) '(exit signal))
         (let* ((pbuf (process-buffer p))
                (out (if (buffer-live-p pbuf)
                         (with-current-buffer pbuf (buffer-string))
                       "")))
           (when (buffer-live-p pbuf) (kill-buffer pbuf))
           (funcall callback (transmute--parse-date-output out))))))
    proc))

(defun transmute-format-date (date-string)
  "Format exiftool date (YYYY:MM:DD HH:MM:SS) to YYYYMMDDHHMMSS."
  (let ((cleaned (replace-regexp-in-string "[: ]" "" date-string)))
    (if (string-match "^\\([0-9]\\{14\\}\\)" cleaned)
        (match-string 1 cleaned)
      cleaned)))

;;; Internal Process Wrappers

(defun transmute--rename-file-safe (file newname &optional ok-if-already-exists)
  "Rename FILE to NEWNAME, updating visiting buffers first.
This prevents \"changed on disk\" prompts from buffers visiting FILE."
  (let ((old-abs (expand-file-name file))
        (new-abs (expand-file-name newname)))
    (dolist (buf (buffer-list))
      (with-current-buffer buf
        (when (and buffer-file-name
                   (string= (expand-file-name buffer-file-name) old-abs))
          (set-visited-file-name new-abs nil t))))
    (rename-file old-abs new-abs ok-if-already-exists)))

(defun transmute--name-collides-p (candidate original)
  "Return non-nil when CANDIDATE names an existing file other than ORIGINAL.
Used by rename loops so a file whose computed name is unchanged is not
treated as a collision with itself."
  (and (file-exists-p candidate)
       (not (string= (expand-file-name candidate)
                     (expand-file-name original)))))

(defun transmute--unique-name (dir filename)
  "Return an unused absolute path in DIR based on FILENAME.
A numeric suffix is added before the extension on collision."
  (let* ((base (file-name-sans-extension filename))
         (ext (file-name-extension filename))
         (candidate (expand-file-name filename dir))
         (counter 1))
    (while (file-exists-p candidate)
      (setq candidate
            (expand-file-name (if ext
                                  (format "%s-%d.%s" base counter ext)
                                (format "%s-%d" base counter))
                              dir))
      (cl-incf counter))
    candidate))

(defun transmute--run-command-async (name cmd &optional callback quiet)
  "Run CMD string asynchronously as NAME.
Optional CALLBACK is called with (PROCESS EXIT-STATUS) after completion.
When QUIET is non-nil only failures are logged, keeping the log readable
for bulk jobs that start one process per file."
  (unless quiet
    (transmute--log "[START] %s: %s" name cmd))
  (let ((log-buf (get-buffer-create transmute-log-buffer-name)))
    (unless (get-buffer-window log-buf)
      (display-buffer log-buf)))
  (setq transmute--task-registered t)
  (let* ((buf (generate-new-buffer (format " *transmute-%s*" name)))
         (process (start-process-shell-command name buf cmd)))
    (push process transmute-active-processes)
    (set-process-sentinel
     process
     (lambda (proc _event)
       (when (memq (process-status proc) '(exit signal))
         (let ((exit-code (process-exit-status proc))
               (proc-name (process-name proc))
               (proc-buf (process-buffer proc)))
           (setq transmute-active-processes (delq proc transmute-active-processes))
           (setq transmute-completed-tasks (1+ transmute-completed-tasks))
           (if (zerop exit-code)
               (unless quiet
                 (transmute--log "[SUCCESS] %s" proc-name))
             (transmute--log "[FAILED] %s (exit code %d)" proc-name exit-code)
             (message "Transmute task FAILED: %s" proc-name)
             (when (buffer-live-p proc-buf)
               (transmute--log "--- Output for %s ---" proc-name)
               (transmute--log "%s" (with-current-buffer proc-buf (buffer-string)))
               (transmute--log "---------------------" proc-name)))
           (when (buffer-live-p proc-buf)
             (kill-buffer proc-buf))
           (when callback (funcall callback proc exit-code))
           (when (null transmute-active-processes)
             (setq transmute-total-tasks 0
                   transmute-completed-tasks 0)
             (run-hooks 'transmute-after-batch-hook))
           (transmute--update-progress-display)))))
    (set-process-query-on-exit-flag process nil)
    process))

(defun transmute--run-async (cmd callback)
  "Run shell CMD asynchronously, calling CALLBACK with the exit code.
Lightweight helper for use inside `transmute-do-batch-async' bodies:
unlike `transmute--run-command-async' it does not register the process
in `transmute-active-processes' or touch global progress counters, so
it will not prematurely trigger `transmute-after-batch-hook'."
  (transmute--log "[START] %s" cmd)
  (let* ((buf (generate-new-buffer " *transmute-async*"))
         (proc (start-process-shell-command "transmute-async" buf cmd)))
    (set-process-query-on-exit-flag proc nil)
    (set-process-sentinel
     proc
     (lambda (p _event)
       (when (memq (process-status p) '(exit signal))
         (let ((code (process-exit-status p))
               (pbuf (process-buffer p)))
           (if (zerop code)
               (transmute--log "[SUCCESS] %s" cmd)
             (transmute--log "[FAILED] %s (exit %d)" cmd code))
           (when (buffer-live-p pbuf) (kill-buffer pbuf))
           (funcall callback code)))))
    proc))

(defun transmute--run-command (cmd &rest args)
  "Run CMD with ARGS and return exit code."
  (let ((full-cmd (mapconcat #'shell-quote-argument (cons cmd args) " ")))
    (transmute--log "[EXEC] %s" full-cmd)
    (shell-command full-cmd)))

(defun transmute--delete-temp (path)
  "Delete temporary PATH, which may name a file or a directory.
Errors are ignored so cleanup never masks the task's own result."
  (ignore-errors
    (cond ((file-directory-p path) (delete-directory path t))
          ((file-exists-p path) (delete-file path)))))

(defun transmute--concat-escape-path (path)
  "Escape PATH for use in an ffmpeg concat demuxer list file.
Backslashes and single quotes are backslash-escaped so paths
containing those characters cannot break or inject into the file."
  (mapconcat (lambda (char)
               (cond ((eq char ?\\) "\\\\")
                     ((eq char ?') "\\'")
                     (t (char-to-string char))))
             path ""))

(defun transmute--preserve-metadata (src dst)
  "Copy metadata from SRC to DST, excluding image dimensions and orientation.
Sets Orientation to Normal."
  (transmute--run-command "exiftool" "-overwrite_original_in_place" "-Orientation=1" "-n"
                          "-TagsFromFile" src 
                          "--ExifImageWidth" "--ExifImageHeight" "--Orientation"
                          dst))

(defun transmute--trash (file)
  "Move FILE to trash."
  (if (executable-find transmute-trash-command)
      (transmute--run-command transmute-trash-command file)
    (move-file-to-trash file)))

(defun transmute--exif-cmd (src dst)
  "Return exiftool command string to copy tags from SRC to DST.
Image dimensions, orientation, and the embedded EXIF thumbnail are
excluded: the pixels may have changed size or rotation, so a stale
thumbnail would misrepresent the image.  Orientation is set to Normal."
  (format "exiftool -overwrite_original_in_place -Orientation=1 -n -TagsFromFile %s --ExifImageWidth --ExifImageHeight --ThumbnailImage --Orientation %s"
          (shell-quote-argument src) (shell-quote-argument dst)))

(defun transmute--processed-xattr-cmd (file)
  "Return a command string setting the user.do_backup.processed xattr on FILE.
This tells `do_backup` that the file has already been processed
and should not be rotated or re-processed on the next backup run.
Returns nil when `setfattr` is not available."
  (when (executable-find "setfattr")
    (format "setfattr -n user.do_backup.processed -v 1 %s"
            (shell-quote-argument (expand-file-name file)))))

;;; Batch Macros
;;
;; These are defined before their first use (`transmute-picture-set-xattr')
;; so the byte compiler expands them instead of emitting funcalls.

(defmacro transmute-do-batch (files &rest body)
  "Run BODY for each file in FILES, binding `file' to current file.
After processing all files, run `transmute-after-batch-hook' if no
asynchronous processes are active."
  (declare (indent 1))
  `(let ((batch-files ,files))
     ;; Only reset shared rename/bookkeeping state when no other batch is
     ;; still in flight, so overlapping batches accumulate instead of
     ;; clobbering each other.
     (unless transmute-active-processes
       (setq transmute--last-renames nil))
     (setq transmute-total-tasks (+ transmute-total-tasks (length batch-files))
           transmute-batch-files (if transmute-active-processes
                                     (append transmute-batch-files batch-files)
                                   batch-files))
     (dolist (file batch-files)
       (let ((default-directory (file-name-directory file))
             (transmute--task-registered nil))
         ,@body
         ;; A purely synchronous task never reaches a process sentinel, so
         ;; count it here; asynchronous tasks are counted when they exit.
         (unless transmute--task-registered
           (setq transmute-completed-tasks (1+ transmute-completed-tasks))
           (transmute--update-progress-display))))
     ;; If after processing all files no asynchronous tasks are pending,
     ;; run the refresh hook immediately.
     (when (null transmute-active-processes)
       (setq transmute-total-tasks 0
             transmute-completed-tasks 0)
       (run-hooks 'transmute-after-batch-hook))))

(defmacro transmute-do-batch-async (files &rest body)
  "Process FILES one at a time, asynchronously.
BODY is evaluated with `file' and `done'.  Call (funcall done)
when processing for the current file completes.  If BODY signals an
error the error is logged and the queue still advances, so a single
bad file cannot stall the batch."
  (declare (indent 1))
  `(let* ((--queue ,files)
          (--continuation nil))
     (setq --continuation
           (lambda ()
             (if --queue
                 (let* ((file (pop --queue))
                        (default-directory (file-name-directory file))
                        (--advanced nil)
                        (done (lambda ()
                                (unless --advanced
                                  (setq --advanced t)
                                  (setq transmute-completed-tasks
                                        (1+ transmute-completed-tasks))
                                  (transmute--update-progress-display)
                                  (run-at-time 0 nil --continuation)))))
                   (condition-case err
                       (progn ,@body)
                     (error
                      (transmute--log "[ERROR] %s: %s" file
                                      (error-message-string err))
                      (funcall done))))
               (when (null transmute-active-processes)
                 (setq transmute-total-tasks 0
                       transmute-completed-tasks 0)
                 (run-hooks 'transmute-after-batch-hook)))))
     (unless transmute-active-processes
       (setq transmute--last-renames nil))
     (setq transmute-total-tasks (+ transmute-total-tasks (length --queue))
           transmute-batch-files (if transmute-active-processes
                                     (append transmute-batch-files
                                             (copy-sequence --queue))
                                   (copy-sequence --queue)))
     (funcall --continuation)))

(defmacro transmute-do-batch-parallel (files &rest body)
  "Process FILES in parallel, asynchronously.
BODY is evaluated for each FILE.  All files are started at once.
The after-batch hook runs when all processes finish."
  (declare (indent 1))
  `(let ((batch-files ,files))
     (unless transmute-active-processes
       (setq transmute--last-renames nil))
     (setq transmute-total-tasks (+ transmute-total-tasks (length batch-files))
           transmute-batch-files (if transmute-active-processes
                                     (append transmute-batch-files batch-files)
                                   batch-files))
     (dolist (file batch-files)
       (let ((default-directory (file-name-directory file))
             (transmute--task-registered nil))
         ,@body
         ;; Tasks that started no process (e.g. a skipped file) are
         ;; synchronous as far as the progress counter is concerned.
         (unless transmute--task-registered
           (setq transmute-completed-tasks (1+ transmute-completed-tasks))
           (transmute--update-progress-display))))
     (when (null transmute-active-processes)
       (setq transmute-total-tasks 0
             transmute-completed-tasks 0)
       (run-hooks 'transmute-after-batch-hook))))

;;;###autoload
(defun transmute-picture-show-xattr ()
  "Show user.do_backup.processed xattr for selected files.
Displayed in a dedicated info buffer."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute--display-info targets
                             '("Backup Xattr" . "sh -c 'getfattr -n user.do_backup.processed \"$1\" 2>&1 || echo \"(not set)\"' xattr"))))

;;;###autoload
(defun transmute-picture-set-xattr (name value)
  "Set xattr NAME to VALUE on selected files.
The NAME is completed against known xattr names."
  (interactive
   (let ((name (completing-read "Xattr name: "
                                '("user.do_backup.processed"
                                  "user.do_backup.skip"
                                  "user.transmute.processed")
                                nil nil "user.do_backup.processed")))
     (list name (read-string (format "Value for %s: " name) "1"))))
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute-do-batch targets
      (let* ((abs-file (expand-file-name file))
             (cmd (format "setfattr -n %s -v %s %s"
                          (shell-quote-argument name)
                          (shell-quote-argument value)
                          (shell-quote-argument abs-file))))
        (transmute--run-command-async (file-name-nondirectory file) cmd)))))

(defun transmute--rotate-image (file degrees)
  "Pixel-rotate FILE by DEGREES using ImageMagick.
Uses -auto-orient to bake any existing EXIF orientation into the pixels
first, then applies the rotation.  No EXIF orientation metadata is
written — the result is a pure pixel rotation compatible with all viewers."
  (let* ((file (expand-file-name file))
         (tmp (make-temp-file "transmute-" nil (concat "." (file-name-extension file))))
         (magick-cmd (format "magick %s -auto-orient -rotate %s %s"
                             (shell-quote-argument file) degrees (shell-quote-argument tmp)))
         (strip-orient (format "exiftool -overwrite_original_in_place -Orientation= %s"
                               (shell-quote-argument tmp)))
         (touch-cmd (format "touch -r %s %s" (shell-quote-argument file) (shell-quote-argument tmp)))
         (cp-cmd (format "cp -p %s %s" (shell-quote-argument tmp) (shell-quote-argument file)))
         (rm-tmp (format "rm %s" (shell-quote-argument tmp)))
         (xattr-cmd (transmute--processed-xattr-cmd file))
         (full-cmd (mapconcat #'identity (delq nil (list magick-cmd strip-orient touch-cmd cp-cmd rm-tmp xattr-cmd)) " && ")))
    (transmute--run-command-async (file-name-nondirectory file) full-cmd
                                  (lambda (_proc _code)
                                    (transmute--delete-temp tmp)))))

;;; High-level Conversion Helpers

(defun transmute-convert-image (src dst &rest magick-args)
  "Convert image SRC to DST using MAGICK-ARGS.
Preserves metadata and moves SRC to trash."
  (let* ((src (expand-file-name src))
         (dst (expand-file-name dst))
         (tmp (make-temp-file "transmute-" nil (concat "." (file-name-extension dst))))
         (magick-cmd (mapconcat #'shell-quote-argument (append (list "magick" src) magick-args (list tmp)) " "))
         (exif-cmd (transmute--exif-cmd src tmp))
         (touch-cmd (format "touch -r %s %s" (shell-quote-argument src) (shell-quote-argument tmp)))
         (cp-cmd (format "cp -p %s %s" (shell-quote-argument tmp) (shell-quote-argument dst)))
         (rm-tmp (format "rm %s" (shell-quote-argument tmp)))
         (trash-cmd (unless (string= src dst)
                      (if (executable-find transmute-trash-command)
                          (format "%s %s" transmute-trash-command (shell-quote-argument src))
                        nil)))
         (trash-fallback (unless (string= src dst)
                           (unless (executable-find transmute-trash-command)
                             src)))
         (xattr-cmd (transmute--processed-xattr-cmd dst))
         (full-cmd (mapconcat #'identity (delq nil (list magick-cmd exif-cmd touch-cmd cp-cmd rm-tmp trash-cmd xattr-cmd)) " && ")))
    (transmute--run-command-async
     (file-name-nondirectory src) full-cmd
     (lambda (_proc exit-code)
       (transmute--delete-temp tmp)
       (when (and trash-fallback (zerop exit-code))
         (move-file-to-trash trash-fallback))))))

(defun transmute--convert-image-copy (src dst magick-args preserve-metadata)
  "Internal core for `transmute-convert-image-copy'.
MAGICK-ARGS is a list of arguments passed to magick.  When
PRESERVE-METADATA is non-nil, tags are copied from SRC to DST;
when nil, DST keeps only the metadata magick wrote, which strips
EXIF (including GPS) for sharing."
  (let* ((src (expand-file-name src))
         (dst (expand-file-name dst))
         (tmp (make-temp-file "transmute-" nil (concat "." (file-name-extension dst))))
         (magick-cmd (mapconcat #'shell-quote-argument (append (list "magick" src) magick-args (list tmp)) " "))
         (exif-cmd (when preserve-metadata (transmute--exif-cmd src tmp)))
         (touch-cmd (format "touch -r %s %s" (shell-quote-argument src) (shell-quote-argument tmp)))
         (cp-cmd (format "cp -p %s %s" (shell-quote-argument tmp) (shell-quote-argument dst)))
         (rm-tmp (format "rm %s" (shell-quote-argument tmp)))
         (xattr-cmd (transmute--processed-xattr-cmd dst))
         (full-cmd (mapconcat #'identity (delq nil (list magick-cmd exif-cmd touch-cmd cp-cmd rm-tmp xattr-cmd)) " && ")))
    (transmute--run-command-async (file-name-nondirectory src) full-cmd
                                  (lambda (_proc _code)
                                    (transmute--delete-temp tmp)))))

(defun transmute-convert-image-copy (src dst &rest magick-args)
  "Convert image SRC to DST using MAGICK-ARGS.
Preserves metadata, keeps SRC."
  (transmute--convert-image-copy src dst magick-args t))

(defun transmute-convert-video (src dst &rest ffmpeg-args)
  "Convert video SRC to DST using FFMPEG-ARGS.
Preserves metadata."
  (let* ((src (expand-file-name src))
         (dst (expand-file-name dst))
         (tmp (make-temp-file "transmute-" nil (concat "." (file-name-extension dst))))
         (ffmpeg-cmd (mapconcat #'shell-quote-argument
                                (append (list "ffmpeg" "-hide_banner" "-loglevel" "warning" "-stats" "-y" "-i" src "-map_metadata" "0")
                                        (when transmute-ffmpeg-threads
                                          (list "-threads"
                                                (number-to-string transmute-ffmpeg-threads)))
                                        ffmpeg-args
                                        (list tmp)) " "))
         (touch-cmd (format "touch -r %s %s" (shell-quote-argument src) (shell-quote-argument tmp)))
         (cp-cmd (format "cp -p %s %s" (shell-quote-argument tmp) (shell-quote-argument dst)))
         (rm-tmp (format "rm %s" (shell-quote-argument tmp)))
         (full-cmd (mapconcat #'identity (list ffmpeg-cmd touch-cmd cp-cmd rm-tmp) " && ")))
    (transmute--run-command-async (file-name-nondirectory src) full-cmd
                                  (lambda (_proc _code)
                                    (transmute--delete-temp tmp)))))

(defun transmute--gif-filter ()
  "Return the ffmpeg filter chain shared by both GIF conversion passes."
  (mapconcat #'identity
             (delq nil
                   (list (when (and transmute-gif-fps (> transmute-gif-fps 0))
                           (format "fps=%s" transmute-gif-fps))
                         (when (and transmute-gif-width (> transmute-gif-width 0))
                           (format "scale=%d:-1:flags=lanczos"
                                   transmute-gif-width))))
             ","))

(defun transmute--convert-video-to-gif (src dst)
  "Convert video SRC to GIF DST using a two-pass palette.
A single-pass GIF encode uses ffmpeg's generic palette, which
darkens the image and dithers flat areas into speckles.  Generating
a palette from the video first keeps the original colours and makes
text and flat backgrounds much cleaner.  Preserves the source's
modification time."
  (let* ((src (expand-file-name src))
         (dst (expand-file-name dst))
         (tmp (make-temp-file "transmute-" nil ".gif"))
         (palette (make-temp-file "transmute-palette-" nil ".png"))
         (base (or (transmute--gif-filter) "null"))
         (threads (when transmute-ffmpeg-threads
                    (list "-threads" (number-to-string transmute-ffmpeg-threads))))
         (palette-cmd
          (mapconcat #'shell-quote-argument
                     (append (list "ffmpeg" "-hide_banner" "-loglevel" "warning"
                                   "-stats" "-y" "-i" src)
                             threads
                             (list "-vf"
                                   (format "%s,palettegen=stats_mode=diff:max_colors=%d"
                                           base (max 2 (min 256 transmute-gif-colours)))
                                   "-frames:v" "1" palette))
                     " "))
         (encode-cmd
          (mapconcat #'shell-quote-argument
                     (append (list "ffmpeg" "-hide_banner" "-loglevel" "warning"
                                   "-stats" "-y" "-i" src "-i" palette)
                             threads
                             (list "-lavfi"
                                   (concat base " [x]; [x][1:v] paletteuse=dither="
                                           transmute-gif-dither ":diff_mode=rectangle")
                                   "-loop" "0" tmp))
                     " "))
         (touch-cmd (format "touch -r %s %s"
                            (shell-quote-argument src) (shell-quote-argument tmp)))
         (cp-cmd (format "cp -p %s %s"
                         (shell-quote-argument tmp) (shell-quote-argument dst)))
         (rm-tmp (format "rm %s %s"
                         (shell-quote-argument tmp) (shell-quote-argument palette)))
         (full-cmd (mapconcat #'identity
                              (list palette-cmd encode-cmd touch-cmd cp-cmd rm-tmp)
                              " && ")))
    (transmute--run-command-async (file-name-nondirectory src) full-cmd
                                  (lambda (_proc _code)
                                    (transmute--delete-temp tmp)
                                    (transmute--delete-temp palette)))))

(defun transmute-convert-gan (src dst &rest gan-args)
  "Upscale image SRC to DST using realesrgan-ncnn-vulkan with GAN-ARGS.
Preserves metadata and moves SRC to trash."
  (let* ((src (expand-file-name src))
         (dst (expand-file-name dst))
         (tmp (make-temp-file "transmute-" nil (concat "." (file-name-extension dst))))
         (gan-cmd (mapconcat #'shell-quote-argument (append (list "realesrgan-ncnn-vulkan") gan-args (list "-i" src "-o" tmp)) " "))
         (exif-cmd (transmute--exif-cmd src tmp))
         (touch-cmd (format "touch -r %s %s" (shell-quote-argument src) (shell-quote-argument tmp)))
         (cp-cmd (format "cp -p %s %s" (shell-quote-argument tmp) (shell-quote-argument dst)))
         (rm-tmp (format "rm %s" (shell-quote-argument tmp)))
         (trash-cmd (unless (string= src dst)
                      (if (executable-find transmute-trash-command)
                          (format "%s %s" transmute-trash-command (shell-quote-argument src))
                        nil)))
         (trash-fallback (unless (string= src dst)
                           (unless (executable-find transmute-trash-command)
                             src)))
         (xattr-cmd (transmute--processed-xattr-cmd dst))
         (full-cmd (mapconcat #'identity (delq nil (list gan-cmd exif-cmd touch-cmd cp-cmd rm-tmp trash-cmd xattr-cmd)) " && ")))
    (transmute--run-command-async
     (file-name-nondirectory src) full-cmd
     (lambda (_proc exit-code)
       (transmute--delete-temp tmp)
       (when (and trash-fallback (zerop exit-code))
         (move-file-to-trash trash-fallback))))))

;;; Upscayl Integration

(defun transmute--upscayl-binary ()
  "Return the upscayl-bin executable to use, or nil if none is found.
Honors `transmute-upscayl-binary'.  When nil, auto-detects.  The
result is always an absolute file name so the spawned shell does not
need to resolve the binary via its own PATH, which may differ from
`exec-path' and would otherwise cause a shell \"command not found\"
(exit 127)."
  (let ((names (if transmute-upscayl-binary
                   (list transmute-upscayl-binary)
                 '("upscayl-bin")))
        (paths '("/opt/upscayl/resources/bin/upscayl-bin"
                 "/usr/local/bin/upscayl-bin"
                 "/usr/lib/upscayl/bin/upscayl-bin")))
    (or (cl-some (lambda (name)
                   (cond ((string-match-p "\\`/" name)
                          (when (file-executable-p name) name))
                         ((executable-find name))))
                 names)
        (cl-some (lambda (path) (when (file-executable-p path) path)) paths))))

(defun transmute--upscayl-models-dir ()
  "Return the folder holding Upscayl models, or nil when not found.
Honors `transmute-upscayl-models-dir'.  When nil, prefers a models
folder next to the detected binary (the Upscayl AppImage ships one
at resources/models), then the common system-wide locations."
  (or (when transmute-upscayl-models-dir
        (let ((dir (expand-file-name transmute-upscayl-models-dir)))
          (when (file-directory-p dir) dir)))
      (when-let* ((binary (transmute--upscayl-binary)))
        (let ((dir (expand-file-name "../models" (file-name-directory binary))))
          (when (file-directory-p dir) dir)))
      (cl-some (lambda (dir)
                 (when (file-directory-p dir) (expand-file-name dir)))
               '("~/.config/upscayl/models"
                 "/opt/upscayl/resources/models"))))

(defun transmute--upscayl-models ()
  "Return the sorted names of Upscayl models found on disk."
  (when-let* ((dir (transmute--upscayl-models-dir)))
    (sort (mapcar (lambda (file)
                    (file-name-sans-extension (file-name-nondirectory file)))
                  (directory-files dir t "\\.param\\'"))
          #'string<)))

(defun transmute--upscayl-target-width (width height edge)
  "Return the output width putting the short edge of WIDTH x HEIGHT at EDGE.
Returns nil when EDGE is nil or 0, meaning the model's native scale
is kept.  upscayl-bin only accepts a target width, so landscape and
square images are scaled so their short edge (the height) reaches
EDGE, while portrait images keep EDGE as their width."
  (when (and edge (> edge 0))
    (if (>= width height)
        (ceiling (* edge width) height)
      edge)))

(defun transmute--image-dimensions (file)
  "Return (WIDTH HEIGHT) for FILE, or nil when they cannot be read."
  (let ((dims (string-trim
               (shell-command-to-string
                (format "magick identify -format \"%%w %%h\" %s"
                        (shell-quote-argument (expand-file-name file)))))))
    (when (string-match "\\`\\([0-9]+\\)[ \t]+\\([0-9]+\\)\\'" dims)
      (list (string-to-number (match-string 1 dims))
            (string-to-number (match-string 2 dims))))))

(defun transmute-convert-upscayl (src dst &rest upscayl-args)
  "Upscale image SRC to DST using upscayl-bin and UPSCAYL-ARGS.
UPSCAYL-ARGS are extra CLI arguments (model, models folder, format,
compression, width, GPU, tile).  Preserves metadata and moves SRC to
trash.  Signals a user error when no upscayl-bin executable exists."
  (let ((binary (transmute--upscayl-binary)))
    (unless binary
      (user-error "upscayl-bin not found; install the Upscayl AppImage or set `transmute-upscayl-binary'"))
    (let* ((src (expand-file-name src))
           (dst (expand-file-name dst))
           (tmp (make-temp-file "transmute-" nil (concat "." (file-name-extension dst))))
           (upscayl-cmd (mapconcat #'shell-quote-argument
                                   (append (list binary) upscayl-args
                                           (list "-i" src "-o" tmp)) " "))
           (exif-cmd (transmute--exif-cmd src tmp))
           (touch-cmd (format "touch -r %s %s" (shell-quote-argument src) (shell-quote-argument tmp)))
           (cp-cmd (format "cp -p %s %s" (shell-quote-argument tmp) (shell-quote-argument dst)))
           (rm-tmp (format "rm %s" (shell-quote-argument tmp)))
           (trash-cmd (unless (string= src dst)
                        (if (executable-find transmute-trash-command)
                            (format "%s %s" transmute-trash-command (shell-quote-argument src))
                          nil)))
           (trash-fallback (unless (string= src dst)
                             (unless (executable-find transmute-trash-command)
                               src)))
           (xattr-cmd (transmute--processed-xattr-cmd dst))
           (full-cmd (mapconcat #'identity (delq nil (list upscayl-cmd exif-cmd touch-cmd cp-cmd rm-tmp trash-cmd xattr-cmd)) " && ")))
      (transmute--run-command-async
       (file-name-nondirectory src) full-cmd
       (lambda (_proc exit-code)
         (transmute--delete-temp tmp)
         (when (and trash-fallback (zerop exit-code))
           (move-file-to-trash trash-fallback)))))))

;;; Batch / Dired Integration

(defun transmute--image-dired-display-file ()
  "Return the original file displayed in the image-dired display buffer.
Works when the current buffer is *image-dired-display-image* (focused
from the thumbnail view).  Returns nil if not in a display buffer."
  (when (string-match-p "\\`\\*image-dired-display-image\\*" (buffer-name))
    (or buffer-file-name
        (when-let* ((thumb-buf (and (boundp 'image-dired-thumbnail-buffer)
                                    (get-buffer image-dired-thumbnail-buffer))))
          (with-current-buffer thumb-buf
            (or (and (fboundp 'dired-image-thumbnail--nearest-image-original-file-name)
                     (dired-image-thumbnail--nearest-image-original-file-name))
                (and (fboundp 'image-dired-original-file-name)
                     (image-dired-original-file-name))))))))

(defun transmute-get-targets ()
  "Get list of files to process. 
If in dired, use marked files or file at point.
If in image-dired-thumbnail-mode, use marked or file at point.
If in image-dired-display-image buffer, use the displayed file.
Otherwise ask for file."
  (cond
   ((derived-mode-p 'dired-mode)
    (dired-get-marked-files))
   ((and (derived-mode-p 'image-dired-thumbnail-mode)
         (fboundp 'dired-image-thumbnail-get-marked))
    (or (dired-image-thumbnail-get-marked)
        (and (fboundp 'dired-image-thumbnail--nearest-image-original-file-name)
             (let ((file (dired-image-thumbnail--nearest-image-original-file-name)))
               (when file (list file))))))
   ((transmute--image-dired-display-file)
    (list (transmute--image-dired-display-file)))
   ((derived-mode-p 'image-mode)
    (when buffer-file-name (list buffer-file-name)))
   (t (list (read-file-name "Process file: ")))))

(defun transmute-get-filtered-targets (type)
  "Get marked files filtered by TYPE ('image, 'video, 'audio, 'document, or 'any)."
  (let* ((files (transmute-get-targets))
         (extensions (cl-case type
                       (image transmute-image-extensions)
                       (video transmute-video-extensions)
                       (audio transmute-audio-extensions)
                       (document transmute-document-extensions)
                       (any (append transmute-image-extensions 
                                    transmute-video-extensions 
                                    transmute-audio-extensions))
                       (t nil))))
    (if extensions
        (let ((filtered (cl-remove-if-not
                         (lambda (f)
                           (let ((ext (file-name-extension f)))
                             (and ext (member (downcase ext) extensions))))
                         files)))
          (unless filtered
            (message "No %s files found in selection." (symbol-name type)))
          filtered)
      files)))

;;; Specific Commands

;;;###autoload
(defun transmute-picture-convert ()
  "Convert images to JPG."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute-do-batch targets
      (let* ((parsed (transmute--parse-filename file))
             (dst (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed)) ".jpg")))
        (if (string-suffix-p ".svg" file t)
            (transmute-convert-image-copy file dst "-density" "300" "-auto-orient" "-strip")
          (transmute-convert-image file dst "-auto-orient" "-strip"))))))

;;;###autoload
(defun transmute-picture-crush ()
  "Resize images to 640px."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute-do-batch targets
      (transmute-convert-image file file "-auto-orient" "-strip" "-quality" "50%" "-resize" "640x>" "-resize" "x640>"))))

;;;###autoload
(defun transmute-picture-scale ()
  "Resize images to 1920px."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute-do-batch targets
      (transmute-convert-image file file "-auto-orient" "-strip" "-quality" "50%" "-resize" "1920x>" "-resize" "x1920>"))))

;;;###autoload
(defun transmute-picture-resize (width height)
  "Resize images to exactly WIDTH x HEIGHT, ignoring aspect ratio."
  (interactive (list (read-number "Width: " 1920)
                     (read-number "Height: " 1080)))
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute-do-batch targets
      (transmute-convert-image file file "-auto-orient" "-resize" (format "%dx%d!" width height)))))

;;;###autoload
(defun transmute-picture-compress ()
  "Compress images in place, keeping resolution.
Re-encodes at `transmute-compress-quality' and preserves the source
metadata (the dimensions/orientation tags are refreshed).  No resizing
is performed — pixel dimensions are preserved.  Processes files
sequentially so Emacs stays responsive on large batches."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute-do-batch-async targets
      (let* ((src (expand-file-name file))
             (tmp (make-temp-file "transmute-" nil (concat "." (file-name-extension src))))
             (magick-cmd (mapconcat #'shell-quote-argument
                                    (append (list "magick" src)
                                            (list "-auto-orient" "-strip"
                                                  "-quality" transmute-compress-quality)
                                            (list tmp)) " "))
             (exif-cmd (transmute--exif-cmd src tmp))
             (touch-cmd (format "touch -r %s %s"
                                (shell-quote-argument src)
                                (shell-quote-argument tmp)))
             (cp-cmd (format "cp -p %s %s"
                             (shell-quote-argument tmp)
                             (shell-quote-argument src)))
             (rm-tmp (format "rm %s" (shell-quote-argument tmp)))
             (xattr-cmd (transmute--processed-xattr-cmd src))
             (full-cmd (mapconcat #'identity
                                  (delq nil (list magick-cmd exif-cmd touch-cmd
                                                  cp-cmd rm-tmp xattr-cmd))
                                  " && ")))
        (transmute--run-async full-cmd
          (lambda (_code) (funcall done)))))))

;;;###autoload
(defun transmute-picture-rotate-right ()
  "Rotate images 90 degrees clockwise (pixel-only, no EXIF orientation)."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute-do-batch targets
      (transmute--rotate-image file "90"))))

;;;###autoload
(defun transmute-picture-rotate-left ()
  "Rotate images 90 degrees counter-clockwise (pixel-only, no EXIF orientation)."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute-do-batch targets
      (transmute--rotate-image file "-90"))))

;;;###autoload
(defun transmute-picture-rotate (degrees)
  "Rotate images by user-supplied DEGREES (pixel-only, no EXIF orientation).
Positive values rotate clockwise, negative counter-clockwise."
  (interactive (list (read-number "Degrees (+ clockwise, - counter-clockwise): " 90)))
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute-do-batch targets
      (transmute--rotate-image file (number-to-string degrees)))))

;;;###autoload
(defun transmute-picture-correct ()
  "Brighten images (120% modulate)."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute-do-batch targets
      (transmute-convert-image file file "-modulate" "120,100,100"))))

;;;###autoload
(defun transmute-video-convert ()
  "Convert videos to MP4 (h264/aac)."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((parsed (transmute--parse-filename file))
             (dst (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed)) ".mp4")))
        (transmute-convert-video file dst "-c:a" "aac" "-c:v" "libx264" "-crf" "23")))))

;;;###autoload
(defun transmute-video-shrink ()
  "Resize videos to fit 960x960."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((parsed (transmute--parse-filename file))
             (dst (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed)) ".mp4")))
        (transmute-convert-video file dst 
                                 "-vf" "scale='min(960,iw)':'min(960,ih)':force_original_aspect_ratio=decrease"
                                 "-vcodec" "libx264" "-crf" "28" "-preset" "medium" "-movflags" "+faststart")))))

;;;###autoload
(defun transmute-video-extract-audio ()
  "Extract audio from videos as WAV."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((parsed (transmute--parse-filename file))
             (timestamp (format-time-string "%Y%m%d%H%M%S"))
             (dst (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed)) "-" timestamp ".wav")))
        (transmute-convert-video file dst "-vn" "-q:a" "0" "-map" "a")))))

;;;###autoload
(defun transmute-video-toptail (trim-start trim-end)
  "Trim video from start and end."
  (interactive "nTrim from start (sec): \nnTrim from end (sec): ")
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((duration-str (shell-command-to-string
                            (format "ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 %s"
                                    (shell-quote-argument file))))
             (duration (floor (string-to-number duration-str)))
             (end-time (- duration trim-end))
             (parsed (transmute--parse-filename file))
             (dst (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed)) "-trimmed." (cdr (assoc 'extension parsed)))))
        (if (<= end-time trim-start)
            (message "Error: Trim amount exceeds duration for %s" file)
          ;; -t takes a *duration*, not an end timestamp: the clip must be
          ;; (end-time - trim-start) seconds long to stop at end-time.
          (transmute-convert-video file dst "-ss" (number-to-string trim-start)
                                   "-t" (number-to-string (- end-time trim-start))
                                   "-c" "copy"))))))

;;;###autoload
(defun transmute-picture-upscale ()
  "Upscale images using realesrgan-x4plus.
Requires the `realesrgan-ncnn-vulkan' executable.  Use
`transmute-picture-upscale-upscayl' for upscaling through the
Upscayl CLI instead."
  (interactive)
  (unless (executable-find "realesrgan-ncnn-vulkan")
    (user-error "realesrgan-ncnn-vulkan not found; install it or use `transmute-picture-upscale-upscayl' (upscayl-bin)"))
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute-do-batch targets
      (let* ((parsed (transmute--parse-filename file))
             (dst (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed)) ".jpg")))
        (transmute-convert-gan file dst "-n" "realesrgan-x4plus" "-j" "8:8:8" "-f" "jpg")))))

;;;###autoload
(defun transmute-picture-upscale-upscayl (model edge format)
  "Upscale images through the Upscayl CLI (upscayl-bin).
MODEL is an Upscayl model name, chosen from the .param files in the
models folder (e.g. digital-art-4x).  EDGE is the target size of the
image's short edge in pixels; 0 keeps the model's native scale
(usually 4x).  FORMAT is the output format: jpg, png or webp.  Each
upscaled file gets the same base name as its source with the new
extension; the source is moved to the trash once the upscale
succeeds.  Compression, GPU and tile size come from the
`transmute-upscayl-*' options.  Landscape and square images are
resized via upscayl-bin's -w argument so the short edge reaches
EDGE, mirroring the `upscale_art.sh' pipeline.  Input files must be
readable by upscayl-bin (jpg, png or webp)."
  (interactive
   (progn
     (unless (transmute--upscayl-binary)
       (user-error "upscayl-bin not found; install the Upscayl AppImage or set `transmute-upscayl-binary'"))
     (unless (transmute--upscayl-models-dir)
       (user-error "No Upscayl models folder found; set `transmute-upscayl-models-dir'"))
     (list (let ((models (transmute--upscayl-models)))
             (if models
                 (completing-read "Upscayl model: " models nil t nil nil
                                  transmute-upscayl-model)
               (read-string "Upscayl model: " transmute-upscayl-model)))
           (read-number "Target short edge in px (0 = native model scale): "
                        transmute-upscayl-edge)
           (completing-read "Output format: " '("jpg" "png" "webp")
                            nil t nil nil transmute-upscayl-format))))
  (let ((binary (transmute--upscayl-binary))
        (models-dir (transmute--upscayl-models-dir)))
    (unless binary
      (user-error "upscayl-bin not found; install the Upscayl AppImage or set `transmute-upscayl-binary'"))
    (unless models-dir
      (user-error "No Upscayl models folder found; set `transmute-upscayl-models-dir'"))
    (when-let* ((targets (transmute-get-filtered-targets 'image)))
      (transmute-do-batch targets
        (let* ((parsed (transmute--parse-filename file))
               (dst (concat (cdr (assoc 'directory parsed))
                            (cdr (assoc 'no-ext parsed)) "." format))
               (resize (> edge 0))
               (dims (when resize (transmute--image-dimensions file)))
               (target-width (when dims
                               (transmute--upscayl-target-width
                                (car dims) (cadr dims) edge)))
               (args (append (list "-n" model "-m" models-dir
                                   "-f" format
                                   "-c" (number-to-string transmute-upscayl-compression))
                             (when target-width
                               (list "-w" (number-to-string target-width)))
                             (when transmute-upscayl-gpu
                               (list "-g" (number-to-string transmute-upscayl-gpu)))
                             (when (and transmute-upscayl-tile (> transmute-upscayl-tile 0))
                               (list "-t" (number-to-string transmute-upscayl-tile))))))
          (when (and resize (null dims))
            (transmute--log "[WARN] %s: could not read image dimensions; using native model scale"
                            (file-name-nondirectory file)))
          (apply #'transmute-convert-upscayl file dst args))))))

;;;###autoload
(defun transmute-picture-get-text ()
  "Extract text from images using tesseract OCR.
Runs asynchronously so Emacs stays responsive during OCR."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute-do-batch-parallel targets
      (let* ((parsed (transmute--parse-filename file))
             (out-base (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed))))
             (cmd (format "tesseract -l eng %s %s"
                          (shell-quote-argument (expand-file-name file))
                          (shell-quote-argument out-base))))
        (transmute--run-command-async (file-name-nondirectory file) cmd)))))

;;;###autoload
(defun transmute-picture-autocolour ()
  "Auto-level image colors."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute-do-batch targets
      (transmute-convert-image file file "-auto-level"))))

;;;###autoload
(defun transmute-video-remove-audio ()
  "Remove audio from videos."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (transmute-convert-video file file "-an" "-c:v" "copy"))))

;;;###autoload
(defun transmute-video-reverse ()
  "Reverse video and audio."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((parsed (transmute--parse-filename file))
             (dst (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed)) "-reversed." (cdr (assoc 'extension parsed)))))
        (transmute-convert-video file dst "-vf" "reverse" "-af" "areverse")))))

;;;###autoload
(defun transmute-video-rotate-right ()
  "Rotate video 90 degrees clockwise."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (transmute-convert-video file file "-vf" "transpose=1"))))

;;;###autoload
(defun transmute-video-rotate-left ()
  "Rotate video 90 degrees counter-clockwise."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (transmute-convert-video file file "-vf" "transpose=2"))))

;;;###autoload
(defun transmute-picture-to-pdf ()
  "Convert images to PDF."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (if (= (length targets) 1)
        (let* ((file (car targets))
               (parsed (transmute--parse-filename file))
               (dst (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed)) ".pdf")))
          (transmute--run-command-async (file-name-nondirectory file)
                                        (format "magick %s %s" 
                                                (shell-quote-argument file)
                                                (shell-quote-argument dst))))
      (let ((dst (read-file-name "Output PDF: ")))
        (transmute--run-command-async "Batch PDF"
                                      (format "magick %s %s"
                                              (mapconcat #'shell-quote-argument targets " ")
                                              (shell-quote-argument dst)))))))

(defcustom transmute-soffice-command "soffice"
  "LibreOffice headless binary used by `transmute-document-to-pdf'.
Common alternatives are libreoffice or lowriter.  When nil, Transmute
auto-detects the first available of soffice, libreoffice, or lowriter
at run time via `executable-find'."
  :type '(choice (string :tag "Command") (const :tag "Auto-detect" nil))
  :group 'transmute)

(defun transmute--soffice-binary ()
  "Return the LibreOffice headless binary to use, or nil if none found.
Honors `transmute-soffice-command'; when nil, auto-detects.  The result
is always an absolute file name so the spawned shell does not need to
resolve the binary via its own PATH, which may differ from `exec-path'
and would otherwise cause a shell \"command not found\" (exit 127)."
  (let ((names (if transmute-soffice-command
                   (list transmute-soffice-command)
                 '("soffice" "libreoffice" "lowriter")))
        (paths '("/usr/bin/soffice" "/usr/bin/libreoffice" "/usr/bin/lowriter"
                 "/usr/lib/libreoffice/program/soffice"
                 "/opt/libreoffice/program/soffice")))
    (or (cl-some (lambda (name)
                   (cond ((string-match-p "\\`/" name)
                          (when (file-executable-p name) name))
                         ((executable-find name))))
                 names)
        (cl-some (lambda (p) (when (file-executable-p p) p)) paths))))

(defun transmute--file-uri (path)
  "Return a file:// URI for absolute PATH.
Percent-encodes characters that would otherwise break the URI, so
LibreOffice accepts profiles under directories with spaces (e.g. on
Windows or a home directory containing spaces)."
  (concat "file://"
          (replace-regexp-in-string
           "[ %#?]" (lambda (m) (format "%%%02X" (aref m 0))) path)))

(defun transmute--document-convert (format)
  "Convert selected documents to FORMAT using LibreOffice headless.
FORMAT is the soffice --convert-to filter, e.g. \"pdf\" or
\"txt:Text (encoded):UTF8\".  Each output is written alongside its
source file.  An isolated LibreOffice profile is used per file so a
running GUI instance won't interfere.  Runs asynchronously, one file at
a time, so Emacs stays responsive.  The binary is chosen via
`transmute-soffice-command' (auto-detected when nil).  If no LibreOffice
binary is found, the batch is aborted with a user error."
  (let ((soffice (transmute--soffice-binary)))
    (unless soffice
      (transmute--log "[FAILED] No LibreOffice binary found (soffice/libreoffice/lowriter).")
      (user-error "No LibreOffice binary found.  Install libreoffice or set `transmute-soffice-command'"))
    (when-let ((targets (transmute-get-filtered-targets 'document)))
      (transmute-do-batch-async targets
        (let* ((dir (file-name-directory (expand-file-name file)))
               (profile (make-temp-file "lo-profile-" t))
               (env-arg (format "-env:UserInstallation=%s"
                                (transmute--file-uri profile)))
               (cmd (format "%s --headless %s --convert-to %s --outdir %s %s"
                            (shell-quote-argument soffice)
                            (shell-quote-argument env-arg)
                            (shell-quote-argument format)
                            (shell-quote-argument dir)
                            (shell-quote-argument (expand-file-name file)))))
          (transmute--run-async cmd
            (lambda (_code)
              (when (file-directory-p profile)
                (delete-directory profile t))
              (funcall done))))))))

;;;###autoload
(defun transmute-document-to-pdf ()
  "Convert documents to PDF using LibreOffice headless."
  (interactive)
  (transmute--document-convert "pdf"))

;;;###autoload
(defun transmute-document-to-docx ()
  "Convert documents to DOCX using LibreOffice headless."
  (interactive)
  (transmute--document-convert "docx"))

;;;###autoload
(defun transmute-document-to-odt ()
  "Convert documents to ODT using LibreOffice headless."
  (interactive)
  (transmute--document-convert "odt"))

;;;###autoload
(defun transmute-document-to-txt ()
  "Convert documents to UTF-8 TXT using LibreOffice headless."
  (interactive)
  (transmute--document-convert "txt:Text (encoded):UTF8"))

;;;###autoload
(defun transmute-document-to-rtf ()
  "Convert documents to RTF using LibreOffice headless."
  (interactive)
  (transmute--document-convert "rtf"))

;;;###autoload
(defun transmute-document-to-html ()
  "Convert documents to HTML using LibreOffice headless."
  (interactive)
  (transmute--document-convert "html"))

;;;###autoload
(defun transmute-document-to-epub ()
  "Convert documents to EPUB using LibreOffice headless."
  (interactive)
  (transmute--document-convert "epub"))

;;;###autoload
(defun transmute-picture-montage (output-file)
  "Create a 2x4 montage of selected images at 1024px width.
Images are resized to temporary files to avoid modifying originals."
  (interactive (list (read-file-name "Output montage: " nil "montage_001.jpg")))
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (let* ((tmp-dir (make-temp-file "transmute-montage-" t))
           (resized-files nil)
           (width 1024)
           (resize-cmds nil))
      (dolist (img targets)
        (let* ((base (file-name-nondirectory img))
               (tmp-img (expand-file-name base tmp-dir)))
          (push tmp-img resized-files)
          (push (format "magick %s -resize %dx %s"
                        (shell-quote-argument (expand-file-name img))
                        width
                        (shell-quote-argument tmp-img))
                resize-cmds)))
      (let* ((montage-cmd (format "magick montage -tile 2x4 -mode Concatenate -gravity NorthWest -alpha off -background darkgrey %s %s"
                                  (mapconcat #'shell-quote-argument (reverse resized-files) " ")
                                  (shell-quote-argument (expand-file-name output-file))))
             (cleanup-cmd (format "rm -rf %s" (shell-quote-argument tmp-dir)))
             (full-cmd (mapconcat #'identity (append (reverse resize-cmds) (list montage-cmd cleanup-cmd)) " && ")))
        (transmute--run-command-async "Montage" full-cmd)))))

;;;###autoload
(defun transmute-tag-interactive (tags)
  "Interactively tag selected media files.
TAGS is a comma-separated string or list of tags."
  (interactive (list (completing-read-multiple "Tags (comma separated): " nil)))
  (when-let ((targets (transmute-get-filtered-targets 'any)))
    (let* ((tag-list (if (stringp tags) (split-string tags "," t) tags))
           (tag-str (mapconcat #'identity tag-list ","))
           (hier-tag-str (replace-regexp-in-string "@" "/" tag-str))
           (keywords (delete-dups (sort (mapcan (lambda (tag) (split-string (replace-regexp-in-string "@" " " tag) " " t)) tag-list) #'string<)))
           (keyword-str (mapconcat #'identity keywords ",")))
      (transmute-do-batch-parallel targets
        (transmute--log "[TAG] %s <- %s" file tag-str)
        (let ((cmd (format "exiftool -P -overwrite_original_in_place %s %s %s %s %s %s"
                           (shell-quote-argument (format "-TagsList=%s" hier-tag-str))
                           (shell-quote-argument (format "-XMP-microsoft:LastKeywordXMP=%s" hier-tag-str))
                           (shell-quote-argument (format "-HierarchicalSubject=%s"
                                                         (replace-regexp-in-string "/" "|" hier-tag-str)))
                           (shell-quote-argument (format "-XPKeywords=%s" keyword-str))
                           (shell-quote-argument (format "-Subject=%s" keyword-str))
                           (shell-quote-argument file))))
          (transmute--run-command-async (file-name-nondirectory file) cmd
                                        (lambda (_proc _exit-code)
                                          (transmute--log "[DONE] %s" file))))))))

;;;###autoload
(defun transmute-picture-email ()
  "Prepare images for email sending by resizing and stripping metadata.
Saves to ~/Pictures/YYYYMMDDHH/."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (let* ((date (format-time-string "%Y%m%d%H"))
           (dest-dir (expand-file-name (format "~/Pictures/%s" date))))
      (unless (file-directory-p dest-dir)
        (make-directory dest-dir t))
      (transmute-do-batch targets
        (let* ((filename (file-name-nondirectory file))
               (dst (expand-file-name filename dest-dir)))
          ;; nil => don't copy tags from the source, so the emailed copy
          ;; really is stripped of EXIF/GPS metadata.
          (transmute--convert-image-copy
           file dst
           (list "-auto-orient" "-strip" "-quality" "50%"
                 "-resize" "1920x>" "-resize" "x1920>")
           nil))))))

;;;###autoload
(defun transmute-picture-from-pdf ()
  "Extract JPEGs from PDF files using pdftoppm."
  (interactive)
  (let ((targets (seq-filter (lambda (f) (string-suffix-p ".pdf" f t)) (transmute-get-targets))))
    (if (null targets)
        (message "No PDF files selected.")
      (transmute-do-batch targets
        (let* ((parsed (transmute--parse-filename file))
               (basedir (cdr (assoc 'directory parsed)))
               (no-ext (cdr (assoc 'no-ext parsed)))
               ;; Use the full base name: truncating made distinct PDFs
               ;; that share a prefix overwrite each other's output.
               (dst-prefix (expand-file-name no-ext basedir)))
          (transmute--run-command-async (file-name-nondirectory file)
                                        (format "pdftoppm -r 300 -jpeg %s %s"
                                                (shell-quote-argument file)
                                                (shell-quote-argument dst-prefix))))))))

;;;###autoload
(defun transmute-picture-orientation-reset ()
  "Reset EXIF orientation to normal and optimization image."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute-do-batch targets
      ;; Bake any EXIF orientation into the pixels *before* clearing the
      ;; tag; doing it the other way round makes -auto-orient a no-op and
      ;; silently leaves the image rotated.
      (let* ((cmd (format "magick %s -auto-orient -strip %s && exiftool -overwrite_original -orientation#=1 %s"
                          (shell-quote-argument file)
                          (shell-quote-argument file)
                          (shell-quote-argument file)))
             (xattr-cmd (transmute--processed-xattr-cmd file))
             (full-cmd (if xattr-cmd (format "%s && %s" cmd xattr-cmd) cmd)))
        (transmute--run-command-async (file-name-nondirectory file) full-cmd)))))

;;;###autoload
(defun transmute-picture-split (num-splits)
  "Split image horizontally into NUM-SPLITS parts."
  (interactive "nNumber of horizontal splits: ")
  (unless (> num-splits 0)
    (user-error "Number of splits must be a positive integer"))
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute-do-batch targets
      (let* ((filename (file-name-nondirectory file))
             (no-ext (file-name-sans-extension filename))
             (dims (string-trim
                    (shell-command-to-string
                     (format "magick identify -format \"%%w %%h\" %s"
                             (shell-quote-argument file)))))
             (dim-list (split-string dims " "))
             (width (string-to-number (car dim-list)))
             (height (string-to-number (cadr dim-list)))
             (slice-width (/ width num-splits))
             (cmds nil))
        (if (or (<= width 0) (<= height 0))
            (message "Could not determine image dimensions for %s" file)
          (dotimes (i num-splits)
            (let* ((offset (* i slice-width))
                   ;; The last slice takes any remainder so no columns are lost.
                   (slice-w (if (= i (1- num-splits))
                                (- width offset)
                              slice-width))
                   (out-file (format "%s_%d.png" no-ext i)))
              (push (format "magick %s -auto-orient -crop %dx%d+%d+0 %s"
                            (shell-quote-argument file)
                            slice-w height offset
                            (shell-quote-argument out-file))
                    cmds)))
          (transmute--run-command-async
           (file-name-nondirectory file)
           (mapconcat #'identity (reverse cmds) " && ")))))))

(defvar transmute--gallery-marked-files nil
  "Stores the current gallery marked files for `transmute-gallery-after-finalize'.")

(defvar transmute--gallery-section nil
  "Stores the section path for the current gallery capture.")

;;;###autoload
(defun transmute-picture-to-capture ()
  "Trigger Org capture gallery with selected files.
Creates a new gallery post using the org-bootstrap-publish
compatible workflow (EXPORT_HUGO_TYPE: gallery).
Images are copied to ~/DCIM/content/static/<section>/ and
PictureCrush is run on them via the :after-finalize hook."
  (interactive)
  (when-let ((targets (transmute-get-targets)))
    (setq transmute--gallery-marked-files targets)
    (org-capture nil "g")))

(defun transmute--capture-top-level ()
  "Move to the top-level heading in the capture buffer."
  (goto-char (point-min))
  (or (outline-next-heading)
      (goto-char (point-max)))
  (unless (bolp) (insert "\n")))

(defun transmute--gallery-capture-template ()
  "Generate the gallery capture template string.
Prompts for date and title, returns an org-mode subtree
with org-bootstrap-publish compatible properties."
  (let* ((default-date (format-time-string "%Y-%m-%d" (current-time)))
         (input-date (read-string (format "Date (%s): " default-date) nil nil default-date))
         (parsed-date (org-read-date nil t input-date))
         (date (format-time-string (org-time-stamp-format :inactive) parsed-date))
         (date-string (format-time-string "%Y-%m-%d" parsed-date))
         (year-string (format-time-string "%Y" parsed-date))
         (timestamp-string (format-time-string "%Y%m%d%H%M%S" parsed-date))
         (title (read-from-minibuffer "Post Title: "))
         (fname (org-hugo-slug title))
         (section (concat "blog/" timestamp-string "-blog--" fname)))
    (setq transmute--gallery-section section)
    (mapconcat #'identity
               `(,(concat "* DONE Photos " title " " date-string " :" year-string ":")
                 ":PROPERTIES:"
                 ":EXPORT_FILE_NAME: index"
                 ,(concat ":EXPORT_HUGO_SECTION: " section)
                 ,(concat ":EXPORT_HUGO_LASTMOD: " date)
                 ":EXPORT_HUGO_TYPE: gallery"
                 ,(concat ":EXPORT_HUGO_CUSTOM_FRONT_MATTER+: :thumbnail /" section ".jpg")
                 ":END:"
                 "%?\n")
               "\n")))

(defun transmute-gallery-after-finalize ()
  "Copy gallery images to static dir and run PictureCrush.
Called by org-capture's :after-finalize hook after a gallery capture.
Images are copied to ~/DCIM/content/static/<section>/ and a thumbnail
is placed at ~/DCIM/content/static/<section>.jpg."
  (unless org-note-abort
    (let* ((target-dir (concat "~/DCIM/content/static/" transmute--gallery-section))
           (files transmute--gallery-marked-files))
      ;; `org-note-abort' can be nil while the marked-files list is empty if
      ;; the capture was started by other means; avoid (random 0).
      (when (and transmute--gallery-section files)
        (let ((thumb (nth (random (length files)) files))
              (copied-files '()))
          (make-directory target-dir t)
          (copy-file thumb (concat "~/DCIM/content/static/"
                                   transmute--gallery-section ".jpg")
                     t)
          (dolist (file files)
            (let ((target-file (transmute--unique-name
                                target-dir (file-name-nondirectory file))))
              (copy-file file target-file)
              (push target-file copied-files)))
          (when copied-files
            (dolist (f copied-files)
              (transmute-convert-image f f "-auto-orient" "-strip"
                                       "-quality" "50%"
                                       "-resize" "640x>" "-resize" "x640>")))))
      (setq transmute--gallery-marked-files nil
            transmute--gallery-section nil))))

(add-to-list 'org-capture-templates
             '("g" "Gallery" plain
               (file+function
                "~/DCIM/content/blog.org"
                transmute--capture-top-level)
               (function transmute--gallery-capture-template)
               :prepend t :jump-to-captured t :after-finalize transmute-gallery-after-finalize))

(defun transmute--normalise-string (name)
  "Return NAME with whitespace and shell/glob-unsafe characters replaced.
Diacritics are stripped (e.g. \"é\" becomes \"e\"), runs of whitespace
become a single dash, and any character outside the safe set
[A-Za-z0-9._@-] becomes a dash.  Existing \"--\" and \"__\" separators
are preserved.  Leading and trailing dashes are trimmed.  When
`transmute-normalise-downcase' is non-nil the result is lowercased."
  (let* ((decomposed (ucs-normalize-NFD-string name))
         ;; Drop combining diacritical marks left by NFD decomposition.
         (stripped (replace-regexp-in-string "[̀-ͯ]" "" decomposed))
         ;; Collapse any run of whitespace to a single dash.
         (despaced (replace-regexp-in-string "[[:space:]]+" "-" stripped))
         ;; Replace every remaining unsafe character with a dash.
         (safe (replace-regexp-in-string "[^A-Za-z0-9._@-]" "-" despaced))
         ;; Trim leading and trailing dashes.
         (trimmed (replace-regexp-in-string "\\(?:\\`-+\\|-+\\'\\)" "" safe)))
    (if transmute-normalise-downcase (downcase trimmed) trimmed)))

(defun transmute--tags-to-filename (tags)
  "Convert raw TAGS string to a filename-safe `__tags' segment.
TAGS uses the on-disk convention where hierarchical separators are
\"@\" and multi-tag separators are \"-\" (commas from exiftool output
are first converted, folding any surrounding whitespace so \", \"
becomes a single \"-\").  Runs the result through
`transmute--normalise-string' so spaces (e.g. from entries in
`transmute-tag-list-file' like \"oaktrees animals animals@cow\")
become dashes and shell/glob-unsafe characters are removed.
EXIF metadata is left untouched; only the filename segment is
sanitised."
  (transmute--normalise-string
   (replace-regexp-in-string
    "/" "@"
    (replace-regexp-in-string "[[:space:]]*,[[:space:]]*" "-" tags))))

(defun transmute--known-tags ()
  "Return a list of known tags from `transmute-tag-list-file'."
  (when (and transmute-tag-list-file
             (file-readable-p transmute-tag-list-file))
    (with-temp-buffer
      (insert-file-contents transmute-tag-list-file)
      ;; Accept CRLF files (e.g. edited on Windows) as well as LF.
      (split-string (buffer-string) "\r\n\\|\n" t))))

;;;###autoload
(defun transmute-tag-from-list (tags)
  "Interactively tag selected media files from a list of known tags.
TAGS is a comma-separated string or list of tags selected via
`completing-read-multiple' against the tag list file."
  (interactive (list (completing-read-multiple "Tags: " (transmute--known-tags))))
  (when-let ((targets (transmute-get-filtered-targets 'any)))
    (let* ((tag-list (if (stringp tags) (split-string tags "," t) tags))
           (tag-str (mapconcat #'identity tag-list ","))
           (hier-tag-str (replace-regexp-in-string "@" "/" tag-str))
           (keywords (delete-dups (sort (mapcan (lambda (tag) (split-string (replace-regexp-in-string "@" " " tag) " " t)) tag-list) #'string<)))
           (keyword-str (mapconcat #'identity keywords ",")))
      (transmute-do-batch-parallel targets
        (transmute--log "[TAG] %s <- %s" file tag-str)
        (let ((cmd (format "exiftool -P -overwrite_original_in_place %s %s %s %s %s %s %s"
                           (shell-quote-argument (format "-TagsList=%s" hier-tag-str))
                           (shell-quote-argument (format "-XMP-microsoft:LastKeywordXMP=%s" hier-tag-str))
                           (shell-quote-argument (format "-HierarchicalSubject=%s"
                                                         (replace-regexp-in-string "/" "|" hier-tag-str)))
                           (shell-quote-argument (format "-XPKeywords=%s" keyword-str))
                           (shell-quote-argument (format "-Subject=%s" keyword-str))
                           (shell-quote-argument (format "-Keywords=%s" keyword-str))
                           (shell-quote-argument file))))
          (transmute--run-command-async (file-name-nondirectory file) cmd
                                        (lambda (_proc _exit-code)
                                          (transmute--log "[DONE] %s" file))))))))

;;;###autoload
(defun transmute-retag-by-date ()
  "Rename images based on EXIF creation date.
Runs asynchronously so Emacs stays responsive during batch processing."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'any)))
    (transmute-do-batch-async targets
      (transmute-get-date-async
       file
       (lambda (date-info)
         (if (not date-info)
             (funcall done)
           (let* ((prop (car date-info))
                  (val (cadr date-info))
                  ;; Compute the new name and perform the rename, always
                  ;; advancing the queue afterwards even if it errors.
                  (finish
                   (lambda ()
                     (unwind-protect
                         (let* ((formatted-date (transmute-format-date val))
                                (parsed (transmute--parse-filename file))
                                (current-ts (cdr (assoc 'timestamp parsed)))
                                (label (cdr (assoc 'label parsed)))
                                (tags-raw (cdr (assoc 'tags-raw parsed)))
                                (ext (cdr (assoc 'extension parsed)))
                                (basedir (cdr (assoc 'directory parsed))))
                           (if (not (string= formatted-date current-ts))
                                (let* ((new-base
                                        (if (string-empty-p label)
                                            formatted-date
                                          (format "%s--%s" formatted-date label)))
                                      (new-name (if tags-raw
                                                    (format "%s/%s__%s.%s" basedir new-base tags-raw ext)
                                                  (format "%s/%s.%s" basedir new-base ext)))
                                      (final-name new-name)
                                      (counter 1))
                                 (while (transmute--name-collides-p final-name file)
                                   (setq final-name (if tags-raw
                                                        (format "%s/%s%d__%s.%s" basedir new-base counter tags-raw ext)
                                                      (format "%s/%s%d.%s" basedir new-base counter ext)))
                                   (cl-incf counter))
                                 (let ((abs-orig (expand-file-name file))
                                       (abs-final (expand-file-name final-name)))
                                   (unless (string= abs-final abs-orig)
                                     (transmute--log "%s -> %s" abs-orig abs-final)
                                     (setq transmute--last-renames
                                           (cons (cons abs-orig abs-final)
                                                 transmute--last-renames))
                                     (transmute--rename-file-safe abs-orig abs-final))))
                             (message "#### %s : NO CHANGE" file)))
                       (funcall done)))))
             ;; When the date came from a modify-time tag, first bake it
             ;; into CreateDate/DateTimeOriginal (asynchronously), then rename.
             (if (member prop '("FileModifyDate" "ModifyDate"))
                 (progn
                   (transmute--log "Writing %s to CreateDate and DateTimeOriginal for %s" prop file)
                   (transmute--run-async
                    (format "exiftool -P -overwrite_original_in_place \"-CreateDate<%s\" \"-DateTimeOriginal<%s\" %s"
                            prop prop (shell-quote-argument file))
                    (lambda (_code) (funcall finish))))
               (funcall finish)))))))))

;;;###autoload
(defun transmute-audio-convert ()
  "Convert audio to MP3."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'audio)))
    (transmute-do-batch targets
      (let* ((parsed (transmute--parse-filename file))
             (dst (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed)) ".mp3")))
        ;; Route through the shared helper so the output is written to a
        ;; temp file first (no partial MP3s) and metadata/mtime survive.
        (transmute-convert-video file dst "-b:a" "192k")))))

;;;###autoload
(defun transmute-audio-info ()
  "Show audio ID3 tags."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'audio)))
    (transmute--display-info targets "id3v2 -l")))

;;;###autoload
(defun transmute-picture-info ()
  "Show image metadata."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (transmute--display-info targets "exiftool -g")))

;;;###autoload
(defun transmute-video-info ()
  "Show video info using ffprobe and exiftool."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute--display-info targets 
                             '("FFProbe" . "ffprobe -hide_banner")
                             '("ExifTool" . "exiftool"))))

;;;###autoload
(defun transmute-video-to-gif ()
  "Convert video to GIF."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((parsed (transmute--parse-filename file))
             (dst (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed)) ".gif")))
        (transmute--convert-video-to-gif file dst)))))

;;;###autoload
(defun transmute-picture-update-from-create-date ()
  "Update FileModifyDate and DateTimeOriginal from CreateDate."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'any)))
    (transmute-do-batch targets
      (transmute--run-command-async (file-name-nondirectory file)
                                    (format "exiftool -P -overwrite_original \"-FileModifyDate<CreateDate\" \"-DateTimeOriginal<CreateDate\" %s"
                                            (shell-quote-argument file))))))

;;;###autoload
(defun transmute-picture-update-to-create-date ()
  "Update CreateDate and DateTimeOriginal from FileModifyDate."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'any)))
    (transmute-do-batch targets
      (transmute--run-command-async (file-name-nondirectory file)
                                    (format "exiftool -overwrite_original \"-CreateDate<FileModifyDate\" \"-DateTimeOriginal<FileModifyDate\" %s"
                                            (shell-quote-argument file))))))

;;;###autoload
(defun transmute-picture-tag-rename ()
  "Rename file based on its tags and creation date."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'any)))
    (transmute-do-batch targets
      (let* ((date-info (transmute-get-date file))
             (val (cadr date-info))
             (tags-out (shell-command-to-string (format "exiftool -s3 -TagsList %s" (shell-quote-argument file))))
             (tags (string-trim tags-out)))
        (when (and date-info (not (string-empty-p tags)))
          (let* ((formatted-tags (transmute--tags-to-filename tags))
                 (formatted-date (transmute-format-date val))
                 (parsed (transmute--parse-filename file))
                 (label (cdr (assoc 'label parsed)))
                 (ext (cdr (assoc 'extension parsed)))
                 (basedir (cdr (assoc 'directory parsed)))
                          (new-base (if (string-empty-p label)
                                        formatted-date
                                      (format "%s--%s" formatted-date label)))
                 (new-name (format "%s/%s__%s.%s" basedir new-base formatted-tags ext))
                 (final-name new-name)
                 (counter 1))
            (while (transmute--name-collides-p final-name file)
              (setq final-name (format "%s/%s%d__%s.%s" basedir new-base counter formatted-tags ext))
              (cl-incf counter))
            (let ((abs-final (expand-file-name final-name basedir))
                  (abs-orig (expand-file-name file)))
              (unless (string= abs-final abs-orig)
                (message "%s -> %s" abs-orig abs-final)
                (setq transmute--last-renames (cons (cons abs-orig abs-final) transmute--last-renames))
                (transmute--rename-file-safe abs-orig abs-final)))))))))

;;;###autoload
(defun transmute-tag-and-rename (tags)
  "Tag selected media files from known tags, then rename based on tags and date.
TAGS is selected via `completing-read-multiple' against the tag list file.
After writing metadata, each file is renamed to the
YYYYMMDDHHMMSS--label__tag1@tag2.ext pattern.
The filename tag segment is sanitised via `transmute--tags-to-filename'
so spaces become dashes and no spaces appear on disk; EXIF tags keep
their original form."
  (interactive (list (completing-read-multiple "Tags: " (transmute--known-tags))))
  (when-let ((targets (transmute-get-filtered-targets 'any)))
    (let* ((tag-list (if (stringp tags) (split-string tags "," t) tags))
           (tag-str (mapconcat #'identity tag-list ","))
           (hier-tag-str (replace-regexp-in-string "@" "/" tag-str))
           (keywords (delete-dups (sort (mapcan (lambda (tag) (split-string (replace-regexp-in-string "@" " " tag) " " t)) tag-list) #'string<)))
           (keyword-str (mapconcat #'identity keywords ","))
           (formatted-tags (transmute--tags-to-filename hier-tag-str)))
      (transmute-do-batch-parallel targets
        (transmute--log "[TAG] %s <- %s" file tag-str)
        (let ((cmd (format "exiftool -P -overwrite_original_in_place %s %s %s %s %s %s %s"
                           (shell-quote-argument (format "-TagsList=%s" hier-tag-str))
                           (shell-quote-argument (format "-XMP-microsoft:LastKeywordXMP=%s" hier-tag-str))
                           (shell-quote-argument (format "-HierarchicalSubject=%s"
                                                         (replace-regexp-in-string "/" "|" hier-tag-str)))
                           (shell-quote-argument (format "-XPKeywords=%s" keyword-str))
                           (shell-quote-argument (format "-Subject=%s" keyword-str))
                           (shell-quote-argument (format "-Keywords=%s" keyword-str))
                           (shell-quote-argument file))))
          (transmute--run-command-async
           (file-name-nondirectory file) cmd
           (lambda (_proc exit-code)
             (when (zerop exit-code)
               (let* ((date-info (transmute-get-date file))
                      (val (cadr date-info)))
                 (when date-info
                   (let* ((formatted-date (transmute-format-date val))
                          (parsed (transmute--parse-filename file))
                          (label (cdr (assoc 'label parsed)))
                          (ext (cdr (assoc 'extension parsed)))
                          (basedir (cdr (assoc 'directory parsed)))
                 (new-base (if (string-empty-p label)
                               formatted-date
                             (format "%s--%s" formatted-date label)))
                          (new-name (format "%s/%s__%s.%s" basedir new-base formatted-tags ext))
                          (final-name new-name)
                          (counter 1))
                     (while (transmute--name-collides-p final-name file)
                       (setq final-name (format "%s/%s%d__%s.%s" basedir new-base counter formatted-tags ext))
                       (cl-incf counter))
                     (let ((abs-final (expand-file-name final-name basedir))
                           (abs-orig (expand-file-name file)))
                       (unless (string= abs-final abs-orig)
                         (message "%s -> %s" abs-orig abs-final)
                         (setq transmute--last-renames (cons (cons abs-orig abs-final) transmute--last-renames))
                         (transmute--rename-file-safe abs-orig abs-final))))))))))))))

;;;###autoload
(defun transmute-clear-tags ()
  "Remove all tags from selected media files."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'any)))
    (transmute-do-batch-parallel targets
      (transmute--log "[CLEAR] %s" file)
      (let ((cmd (format "exiftool -P -overwrite_original_in_place %s %s %s %s %s %s %s"
                         (shell-quote-argument "-TagsList=")
                         (shell-quote-argument "-XMP-microsoft:LastKeywordXMP=")
                         (shell-quote-argument "-HierarchicalSubject=")
                         (shell-quote-argument "-XPKeywords=")
                         (shell-quote-argument "-Subject=")
                         (shell-quote-argument "-Keywords=")
                         (shell-quote-argument file))))
        (transmute--run-command-async (file-name-nondirectory file) cmd
                                      (lambda (_proc _exit-code)
                                        (transmute--log "[DONE] %s" file)))))))

(defun transmute--exif-field (file field)
  "Return exiftool FIELD value for FILE, or nil if empty."
  (let ((val (string-trim
              (shell-command-to-string
               (format "exiftool -s3 -%s %s" field (shell-quote-argument (expand-file-name file)))))))
    (unless (or (string-empty-p val) (string-prefix-p "Warning" val)) val)))

(defun transmute--get-sidecar-files (file)
  "Return list of sidecar files for FILE (e.g. file.xmp, file.jpg.xmp)."
  (let* ((abs-file (expand-file-name file))
         (dir (file-name-directory abs-file))
         (name (file-name-nondirectory abs-file))
         (sidecars nil))
    ;; case 1: file.xmp
    (let ((s1 (concat (file-name-sans-extension abs-file) ".xmp")))
      (when (and (file-exists-p s1) (not (string= s1 abs-file)))
        (push s1 sidecars)))
    ;; case 2: file.ext.xmp
    (let ((s2 (concat abs-file ".xmp")))
      (when (file-exists-p s2)
        (push s2 sidecars)))
    sidecars))

;;;###autoload
(defun transmute-picture-organise ()
  "Move selected files into YYYYMM subdirectories and move sidecars (.xmp).
Runs asynchronously so Emacs stays responsive during batch processing.
Progress is shown in the log buffer; the stale image display is hidden
once the whole batch has finished."
  (interactive)
  (when-let ((targets (transmute-get-targets)))
    ;; Pop to log buffer so user sees progress
    (let ((buf (get-buffer-create transmute-log-buffer-name)))
      (pop-to-buffer buf)
      (transmute--log "[START] Organizing %d files..." (length targets)))
    (setq transmute--inhibit-display-refresh-once t)
    ;; One-shot finalizer: hide the stale display and resurface the log
    ;; buffer once the asynchronous batch has fully drained.  Appended so
    ;; it runs after `transmute-refresh-thumbnail'.
    (let (finalize)
      (setq finalize
            (lambda ()
              (remove-hook 'transmute-after-batch-hook finalize)
              (when (fboundp 'dired-image-thumbnail-hide-display)
                (dired-image-thumbnail-hide-display))
              (pop-to-buffer (get-buffer-create transmute-log-buffer-name))))
      (add-hook 'transmute-after-batch-hook finalize t))
    (transmute-do-batch-async targets
      (transmute-get-date-async
       file
       (lambda (date-info)
         (unwind-protect
             (if (not date-info)
                 (transmute--log "[WARN] No date found for %s" file)
               (let* ((val (cadr date-info))
                      (formatted-date (transmute-format-date val))
                      (year-month (substring formatted-date 0 6))
                      (basedir (file-name-directory (expand-file-name file)))
                      (dest-dir (expand-file-name year-month basedir))
                      (main-name (file-name-nondirectory file))
                      (new-main (expand-file-name main-name dest-dir))
                      (sidecars (transmute--get-sidecar-files file)))
                 (unless (file-directory-p dest-dir)
                   (make-directory dest-dir t))
                  ;; Move the main file first, refusing to overwrite an
                  ;; existing file of the same name.  Sidecars only move
                  ;; when the main file moved (or was already in place).
                  (let* ((abs-orig (expand-file-name file))
                         (abs-new (expand-file-name new-main))
                         (same (string= abs-orig abs-new))
                         (moved (or same (not (file-exists-p abs-new)))))
                    (cond
                     (same nil)
                     (moved
                      (transmute--log "[MOVE] %s -> %s"
                                      (file-name-nondirectory abs-orig)
                                      (concat year-month "/" (file-name-nondirectory abs-new)))
                      (setq transmute--last-renames
                            (cons (cons abs-orig abs-new) transmute--last-renames))
                      (transmute--rename-file-safe abs-orig abs-new))
                     (t
                      (transmute--log "[WARN] Not moving %s: %s already exists"
                                      (file-name-nondirectory abs-orig)
                                      (concat year-month "/" (file-name-nondirectory abs-new)))))
                    (when moved
                      (dolist (s sidecars)
                        (let* ((s-abs (expand-file-name s))
                               (new-s (expand-file-name (file-name-nondirectory s) dest-dir))
                               (new-s-abs (expand-file-name new-s)))
                          (unless (string= s-abs new-s-abs)
                            (if (file-exists-p new-s-abs)
                                (transmute--log "[WARN] Not moving sidecar %s: %s already exists"
                                                (file-name-nondirectory s-abs)
                                                (concat year-month "/" (file-name-nondirectory new-s-abs)))
                              (transmute--log "[SIDE] %s -> %s"
                                              (file-name-nondirectory s-abs)
                                              (concat year-month "/" (file-name-nondirectory new-s-abs)))
                              (setq transmute--last-renames
                                    (cons (cons s-abs new-s-abs) transmute--last-renames))
                              (transmute--rename-file-safe s-abs new-s-abs)))))))))
           (funcall done)))))))

;;; Duplicate Detection

(defvar transmute-duplicates-buffer-name "*transmute-duplicates*"
  "Name of the buffer showing duplicate image reports.")

(defvar-local transmute-duplicates--groups nil
  "Duplicate file groups shown in the current report buffer.")

(defvar-local transmute-duplicates--targets nil
  "Files rescanned by `transmute-duplicates-rescan' in the report buffer.")

(define-derived-mode transmute-duplicates-mode special-mode "Transmute-Duplicates"
  "Major mode for reviewing duplicate images.
\\<transmute-duplicates-mode-map>
\\[transmute-picture-trash-duplicates] trashes every duplicate,
keeping the largest file of each group.  Files are compared by their
ImageMagick pixel signature, so copies that differ only in metadata
or container format still match."
  (setq-local truncate-lines t))

(define-key transmute-duplicates-mode-map (kbd "x") #'transmute-picture-trash-duplicates)
(define-key transmute-duplicates-mode-map (kbd "d") #'transmute-picture-trash-duplicates)
(define-key transmute-duplicates-mode-map (kbd "g") #'transmute-duplicates-rescan)

(defun transmute--file-size (file)
  "Return the size of FILE in bytes, or 0 when it cannot be determined."
  (or (file-attribute-size (file-attributes file)) 0))

(defun transmute--duplicate-groups ()
  "Return duplicate groups collected by the last scan.
Each group lists its largest file first; groups are ordered by keeper."
  (let (groups)
    (maphash
     (lambda (_signature files)
       (when (cdr files)
         (push (sort (copy-sequence files)
                     (lambda (a b)
                       (let ((size-a (transmute--file-size a))
                             (size-b (transmute--file-size b)))
                         (if (= size-a size-b)
                             (string< a b)
                           (> size-a size-b)))))
               groups)))
     transmute--duplicate-signatures)
    (sort groups (lambda (a b) (string< (car a) (car b))))))

(defun transmute--render-duplicate-report (groups)
  "Insert a report for duplicate GROUPS into the current buffer."
  (let ((dupes (cl-loop for group in groups sum (1- (length group)))))
    (insert (format "Duplicate Images: %d group%s, %d duplicate%s\n"
                    (length groups) (if (= (length groups) 1) "" "s")
                    dupes (if (= dupes 1) "" "s")))
    (insert (substitute-command-keys
             "Press \\[transmute-picture-trash-duplicates] to trash duplicates (keeping the largest), \\[transmute-duplicates-rescan] to rescan, \\[quit-window] to bury.\n\n"))
    (cl-loop for group in groups
             for index from 1 do
             (insert (format "Group %d -- %d files\n" index (length group)))
             (dolist (file group)
               (insert (format "  %s %8s  %s\n"
                               (if (string= file (car group)) "[KEEP]" "[DUPE]")
                               (file-size-human-readable (transmute--file-size file))
                               file)))
             (insert "\n"))))

(defun transmute--show-duplicate-report ()
  "Show the duplicate groups collected by the current scan."
  (setq transmute--duplicate-queue nil
        transmute--duplicate-inflight 0)
  (let ((groups (transmute--duplicate-groups)))
    (if (null groups)
        (progn
          (transmute--log "[DONE] No duplicate images found.")
          (message "No duplicate images found.")
          ;; Drop any stale report from a previous scan.
          (when-let ((buf (get-buffer transmute-duplicates-buffer-name)))
            (when-let ((win (get-buffer-window buf)))
              (quit-window nil win))
            (kill-buffer buf)))
      (let ((buf (get-buffer-create transmute-duplicates-buffer-name))
            (dupes (cl-loop for group in groups sum (1- (length group)))))
        (transmute--log "[DONE] Found %d duplicate group(s), %d duplicate file(s)."
                        (length groups) dupes)
        (with-current-buffer buf
          (transmute-duplicates-mode)
          (setq-local transmute-duplicates--groups groups
                      transmute-duplicates--targets transmute--duplicate-targets)
          (let ((inhibit-read-only t))
            (erase-buffer)
            (transmute--render-duplicate-report groups)
            (goto-char (point-min))))
        ;; Pop to the report so it cannot be missed: the selection is
        ;; returned to it and the post-scan refresh is skipped, so no
        ;; other buffer can bury it.
        (pop-to-buffer buf)))))

(defun transmute--duplicate-maybe-finish ()
  "Show the duplicate report once no scan work is left."
  (when (and (null transmute--duplicate-queue)
             (zerop transmute--duplicate-inflight)
             (not transmute--duplicate-finished))
    (setq transmute--duplicate-finished t)
    ;; A read-only scan must not trigger the thumbnail refresh: it can
    ;; regenerate every selected thumbnail and re-display the current
    ;; image, burying the report.  Only do this when the scan is the
    ;; last batch running, otherwise the refresh belongs to that batch.
    (when (null transmute-active-processes)
      (setq transmute--skip-refresh-once t))
    (transmute--show-duplicate-report)))

(defun transmute--duplicate-collect (abs-file tmp exit-code)
  "Record the signature computed into TMP for ABS-FILE.
EXIT-CODE is the `magick' process exit status; TMP is always deleted."
  (unwind-protect
      (when (and (file-exists-p tmp) (zerop exit-code))
        (let ((signature (with-temp-buffer
                           (insert-file-contents tmp)
                           (string-trim (buffer-string)))))
          (unless (string-empty-p signature)
            (puthash signature
                     (cons abs-file
                           (gethash signature transmute--duplicate-signatures))
                     transmute--duplicate-signatures))))
    (transmute--delete-temp tmp)))

(defun transmute--duplicate-start-next ()
  "Start a signature process for the next queued file, if there is one."
  (when-let ((file (pop transmute--duplicate-queue)))
    (let* ((abs-file (expand-file-name file))
           (tmp (make-temp-file "transmute-sig-"))
           (name (concat "sig: " (file-name-nondirectory file)))
           (cmd (format "magick identify -quiet -format '%%#' %s > %s"
                        (shell-quote-argument abs-file)
                        (shell-quote-argument tmp))))
      (condition-case err
          (progn
            (transmute--run-command-async
             name cmd
             (lambda (proc exit-code)
               ;; A sentinel may run more than once for the same
               ;; process; make the bookkeeping idempotent so the
               ;; in-flight count cannot underflow.
               (unless (process-get proc 'transmute-duplicate-collected)
                 (process-put proc 'transmute-duplicate-collected t)
                 (unwind-protect
                     (transmute--duplicate-collect abs-file tmp exit-code)
                   (setq transmute--duplicate-inflight
                         (1- transmute--duplicate-inflight))
                   (transmute--duplicate-start-next)
                   (transmute--duplicate-maybe-finish))))
             t)
            (setq transmute--duplicate-inflight
                  (1+ transmute--duplicate-inflight)))
        (error
         ;; The process never started (e.g. out of file descriptors).
         ;; Count the file as done and move on instead of leaving the
         ;; scan stuck forever.
         (transmute--log "[FAILED] %s: %s" name (error-message-string err))
         (transmute--delete-temp tmp)
         (setq transmute-completed-tasks (1+ transmute-completed-tasks))
         (transmute--update-progress-display)
         (transmute--duplicate-start-next)
         (transmute--duplicate-maybe-finish))))))

(defun transmute--scan-duplicates (targets)
  "Asynchronously compute image signatures for TARGETS and report duplicates.
At most `transmute-duplicate-parallelism' `magick' processes run at a
time.  Signature computation decodes every pixel, so starting one
process per file can exhaust memory and freeze Emacs on large scans."
  (when (or transmute--duplicate-queue
            (> transmute--duplicate-inflight 0))
    (user-error "A duplicate scan is already running"))
  (setq transmute--duplicate-signatures (make-hash-table :test 'equal)
        transmute--duplicate-targets (copy-sequence targets)
        transmute--duplicate-queue (copy-sequence targets)
        transmute--duplicate-inflight 0
        transmute--duplicate-finished nil)
  (transmute--log "[START] Checking %d image(s) for duplicates..." (length targets))
  (setq transmute-total-tasks (+ transmute-total-tasks (length targets)))
  (dotimes (_ (min (max 1 transmute-duplicate-parallelism) (length targets)))
    (transmute--duplicate-start-next))
  ;; A scan where no process could be started still has to report.
  (transmute--duplicate-maybe-finish))

;;;###autoload
(defun transmute-picture-find-duplicates ()
  "Find pixel-identical duplicate images among the selected files.
Images are compared by their ImageMagick pixel signature, so copies
that differ only in metadata, filename, or container format are still
reported.  Results appear in a report buffer where duplicates can be
trashed while keeping the largest file in each group."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (if (< (length targets) 2)
        (message "Select at least two images to search for duplicates.")
      (transmute--scan-duplicates targets))))

(defun transmute-duplicates-rescan ()
  "Rescan the files listed in the current duplicate report."
  (interactive)
  (unless (derived-mode-p 'transmute-duplicates-mode)
    (user-error "Not in a duplicate report buffer"))
  (if (null transmute-duplicates--targets)
      (message "No files to rescan.")
    (transmute--scan-duplicates transmute-duplicates--targets)))

;;;###autoload
(defun transmute-picture-trash-duplicates ()
  "Trash the duplicate files in the current report.
The largest file of each group is kept.  Asks for confirmation before
trashing anything."
  (interactive)
  (unless (derived-mode-p 'transmute-duplicates-mode)
    (user-error "Run `transmute-picture-find-duplicates' first"))
  (let ((victims (cl-loop for group in transmute-duplicates--groups
                          append (cdr group))))
    (if (null victims)
        (message "No duplicates to trash.")
      (when (y-or-n-p (format "Trash %d duplicate file(s), keeping the largest of each group? "
                              (length victims)))
        (let ((trashed 0))
          (transmute-do-batch victims
            (when (file-exists-p file)
              (transmute--trash file)
              (setq trashed (1+ trashed))))
          (setq transmute-duplicates--groups
                (cl-loop for group in transmute-duplicates--groups
                         for remaining = (cl-remove-if-not #'file-exists-p group)
                         when (cdr remaining) collect remaining))
          (transmute--log "[TRASH] Removed %d duplicate file(s)." trashed)
          (if (null transmute-duplicates--groups)
              (progn
                (message "Trashed %d duplicate file(s); no duplicates remain." trashed)
                (when-let ((win (get-buffer-window transmute-duplicates-buffer-name)))
                  (quit-window nil win))
                (kill-buffer transmute-duplicates-buffer-name))
            (let ((inhibit-read-only t))
              (erase-buffer)
              (transmute--render-duplicate-report transmute-duplicates--groups)
              (goto-char (point-min)))
            (message "Trashed %d duplicate file(s); %d group(s) remain."
                     trashed (length transmute-duplicates--groups))))))))

;;;###autoload
(defun transmute-normalise-names ()
  "Rename selected files to safe, glob-friendly names.
Spaces become dashes and shell/glob-unsafe characters (parentheses,
brackets, quotes, ampersands, semicolons, etc.) are replaced with
dashes, while the directory and extension are preserved.  Operates on
any file type, not just media.  On a name collision a numeric suffix is
appended.  Files whose names are already clean are left untouched."
  (interactive)
  (when-let ((targets (transmute-get-targets)))
    (transmute-do-batch targets
      (let* ((abs-orig (expand-file-name file))
             (basedir (file-name-directory abs-orig))
             (filename (file-name-nondirectory abs-orig))
             (ext (file-name-extension filename))
             (base (file-name-sans-extension filename))
             (new-base (transmute--normalise-string base))
             (new-base (if (string-empty-p new-base) "unnamed" new-base))
             (new-name (if ext (format "%s.%s" new-base ext) new-base))
             (final-name new-name)
             (counter 1))
        (while (and (file-exists-p (expand-file-name final-name basedir))
                    (not (string= final-name filename)))
          (setq final-name (if ext
                               (format "%s-%d.%s" new-base counter ext)
                             (format "%s-%d" new-base counter)))
          (cl-incf counter))
        (let ((abs-final (expand-file-name final-name basedir)))
          (if (string= abs-final abs-orig)
              (transmute--log "[SKIP] %s (already normalised)" filename)
            (transmute--log "%s -> %s" filename final-name)
            (setq transmute--last-renames
                  (cons (cons abs-orig abs-final) transmute--last-renames))
            (transmute--rename-file-safe abs-orig abs-final)))))))

;;;###autoload
(defun transmute-tag-info ()
  "Show tags and key metadata for selected media files in a summary buffer."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'any)))
    (transmute--display-info targets "exiftool -TagsList -HierarchicalSubject -Keywords -Subject -CreateDate -DateTimeOriginal -FileModifyDate -ImageSize -MIMEType")))

;;;###autoload
(defun transmute-video-speed-up ()
  "Speed up video 2x (removes audio)."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((parsed (transmute--parse-filename file))
             (timestamp (format-time-string "%Y%m%d%H%M%S"))
             (dst (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed)) "-sped-" timestamp ".mp4")))
        (transmute-convert-video file dst "-an" "-filter:v" "setpts=0.5*PTS" "-r" "30")))))

;;;###autoload
(defun transmute-picture-fix-whatsapp ()
  "Fix WhatsApp images by extracting date from filename and setting metadata.
Renames file to YYYYMMDD120000--IMG-YYYYMMDD-WA... pattern and sets EXIF dates."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'image)))
    (let ((buf (get-buffer-create transmute-log-buffer-name)))
      (display-buffer buf)
      (transmute--log "[START] Fixing WhatsApp for %d files..." (length targets)))
    (transmute-do-batch-parallel targets
      (let* ((filename (file-name-nondirectory file))
             (basedir (file-name-directory (expand-file-name file))))
        (if (string-match "IMG-\\([0-9]\\{8\\}\\)-WA" filename)
            (let* ((imgdate (match-string 1 filename))
                   (newtimestamp (concat imgdate "120000"))
                   (rest (cond
                          ((string-match "--IMG-[0-9]\\{8\\}\\(.*\\)$" filename)
                           (concat "--IMG-" imgdate (match-string 1 filename)))
                          ((string-match "IMG-[0-9]\\{8\\}\\(.*\\)$" filename)
                           (concat "--IMG-" imgdate (match-string 1 filename)))
                          (t (concat "--" filename))))
                   (newname (concat newtimestamp rest))
                   (abs-file (expand-file-name file))
                   (abs-newname (expand-file-name newname basedir))
                   (date-fmt (format "%s:%s:%s 12:00:00"
                                     (substring imgdate 0 4)
                                     (substring imgdate 4 6)
                                     (substring imgdate 6 8)))
                   (mtime (encode-time 0 0 12
                                       (string-to-number (substring imgdate 6 8))
                                       (string-to-number (substring imgdate 4 6))
                                       (string-to-number (substring imgdate 0 4)))))
              (transmute--log "[FIX] %s -> %s" filename newname)
              (let ((cmd (format "exiftool -overwrite_original %s %s %s %s"
                                 (shell-quote-argument (format "-DateTimeOriginal=%s" date-fmt))
                                 (shell-quote-argument (format "-CreateDate=%s" date-fmt))
                                 (shell-quote-argument (format "-ModifyDate=%s" date-fmt))
                                 (shell-quote-argument abs-file))))
                (transmute--run-command-async
                 (file-name-nondirectory file) cmd
                 (lambda (_proc exit-code)
                   (when (zerop exit-code)
                     ;; Use the absolute path and an Emacs primitive: the
                     ;; batch's `default-directory' binding is long gone by
                     ;; the time this callback runs.
                     (set-file-times abs-file mtime)
                     (cond
                      ((string= abs-file abs-newname) nil)
                      ((file-exists-p abs-newname)
                       (transmute--log "[WARN] Not renaming %s: %s already exists"
                                       filename newname))
                      (t
                       (setq transmute--last-renames
                             (cons (cons abs-file abs-newname)
                                   transmute--last-renames))
                       (transmute--rename-file-safe abs-file abs-newname))))))))
        (transmute--log "[SKIP] %s: Does not match WhatsApp pattern" filename))))))

;;;###autoload
(defun transmute-video-slow-down ()
  "Slow down video 5x (removes audio)."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((parsed (transmute--parse-filename file))
             (timestamp (format-time-string "%Y%m%d%H%M%S"))
             (dst (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed)) "-slow-" timestamp ".mp4")))
        (transmute-convert-video file dst "-threads" "2" "-an" "-filter:v" "setpts=5*PTS" "-r" "30")))))

;;;###autoload
(defun transmute-video-concat ()
  "Concatenate selected video files in sorted order."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (let* ((tmp-file (make-temp-file "transmute-concat-" nil ".txt"))
           (sorted-targets (sort targets #'string<))
           (basedir (file-name-directory (expand-file-name (car targets))))
           (output-file (expand-file-name (format "concat-%s.mp4" (format-time-string "%Y%m%d%H%M%S")) basedir)))
      (with-temp-file tmp-file
        (dolist (f sorted-targets)
          (insert (format "file '%s'\n"
                          (transmute--concat-escape-path (expand-file-name f))))))
      (let ((cmd (format "ffmpeg -f concat -safe 0 -i %s -c copy %s"
                         (shell-quote-argument tmp-file)
                         (shell-quote-argument output-file))))
        (transmute--run-command-async "Concatenate" cmd
                                      (lambda (_proc _code)
                                        (transmute--delete-temp tmp-file)))))))

;;;###autoload
(defun transmute-video-double ()
  "Double the length of each selected video by repeating it."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((tmp-list (make-temp-file "transmute-double-" nil ".txt"))
             (base (file-name-nondirectory file))
             (no-ext (file-name-sans-extension base))
             (ext (file-name-extension base))
             (dst (expand-file-name (format "%s-double.%s" no-ext ext) (file-name-directory (expand-file-name file)))))
        (with-temp-file tmp-list
          (insert (format "file '%s'\n"
                          (transmute--concat-escape-path (expand-file-name file))))
          (insert (format "file '%s'\n"
                          (transmute--concat-escape-path (expand-file-name file)))))
        (let ((cmd (format "ffmpeg -f concat -safe 0 -i %s -c copy %s"
                           (shell-quote-argument tmp-list)
                           (shell-quote-argument dst))))
          (transmute--run-command-async
           (format "Double %s" base) cmd
           (lambda (_proc _code)
             (transmute--delete-temp tmp-list))))))))

;;;###autoload
(defun transmute-video-extract-frames (fps)
  "Extract frames from video at FPS (default 10)."
  (interactive (list (read-number "FPS: " 10)))
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((basedir (file-name-directory (expand-file-name file)))
             (no-ext (file-name-sans-extension (file-name-nondirectory file)))
             ;; One directory per video so frames from different videos in
             ;; the same folder do not overwrite each other.
             (frames-dir (expand-file-name (concat no-ext "-frames") basedir)))
        (unless (file-directory-p frames-dir)
          (make-directory frames-dir t))
        (let ((cmd (format "ffmpeg -y -i %s -vf fps=%d %s/%%07d.jpg"
                           (shell-quote-argument file)
                           fps
                           (shell-quote-argument frames-dir))))
          (transmute--run-command-async (format "Extract Frames %s" (file-name-nondirectory file)) cmd))))))

;;;###autoload
(defun transmute-video-set-fps (fps)
  "Change video framerate to FPS."
  (interactive "nTarget FPS: ")
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((base (file-name-nondirectory file))
             (no-ext (file-name-sans-extension base))
             (ext (file-name-extension base))
             (dst (expand-file-name (format "%s-fps%d.%s" no-ext fps ext) (file-name-directory (expand-file-name file)))))
        (transmute-convert-video file dst "-filter:v" (format "fps=fps=%d" fps))))))

;;;###autoload
(defun transmute-video-from-frames (pattern fps)
  "Create video from image sequence PATTERN (e.g. img%%03d.jpg) at FPS."
  (interactive (list (read-string "Frame pattern: " "img%03d.jpg")
                     (read-number "FPS: " 25)))
  (let* ((basedir default-directory)
         (output-file (expand-file-name "out.mp4" basedir)))
    (let ((cmd (format "ffmpeg -y -start_number 0 -i %s -c:v libx264 -vf \"fps=%d,format=yuv420p\" %s"
                       (shell-quote-argument pattern)
                       fps
                       (shell-quote-argument output-file))))
      (transmute--run-command-async "Video from Frames" cmd))))

;;;###autoload
(defun transmute-video-remove-flips ()
  "Remove rapid camera flips/glitches using scene filter."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((base (file-name-nondirectory file))
             (no-ext (file-name-sans-extension base))
             (ext (file-name-extension base))
             (tmp1 (expand-file-name (format "%s-pass1.%s" no-ext ext) (file-name-directory (expand-file-name file))))
             (dst (expand-file-name (format "%s-filtered.%s" no-ext ext) (file-name-directory (expand-file-name file)))))
        (let ((cmd (format "ffmpeg -i %s -vf \"select='lt(scene,0.005)',setpts=N/FRAME_RATE/TB\" -vsync vfr %s && ffmpeg -i %s -vf \"select='lt(scene,0.005)',setpts=N/FRAME_RATE/TB\" -vsync vfr %s && rm %s"
                           (shell-quote-argument file)
                           (shell-quote-argument tmp1)
                           (shell-quote-argument tmp1)
                           (shell-quote-argument dst)
                           (shell-quote-argument tmp1))))
          (transmute--run-command-async (format "Remove Flips %s" base) cmd))))))

;;;###autoload
(defun transmute-video-replace-audio (audio-file)
  "Replace video audio with AUDIO-FILE (default newaudio.wav)."
  (interactive (list (read-file-name "Audio file: " nil "newaudio.wav" t)))
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((base (file-name-nondirectory file))
             (no-ext (file-name-sans-extension base))
             (ext (file-name-extension base))
             (dst (expand-file-name (format "%s-newaudio.%s" no-ext ext) (file-name-directory (expand-file-name file)))))
        (let ((cmd (format "ffmpeg -y -i %s -i %s -map 0:v:0 -map 1:a:0 -c:v copy %s"
                           (shell-quote-argument file)
                           (shell-quote-argument audio-file)
                           (shell-quote-argument dst))))
          (transmute--run-command-async (format "Replace Audio %s" base) cmd))))))

;;;###autoload
(defun transmute-video-background-music (music-dir)
  "Add random background music from MUSIC-DIR to selected videos."
  (interactive "DMusic directory: ")
  (when-let ((targets (transmute-get-filtered-targets 'video))
             (music-files (directory-files music-dir t "\\.mp3$\\|\\.wav$")))
    (transmute-do-batch targets
      (let* ((music (nth (random (length music-files)) music-files))
             (base (file-name-nondirectory file))
             (no-ext (file-name-sans-extension base))
             (ext (file-name-extension base))
             (dst (expand-file-name (format "%s-bgm.%s" no-ext ext) (file-name-directory (expand-file-name file))))
             (duration (string-to-number (shell-command-to-string (format "ffprobe -v quiet -of csv=p=0 -show_entries format=duration %s" (shell-quote-argument file))))))
        (if (<= duration 0)
            (message "Could not determine duration for %s" file)
          (let* ((fade-duration 5)
                 ;; A negative fade start made afade fail on short clips.
                 (fade-start (max 0 (- duration fade-duration)))
                 (fade-arg (if (> duration fade-duration)
                               (format "-af \"afade=t=out:st=%f:d=%d\""
                                       fade-start fade-duration)
                             ""))
                 (cmd (format "ffmpeg -y -i %s -stream_loop -1 -i %s -map 0:v:0 -map 1:a:0 -t %f %s -c:v copy %s"
                              (shell-quote-argument file)
                              (shell-quote-argument music)
                              duration
                              fade-arg
                              (shell-quote-argument dst))))
            (transmute--run-command-async (format "BG Music %s" base) cmd)))))))

;;;###autoload
(defun transmute-video-rescale (width height)
  "Rescale video to WIDTH x HEIGHT (default 1800x1080)."
  (interactive (list (read-number "Width: " 1800)
                     (read-number "Height: " 1080)))
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((base (file-name-nondirectory file))
             (no-ext (file-name-sans-extension base))
             (ext (file-name-extension base))
             (dst (expand-file-name (format "%s-rescaled.%s" no-ext ext) (file-name-directory (expand-file-name file)))))
        (transmute-convert-video file dst "-vf" (format "scale=%d:%d" width height) "-vcodec" "libx264" "-crf" "23")))))

;;;###autoload
(defun transmute-video-rotate-ccw ()
  "Rotate video 90 degrees counter-clockwise."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((base (file-name-nondirectory file))
             (no-ext (file-name-sans-extension base))
             (ext (file-name-extension base))
             (dst (expand-file-name (format "%s-rotated-ccw.%s" no-ext ext) (file-name-directory (expand-file-name file)))))
        (transmute-convert-video file dst "-vf" "transpose=2")))))

;;;###autoload
(defun transmute-audio-normalise ()
  "Normalise audio using sox."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'audio)))
    (transmute-do-batch targets
      (let* ((parsed (transmute--parse-filename file))
             (dst (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed)) "-norm." (cdr (assoc 'extension parsed)))))
        (transmute--run-command-async (file-name-nondirectory file)
                                      (format "sox --norm=0 %s %s"
                                              (shell-quote-argument file)
                                              (shell-quote-argument (expand-file-name dst))))))))

;;;###autoload
(defun transmute-audio-trim-silence ()
  "Trim silence from start and end of audio."
  (interactive)
  (when-let ((targets (transmute-get-filtered-targets 'audio)))
    (transmute-do-batch targets
      (let* ((parsed (transmute--parse-filename file))
             (dst (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed)) "-trim.mp3")))
        (transmute--run-command-async (file-name-nondirectory file)
                                      (format "ffmpeg -hide_banner -loglevel warning -stats -y -i %s -af silenceremove=start_periods=1:start_duration=1:start_threshold=-60dB:detection=peak,aformat=dblp,areverse,silenceremove=start_periods=1:start_duration=1:start_threshold=-60dB:detection=peak,aformat=dblp,areverse %s"
                                              (shell-quote-argument file)
                                              (shell-quote-argument (expand-file-name dst))))))))

;;;###autoload
(defun transmute-picture-crop (width height)
  "Crop image to WIDTHxHEIGHT centered."
  (interactive "nWidth: \nnHeight: ")
  (let ((dim (format "%dx%d" width height)))
    (when-let ((targets (transmute-get-filtered-targets 'image)))
      (transmute-do-batch targets
        (transmute-convert-image file file "-auto-orient" "-resize" (concat dim "^")
                                 "-gravity" "center" "-extent" dim)))))

;;;###autoload
(defun transmute-video-cut (start duration)
  "Cut video from START for DURATION seconds."
  (interactive "sStart (HH:MM:SS or sec): \nsDuration (sec): ")
  (when-let ((targets (transmute-get-filtered-targets 'video)))
    (transmute-do-batch targets
      (let* ((parsed (transmute--parse-filename file))
             (dst (concat (cdr (assoc 'directory parsed)) (cdr (assoc 'no-ext parsed)) "-cut." (cdr (assoc 'extension parsed)))))
        (transmute-convert-video file dst "-ss" start "-t" duration "-c" "copy")))))

;;;###autoload
(defun transmute-video-to-mp4 ()
  "Alias for video convert."
  (interactive)
  (call-interactively #'transmute-video-convert))

;;;###autoload
(defun transmute-completing-read-menu ()
  "Execute media command using completing-read."
  (interactive)
  (let* ((commands '(("Picture Convert" . transmute-picture-convert)
                     ("Picture Crush (640px)" . transmute-picture-crush)
                     ("Picture Scale (1920px)" . transmute-picture-scale)
                     ("Picture Resize (Exact)" . transmute-picture-resize)
                     ("Picture Compress (lossless)" . transmute-picture-compress)
                     ("Picture Correct (Brighten)" . transmute-picture-correct)
                     ("Picture Auto Colour" . transmute-picture-autocolour)
                     ("Picture Crop" . transmute-picture-crop)
                     ("Picture Rotate by Degrees" . transmute-picture-rotate)
                     ("Picture Upscale (GAN)" . transmute-picture-upscale)
                     ("Picture Upscale (Upscayl)" . transmute-picture-upscale-upscayl)
                     ("Picture Get Text (OCR)" . transmute-picture-get-text)
                     ("Picture To PDF" . transmute-picture-to-pdf)
                     ("Picture Tag (Interactive)" . transmute-tag-interactive)
                     ("Picture Tag from List" . transmute-tag-from-list)
                     ("Picture Add Tags & Rename" . transmute-tag-and-rename)
                     ("Picture Rename from Tags" . transmute-picture-tag-rename)
                     ("Picture Retag by Date" . transmute-retag-by-date)
                     ("Picture Clear Tags" . transmute-clear-tags)
                     ("Picture Tag Info" . transmute-tag-info)
                     ("Picture Info" . transmute-picture-info)
                     ("Picture Montage" . transmute-picture-montage)
                     ("Picture Organise" . transmute-picture-organise)
                     ("Picture Find Duplicates" . transmute-picture-find-duplicates)
                     ("Normalise Names" . transmute-normalise-names)
                     ("Picture Fix WhatsApp" . transmute-picture-fix-whatsapp)
                     ("Picture Email" . transmute-picture-email)
                     ("Picture From PDF" . transmute-picture-from-pdf)
                     ("Picture Orientation Reset" . transmute-picture-orientation-reset)
                     ("Picture Split" . transmute-picture-split)
                     ("Picture To Capture" . transmute-picture-to-capture)
                     ("Picture Update to CreateDate" . transmute-picture-update-to-create-date)
                     ("Video Convert" . transmute-video-convert)
                     ("Video Shrink" . transmute-video-shrink)
                     ("Video To GIF" . transmute-video-to-gif)
                     ("Video Trim (Top/Tail)" . transmute-video-toptail)
                     ("Video Cut" . transmute-video-cut)
                     ("Video Reverse" . transmute-video-reverse)
                     ("Video Speed Up" . transmute-video-speed-up)
                     ("Video Slow Down" . transmute-video-slow-down)
                     ("Video Extract Audio" . transmute-video-extract-audio)
                     ("Video Remove Audio" . transmute-video-remove-audio)
                     ("Video Replace Audio" . transmute-video-replace-audio)
                     ("Video Background Music" . transmute-video-background-music)
                     ("Video Concat" . transmute-video-concat)
                     ("Video Double" . transmute-video-double)
                     ("Video Extract Frames" . transmute-video-extract-frames)
                     ("Video From Frames" . transmute-video-from-frames)
                     ("Video Remove Flips" . transmute-video-remove-flips)
                     ("Video Set FPS" . transmute-video-set-fps)
                     ("Video Rescale" . transmute-video-rescale)
                     ("Video Rotate CCW" . transmute-video-rotate-ccw)
                     ("Video Info" . transmute-video-info)
                     ("Audio Convert" . transmute-audio-convert)
                     ("Audio Normalise" . transmute-audio-normalise)
                     ("Audio Trim Silence" . transmute-audio-trim-silence)
                     ("Audio Info" . transmute-audio-info)
                     ("Document To PDF" . transmute-document-to-pdf)
                     ("Document To DOCX" . transmute-document-to-docx)
                     ("Document To ODT" . transmute-document-to-odt)
                     ("Document To TXT" . transmute-document-to-txt)
                     ("Document To RTF" . transmute-document-to-rtf)
                     ("Document To HTML" . transmute-document-to-html)
                     ("Document To EPUB" . transmute-document-to-epub)))
         (choice (completing-read "Media Command: " (mapcar #'car commands) nil t))
         (func (cdr (assoc choice commands))))
    (when func
      (call-interactively func))))

;;; Transient Menu

(transient-define-prefix transmute-image-menu ()
  ["Image"
   ["Basic"
    ("c" "Convert" transmute-picture-convert)
    ("C" "Crop" transmute-picture-crop)
    ("S" "Split" transmute-picture-split)
    ("m" "Montage" transmute-picture-montage)
    ("p" "To PDF" transmute-picture-to-pdf)
    ("t" "Get Text (OCR)" transmute-picture-get-text)]
   ["Meta"
    ("d" "From PDF" transmute-picture-from-pdf)
    ("i" "Info" transmute-picture-info)
    ("x" "Show Backup Xattr" transmute-picture-show-xattr)
    ("X" "Set Xattr" transmute-picture-set-xattr)]
    ["Enhance"
     ("z" "Crush (640px)" transmute-picture-crush)
     ("s" "Scale (1920px)" transmute-picture-scale)
     ("E" "Resize (exact)" transmute-picture-resize)
     ("Z" "Compress (lossless)" transmute-picture-compress)
     ("u" "Upscale (GAN)" transmute-picture-upscale)
     ("y" "Upscale (Upscayl)" transmute-picture-upscale-upscayl)
    ("r" "Rotate Right" transmute-picture-rotate-right)
    ("l" "Rotate Left" transmute-picture-rotate-left)
    ("R" "Rotate by Degrees..." transmute-picture-rotate)]
   ["Colour"
    ("b" "Brighten" transmute-picture-correct)
    ("a" "Auto Colour" transmute-picture-autocolour)
    ("O" "Orientation Reset" transmute-picture-orientation-reset)]
   ["Organise"
    ("o" "Organise" transmute-picture-organise)
    ("n" "Normalise Names" transmute-normalise-names)
    ("D" "Find Duplicates" transmute-picture-find-duplicates)
    ("w" "WhatsApp Fix" transmute-picture-fix-whatsapp)
    ("F" "Update from CreateDate" transmute-picture-update-from-create-date)
    ("U" "Update to CreateDate" transmute-picture-update-to-create-date)]
   ["Share"
    ("e" "Email" transmute-picture-email)
    ("g" "To Capture" transmute-picture-to-capture)]])

(transient-define-prefix transmute-video-menu ()
  ["Video"
   ["Convert"
    ("c" "Convert" transmute-video-convert)
    ("s" "Shrink" transmute-video-shrink)
    ("e" "Rescale" transmute-video-rescale)
    ("R" "Rotate Right" transmute-video-rotate-right)
    ("L" "Rotate Left" transmute-video-rotate-left)]
   ["Trim"
    ("C" "Rotate CCW" transmute-video-rotate-ccw)
    ("r" "Reverse" transmute-video-reverse)
    ("t" "Top/Tail (Trim)" transmute-video-toptail)
    ("k" "Cut" transmute-video-cut)]
   ["Effects"
    ("g" "To GIF" transmute-video-to-gif)
    ("+" "Speed Up" transmute-video-speed-up)
    ("-" "Slow Down" transmute-video-slow-down)
    ("f" "Remove Flips" transmute-video-remove-flips)
    ("F" "Set FPS" transmute-video-set-fps)]
   ["Sequence"
    ("j" "Concat" transmute-video-concat)
    ("2" "Double" transmute-video-double)
    ("E" "Extract Frames" transmute-video-extract-frames)
    ("I" "From Frames" transmute-video-from-frames)]
   ["Audio"
    ("a" "Extract Audio" transmute-video-extract-audio)
    ("x" "Remove Audio" transmute-video-remove-audio)
    ("m" "Replace Audio" transmute-video-replace-audio)
    ("B" "Background Music" transmute-video-background-music)]
   ["Meta"
    ("i" "Info" transmute-video-info)]])

(transient-define-prefix transmute-audio-menu ()
  ["Audio"
   ("c" "Convert" transmute-audio-convert)
   ("n" "Normalise" transmute-audio-normalise)
   ("t" "Trim Silence" transmute-audio-trim-silence)
   ("i" "Info" transmute-audio-info)
   ("I" "Video Info" transmute-video-info)])

(transient-define-prefix transmute-tag-menu ()
  ["Tags"
   ["Tag"
    ("t" "Tag (Interactive)" transmute-tag-interactive)
    ("k" "Tag from List" transmute-tag-from-list)
    ("r" "Add Tags & Rename" transmute-tag-and-rename)
    ("R" "Rename from Tags" transmute-picture-tag-rename)]
   ["Clean"
    ("d" "Retag by Date" transmute-retag-by-date)
    ("c" "Clear Tags" transmute-clear-tags)
    ("i" "Tag Info" transmute-tag-info)]])

(transient-define-prefix transmute-document-menu ()
  ["Document"
   ["Convert"
    ("p" "To PDF" transmute-document-to-pdf)
    ("w" "To DOCX" transmute-document-to-docx)
    ("o" "To ODT" transmute-document-to-odt)
    ("t" "To TXT" transmute-document-to-txt)
    ("r" "To RTF" transmute-document-to-rtf)]
   ["Publish"
    ("h" "To HTML" transmute-document-to-html)
    ("e" "To EPUB" transmute-document-to-epub)]])

;;;###autoload
(transient-define-prefix transmute-menu ()
  "Main menu for media management utilities."
  [["Transmute"
    ("i" "Image Commands" transmute-image-menu)
    ("v" "Video Commands" transmute-video-menu)
    ("a" "Audio Commands" transmute-audio-menu)
    ("t" "Tag Commands" transmute-tag-menu)
    ("d" "Document" transmute-document-menu)]
   ["Utilities"
    ("n" "Normalise Names" transmute-normalise-names)
    ("m" "Completing Read Menu" transmute-completing-read-menu)
    ("L" "Show Log" transmute-show-log)
    ("S" "Stop Conversions" transmute-stop-conversions)]])

;;;###autoload
(transmute-progress-mode 1)

(defun transmute--image-dired-kill-buffer-query ()
  "Allow killing *image-dired-display-image* buffers without confirmation.
Transmute modifies image files externally (rotate, tag, etc.) which
marks the display buffer as modified.  image-dired-display-image calls
kill-buffer on it when switching images, triggering a \"Buffer modified;
kill anyway?\" prompt.  This handler silently clears the modified flag
so the kill proceeds without prompting.  Always returns t to allow the kill."
  (when (and (string-match-p "\\`\\*image-dired-display-image\\*"
                             (buffer-name))
             (buffer-modified-p))
    (set-buffer-modified-p nil))
  t)

(defun transmute--stale-lock-p (lock)
  "Return non-nil when LOCK is an orphaned Emacs file-lock symlink.
A lock is orphaned when its `user@host.pid:boot' target belongs to the
current user and host but the recorded PID is no longer running.  A
lock we cannot positively identify as dead is never reported stale."
  (when-let ((target (file-symlink-p lock)))
    (let ((user-pattern (format "%s@%s" (user-login-name) (system-name))))
      (when (string-match
             (concat "\\`" (regexp-quote user-pattern) "\\.\\([0-9]+\\):")
             target)
        (let ((pid (string-to-number (match-string 1 target))))
          (and (> pid 0)
               (fboundp 'process-attributes)
               (null (process-attributes pid))))))))

(defun transmute--clean-orphaned-locks (files &optional directory)
  "Delete orphaned Emacs file-lock symlinks for FILES or DIRECTORY.
Only locks owned by the current user and host whose process is gone
are deleted; live locks, including those held by this Emacs session,
are left alone.  If DIRECTORY is provided, scan it for all orphaned
media locks."
  (if directory
      (let ((lock-files (directory-files directory t "\\`\\.#" t))
            (media-exts (append transmute-image-extensions
                                transmute-video-extensions
                                transmute-audio-extensions)))
        (dolist (lock lock-files)
          (let* ((base (substring (file-name-nondirectory lock) 2))
                 (ext (file-name-extension base)))
            (when (and (member (downcase (or ext "")) media-exts)
                       (transmute--stale-lock-p lock))
              (delete-file lock)))))
    ;; Individual files mode
    (dolist (f files)
      (let* ((f (expand-file-name f))
             (dir (file-name-directory f))
             (base (file-name-nondirectory f))
             (lock (expand-file-name (concat ".#" base) dir)))
        (when (transmute--stale-lock-p lock)
          (delete-file lock))))))

(defun transmute-refresh-thumbnail ()
  "Refresh dired and thumbnail buffers after a transmute batch operation.
A read-only batch (the duplicate scan) skips the refresh entirely:
nothing changed on disk, and regenerating thumbnails would be slow and
would re-display the current image over the report buffer."
  (if (and transmute--skip-refresh-once (null transmute-batch-files))
      (progn
        (setq transmute--skip-refresh-once nil
              transmute--inhibit-display-refresh-once nil
              transmute--last-renames nil)
        (transmute--log "[REFRESH] Skipped (read-only batch)."))
    (setq transmute--skip-refresh-once nil)
    (transmute--refresh-thumbnail)))

(defun transmute--refresh-thumbnail ()
  "Refresh dired and thumbnail buffers after a transmute batch operation.
Handles renamed files by updating their visiting buffers and reverts
affected buffers silently to prevent file-supersession prompts.
Clears modified flags and orphaned lock files immediately to avoid
\"Buffer modified; kill anyway?\" prompts; defers cache refresh."
  (let ((files (mapcar #'expand-file-name transmute-batch-files))
        (renames transmute--last-renames)
        (inhibit-display transmute--inhibit-display-refresh-once)
        (affected-dirs nil))

    ;; Consume the shared state immediately so a batch started while this
    ;; one is still refreshing does not accumulate stale entries.
    (setq transmute--inhibit-display-refresh-once nil
          transmute-batch-files nil
          transmute--last-renames nil)
    (setq affected-dirs
          (delete-dups
           (delq nil
                 (append (mapcar #'file-name-directory files)
                         (mapcar (lambda (r)
                                   (file-name-directory (cdr r)))
                                 renames)))))

    ;; -- Immediate cleanup: must happen before user can interact --

    ;; 1. Clear modified flag on image-dired display buffers so they
    ;;    can be reused without "kill anyway?" prompts.
    (dolist (buf (buffer-list))
      (when (and (buffer-live-p buf)
                 (string-match-p "\\`\\*image-dired-display-image\\*"
                                 (buffer-name buf)))
        (with-current-buffer buf
          (set-buffer-modified-p nil)
          (unlock-buffer))))

    ;; -- Deferred refresh: cache/thumb/dired can wait --
    (run-at-time 0.5 nil
                 (lambda ()
                   (clear-image-cache)
                   (when (fboundp 'dired-image-thumbnail-clear-preview-cache)
                     (dired-image-thumbnail-clear-preview-cache))

                   ;; 3. Delete associated thumbnails to force regeneration
                   (dolist (f files)
                     (when (and (boundp 'image-dired-dir)
                                (fboundp 'image-dired-thumb-name))
                       (let ((thumb (image-dired-thumb-name f)))
                         (when (file-exists-p thumb)
                           (delete-file thumb)))))

                   ;; 4. Synchronize all buffers visiting affected files
                   ;;    Skip image-dired display buffers — clearing their modified
                   ;;    flag is enough; refreshing them is handled by image-dired itself.
                   (dolist (buf (buffer-list))
                     (when (buffer-live-p buf)
                       (with-current-buffer buf
                         (unless (string-match-p "\\`\\*image-dired-display-image\\*"
                                                 (buffer-name buf))
                           (let ((bfn (and buffer-file-name (expand-file-name buffer-file-name))))
                             (when bfn
                               (let ((new-name (cdr (assoc bfn renames))))
                                 (cond
                                  (new-name
                                   (set-buffer-modified-p nil)
                                   (set-visited-file-name new-name nil t)
                                   (unlock-buffer)
                                   (revert-buffer nil t))
                                  ((member bfn files)
                                   (set-buffer-modified-p nil)
                                   (unlock-buffer)
                                   (revert-buffer nil t))))))
                           ;; Only revert dired buffers showing a directory
                           ;; this batch actually touched.
                           (when (and (derived-mode-p 'dired-mode)
                                      (member (expand-file-name default-directory)
                                              affected-dirs))
                             (revert-buffer nil t))))))

                   ;; 5. Refresh the thumbnail view
                   (when (fboundp 'dired-image-thumbnail-invalidate-files)
                     (dired-image-thumbnail-invalidate-files files))
                   (if (fboundp 'dired-image-thumbnail-refresh-all)
                       (dired-image-thumbnail-refresh-all renames)
                     (dolist (buf (buffer-list))
                       (when (buffer-live-p buf)
                         (with-current-buffer buf
                           (when (derived-mode-p 'image-dired-thumbnail-mode)
                             (when (and (boundp 'dired-image-thumbnail--dimension-cache)
                                        dired-image-thumbnail--dimension-cache)
                               (clrhash dired-image-thumbnail--dimension-cache))
                             (when (fboundp 'dired-image-thumbnail-refresh)
                               (dired-image-thumbnail-refresh)))))))

                   ;; 6. Finally, refresh the full-size display if active
                   (when (and (not inhibit-display)
                              (fboundp 'dired-image-thumbnail-refresh-current-display))
                     (dired-image-thumbnail-refresh-current-display))

                   ;; 7. FINAL SWEEP: Clean orphaned Emacs file-lock symlinks
                   (transmute--clean-orphaned-locks files)
                   (transmute--clean-orphaned-locks (mapcar #'cdr renames))
                   (when-let ((batch-dir (and (car files) (file-name-directory (car files)))))
                     (transmute--clean-orphaned-locks nil batch-dir))
                   (transmute--log "[FINISH] Batch refresh complete.")))))

(add-hook 'transmute-after-batch-hook #'transmute-refresh-thumbnail)

(add-hook 'kill-buffer-query-functions
          #'transmute--image-dired-kill-buffer-query)

(defun transmute--setup-display-buffer-keys ()
  "Set up `transmute-menu' binding in image-dired display and image-mode buffers.
Added to `special-mode-hook', `image-dired-image-mode-hook', and `image-mode-hook'
so that C-c I works in the *image-dired-display-image* buffer and image-mode buffers."
  (when (or (string-match-p "\\`\\*image-dired-display-image\\*" (buffer-name))
            (derived-mode-p 'image-mode))
    (local-set-key (kbd "C-c I") #'transmute-menu)))

(add-hook 'special-mode-hook #'transmute--setup-display-buffer-keys)
(add-hook 'image-dired-image-mode-hook #'transmute--setup-display-buffer-keys)
(add-hook 'image-mode-hook #'transmute--setup-display-buffer-keys)

;;;###autoload
(defun transmute-setup-thumbnail-keys ()
  "Bind `transmute-menu' in image-dired thumbnail and display buffers.
In the thumbnail buffer both `I' and `C-c I' run `transmute-menu'.
In the display-image buffer only `C-c I' is bound, since a bare `I'
could clash with image-mode bindings there.
Call this in your init file after loading both packages.
Also activates keybindings in the *image-dired-display-image* buffer
via `special-mode-hook' and `image-dired-image-mode-hook'."
  (when (and (boundp 'image-dired-thumbnail-mode-map)
             (keymapp image-dired-thumbnail-mode-map))
    (define-key image-dired-thumbnail-mode-map (kbd "I") #'transmute-menu)
    (define-key image-dired-thumbnail-mode-map (kbd "C-c I") #'transmute-menu))
  (when (and (boundp 'image-dired-display-image-mode-map)
             (keymapp image-dired-display-image-mode-map))
    (define-key image-dired-display-image-mode-map (kbd "C-c I") #'transmute-menu)))

(provide 'transmute)

;;; transmute.el ends here
