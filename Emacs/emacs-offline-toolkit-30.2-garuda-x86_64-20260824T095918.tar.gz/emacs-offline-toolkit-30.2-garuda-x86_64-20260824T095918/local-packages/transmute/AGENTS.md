# AGENTS.md - Transmute

## Architecture
- Single-file Elisp package (`transmute.el`) providing a wrapper around CLI media tools.
- Heavily integrated with `dired` for batch processing of marked files.
- Uses `transient` for its primary keyboard-driven menu.

## External Dependencies
The following system tools must be in the PATH:
- `exiftool`: Metadata and date management.
- `magick`: ImageMagick 7+ for image processing.
- `ffmpeg` / `ffprobe`: Video and audio processing.
- `sox`: Audio normalization.
- `tesseract`: OCR.
- `soffice`: Document to PDF conversion (LibreOffice headless).
- `realesrgan-ncnn-vulkan`: AI upscaling (optional).
- `trash-put`: Safe file deletion (optional; falls back to `move-file-to-trash`).

## Conventions & Quirks
- **Filename Pattern**: Uses a specific parsing logic for filenames: `YYYYMMDDHHMMSS--description__tag1@tag2.ext`.
- **Metadata**: Prioritizes preserving metadata via `exiftool` and restoring modification times using `set-file-times`.
- **Temporary Files**: Most conversion functions use `make-temp-file` to prevent partial output files on failure.
- **Batching**: Use the `transmute-do-batch` macro to iterate over files targets.

## Development & Testing
- **Manual Testing**: 
  1. Load the file in Emacs: `(load "transmute.el")`.
  2. Use a Dired buffer to mark files.
  3. Run `M-x transmute-menu`.
- **Linting**: Standard Emacs Lisp style. No automated test suite present in repo.
