;;; jasspa-modes.el --- Major modes for Jasspa MicroEmacs config files  -*- lexical-binding: t; -*-
;;
;; Author: James Dyer <james@dyerdwelling.family>
;; Version: 0.1.0
;; Package-Requires: ((emacs "27.1"))
;; Keywords: languages, tools, convenience
;; URL: https://github.com/bjasspa/jasspa/
;;
;; This file is not part of GNU Emacs.
;;
;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or (at
;; your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.
;;
;;; Commentary:
;;
;; This package provides two major modes for editing Jasspa MicroEmacs
;; configuration files:
;;
;;   `jasspa-emf-mode' --- for *.emf macro files (keybindings, macros).
;;   `jasspa-erf-mode' --- for *.erf resource files (settings, file types).
;;
;; Both modes derive from `prog-mode' and provide font-lock, indentation,
;; and imenu.  They do not handle the binary-ish *.esf session-state file
;; format, which is not meant to be hand-edited.
;;
;; Quick start:
;;
;;   (require 'jasspa-modes)
;;   ;; now *.emf and *.erf files open in the correct mode automatically
;;
;; Or with use-package (no :ensure since it is a local package):
;;
;;   (use-package jasspa-modes
;;     :load-path "~/.emacs.d/offline-packages/local-packages/jasspa-modes")
;;
;;; Code:

(require 'imenu)
(require 'subr-x)


;; -> Common syntax tables

(defvar jasspa-emf-mode-syntax-table
  (let ((table (make-syntax-table prog-mode-syntax-table)))
    (modify-syntax-entry ?\; "<" table)
    (modify-syntax-entry ?\n ">" table)
    table)
  "Syntax table for `jasspa-emf-mode'.
`;' starts a single-line comment terminated by newline.")

(defvar jasspa-erf-mode-syntax-table
  (let ((table (make-syntax-table prog-mode-syntax-table)))
    (modify-syntax-entry ?\; "<" table)
    (modify-syntax-entry ?\n ">" table)
    table)
  "Syntax table for `jasspa-erf-mode'.
`;' starts a single-line comment terminated by newline;
`\"' has string syntax (inherited from prog-mode).")


;; -> Common faces

(defface jasspa-keyword
  '((t :inherit font-lock-keyword-face))
  "Face for Jasspa reserved words like `define-macro' and `global-bind-key'."
  :group 'jasspa)

(defface jasspa-macro-name
  '((t :inherit font-lock-function-name-face))
  "Face for names defined with `define-macro'."
  :group 'jasspa)

(defface jasspa-repeat
  '((t :inherit font-lock-constant-face))
  "Face for numeric repeat counts and section indices."
  :group 'jasspa)

(defface jasspa-key-seq
  '((t :inherit font-lock-string-face :weight bold))
  "Face for key-sequence strings like \"C-x d\" in emf files."
  :group 'jasspa)

(defface jasspa-section
  '((t :inherit font-lock-function-name-face))
  "Face for section names in erf files."
  :group 'jasspa)


;; -> emf mode

(defconst jasspa-emf--keywords
  '("define-macro" "global-bind-key" "global-unbind-key"
    "buffer-bind-key" "buffer-unbind-key" "!emacro")
  "Jasspa emf reserved words.")

(defconst jasspa-emf--keyword-regexp
  (regexp-opt jasspa-emf--keywords 'symbols))

(defconst jasspa-emf--key-regexp
  (rx ?\"
      (optional (any "CSAM") ?-)
      (optional (any "CSAM") ?-)
      (1+ (or alnum ?/ ?+ ?. ?, ?- ?:))
      (zero-or-more (1+ space)
                    (any "CSAM") ?-
                    (1+ (or alnum ?/ ?+ ?. ?, ?- ?:)))
      ?\"))

(defvar jasspa-emf--font-lock-keywords
  `((,jasspa-emf--keyword-regexp . 'jasspa-keyword)
    (,(rx bow "define-macro" (1+ space) (group (1+ (or word ?- ?_))))
     (1 'jasspa-macro-name))
    (,(rx bol (1+ space) (group (optional ?-) (1+ digit)) (1+ space))
     1 'jasspa-repeat)
    (,jasspa-emf--key-regexp 0 'jasspa-key-seq append))
  "Font-lock keywords for `jasspa-emf-mode'.")

(defvar jasspa-emf-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map [remap comment-line] #'jasspa-emf-comment-line)
    map)
  "Keymap for `jasspa-emf-mode'.")

(defun jasspa-emf-indent-line ()
  "Indent current line in `jasspa-emf-mode'.
Top-level meta commands (`define-macro', `!emacro', `global-bind-key',
etc.) start at column 0.  Lines inside a `define-macro' body indent to
`jasspa-emf-body-indent' (default 2)."
  (let ((body-indent 2)
        (pos0 (- (point) (line-beginning-position))))
    (save-excursion
      (beginning-of-line)
      (delete-horizontal-space)
      (let ((on-meta
             (save-excursion
               (skip-chars-forward " \t")
               (looking-at-p jasspa-emf--keyword-regexp))))
        (if on-meta
            (indent-line-to 0)
          (let ((in-body nil))
            (save-excursion
              (while (and (zerop (forward-line -1))
                          (not (bobp))
                          (not in-body))
                (beginning-of-line)
                ;; Stop scanning once we hit !emacro (end of prior macro)
                ;; or a top-level meta command that is not define-macro.
                (let ((line (buffer-substring-no-properties
                             (line-beginning-position)
                             (line-end-position))))
                  (cond
                   ((string-match-p "^\\s-*!emacro" line) (setq in-body nil))
                   ((string-match-p "^\\s-*define-macro" line) (setq in-body t))
                   ((string-match-p
                     (concat "^\\s-*" jasspa-emf--keyword-regexp) line)
                    (setq in-body nil))))))
            (indent-line-to (if in-body body-indent 0))))))
    (when (< pos0 (current-column))
      (move-to-column pos0))))

(defun jasspa-emf-comment-line (n)
  "Comment or uncomment N lines in `jasspa-emf-mode' using the `;' prefix."
  (interactive "p")
  (let ((comment-start ";")
        (comment-end ""))
    (comment-line n)))

(defun jasspa-emf-imenu-index ()
  "Return an imenu alist for `jasspa-emf-mode'."
  (save-excursion
    (goto-char (point-min))
    (let ((entries nil))
      (while (re-search-forward
              "^define-macro[ \t]+\\([A-Za-z0-9_-]+\\)" nil t)
        (push (cons (match-string 1) (match-beginning 0)) entries))
      (nreverse entries))))

;;;###autoload
(define-derived-mode jasspa-emf-mode prog-mode "Jasspa-emf"
  "Major mode for Jasspa MicroEmacs macro files (*.emf).

Provides font-lock, indentation, imenu and `;'-based comment commands
for the emf config format used by Jasspa's MicroEmacs.

The syntax is line-oriented: `define-macro' starts a macro block
terminated by `!emacro'; `global-bind-key' and `buffer-bind-key'
attach commands or macros to key sequences."
  :group 'jasspa
  (setq-local comment-start ";")
  (setq-local comment-end "")
  (setq-local comment-start-skip ";+ *")
  (setq-local parse-sexp-ignore-comments t)
  (setq-local font-lock-defaults
              '((jasspa-emf--font-lock-keywords)
                nil nil nil nil))
  (setq-local indent-line-function #'jasspa-emf-indent-line)
  (setq-local imenu-create-index-function #'jasspa-emf-imenu-index))


;; -> erf mode

;; A quoted key name, e.g. "linux", "kept-vers", "file-ignore".
(defconst jasspa-erf--key-regexp
  (rx ?\" (group (1+ (or alnum ?- ?_ ?:))) ?\"))

;; key = "value" pair, where value may be empty.
(defconst jasspa-erf--assign-regexp
  (rx ?\" (group (1+ (or alnum ?- ?_ ?:))) ?\"
      (1+ space) ?= (1+ space)
      ?\" (group (0+ (not (any ?\")))) ?\"))

;; Section header: "name" {  OR  "name" 2 {  (with an index).
(defconst jasspa-erf--section-regexp
  (rx ?\" (group (1+ (or alnum ?- ?_ ?:))) ?\"
      (1+ space)
      (optional (group (1+ digit)) (1+ space))
      (group ?{)))

(defvar jasspa-erf--font-lock-keywords
  `((,jasspa-erf--section-regexp
     (1 'jasspa-section)
     (2 'jasspa-repeat nil t))
    (,jasspa-erf--assign-regexp
     (1 'font-lock-variable-name-face)
     (2 'font-lock-string-face))
    ("[{}]" . 'jasspa-keyword))
  "Font-lock keywords for `jasspa-erf-mode'.")

(defvar jasspa-erf-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "C-c C-f") #'jasspa-erf-flatten-buffer)
    (define-key map (kbd "C-c C-t") #'jasspa-erf-ensure-trailer)
    map)
  "Keymap for `jasspa-erf-mode'.")

(defun jasspa-erf--block-depth-at-pos (pos)
  "Return the brace nesting depth at the start of the line at POS.
Depth is the number of enclosing `{' blocks between `point-min' and POS.
Strings and comments are skipped via `syntax-ppss'."
  (save-excursion
    (goto-char (point-min))
    (let ((depth 0))
      (while (< (point) pos)
        (let ((ch (char-after))
              (ppss (syntax-ppss (point))))
          (cond
           ((nth 8 ppss) (forward-char))  ; inside string/comment
           ((eq ch ?{) (cl-incf depth) (forward-char))
           ((eq ch ?}) (cl-decf depth) (forward-char))
           (t (forward-char)))))
      (max 0 depth))))

(defun jasspa-erf-indent-line ()
  "Indent current line in `jasspa-erf-mode' using `{' / `}' nesting.
A line whose first non-whitespace character is `}' aligns with the
opening block; everything else aligns one step deeper than its parent."
  (let ((pos0 (- (point) (line-beginning-position)))
        (step 1))
    (save-excursion
      (beginning-of-line)
      (delete-horizontal-space)
      (let* ((bol (point))
             (line-closes (looking-at-p "}"))
             (depth (jasspa-erf--block-depth-at-pos bol))
             (target (max 0 (* step (if line-closes (1- depth) depth)))))
        (indent-line-to (* target step))))
    (when (< pos0 (current-column))
      (move-to-column pos0))))

(defun jasspa-erf-imenu-index ()
  "Return an imenu alist of section names for `jasspa-erf-mode'."
  (save-excursion
    (goto-char (point-min))
    (let ((entries nil))
      (while (re-search-forward jasspa-erf--section-regexp nil t)
        (push (cons (match-string 1) (match-beginning 0)) entries))
      (nreverse entries))))

(defun jasspa-erf-flatten-buffer ()
  "Normalise whitespace around `=' in every \"key\" = \"value\" assignment.
This is purely cosmetic; the file's meaning is unchanged."
  (interactive)
  (save-excursion
    (goto-char (point-min))
    (while (re-search-forward jasspa-erf--assign-regexp nil t)
      (replace-match (concat "\"" (match-string 1) "\" = \""
                              (match-string 2) "\"")))))

(defun jasspa-erf-ensure-trailer ()
  "Ensure the erf buffer ends with a final newline (required by ME)."
  (interactive)
  (save-excursion
    (goto-char (point-max))
    (unless (bolp)
      (insert "\n"))))

;;;###autoload
(define-derived-mode jasspa-erf-mode prog-mode "Jasspa-erf"
  "Major mode for Jasspa MicroEmacs resource files (*.erf).

Section blocks delimited by `{ ... }' get their own indentation level.
Includes font-lock for keys, values, section names, and brace
delimiters, plus imenu navigation of sections."
  :group 'jasspa
  (setq-local comment-start ";")
  (setq-local comment-end "")
  (setq-local comment-start-skip ";+ *")
  (setq-local parse-sexp-ignore-comments t)
  (setq-local electric-indent-chars
              (append '(?\{ ?\}) electric-indent-chars))
  (setq-local font-lock-defaults
              '((jasspa-erf--font-lock-keywords)
                nil nil nil nil))
  (setq-local indent-line-function #'jasspa-erf-indent-line)
  (setq-local imenu-create-index-function #'jasspa-erf-imenu-index))


;; -> Autoloads

;;;###autoload
(with-eval-after-load 'jasspa-modes
  (add-to-list 'auto-mode-alist '("\\.emf\\'" . jasspa-emf-mode))
  (add-to-list 'auto-mode-alist '("\\.erf\\'" . jasspa-erf-mode)))

(provide 'jasspa-emf-mode)
(provide 'jasspa-erf-mode)
(provide 'jasspa-modes)

;;; jasspa-modes.el ends here