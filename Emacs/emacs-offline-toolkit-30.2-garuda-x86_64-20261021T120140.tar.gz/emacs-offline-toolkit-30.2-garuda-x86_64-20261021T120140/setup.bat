@echo off
setlocal enabledelayedexpansion

set HERE=%~dp0

:: Ensure System32 and common Windows binary locations are on PATH.
:: When invoked from Emacs eshell or a minimal cmd, System32 may be missing.
set "WIN_PATH=%SystemRoot%\System32;%SystemRoot%;%SystemRoot%\System32\Wbem;%SystemRoot%\System32\WindowsPowerShell\v1.0\;%SystemRoot%\System32\OpenSSH\"
set "PATH=%WIN_PATH%;%PATH%"

:: Use Windows' bundled bsdtar explicitly. The MSYS/Git-bash GNU tar that is
:: often first on PATH treats a "z:\..." archive path as a remote host ("z:")
:: and fails with "Cannot connect to z: resolve failed".
set "TAR=%SystemRoot%\System32\tar.exe"
if not exist "%TAR%" set "TAR=tar"

:: Accept either EMACS_D path (ending with .emacs.d) or HOME path.
:: Falls back to %APPDATA%\.emacs.d (the standard Emacs config location on Windows).
if not "%1"=="" (
  set "TARGET=%1"
  :: Strip trailing separator if present
  if "!TARGET:~-1!"=="\" set "TARGET=!TARGET:~0,-1!"
  if "!TARGET:~-1!"=="/" set "TARGET=!TARGET:~0,-1!"
  :: Check if it's an .emacs.d path (last 8 chars == ".emacs.d")
  if /i "!TARGET:~-8!"==".emacs.d" (
    set EMACS_D=!TARGET!
    set MY_HOME=!TARGET:~0,-8!
    :: Strip any separator left at the end of MY_HOME
    if "!MY_HOME:~-1!"=="\" set MY_HOME=!MY_HOME:~0,-1!
    if "!MY_HOME:~-1!"=="/" set MY_HOME=!MY_HOME:~0,-1!
  ) else (
    set MY_HOME=!TARGET!
    set EMACS_D=!TARGET!\.emacs.d
  )
) else (
  rem Use %APPDATA% as the default HOME — Emacs on Windows looks here by
  rem default, so .emacs.d lives at %APPDATA%\.emacs.d.
  set "MY_HOME=%APPDATA%"
  set "EMACS_D=%APPDATA%\.emacs.d"
)
for /f %%I in ('powershell -Command "Get-Date -Format 'yyyyMMddTHHmmss'"') do set STAMP=%%I
set BACKUP_DIR=%EMACS_D%\.backups\%STAMP%

echo ^>^> Target: %EMACS_D%
echo ^>^> HOME:     %MY_HOME%
if not exist "%EMACS_D%" mkdir "%EMACS_D%"
if not exist "%BACKUP_DIR%" mkdir "%BACKUP_DIR%"

:: Back up existing init files so we don't silently clobber an existing setup.
for %%f in (init.el early-init.el abbrev_defs init-starter.el init-starter-coding.el init-on-windows.el) do (
  if exist "%EMACS_D%\%%f" (
    echo    backing up %%f -^> .backups\%STAMP%\%%f
    move "%EMACS_D%\%%f" "%BACKUP_DIR%\%%f" >nul
  )
)

:: Move any existing elpa aside so packages reinstall from the fresh mirror.
if exist "%EMACS_D%\elpa" (
  echo    backing up elpa -^> .backups\%STAMP%\elpa
  move "%EMACS_D%\elpa" "%BACKUP_DIR%\elpa" >nul
)

:: Move any pre-existing mirror extractions aside too.
for /d %%d in ("%MY_HOME%\elpa-mirror-emacs-*") do (
  if exist "%%d" (
    if not exist "%BACKUP_DIR%\home-mirrors" mkdir "%BACKUP_DIR%\home-mirrors"
    echo    backing up %%~nxd -^> .backups\%STAMP%\home-mirrors\%%~nxd
    move "%%d" "%BACKUP_DIR%\home-mirrors\%%~nxd" >nul
  )
)

:: Extract ELPA mirror into %MY_HOME% (init.el globs ~/elpa-mirror-emacs-*).
for %%m in ("%HERE%elpa-mirror-*.tar.gz") do (
  if exist "%%m" (
    echo ^>^> Extracting %%~nxm into %MY_HOME%
    "%TAR%" -xzf "%%m" -C "%MY_HOME%"
  )
)

:: Install the literate config directories.
for %%d in (Emacs-vanilla Emacs-DIYer) do (
  if exist "%HERE%%%d" (
    if exist "%EMACS_D%\%%d" (
      echo    backing up %%d -^> .backups\%STAMP%\%%d
      move "%EMACS_D%\%%d" "%BACKUP_DIR%\%%d" >nul
    )
    echo ^>^> Installing %%d to %EMACS_D%\%%d
    if not exist "%EMACS_D%\%%d" mkdir "%EMACS_D%\%%d"
    xcopy "%HERE%%%d\." "%EMACS_D%\%%d\" /E /I /H /Y >nul
  )
)

:: Install local-packages if bundled.
if exist "%HERE%local-packages" (
  if exist "%EMACS_D%\local-packages" (
    echo    backing up local-packages -^> .backups\%STAMP%\local-packages
    move "%EMACS_D%\local-packages" "%BACKUP_DIR%\local-packages" >nul
  )
  echo ^>^> Installing local-packages to %EMACS_D%\local-packages
  if not exist "%EMACS_D%\local-packages" mkdir "%EMACS_D%\local-packages"
  xcopy "%HERE%local-packages\." "%EMACS_D%\local-packages\" /E /I /H /Y >nul
)

:: Install init.el and optional early-init.el.
copy "%HERE%init.el" "%EMACS_D%\init.el" >nul
if exist "%HERE%early-init.el" copy "%HERE%early-init.el" "%EMACS_D%\early-init.el" >nul
if exist "%HERE%abbrev_defs" copy "%HERE%abbrev_defs" "%EMACS_D%\abbrev_defs" >nul

:: Install starter snippets (not auto-loaded).
if exist "%HERE%init-starter.el" (
  copy "%HERE%init-starter.el" "%EMACS_D%\init-starter.el" >nul
  echo ^>^> Starter snippet installed at %EMACS_D%\init-starter.el (not auto-loaded^)
)
if exist "%HERE%init-starter-coding.el" (
  copy "%HERE%init-starter-coding.el" "%EMACS_D%\init-starter-coding.el" >nul
  echo ^>^> Coding companion installed at %EMACS_D%\init-starter-coding.el (not auto-loaded^)
)
if exist "%HERE%init-on-windows.el" (
  copy "%HERE%init-on-windows.el" "%EMACS_D%\init-on-windows.el" >nul
  echo ^>^> Windows starter installed at %EMACS_D%\init-on-windows.el (not auto-loaded^)
)

:: Install docs/ drop-zone (coding guide, reference material).
if exist "%HERE%docs" (
  if exist "%EMACS_D%\docs" (
    echo    backing up docs -^> .backups\%STAMP%\docs
    move "%EMACS_D%\docs" "%BACKUP_DIR%\docs" >nul
  )
  echo ^>^> Installing docs to %EMACS_D%\docs
  if not exist "%EMACS_D%\docs" mkdir "%EMACS_D%\docs"
  xcopy "%HERE%docs\." "%EMACS_D%\docs\" /E /I /H /Y >nul
)

:: Install standalone tools (MicroEmacs, mg) if bundled.
if exist "%HERE%tools" (
  set "BIN_DIR=%EMACS_D%\bin"
  echo ^>^> Installing tools to !BIN_DIR!
  if not exist "!BIN_DIR!" mkdir "!BIN_DIR!"
  xcopy "%HERE%tools\." "!BIN_DIR!\" /E /I /H /Y >nul
)

:: Report on optional Emacs source.
dir "%HERE%emacs-*.tar.xz" 2>nul >nul
if !errorlevel! equ 0 (
  echo.
  echo ^>^> Bundled Emacs source found.
  echo    Extract and build using MSYS2 or Cygwin.
)

:: Summarise backups.
dir "%BACKUP_DIR%" /b 2>nul | findstr /r . >nul
if !errorlevel! equ 0 (
  echo ^>^> Previous state backed up to %EMACS_D%\.backups\%STAMP%\
)

echo.
echo Done. Launch Emacs; *Messages* should report:
echo   my/offline-packages=t  dir=%MY_HOME%\elpa-mirror-emacs-...
echo.
echo Note: If tar failed above with "Cannot connect to" a drive letter,
echo a stray GNU tar was used. Extract the mirror with Windows' bsdtar:
echo   "%SystemRoot%\System32\tar.exe" -xzf "%HERE%elpa-mirror-*.tar.gz" -C "%MY_HOME%"
