int main(void) {
    // left note
    return 0;
}
