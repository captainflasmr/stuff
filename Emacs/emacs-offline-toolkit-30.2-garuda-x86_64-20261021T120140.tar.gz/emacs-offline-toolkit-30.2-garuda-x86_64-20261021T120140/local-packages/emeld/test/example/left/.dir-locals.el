;;; Directory Local Variables
;;; See Info node `(emacs) Directory Variables' for more information.

((nil
  (emeld-filter-groups
   ("Backups" t "#*#" ".#*" "~*" "*~" "*.orig" "*.bak" "*.swp")
   ("OS metadata" t ".DS_Store" "._*" ".Spotlight-V100" ".Trashes"
    "Thumbs.db" "Desktop.ini")
   ("Version Control" t ".git" ".svn" ".hg" "CVS" "_darcs" ".bzr"
    "_MTN" ".fslckout" "_FOSSIL_" ".fos" ".osc")
   ("Binaries" t "*.pyc" "*.a" "*.obj" "*.o" "*.so" "*.la" "*.lib"
    "*.dll" "*.exe")
   ("Media" nil "*.jpg" "*.gif" "*.png" "*.bmp" "*.wav" "*.mp3"
    "*.ogg" "*.flac" "*.avi" "*.mpg" "*.xcf" "*.xpm"))))
