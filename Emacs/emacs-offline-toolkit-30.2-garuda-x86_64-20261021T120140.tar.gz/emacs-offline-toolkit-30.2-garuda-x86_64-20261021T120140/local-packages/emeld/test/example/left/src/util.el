;;; util.el --- shared helpers

(provide 'util)
