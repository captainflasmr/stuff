int main(void) {
    // right note
    return 0;
}
