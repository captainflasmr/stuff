# org-ibullets.el - Display Emacs org-mode heading stars as UTF-8 bullets
![Build Status](https://github.com/jamescherti/org-ibullets.el/actions/workflows/melpazoid.yml/badge.svg)
![License](https://img.shields.io/github/license/jamescherti/org-ibullets.el)
![](https://jamescherti.com/misc/made-for-gnu-emacs.svg)

The **[org-ibullets](https://github.com/jamescherti/org-ibullets.el)** Emacs package provides a minor mode that enhances `org-mode` by displaying headings bullets as UTF-8 characters.

![screenshot](https://github.com/jamescherti/org-ibullets.el/raw/main/.images/screenshot.png)

## Features

- Replace standard Org mode bullets with visually appealing UTF-8 characters.
- Customizable bullet list for different heading levels.
- Supports inline tasks with appropriate bullet representation.
- Configurable face for bullets to match your theme.

## Installation

### Installing with use-package and :vc (Emacs version >= 30)

To install **org-ibullets** using the built-in `:vc` keyword:
```emacs-lisp
(use-package org-ibullets
  :vc (:url "https://github.com/jamescherti/org-ibullets.el"
       :rev :newest))
  :commands org-ibullets-mode
  :hook (org-mode . org-ibullets-mode))
```

### Install with straight (Emacs version < 30)

To install **org-ibullets** with `straight.el`:

1. If it hasn't already been done, [add the straight.el bootstrap code](https://github.com/radian-software/straight.el?tab=readme-ov-file#getting-started) to your init file.
2. Add the following code to the Emacs init file:

```emacs-lisp
(use-package org-ibullets
  :straight (org-ibullets
             :type git
             :host github
             :repo "jamescherti/org-ibullets.el")
  :commands org-ibullets-mode
  :hook (org-mode . org-ibullets-mode))
```

### Manual installation

To install **org-ibullets**, clone the repository or download the `.el` file and add it to your Emacs load path, then add to your .emacs:

```emacs-lisp
(require 'org-ibullets)
(add-hook 'org-mode-hook (lambda () (org-ibullets-mode 1)))
```

## FAQ / Troubleshooting

### What is the difference with org-bullets?

The `org-ibullets` package is based on the [MELPA org-bullets fork](https://github.com/integral-dw/org-bullets), which in turn is derived from the unmaintained [org-bullets](https://github.com/sabof/org-bullets).

Here are the improvements `org-ibullets`:
- **Optimizations**: `org-ibullets` has been optimized to eliminate redundant computations, such as repeated calls to functions.
- **No syntax warnings**: Unlike `org-bullets`, which may generate syntax or font-lock warnings in certain Emacs configurations, `org-ibullets` resolves these issues.
- **Various enhancements**: Improved readability and reduced redundancy, fixed warnings, included `-*- lexical-binding: t; -*-`, added Melpazoid tests, implemented additional tests, and resolved fontification issues.

### How can I further improve its speed?

I recommend adding the following to your Emacs init:

```emacs-lisp
(setq inhibit-compacting-font-caches t)
```

This variable also holds further information regarding what I believe is the cause of the problem.

## Links

- [org-ibullets.el @GitHub](https://github.com/jamescherti/org-ibullets.el)

Other Emacs packages by the same author:
- [minimal-emacs.d](https://github.com/jamescherti/minimal-emacs.d): This repository hosts a minimal Emacs configuration designed to serve as a foundation for your vanilla Emacs setup and provide a solid base for an enhanced Emacs experience.
- [outline-indent.el](https://github.com/jamescherti/outline-indent.el): An Emacs package that provides a minor mode that enables code folding and outlining based on indentation levels for various indentation-based text files, such as YAML, Python, and other indented text files.
- [vim-tab-bar.el](https://github.com/jamescherti/vim-tab-bar.el): Make the Emacs tab-bar Look Like Vim's Tab Bar.
- [easysession.el](https://github.com/jamescherti/easysession.el): Easysession is lightweight Emacs session manager that can persist and restore file editing buffers, indirect buffers/clones, Dired buffers, the tab-bar, and the Emacs frames (with or without the Emacs frames size, width, and height).
- [elispcomp](https://github.com/jamescherti/elispcomp): A command line tool that allows compiling Elisp code directly from the terminal or from a shell script. It facilitates the generation of optimized .elc (byte-compiled) and .eln (native-compiled) files.
- [tomorrow-night-deepblue-theme.el](https://github.com/jamescherti/tomorrow-night-deepblue-theme.el): The Tomorrow Night Deepblue Emacs theme is a beautiful deep blue variant of the Tomorrow Night theme, which is renowned for its elegant color palette that is pleasing to the eyes. It features a deep blue background color that creates a calming atmosphere. The theme is also a great choice for those who miss the blue themes that were trendy a few years ago.
- [Ultyas](https://github.com/jamescherti/ultyas/): A command-line tool designed to simplify the process of converting code snippets from UltiSnips to YASnippet format.
- [dir-config.el](https://github.com/jamescherti/dir-config.el): Automatically find and evaluate .dir-config.el Elisp files to configure directory-specific settings.
- [flymake-bashate.el](https://github.com/jamescherti/flymake-bashate.el): A package that provides a Flymake backend for the bashate Bash script style checker.
- [flymake-ansible-lint.el](https://github.com/jamescherti/flymake-ansible-lint.el): An Emacs package that offers a Flymake backend for `ansible-lint`.
- [stripspace.el](https://github.com/jamescherti/stripspace.el): Ensure Emacs Automatically removes trailing whitespace before saving a buffer, with an option to preserve the cursor column.
- [persist-text-scale.el](https://github.com/jamescherti/persist-text-scale.el): Ensure that all adjustments made with text-scale-increase and text-scale-decrease are persisted and restored across sessions.
- [pathaction.el](https://github.com/jamescherti/pathaction.el): Execute the pathaction command-line tool from Emacs. The pathaction command-line tool enables the execution of specific commands on targeted files or directories. Its key advantage lies in its flexibility, allowing users to handle various types of files simply by passing the file or directory as an argument to the pathaction tool. The tool uses a .pathaction.yaml rule-set file to determine which command to execute. Additionally, Jinja2 templating can be employed in the rule-set file to further customize the commands.
- [kirigami.el](https://github.com/jamescherti/kirigami.el): The *kirigami* Emacs package offers a unified interface for opening and closing folds across a diverse set of major and minor modes in Emacs, including `outline-mode`, `outline-minor-mode`, `outline-indent-minor-mode`, `org-mode`, `markdown-mode`, `vdiff-mode`, `vdiff-3way-mode`, `hs-minor-mode`, `hide-ifdef-mode`, `origami-mode`, `yafolding-mode`, `folding-mode`, and `treesit-fold-mode`. With Kirigami, folding key bindings only need to be configured **once**. After that, the same keys work consistently across all supported major and minor modes, providing a unified and predictable folding experience.
- [buffer-guardian.el](https://github.com/jamescherti/buffer-guardian.el): Automatically saves Emacs buffers without requiring manual intervention. By default, it triggers a save when the user switches to another buffer, switches to another window or frame, Emacs loses focus, or the minibuffer is opened. Beyond standard file buffers, *buffer-guardian* also manages specialized editing buffers such as *org-src* and *edit-indirect*. Additional features, disabled by default, include periodic or idle-time saving of all buffers, automatic exclusion of remote, nonexistent, or large files, and support for custom exclusion rules via regular expressions or predicate functions.
