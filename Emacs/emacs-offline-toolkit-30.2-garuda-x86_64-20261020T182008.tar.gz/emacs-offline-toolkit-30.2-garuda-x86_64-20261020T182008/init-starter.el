;; -*- lexical-binding: t; -*-
;;
;; Starter customisations for Emacs 30.2 — optional, unused by default.
;;
;; Distilled from the upstream author's live init.el. Supplements (does not
;; replace) the bundled init.el, which already installs the ELPA mirror,
;; bootstraps ~/.emacs.d/local-packages, and loads the Emacs-vanilla base.
;;
;; Coding-oriented blocks (eglot, dape, emeld-sidebar, demap, protobuf-mode, etc.)
;; live in starters/coding.el to avoid duplication — load both:
;;   (load (expand-file-name "init-starter" user-emacs-directory) t t)
;;   (load (expand-file-name "init-starter-coding" user-emacs-directory) t t)
;;
;; To try it, either:
;;   (a) append this line to ~/.emacs.d/init.el:
;;         (load (expand-file-name "init-starter" user-emacs-directory) t t)
;;   (b) or cherry-pick blocks into your own init.el.
;;
;; Assumes `use-package' is installed (bundled via the offline mirror, and
;; also built in to Emacs 29+). `:ensure' is left off deliberately — the
;; bundled init.el already `my/ensure-package'd everything from
;; packages/emacs-30.2.el.

(require 'use-package)
(setq use-package-always-ensure nil)

;;
;; -> themes (pick one to enable at startup, or just M-x load-theme)
;;
(use-package doom-themes)
(use-package ef-themes)
(use-package modus-themes)
(use-package gruvbox-theme)
(use-package timu-caribbean-theme)

(use-package timu-spacegrey-theme
  :config
  (setq timu-spacegrey-scale-org-document-title 1.8)
  (setq timu-spacegrey-scale-org-document-info 1.4)
  (setq timu-spacegrey-scale-org-level-1 1.8)
  (setq timu-spacegrey-scale-org-level-2 1.4)
  (setq timu-spacegrey-scale-org-level-3 1.2))

(use-package timu-rouge-theme
  :config
  (setq timu-rouge-mode-line-border t)
  (setq timu-rouge-scale-org-document-title 1.8)
  (setq timu-rouge-scale-org-document-info 1.4)
  (setq timu-rouge-scale-org-level-1 1.8)
  (setq timu-rouge-scale-org-level-2 1.4)
  (setq timu-rouge-scale-org-level-3 1.2))

;; (load-theme 'ef-dark t)          ; uncomment to pick one

;;
;; -> mode hints for file types
;;
(use-package yaml-mode)
(use-package csv-mode)
(use-package i3wm-config-mode)

(use-package web-mode
  :mode "\\.cshtml?\\'"
  :hook (html-mode . web-mode)
  :bind (:map web-mode-map ("M-;" . nil)))

(use-package plantuml-mode
  :mode ("\\.puml\\'" "\\.plantuml\\'" "\\.iuml\\'")
  :custom
  (plantuml-jar-path "~/.emacs.d/local-packages/ox-plantuml-gantt/plantuml.jar")
  (plantuml-default-exec-mode 'jar)
  (plantuml-output-type "png"))

(add-to-list 'auto-mode-alist '("\\.yml\\'" . yaml-mode))
(add-to-list 'auto-mode-alist '("\\.cshtml\\'" . html-mode))
(add-to-list 'auto-mode-alist '("/sway/config\\'" . i3wm-config-mode))
(add-to-list 'auto-mode-alist '("/sway/.*config.*/" . i3wm-config-mode))

;;
;; -> async dired
;;
(use-package async
  :config
  (require 'dired-async)
  (dired-async-mode 1))

;;
;; -> vlf — view and edit huge files in batches (GNU ELPA)
;;
;; VLF reads a file chunk by chunk, so files larger than RAM open without
;; swapping. Loading `vlf-setup' hooks the built-in large-file prompt;
;; `vlf-application' decides when VLF is used:
;;   ask       (default) offer VLF past `large-file-warning-threshold'
;;   dont-ask  open large files in VLF automatically
;;   always    use VLF for every file
;;   nil       never automatic — open explicitly with M-x vlf
;;
;; Dired gains a `V' binding (dired-vlf) once vlf-setup is loaded.
;; Inside a VLF buffer C-c C-v is the prefix: n/p next/prev batch,
;; s/r search forward/backward, o occur index, l goto-line, j jump to
;; a batch, % query-replace across the whole file.
;;
;; Other useful options:
;;   (setq vlf-tune-enabled nil)         ; don't auto-tune batch size
;;   (setq vlf-tune-max (* 4 1024 1024)) ; cap tuned batch size at 4 MB
;;   (setq vlf-save-in-place 'ask)       ; write via temp file on resize
(use-package vlf
  :commands vlf
  :init
  (require 'vlf-setup)
  :custom
  (vlf-application 'dont-ask))

;;
;; -> selected-window-accent-mode — highlights the active window's borders
;;
(use-package selected-window-accent-mode
  :config (selected-window-accent-mode 1)
  :custom
  (selected-window-accent-fringe-thickness 10)
  (selected-window-accent-mode-style 'default)
  (selected-window-accent-percentage-darken 20)
  (selected-window-accent-percentage-desaturate 20)
  (selected-window-accent-tab-accent t)
  (selected-window-accent-smart-borders nil))

(define-key my-overrides-mode-map (kbd "C-c w") selected-window-accent-map)

;;
;; -> simply-annotate — overlay notes on any file
;;
(use-package simply-annotate
  :hook (find-file-hook . simply-annotate-mode)
  :config
  (define-key my-overrides-mode-map (kbd "M-s") simply-annotate-command-map)
  (setq simply-annotate-inline-position 'above)
  (setq simply-annotate-tint-amount 20)
  (setq simply-annotate-inline-pointer-above "┗━▶")
  (setq simply-annotate-inline-pointer-after "┏━▶")
  (setq simply-annotate-database-strategy 'both)
  (setq simply-annotate-inline-default t))


;;
;; -> doc-view-follow — sync pages between windows showing the same document
;; (doc-view-mode / pdf-view-mode). Split the window and both panes navigate
;; in lockstep — handy for a side-by-side "book view".
;;
(use-package doc-view-follow
  :config (global-doc-view-follow-mode 1))


;;
;; -> package-lint — M-x package-lint-current-buffer to audit your own packages
;;
(use-package package-lint)

;;
;; -> ollama-buddy — AI chat against a local ollama server or cloud providers
;; Needs `ollama serve' running locally, or cloud API keys in auth-source.
;;
(use-package ollama-buddy
  :bind
  ("C-c o" . ollama-buddy-role-transient-menu)
  ("C-c O" . ollama-buddy-transient-menu)
  :config
  (setq ollama-buddy-default-model "deepseek-v3.1:671b-cloud")
  (setq ollama-buddy-max-history-length 999))

;;
;; -> diff-minimap — minimap sidebar showing diff-hl regions
;;
(use-package diff-minimap :demand t)

;;
;; -> transmute — media management utilities (image, video, audio)
;;
;; On GNU/Linux, make a bundled exiftool under ~/.emacs.d/bin/exiftool
;; discoverable by `executable-find' (transmute treats exiftool as a hard
;; dependency with no fallback, unlike trash-put). Mirrors the Linux PATH
;; block in init-starter-coding.el.
(when (and (eq system-type 'gnu/linux)
           (file-directory-p
            (expand-file-name "bin/exiftool" user-emacs-directory)))
  (let ((p (expand-file-name "bin/exiftool" user-emacs-directory)))
    (setenv "PATH" (concat p path-separator (getenv "PATH")))
    (add-to-list 'exec-path p)))

(use-package transmute
  :demand t
  :config
  (define-key my-overrides-mode-map (kbd "C-c I") #'transmute-menu)
  (with-eval-after-load 'image-dired
    (transmute-setup-thumbnail-keys)))

;;
;; -> org-bootstrap-publish — generate Bootstrap 5 sites from Org files
;;
(use-package org-bootstrap-publish :demand t)

;;
;; -> org-ibullets — render Org heading stars as UTF-8 bullets
;;
;; Vendored under local-packages/org-ibullets; no ELPA archive needed.
;; Disabling font-cache compaction keeps the composed bullets fast.
;;
(unless (and (boundp 'my/org-ibullets-configured)
             my/org-ibullets-configured)
  (use-package org-ibullets
    :ensure nil
    :load-path ("offline-packages/local-packages/org-ibullets"
                "local-packages/org-ibullets")
    :commands org-ibullets-mode
    :init
    (setq my/org-ibullets-configured t
          inhibit-compacting-font-caches t)
    :hook (org-mode . org-ibullets-mode)))

;;
;; -> org-present — present an Org buffer, one top-level heading per slide
;;
;; Vendored under local-packages/org-present; no ELPA archive needed.
;; C-c s p starts, left/right navigate, C-c C-q quits, C-c C-w toggles
;; read-only.
;;
(unless (and (boundp 'my/org-present-configured)
             my/org-present-configured)
  (use-package org-present
    :ensure nil
    :load-path ("offline-packages/local-packages/org-present"
                "local-packages/org-present")
    :commands org-present
    :init
    (setq my/org-present-configured t)
    (with-eval-after-load 'org
      (define-key org-mode-map (kbd "C-c s p") #'org-present))
    :config
    (add-hook 'org-present-mode-hook
              (lambda ()
                (org-present-big)
                (org-display-inline-images)
                ;; Cache the cursor before hiding it: `org-present-read-only'
                ;; also records `cursor-type', so calling it first prevents it
                ;; from clobbering the cached value with nil.
                (org-present-read-only)
                (org-present-hide-cursor)))
    (add-hook 'org-present-mode-quit-hook
              (lambda ()
                (org-present-small)
                (org-remove-inline-images)
                ;; Restore a visible cursor even if the cache was empty.
                (setq-local cursor-type (or org-present-cursor-cache t))
                (org-present-show-cursor)
                (org-present-read-write)))))

;;
;; -> quality-of-life
;;
(setq recentf-max-menu-items 40
      recentf-max-saved-items 40
      max-mini-window-height 8
      tab-bar-auto-width-max '((120) 20))

(when (fboundp 'repeat-mode) (repeat-mode 1))

(use-package chess)

(setq chess-images-separate-frame nil)
(setq chess-images-default-size 64)

(when (eq system-type 'gnu/linux)
  (define-key my-jump-keymap (kbd "c") (lambda () (interactive) (find-file "~/DCIM/content/aaa--calendar.org")))
  (define-key my-jump-keymap (kbd "m") (lambda () (interactive) (find-file "~/DCIM/Camera")))
  (define-key my-jump-keymap (kbd "j") (lambda () (interactive) (find-file "~/DCIM/content/aaa--todo.org")))
  (define-key my-jump-keymap (kbd "n") (lambda () (interactive) (find-file "~/DCIM/Screenshots")))
  (define-key my-jump-keymap (kbd "w") (lambda () (interactive) (find-file "~/DCIM/content/")))
  (setq diary-file "~/DCIM/content/diary.org"))

(use-package gnuplot)
