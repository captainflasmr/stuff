;;; dired-image-thumbnail-test.el --- ERT suite for dired-image-thumbnail -*- lexical-binding: t; -*-

;; Copyright (C) 2025 James Dyer

;; Author: James Dyer
;; Keywords: multimedia, files, dired

;; This file is not part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Batch tests for `dired-image-thumbnail'.  Run with:
;;
;;   emacs -Q --batch -L .. -l dired-image-thumbnail-test.el \
;;         -f ert-run-tests-batch-and-exit
;;
;; or via test/run-tests.sh.

;;; Code:

(require 'ert)
(require 'cl-lib)
(require 'dired-image-thumbnail)

;;; Utilities

(defmacro dit--with-temp-dir (dir-var &rest body)
  "Bind DIR-VAR to a fresh temporary directory and run BODY, cleaning up."
  (declare (indent 1))
  `(let ((,dir-var (file-name-as-directory (make-temp-file "dit-" t))))
     (unwind-protect
         (progn ,@body)
       (when (file-directory-p ,dir-var)
         (delete-directory ,dir-var t)))))

;;; Sorting and filtering

(ert-deftest dit-parse-size ()
  (should (= (dired-image-thumbnail--parse-size "1k") 1024))
  (should (= (dired-image-thumbnail--parse-size "2m") (* 2 1048576)))
  (should (= (dired-image-thumbnail--parse-size "1g") 1073741824))
  (should (= (dired-image-thumbnail--parse-size "500") 500)))

(ert-deftest dit-sort-images-name ()
  (let ((dired-image-thumbnail--sort-by 'name)
        (dired-image-thumbnail--sort-order 'ascending))
    (should (equal (dired-image-thumbnail--sort-images
                    '("/tmp/b.jpg" "/tmp/A.jpg" "/tmp/c.jpg"))
                   '("/tmp/A.jpg" "/tmp/b.jpg" "/tmp/c.jpg"))))
  (let ((dired-image-thumbnail--sort-by 'name)
        (dired-image-thumbnail--sort-order 'descending))
    (should (equal (dired-image-thumbnail--sort-images
                    '("/tmp/b.jpg" "/tmp/A.jpg"))
                   '("/tmp/b.jpg" "/tmp/A.jpg")))))

(ert-deftest dit-sort-tolerates-vanished-files ()
  (let ((dired-image-thumbnail--sort-by 'date)
        (dired-image-thumbnail--sort-order 'ascending))
    (should (equal (dired-image-thumbnail--sort-images
                    (list "/tmp/dit-missing-sort.jpg"))
                   (list "/tmp/dit-missing-sort.jpg")))))

(ert-deftest dit-filter-by-name ()
  (let ((dired-image-thumbnail--filter-name "foo")
        (dired-image-thumbnail--filter-size-min nil)
        (dired-image-thumbnail--filter-size-max nil))
    (should (equal (dired-image-thumbnail--filter-images
                    '("/tmp/foo.jpg" "/tmp/bar.jpg"))
                   '("/tmp/foo.jpg")))))

(ert-deftest dit-filter-by-size ()
  (dit--with-temp-dir dir
    (let ((small (expand-file-name "s.jpg" dir))
          (big (expand-file-name "b.jpg" dir))
          (dired-image-thumbnail--filter-name nil)
          (dired-image-thumbnail--filter-size-min 50)
          (dired-image-thumbnail--filter-size-max nil))
      (write-region "aaaa" nil small nil 'silent)
      (write-region (make-string 100 ?x) nil big nil 'silent)
      (should (equal (dired-image-thumbnail--filter-images (list small big))
                     (list big))))))

(ert-deftest dit-filter-drops-vanished-files ()
  (let ((dired-image-thumbnail--filter-name nil)
        (dired-image-thumbnail--filter-size-min 1)
        (dired-image-thumbnail--filter-size-max 1000))
    (should (null (dired-image-thumbnail--filter-images
                   (list "/tmp/dit-missing-filter.jpg"))))))

;;; Property scanning helpers

(ert-deftest dit-property-helpers ()
  (with-temp-buffer
    (insert "  ")
    (add-text-properties (point-min) (1+ (point-min))
                         '(original-file-name "a"))
    (add-text-properties (1+ (point-min)) (point-max)
                         '(original-file-name "b"))
    (should (equal (dired-image-thumbnail--property-positions 'original-file-name)
                   (list (point-min) (1+ (point-min)))))
    (should (equal (dired-image-thumbnail--property-values 'original-file-name)
                   '("a" "b")))
    (should (equal (dired-image-thumbnail--position-of-file "b")
                   (1+ (point-min))))
    (should (null (dired-image-thumbnail--position-of-file "z")))))

;;; State helpers

(ert-deftest dit-image-index ()
  (with-temp-buffer
    (setq dired-image-thumbnail--current-images '("/a.jpg" "/b.jpg" "/c.jpg"))
    (dired-image-thumbnail--rebuild-image-index)
    (should (= (gethash "/a.jpg" dired-image-thumbnail--image-index) 0))
    (should (= (gethash "/c.jpg" dired-image-thumbnail--image-index) 2))
    (should (null (gethash "/z.jpg" dired-image-thumbnail--image-index)))))

(ert-deftest dit-drop-from-state ()
  (with-temp-buffer
    (setq dired-image-thumbnail--current-images '("/a.jpg" "/b.jpg"))
    (setq dired-image-thumbnail--all-images '("/a.jpg" "/b.jpg"))
    (dired-image-thumbnail--rebuild-image-index)
    (dired-image-thumbnail--drop-from-state "/a.jpg")
    (should (equal dired-image-thumbnail--current-images '("/b.jpg")))
    (should (equal dired-image-thumbnail--all-images '("/b.jpg")))
    (should (= (gethash "/b.jpg" dired-image-thumbnail--image-index) 0))))

(ert-deftest dit-header-shows-image-count ()
  (with-temp-buffer
    (image-dired-thumbnail-mode)
    (setq dired-image-thumbnail--all-images '("/a.jpg" "/b.jpg" "/c.jpg")
          dired-image-thumbnail--current-images '("/a.jpg" "/b.jpg" "/c.jpg")
          dired-image-thumbnail--dired-buffer nil)
    (dired-image-thumbnail--rebuild-image-index)
    (let ((dired-image-thumbnail--identify-cached-command nil))
      (let ((result (dired-image-thumbnail--format-properties-string
                     (lambda (&rest _) "orig") nil "/b.jpg" "99/99" nil nil)))
        (should (string-match-p "\\[3 images\\]" result))
        (should-not (string-match-p "2/3" result)))
      (setq dired-image-thumbnail--current-images '("/a.jpg" "/b.jpg")
            dired-image-thumbnail--filter-name "a")
      (dired-image-thumbnail--rebuild-image-index)
      (let ((result (dired-image-thumbnail--format-properties-string
                     (lambda (&rest _) "orig") nil "/b.jpg" "99/99" nil nil)))
        (should (string-match-p "\\[2/3 images\\]" result))))))

(ert-deftest dit-mode-line-thumb-size ()
  (with-temp-buffer
    (setq-local dired-image-thumbnail--display-size 160)
    (should (string-match-p "\\[160px\\]"
                            (dired-image-thumbnail--mode-line-size-string)))
    (setq-local dired-image-thumbnail--display-size nil)
    (setq-local image-dired-thumb-size 128)
    (should (string-match-p "\\[128px\\]"
                            (dired-image-thumbnail--mode-line-size-string)))))

(ert-deftest dit-mode-line-segments-use-mode-line-face ()
  "Quality and size segments must follow the theme's mode-line colours.
They use `dired-image-thumbnail-mode-line-info', which sets no
foreground or background of its own, so the mode line supplies
them (including `mode-line-inactive' in unselected windows)."
  (should (eq (face-attribute 'dired-image-thumbnail-mode-line-info
                              :foreground nil t)
              'unspecified))
  (should (eq (face-attribute 'dired-image-thumbnail-mode-line-info
                              :background nil t)
              'unspecified))
  (with-temp-buffer
    (setq-local dired-image-thumbnail--display-quality 'faster)
    (let ((quality (dired-image-thumbnail--mode-line-quality-string)))
      (should (string-match-p "\\[Q4 faster\\]" quality))
      (should (eq (get-text-property 0 'face quality)
                  'dired-image-thumbnail-mode-line-info)))
    (setq-local dired-image-thumbnail--display-size 160)
    (let ((size (dired-image-thumbnail--mode-line-size-string)))
      (should (string-match-p "\\[160px\\]" size))
      (should (eq (get-text-property 0 'face size)
                  'dired-image-thumbnail-mode-line-info)))))

(ert-deftest dit-setup-mode-line-inserts-segments ()
  (with-temp-buffer
    (image-dired-thumbnail-mode)
    (kill-local-variable 'mode-line-format)
    (setq-local mode-line-format
                '("%e" mode-line-front-space mode-line-buffer-identification
                  mode-line-end-spaces))
    (dired-image-thumbnail--setup-mode-line)
    (should (memq 'dired-image-thumbnail--mode-line-quality mode-line-format))
    (should (memq 'dired-image-thumbnail--mode-line-size mode-line-format))
    (should (eq (cadr (memq 'mode-line-buffer-identification mode-line-format))
                'dired-image-thumbnail--mode-line-quality))
    (should (eq (cadr (memq 'dired-image-thumbnail--mode-line-quality
                            mode-line-format))
                'dired-image-thumbnail--mode-line-size))))

(ert-deftest dit-count-thumbnail-work ()
  (with-temp-buffer
    (setq dired-image-thumbnail--current-images '("/tmp/dit-nonexistent-xyz.jpg"))
    (setq dired-image-thumbnail-square-thumbnails nil)
    (let ((state (dired-image-thumbnail--make-work-state)))
      (dired-image-thumbnail--count-thumbnail-work state)
      (should (= (dired-image-thumbnail--work-state-needed state) 1))
      (should (dired-image-thumbnail--work-state-progress state)))))

(ert-deftest dit-work-state ()
  (let ((state (dired-image-thumbnail--make-work-state)))
    (should (= (dired-image-thumbnail--work-state-needed state) 0))
    (cl-incf (dired-image-thumbnail--work-state-needed state))
    (should (= (dired-image-thumbnail--work-state-needed state) 1))))

(ert-deftest dit-ensure-thumb-geometry ()
  (with-temp-buffer
    (setq-local image-dired-thumb-size nil)
    (setq-local image-dired-thumb-relief nil)
    (setq-local image-dired-thumb-margin nil)
    (setq-local image-dired-thumbs-per-row nil)
    (dired-image-thumbnail--ensure-thumb-geometry)
    (should (numberp image-dired-thumb-size))
    (should (numberp image-dired-thumb-relief))
    (should (numberp image-dired-thumb-margin))
    (should (numberp image-dired-thumbs-per-row))))

(ert-deftest dit-base-thumb-size ()
  (should (numberp (dired-image-thumbnail--base-thumb-size))))

(ert-deftest dit-cursor-copy-preserves-global ()
  (let ((saved face-remapping-alist))
    (unwind-protect
        (progn
          (setq face-remapping-alist
                '((mode-line . highlight)
                  (cursor . (:background "red"))))
          (with-temp-buffer
            (image-dired-thumbnail-mode)
            (dired-image-thumbnail--setup-cursor))
          (should (equal face-remapping-alist
                         '((mode-line . highlight)
                           (cursor . (:background "red"))))))
      (setq face-remapping-alist saved))))

(ert-deftest dit-auto-display-p ()
  (with-temp-buffer
    (image-dired-thumbnail-mode)
    (setq-local dired-image-thumbnail-auto-display-on-navigate nil)
    (should (not (dired-image-thumbnail--auto-display-p)))))

;;; Per-directory settings

(ert-deftest dit-filter-plist-p ()
  (should (dired-image-thumbnail--filter-plist-p nil))
  (should (dired-image-thumbnail--filter-plist-p '(:name "x")))
  (should (dired-image-thumbnail--filter-plist-p
           '(:name "x" :size-min 1 :size-max 100)))
  (should (not (dired-image-thumbnail--filter-plist-p '(:name 42))))
  (should (not (dired-image-thumbnail--filter-plist-p '(:name)))))

(ert-deftest dit-valid-dir-setting-p ()
  (should (dired-image-thumbnail--valid-dir-setting-p
           'dired-image-thumbnail-sort-by 'date))
  (should (not (dired-image-thumbnail--valid-dir-setting-p
                'dired-image-thumbnail-sort-by 'dimensions)))
  (should (not (dired-image-thumbnail--valid-dir-setting-p
                'dired-image-thumbnail-display-quality 'bogus)))
  (should (dired-image-thumbnail--valid-dir-setting-p
           'dired-image-thumbnail-default-filter '(:name "foo" :size-min 1)))
  (should (dired-image-thumbnail--valid-dir-setting-p
           'dired-image-thumbnail-default-display-size 160))
  (should (dired-image-thumbnail--valid-dir-setting-p
           'dired-image-thumbnail-default-display-size nil))
  (should (not (dired-image-thumbnail--valid-dir-setting-p
                'dired-image-thumbnail-default-display-size 16)))
  (should (not (dired-image-thumbnail--valid-dir-setting-p
                'dired-image-thumbnail-default-display-size 1024)))
  (should (not (dired-image-thumbnail--valid-dir-setting-p
                'dired-image-thumbnail-default-display-size "160"))))

(ert-deftest dit-apply-dir-settings-display-size ()
  (dit--with-temp-dir dir
    (dired-image-thumbnail--write-dir-locals
     dir '((dired-image-thumbnail-default-display-size . 192)))
    (with-temp-buffer
      (setq-local dired-image-thumbnail--source-dir dir)
      (let ((dired-image-thumbnail-default-display-size nil)
            (dired-image-thumbnail--display-size nil))
        (dired-image-thumbnail--apply-dir-settings)
        (should (= dired-image-thumbnail--display-size 192)))))
  (dit--with-temp-dir dir
    (with-temp-buffer
      (setq-local dired-image-thumbnail--source-dir dir)
      (let ((dired-image-thumbnail-default-display-size 160)
            (dired-image-thumbnail--display-size nil))
        (dired-image-thumbnail--apply-dir-settings)
        (should (= dired-image-thumbnail--display-size 160))))))

(ert-deftest dit-dir-locals-roundtrip ()
  (dit--with-temp-dir dir
    (dired-image-thumbnail--write-dir-locals
     dir '((dired-image-thumbnail-sort-by . date)))
    (should (equal (dired-image-thumbnail--read-dir-settings dir)
                   '((dired-image-thumbnail-sort-by . date))))
    (let ((enable-local-variables nil))
      (should (null (dired-image-thumbnail--read-dir-settings dir))))))

(ert-deftest dit-dir-locals-preserves-other-entries ()
  (dit--with-temp-dir dir
    (with-temp-file (expand-file-name ".dir-locals.el" dir)
      (prin1 '((nil . ((fill-column . 72)))) (current-buffer)))
    (dired-image-thumbnail--write-dir-locals
     dir '((dired-image-thumbnail-sort-by . date)))
    (let* ((all (with-temp-buffer
                  (insert-file-contents (expand-file-name ".dir-locals.el" dir))
                  (read (current-buffer))))
           (entry (cdr (assq nil all))))
      (should (= (cdr (assq 'fill-column entry)) 72))
      (should (eq (cdr (assq 'dired-image-thumbnail-sort-by entry)) 'date)))))

;;; Dimension querying

(ert-deftest dit-identify-guard ()
  (with-temp-buffer
    (let ((dired-image-thumbnail--dimension-cache (make-hash-table :test 'equal))
          (dired-image-thumbnail--dimension-pending (make-hash-table :test 'equal))
          (dired-image-thumbnail--identify-cached-command nil))
      (should (equal (dired-image-thumbnail--get-image-dimensions "/tmp/nope.jpg")
                     '(0 . 0)))
      (should (zerop (hash-table-count
                      dired-image-thumbnail--dimension-pending))))))

;;; Display-buffer rule tagging

(ert-deftest dit-display-buffer-tagging ()
  (let ((saved-entries dired-image-thumbnail--display-buffer-entries)
        (saved-layout dired-image-thumbnail-window-layout)
        (saved-ratio dired-image-thumbnail-window-ratio)
        (saved-alist display-buffer-alist))
    (unwind-protect
        (progn
          (setq dired-image-thumbnail-window-layout 'left-right)
          (setq dired-image-thumbnail-window-ratio 0.6)
          (setq display-buffer-alist '(("\\*image-dired\\*" . user-rule)))
          (dired-image-thumbnail-setup-display-buffer)
          (should (assoc "\\*image-dired\\*" display-buffer-alist))
          (should (= 2 (length dired-image-thumbnail--display-buffer-entries)))
          (dired-image-thumbnail-setup-display-buffer)
          (should (= 2 (length dired-image-thumbnail--display-buffer-entries)))
          (should (assoc "\\*image-dired\\*" display-buffer-alist)))
      (setq dired-image-thumbnail--display-buffer-entries saved-entries)
      (setq dired-image-thumbnail-window-layout saved-layout)
      (setq dired-image-thumbnail-window-ratio saved-ratio)
      (setq display-buffer-alist saved-alist))))

;;; Multiple galleries

(ert-deftest dit-new-gallery-names-are-paired-and-unique ()
  (let* ((dir (file-name-as-directory (make-temp-file "dit-gallery-" t)))
         (stem (dired-image-thumbnail--gallery-stem dir))
         (names (dired-image-thumbnail--new-gallery-names dir)))
    (unwind-protect
        (progn
          (should (string-prefix-p dired-image-thumbnail--thumbnail-buffer-prefix
                                   (car names)))
          (should (string-prefix-p dired-image-thumbnail--display-buffer-prefix
                                   (cdr names)))
          (should (string-match-p (regexp-quote stem) (car names)))
          (should (string-match-p (regexp-quote stem) (cdr names)))
          ;; A second gallery for a different directory must not take
          ;; the same names.
          (should-not (equal names
                             (dired-image-thumbnail--new-gallery-names
                              (file-name-as-directory
                               (make-temp-file "dit-gallery-other-" t)))))
          ;; An existing gallery prefix forces a fresh, non-clashing stem.
          (let ((thumb (get-buffer-create (car names))))
            (unwind-protect
                (should (equal (dired-image-thumbnail--unique-gallery-stem stem)
                               (format "%s<2>" stem)))
              (kill-buffer thumb))))
      (delete-directory dir t))))

(ert-deftest dit-link-gallery-buffers-pairs-both-sides ()
  (let ((thumb (get-buffer-create "*image-dired: dit-link-test*"))
        (img (get-buffer-create
              "*image-dired-display-image: dit-link-test*")))
    (unwind-protect
        (progn
          (with-current-buffer thumb (image-dired-thumbnail-mode))
          (with-current-buffer img (dired-image-thumbnail-display-mode))
          (dired-image-thumbnail--link-gallery-buffers thumb img)
          (with-current-buffer thumb
            (should (equal image-dired-thumbnail-buffer (buffer-name thumb)))
            (should (equal image-dired-display-image-buffer (buffer-name img)))
            (should (eq dired-image-thumbnail--gallery-display-buffer img))
            (should (eq (dired-image-thumbnail--associated-display-buffer) img)))
          (with-current-buffer img
            (should (equal image-dired-display-image-buffer (buffer-name img)))
            (should (equal image-dired-thumbnail-buffer (buffer-name thumb)))
            (should (eq dired-image-thumbnail--gallery-thumbnail-buffer thumb))
            (should (eq (dired-image-thumbnail--associated-thumbnail-buffer)
                        thumb))))
      (kill-buffer thumb)
      (kill-buffer img))))

(ert-deftest dit-ensure-gallery-reuses-directory-gallery ()
  (dit--with-temp-dir dir
    (let* ((source (file-name-as-directory dir))
           (names (dired-image-thumbnail--new-gallery-names source))
           (thumb (get-buffer-create (car names)))
           (img (get-buffer-create (cdr names))))
      (unwind-protect
          (progn
            (with-current-buffer thumb
              (image-dired-thumbnail-mode)
              (setq dired-image-thumbnail--source-dir source)
              (setq dired-image-thumbnail--dired-buffer nil))
            (dired-image-thumbnail--link-gallery-buffers thumb img)
            ;; Revisiting the directory (without a live Dired buffer)
            ;; finds the existing gallery instead of creating a new one.
            (should (equal (dired-image-thumbnail--ensure-gallery nil source)
                           names))
            ;; A different directory gets different buffer names.
            (should-not (equal (dired-image-thumbnail--ensure-gallery
                                nil (file-name-as-directory
                                     (make-temp-file "dit-other-" t)))
                               names)))
        (kill-buffer thumb)
        (kill-buffer img)))))

(ert-deftest dit-apply-layout-preserves-visible-gallery ()
  (let* ((saved-layout dired-image-thumbnail-window-layout)
         (old-thumb (get-buffer-create "*image-dired: dit-old*"))
         (old-img (get-buffer-create
                   "*image-dired-display-image: dit-old*"))
         (new-thumb (get-buffer-create "*image-dired: dit-new*"))
         (new-img (get-buffer-create
                   "*image-dired-display-image: dit-new*"))
         (source-buf (get-buffer-create "*dit-gallery-source*"))
         (config (current-window-configuration)))
    (unwind-protect
        (progn
          (with-current-buffer old-thumb (image-dired-thumbnail-mode))
          (with-current-buffer old-img (dired-image-thumbnail-display-mode))
          (with-current-buffer new-thumb (image-dired-thumbnail-mode))
          (with-current-buffer new-img (dired-image-thumbnail-display-mode))
          (setq dired-image-thumbnail-window-layout 'thumb-only)
          (delete-other-windows)
          (set-window-buffer (selected-window) old-thumb)
          (let ((old-thumb-win (selected-window))
                (old-img-win (split-window-right)))
            (select-window old-img-win)
            (set-window-buffer old-img-win old-img)
            (let ((source-win (split-window-right)))
              (select-window source-win)
              (set-window-buffer source-win source-buf)
              (dired-image-thumbnail--apply-layout new-thumb new-img)
              ;; The old gallery is still visible; the new gallery was
              ;; built elsewhere instead of replacing it.
              (should (window-live-p old-thumb-win))
              (should (eq (window-buffer old-thumb-win) old-thumb))
              (should (window-live-p old-img-win))
              (should (eq (window-buffer old-img-win) old-img))
              (should (eq (window-buffer (selected-window)) new-thumb)))))
      (set-window-configuration config)
      (setq dired-image-thumbnail-window-layout saved-layout)
      (dolist (buf (list old-thumb old-img new-thumb new-img source-buf))
        (when (buffer-live-p buf)
          (kill-buffer buf))))))

(ert-deftest dit-goto-dired-keeps-thumbnail-window ()
  (let* ((config (current-window-configuration))
         (thumb (get-buffer-create "*image-dired: dit-goto*"))
         (img (get-buffer-create
               "*image-dired-display-image: dit-goto*"))
         (dired-buf (get-buffer-create "*dit-goto-dired*")))
    (unwind-protect
        (progn
          (with-current-buffer thumb
            (image-dired-thumbnail-mode)
            (setq dired-image-thumbnail--dired-buffer dired-buf))
          (with-current-buffer img (dired-image-thumbnail-display-mode))
          (dired-image-thumbnail--link-gallery-buffers thumb img)
          (delete-other-windows)
          (set-window-buffer (selected-window) thumb)
          (let ((img-win (split-window-right)))
            (set-window-buffer img-win img)
            (select-window img-win)
            (with-current-buffer thumb
              (dired-image-thumbnail-goto-dired))
            ;; Dired replaces the image view, leaving the thumbnail
            ;; grid visible in its own window.
            (should (eq (selected-window) img-win))
            (should (eq (window-buffer img-win) dired-buf))
            (should (get-buffer-window thumb))))
      (set-window-configuration config)
      (dolist (buf (list thumb img dired-buf))
        (when (buffer-live-p buf)
          (kill-buffer buf))))))

;;; Subdirectory handling

(ert-deftest dit-find-subdirs-cycle ()
  (dit--with-temp-dir root
    (let ((sub (expand-file-name "sub" root)))
      (make-directory sub)
      (make-symbolic-link root (expand-file-name "link" sub) t)
      (should (equal (mapcar #'file-name-nondirectory
                             (dired-image-thumbnail--find-subdirs root))
                     '("sub" "link"))))))

(ert-deftest dit-insert-subdirs-count ()
  (dit--with-temp-dir root
    (let ((sub (expand-file-name "sub" root))
          (dired-buf (dired-noselect root)))
      (make-directory sub)
      (unwind-protect
          (with-current-buffer dired-buf
            (should (= 1 (dired-image-thumbnail--insert-subdirs (list sub))))
            (should (= 0 (dired-image-thumbnail--insert-subdirs (list sub)))))
        (when (buffer-live-p dired-buf)
          (kill-buffer dired-buf))))))

;;; Thumbnail generation flow

(ert-deftest dit-queue-missing-once ()
  (with-temp-buffer
    (setq dired-image-thumbnail--current-images '("/tmp/dit-missing-a.jpg"
                                                  "/tmp/dit-missing-b.jpg"))
    (clrhash dired-image-thumbnail--thumb-queued)
    (clrhash dired-image-thumbnail--thumb-attempts)
    (let ((state (dired-image-thumbnail--make-work-state))
          (created 0))
      (cl-letf (((symbol-function 'image-dired-create-thumb)
                 (lambda (_o _t) (setq created (1+ created)))))
        (dired-image-thumbnail--queue-missing-thumbnails state)
        (dired-image-thumbnail--queue-missing-thumbnails state))
      (should (= created 2))
      (should (= (dired-image-thumbnail--work-state-queued state) 2)))))

(ert-deftest dit-queue-missing-resets-attempts-on-success ()
  (dit--with-temp-dir dir
    (let* ((file (expand-file-name "img.jpg" dir))
           (image-dired-dir (expand-file-name "thumbs" dir))
           (created 0))
      (make-directory image-dired-dir t)
      (with-temp-buffer
        (setq dired-image-thumbnail--current-images (list file))
        (clrhash dired-image-thumbnail--thumb-queued)
        (puthash file 3 dired-image-thumbnail--thumb-attempts)
        (write-region "x" nil (image-dired-thumb-name file) nil 'silent)
        (cl-letf (((symbol-function 'image-dired-create-thumb)
                   (lambda (_o _t) (setq created (1+ created)))))
          (dired-image-thumbnail--queue-missing-thumbnails
           (dired-image-thumbnail--make-work-state)))
        ;; An image rewritten externally gets a fresh retry budget once
        ;; its thumbnail exists again.
        (should (zerop created))
        (should (null (gethash file dired-image-thumbnail--thumb-attempts)))))))

(ert-deftest dit-queue-missing-honours-attempt-cap ()
  (with-temp-buffer
    (image-dired-thumbnail-mode)
    (let ((file "/tmp/dit-missing-cap.jpg")
          (created 0))
      (setq dired-image-thumbnail--current-images (list file))
      (clrhash dired-image-thumbnail--thumb-queued)
      (clrhash dired-image-thumbnail--thumb-attempts)
      (cl-letf (((symbol-function 'image-dired-create-thumb)
                 (lambda (_o _t) (setq created (1+ created)))))
        (dotimes (_ 5)
          (clrhash dired-image-thumbnail--thumb-queued)
          (dired-image-thumbnail--queue-missing-thumbnails
           (dired-image-thumbnail--make-work-state))))
      ;; A permanently failing image must not loop forever.
      (should (= created 3))
      (should (= (gethash file dired-image-thumbnail--thumb-attempts) 3)))))

(ert-deftest dit-invalidate-files-resets-retry-budget ()
  (with-temp-buffer
    (image-dired-thumbnail-mode)
    (let ((file "/tmp/dit-invalidate-budget.jpg"))
      (puthash file 3 dired-image-thumbnail--thumb-attempts)
      (dired-image-thumbnail-invalidate-files (list file))
      (should (null (gethash file dired-image-thumbnail--thumb-attempts))))))

(ert-deftest dit-thumb-queued-appeared-and-prune ()
  (dit--with-temp-dir dir
    (let* ((file (expand-file-name "img.jpg" dir))
           (image-dired-dir (expand-file-name "thumbs" dir)))
      (make-directory image-dired-dir t)
      (with-temp-buffer
        (setq dired-image-thumbnail--current-images (list file))
        (clrhash dired-image-thumbnail--thumb-queued)
        (puthash file t dired-image-thumbnail--thumb-queued)
        (should (not (dired-image-thumbnail--thumb-queued-appeared-p)))
        (write-region "x" nil (image-dired-thumb-name file) nil 'silent)
        (should (dired-image-thumbnail--thumb-queued-appeared-p))
        (dired-image-thumbnail--prune-thumb-queued)
        (should (zerop (hash-table-count dired-image-thumbnail--thumb-queued)))))))

(ert-deftest dit-resize-display-deferral ()
  (with-temp-buffer
    (setq dired-image-thumbnail--all-images '("/tmp/a.jpg")
          dired-image-thumbnail--current-images '("/tmp/a.jpg")
          dired-image-thumbnail--thumbs-generated-at 128
          dired-image-thumbnail--display-size 160)
    (let ((refreshed 0)
          (queued 0))
      (cl-letf (((symbol-function 'dired-image-thumbnail-refresh)
                 (lambda () (setq refreshed (1+ refreshed))))
                ((symbol-function 'dired-image-thumbnail--queue-thumb-regeneration)
                 (lambda () (setq queued (1+ queued)))))
        (dired-image-thumbnail--resize-display))
      (should (= refreshed 0))
      (should (= queued 1))))
  (with-temp-buffer
    (setq dired-image-thumbnail--all-images '("/tmp/a.jpg")
          dired-image-thumbnail--current-images '("/tmp/a.jpg")
          dired-image-thumbnail--thumbs-generated-at 160
          dired-image-thumbnail--display-size 160)
    (let ((refreshed 0))
      (cl-letf (((symbol-function 'dired-image-thumbnail-refresh)
                 (lambda () (setq refreshed (1+ refreshed)))))
        (dired-image-thumbnail--resize-display))
      (should (= refreshed 1)))))

(ert-deftest dit-poll-refreshes-progressively-but-not-during-resize ()
  (with-temp-buffer
    (image-dired-thumbnail-mode)
    (setq dired-image-thumbnail--current-images '("/tmp/dit-missing-a.jpg"))
    (clrhash dired-image-thumbnail--thumb-queued)
    (puthash "/tmp/dit-missing-a.jpg" t dired-image-thumbnail--thumb-queued)
    (let ((refreshed 0)
          (image-dired-thumbnail-buffer (buffer-name))
          (image-dired-queue-active-jobs 1))
      (cl-letf (((symbol-function 'dired-image-thumbnail-refresh)
                 (lambda () (setq refreshed (1+ refreshed))))
                ((symbol-function 'dired-image-thumbnail--thumb-queued-appeared-p)
                 (lambda () t)))
        ;; resize pending: no progressive refresh
        (setq dired-image-thumbnail--resize-pending t)
        (dired-image-thumbnail--poll-thumb-queue)
        (should (= refreshed 0))
        ;; not pending and a thumb appeared: progressive refresh
        (setq dired-image-thumbnail--resize-pending nil)
        (dired-image-thumbnail--poll-thumb-queue)
        (should (= refreshed 1))))))

(ert-deftest dit-regenerate-thumbs-defers-until-ready ()
  (with-temp-buffer
    (image-dired-thumbnail-mode)
    (setq dired-image-thumbnail--current-images '("/tmp/dit-reg-a.jpg")
          dired-image-thumbnail--display-size 160
          dired-image-thumbnail--thumbs-generated-at 128)
    (let ((image-dired-thumbnail-buffer (buffer-name))
          (created 0)
          (refreshed 0))
      (cl-letf (((symbol-function 'dired-image-thumbnail--thumbnails-busy-p)
                 (lambda () nil))
                ((symbol-function 'image-dired-create-thumb)
                 (lambda (_o _t) (setq created (1+ created))))
                ((symbol-function 'dired-image-thumbnail-refresh)
                 (lambda () (setq refreshed (1+ refreshed)))))
        (dired-image-thumbnail--regenerate-thumbs))
      (should (= created 1))
      (should (= refreshed 0))
      (should dired-image-thumbnail--resize-pending)
      (should (= dired-image-thumbnail--thumbs-generated-at 160)))))

(ert-deftest dit-regenerate-thumbs-busy-requeues ()
  (with-temp-buffer
    (image-dired-thumbnail-mode)
    (setq dired-image-thumbnail--current-images '("/tmp/dit-reg-a.jpg")
          dired-image-thumbnail--display-size 160
          dired-image-thumbnail--thumbs-generated-at 128)
    (let ((image-dired-thumbnail-buffer (buffer-name))
          (requeued 0))
      (cl-letf (((symbol-function 'dired-image-thumbnail--thumbnails-busy-p)
                 (lambda () t))
                ((symbol-function 'dired-image-thumbnail--queue-thumb-regeneration)
                 (lambda () (setq requeued (1+ requeued)))))
        (dired-image-thumbnail--regenerate-thumbs))
      (should (= requeued 1)))))

;;; Cropping

(ert-deftest dit-fit-image-spec-preserve-resolution ()
  (cl-letf (((symbol-function 'image-size) (lambda (&rest _) '(4000 . 3000)))
            ((symbol-function 'create-image)
             (lambda (file &optional _type _data-p &rest props)
               (cons 'image (append (list :file file) props)))))
    ;; Normal display uses explicit dimensions, upscaling previews to
    ;; fill the window.
    (let ((spec (dired-image-thumbnail--fit-image-spec "/tmp/x.jpg" 800 600)))
      (should (equal (plist-get (cdr spec) :width) 800))
      (should (equal (plist-get (cdr spec) :height) 600)))
    ;; Crop-safe display must not set :width/:height, since image-crop
    ;; resizes the source to that width before cropping.
    (let ((spec (dired-image-thumbnail--fit-image-spec "/tmp/x.jpg" 800 600 t)))
      (should-not (plist-member (cdr spec) :width))
      (should-not (plist-member (cdr spec) :height))
      (should (equal (plist-get (cdr spec) :max-width) 800))
      (should (equal (plist-get (cdr spec) :max-height) 600)))
    ;; An image smaller than the window is not upscaled for cropping.
    (cl-letf (((symbol-function 'image-size) (lambda (&rest _) '(200 . 150))))
      (let ((spec (dired-image-thumbnail--fit-image-spec "/tmp/x.jpg" 800 600 t)))
        (should-not (plist-member (cdr spec) :width))
        (should (equal (plist-get (cdr spec) :max-width) 800))))))

(ert-deftest dit-save-cropped-image-returns-to-thumbnails ()
  (dit--with-temp-dir dir
    (let ((target (expand-file-name "crop.jpg" dir))
          (thumb-buf (get-buffer-create "*dit-test-thumbs*"))
          (image-buf (get-buffer-create "*dit-test-image*"))
          (image-dired-thumbnail-buffer "*dit-test-thumbs*")
          (other-win nil))
      (unwind-protect
          (progn
            (write-region "" nil target)
            (set-window-buffer (selected-window) thumb-buf)
            (setq other-win (split-window))
            (select-window other-win)
            (set-window-buffer other-win image-buf)
            (with-current-buffer image-buf
              (setq dired-image-thumbnail--display-file target)
              (setq dired-image-thumbnail--display-source target)
              (cl-letf (((symbol-function 'dired-image-thumbnail--image-in-buffer)
                         (lambda () '(image :data "cropped-bytes")))
                        ((symbol-function 'dired-image-thumbnail--after-image-saved)
                         #'ignore))
                (dired-image-thumbnail-save-cropped-image))
              (should (eq (selected-window) (get-buffer-window thumb-buf))))
            (should (file-exists-p target)))
        (when (and other-win (window-live-p other-win))
          (delete-window other-win))
        (kill-buffer thumb-buf)
        (kill-buffer image-buf)))))

;;; Display header dimensions

(ert-deftest dit-original-dimensions-prefers-thumbnail-cache ()
  (let* ((thumb-buf (get-buffer-create "*dit-test-dim-thumbs*"))
         (file (expand-file-name "/tmp/dit-dim-cached.jpg"))
         (image-dired-thumbnail-buffer "*dit-test-dim-thumbs*"))
    (unwind-protect
        (progn
          (with-current-buffer thumb-buf
            (setq dired-image-thumbnail--dimension-cache
                  (make-hash-table :test 'equal))
            (puthash file '(1234 . 567) dired-image-thumbnail--dimension-cache))
          ;; The answered cache is preferred: `image-size' must not be
          ;; consulted, so a hard error in it would fail the test.
          (cl-letf (((symbol-function 'image-size)
                     (lambda (&rest _) (error "must not be called"))))
            (should (equal (dired-image-thumbnail--original-dimensions file)
                           '(1234 . 567)))
            (should (equal (dired-image-thumbnail--dimensions-string file)
                           "1234x567"))))
      (kill-buffer thumb-buf))))

(ert-deftest dit-original-dimensions-image-size-fallback ()
  (let ((file (expand-file-name "/tmp/dit-dim-fallback.jpg")))
    (cl-letf (((symbol-function 'image-size) (lambda (&rest _) '(640 . 480))))
      (should (equal (dired-image-thumbnail--original-dimensions file)
                     '(640 . 480)))
      (should (equal (dired-image-thumbnail--dimensions-string file)
                     "640x480")))))

(ert-deftest dit-original-dimensions-nil-when-unavailable ()
  (let ((file (expand-file-name "/tmp/dit-dim-unknown.jpg")))
    (cl-letf (((symbol-function 'image-size)
               (lambda (&rest _) (error "no window system frame"))))
      (should-not (dired-image-thumbnail--original-dimensions file))
      (should (equal (dired-image-thumbnail--dimensions-string file) "?")))))

(ert-deftest dit-set-display-header-shows-original-dimensions ()
  (with-temp-buffer
    (cl-letf (((symbol-function 'dired-image-thumbnail--original-dimensions)
               (lambda (_file) '(800 . 600))))
      (dired-image-thumbnail--set-display-header "/tmp/dit-header.jpg"))
    (should (equal header-line-format " 800x600 "))))

;;; EXIF orientation

(ert-deftest dit-exif-rotation-maps-codes ()
  (dolist (case '((nil . nil) (1 . nil) (2 . nil) (3 . 180) (4 . nil)
                  (5 . 90) (6 . 90) (7 . 270) (8 . 270)))
    (cl-letf (((symbol-function 'dired-image-thumbnail--exif-orientation)
               (lambda (_file) (car case))))
      (should (equal (dired-image-thumbnail--exif-rotation "photo.jpg")
                     (cdr case))))))

(ert-deftest dit-orientation-transforms-table ()
  (should (equal (cdr (assq 6 dired-image-thumbnail--orientation-transforms))
                 '("-rotate" "90")))
  (should (null (assq 1 dired-image-thumbnail--orientation-transforms)))
  (dolist (code '(2 3 4 5 6 7 8))
    (should (cdr (assq code dired-image-thumbnail--orientation-transforms)))))

;; file-attributes layout: (nil UID GID ATIME MTIME CTIME SIZE MODE ...)
(ert-deftest dit-preview-path-includes-ctime-and-size ()
  ;; Same attributes -> stable key; a rewrite that restores the
  ;; modification time but changes status time/size -> new key, so
  ;; the stale pre-rewrite preview cannot be served.
  (cl-letf* (((symbol-function 'dired-image-thumbnail--preview-dir)
              (lambda () "/tmp/dit-preview-dir/"))
             ((symbol-function 'file-attributes)
              (lambda (file &rest _)
                (if (string= file "/p/rewritten.jpg")
                    '(nil 1000 1000 (10 0) (100 200) (200 310) 12346 420)
                  '(nil 1000 1000 (10 0) (100 200) (200 300) 12345 420)))))
    (let ((before (dired-image-thumbnail--preview-path "/p/a.jpg" 100))
          (same (dired-image-thumbnail--preview-path "/p/a.jpg" 100))
          (after (dired-image-thumbnail--preview-path "/p/rewritten.jpg" 100)))
      (should (equal before same))
      (should-not (equal before after)))))

(ert-deftest dit-apply-orientation-turns-jpeg ()
  (skip-unless (and (executable-find "jpegtran")
                    (executable-find "magick")
                    (executable-find "identify")))
  (dit--with-temp-dir dir
    (let ((jpg (expand-file-name "turned.jpg" dir)))
      (should (zerop (call-process "magick" nil nil nil
                                   "-size" "80x40" "gradient:red-blue" jpg)))
      (should (dired-image-thumbnail--apply-orientation jpg 6))
      (with-temp-buffer
        (should (zerop (call-process "identify" nil t nil
                                     "-format" "%w %h" jpg)))
        (should (string= (string-trim (buffer-string)) "40 80")))
      ;; Orientation 1 (normal) and nil need no transform.
      (should-not (dired-image-thumbnail--apply-orientation jpg 1))
      (should-not (dired-image-thumbnail--apply-orientation jpg nil)))))

(ert-deftest dit-exif-orientation-reads-tag ()
  (skip-unless (and (executable-find "magick")
                    (executable-find "exiftool")))
  (dit--with-temp-dir dir
    (let ((jpg (expand-file-name "tagged.jpg" dir)))
      (should (zerop (call-process "magick" nil nil nil
                                   "-size" "40x20" "gradient:red-blue" jpg)))
      (should (zerop (call-process "exiftool" nil nil nil
                                   "-overwrite_original" "-Orientation#=6" jpg)))
      (clrhash dired-image-thumbnail--orientation-cache)
      (should (equal (dired-image-thumbnail--exif-orientation jpg) 6))
      ;; Cached: a second read does not touch the file again.
      (cl-letf (((symbol-function 'insert-file-contents-literally)
                 (lambda (&rest _) (error "unexpected re-read"))))
        (should (equal (dired-image-thumbnail--exif-orientation jpg) 6)))
      ;; Rewriting the file (attributes change) re-reads it.
      (should (zerop (call-process "exiftool" nil nil nil
                                   "-overwrite_original" "-Orientation#=8" jpg)))
      (should (equal (dired-image-thumbnail--exif-orientation jpg) 8)))))

(provide 'dired-image-thumbnail-test)
;;; dired-image-thumbnail-test.el ends here