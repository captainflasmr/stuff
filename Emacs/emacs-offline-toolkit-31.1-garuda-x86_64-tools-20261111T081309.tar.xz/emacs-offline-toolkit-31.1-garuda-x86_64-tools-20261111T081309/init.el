;; -*- lexical-binding: t; -*-
;;
;; Rendered from init.el.in by create-install.sh for Emacs 31.1.
;; Do not edit the rendered init.el by hand — edit the template or the
;; packages/emacs-<VER>.el list and re-render.

;;
;; -> core-configuration
;;
(let ((f (expand-file-name "~/.emacs.d/Emacs-vanilla/init.el")))
  (when (file-exists-p f) (load-file f)))

;;
;; -> package-archives
;;
(require 'package)

;; When my/offline-packages is t (default), init.el uses a local ELPA mirror
;; discovered by globbing ~/elpa-mirror-emacs-*/.  When no mirror is found but
;; my/offline-packages is still t, package-archives is left unset (nil) so
;; Emacs never reaches out to the network — safe for air-gapped machines.
;; Set to nil in early-init.el or via --eval to force online archives
;; (MELPA / ELPA / Org), e.g. during toolkit build:
;;   emacs --batch --eval '(setq my/offline-packages nil)' -l init.el
(unless (boundp 'my/offline-packages)
  (setq my/offline-packages t))

;; Primary: glob in HOME (~/) for the mirror directory.
;; Fallback: glob in the parent of user-emacs-directory (handles portable
;; Windows installs where HOME may not be set).
(setq my/offline-packages-dir
      (or (car (sort (file-expand-wildcards
                      (expand-file-name "~/elpa-mirror-emacs-*"))
                     #'string>))
          (car (sort (file-expand-wildcards
                      (expand-file-name
                       "../elpa-mirror-emacs-*"
                       (file-name-as-directory
                        (expand-file-name user-emacs-directory))))
                     #'string>))))

(message "my/offline-packages=%s  dir=%s"
         my/offline-packages
         (or my/offline-packages-dir "<none found>"))

(cond
 ((and my/offline-packages my/offline-packages-dir)
  (setq package-archives
        `(("local" . ,(file-name-as-directory my/offline-packages-dir)))))
 (my/offline-packages
  ;; offline mode but no mirror found — don't reach out to the network
  (setq package-archives nil)
  (message "my/offline-packages-dir not found; no package archives configured"))
 (t
  (setq package-archives '(("melpa"  . "https://melpa.org/packages/")
                           ("elpa"   . "https://elpa.gnu.org/packages/")
                           ("nongnu" . "https://elpa.nongnu.org/nongnu/")))))

(package-initialize)
(setq load-prefer-newer t)

;; Skip GPG signature verification on archive refresh — saves downloading
;; and verifying .sig files for every archive.  Safe in the build context:
;; first-build traffic goes over TLS to known-good archives; subsequent
;; builds use the self-controlled local mirror.
(setq package-check-signature nil)

;;
;; -> local-packages
;; Top-level dir + every immediate subdirectory under ~/.emacs.d/local-packages
;; joins load-path, so `foo.el' or `foo/foo.el' can be `require'd directly.
;;
(let ((dir (expand-file-name "~/.emacs.d/local-packages")))
  (when (file-directory-p dir)
    (add-to-list 'load-path dir)
    (dolist (sub (directory-files dir t "^[^.]"))
      (when (file-directory-p sub)
        (add-to-list 'load-path sub)))))

(defun my/ensure-package (pkg)
  "Install PKG from configured archives if it is not already present.
Failures (e.g. package requires a newer Emacs) are logged, not fatal."
  (unless (package-installed-p pkg)
    (unless package-archive-contents
      (package-refresh-contents))
    (condition-case err
        (package-install pkg)
      (error (message "my/ensure-package: skipping %s (%s)" pkg err)))))

;;
;; -> package-list (injected)
;;
(dolist (pkg '(async chess cmake-mode corfu csv-mode dape diff-hl doc-view-follow doom-themes dumb-jump ef-themes gnuplot gruvbox-theme highlight-indent-guides htmlize i3wm-config-mode magit markdown-mode modus-themes outline-indent ollama-buddy package-lint plantuml-mode protobuf-mode selected-window-accent-mode simply-annotate timu-caribbean-theme timu-rouge-theme timu-spacegrey-theme typescript-mode vlf web-mode yaml-mode kotlin-mode powershell zig-mode))
  (my/ensure-package pkg))

;;
;; -> xkb-mode
;;
;; Vendored under local-packages/xkb-mode.  Local packages get no
;; generated autoloads, so register the .xkb association explicitly.
;;
(when (locate-library "xkb-mode")
  (autoload 'xkb-mode "xkb-mode" nil t)
  (add-to-list 'auto-mode-alist '("\\.xkb\\'" . xkb-mode)))

;;
;; -> org-ibullets
;;
;; Vendored under local-packages/org-ibullets.  Render Org heading stars as
;; UTF-8 bullets.  Disabling font-cache compaction keeps the composed glyphs
;; fast (see the package README).
;;
(defvar my/org-ibullets-configured nil
  "Non-nil when the org-ibullets hook and performance setting are installed.")

(when (locate-library "org-ibullets")
  (autoload 'org-ibullets-mode "org-ibullets" nil t)
  (add-hook 'org-mode-hook #'org-ibullets-mode)
  (setq inhibit-compacting-font-caches t)
  (setq my/org-ibullets-configured t))

;;
;; -> org-slides
;;
;; Vendored under local-packages/org-slides.  Each top-level heading is one
;; slide; `C-c P' starts the presentation, `n'/`SPC'/right move forward,
;; `p'/`S-SPC'/left move back, and `q' quits.  The package handles the text
;; scale, inline images, read-only mode, and cursor hiding itself.
;;
(defvar my/org-slides-configured nil
  "Non-nil when the org-slides keybinding is installed.")

(when (locate-library "org-slides")
  (autoload 'org-slides-start "org-slides" nil t)
  (with-eval-after-load 'org
    (define-key org-mode-map (kbd "C-c P") #'org-slides-start))
  (setq my/org-slides-configured t))

;;
;; -> custom-faces
;;
;; `default' must use an absolute height (1/10 pt).  Every other face uses
;; a float relative to it, so global font-size changes and `text-scale-mode'
;; keep the UI proportional.  Tab faces inherit `fixed-pitch' so a
;; buffer-local `variable-pitch-mode' cannot change their typeface.
(condition-case err
    (custom-set-faces
     '(default ((t (:family "Monospace" :foundry "ADBO" :slant normal :weight regular :height 100 :width normal))))
     '(completions-common-part ((t (:foreground "#87ceeb"))))
     '(completions-first-difference ((t (:foreground "#ffb6c1"))))
     '(cursor ((t (:background "coral"))))
     '(ediff-current-diff-A ((t (:extend t :background "#b5daeb" :foreground "#000000"))))
     '(ediff-even-diff-A ((t (:background "#bafbba" :foreground "#000000" :extend t))))
     '(ediff-fine-diff-A ((t (:background "#f4bd92" :foreground "#000000" :extend t))))
     '(ediff-odd-diff-A ((t (:background "#b8fbb8" :foreground "#000000" :extend t))))
     '(fixed-pitch ((t (:family "Monospace" :height 1.1))))
     '(font-lock-warning-face ((t (:foreground "#930000" :inverse-video nil))))
     '(fringe ((t (:foreground "#2d3743" :background "#2d3743"))))
     '(hl-line ((t (:background "#3636424250b6"))))
     '(icomplete-first-match ((t (:foreground "#7c7c75" :background "#3a3a3a" :weight bold))))
     '(icomplete-selected-match ((t (:foreground "#ffffff" :background "#5f87af" :weight bold))))
     '(indent-guide-face ((t (:background "#282828" :foreground "#666666"))))
     '(mode-line ((t (:height 1.4 :underline nil :overline nil :box nil))))
     '(mode-line-inactive ((t (:height 1.4 :underline nil :overline nil :box nil))))
     '(org-level-1 ((t (:inherit default :weight regular :height 1.0))))
     '(org-level-2 ((t (:inherit default :weight light :height 1.0))))
     '(org-level-3 ((t (:inherit default :weight light :height 1.0))))
     '(org-level-4 ((t (:inherit default :weight light :height 1.0))))
     '(org-level-5 ((t (:inherit default :weight light :height 1.0))))
     '(org-level-6 ((t (:inherit default :weight light :height 1.0))))
     '(org-link ((t (:underline nil))))
     '(org-tag ((t (:height 0.9))))
     '(tab-bar ((t (:inherit fixed-pitch :background "#2d3743" :foreground "#e1e1e0"))))
     '(tab-bar-tab ((t (:inherit (highlight fixed-pitch) :background "coral" :foreground "#000000"))))
     '(tab-bar-tab-inactive ((t (:inherit fixed-pitch :background "#2d3743" :foreground "#e1e1e0" :box (:line-width 1 :color "#2d3743" :style flat-button)))))
     '(variable-pitch ((t (:family "DejaVu Sans" :height 1.2 :weight normal))))
     '(vertical-border ((t (:foreground "#000000"))))
     '(widget-button ((t (:inherit fixed-pitch :weight regular))))
     '(window-divider ((t (:foreground "black")))))
  (error (message "custom-set-faces skipped: %s" err)))

;;
;; -> font-size-overrides
;;
;; Emacs-vanilla/init.el owns the default font sizes.  Override them here
;; per machine without editing that module.  `default' and
;; `variable-pitch' are in 1/10pt; `fixed-pitch' and `mode-line' are
;; relative to `default'.  `my/set-font-size-overrides' applies the whole
;; set, so include every face you want to pin; unspecified faces fall
;; back to Emacs-vanilla's defaults.  Uncomment and adjust for the
;; current display.
;;
;; (when (fboundp 'my/set-font-size-overrides)
;;   (my/set-font-size-overrides
;;    '((default . 100)
;;      (fixed-pitch . 1.1)
;;      (variable-pitch . 120)
;;      (mode-line . 1.4))))
