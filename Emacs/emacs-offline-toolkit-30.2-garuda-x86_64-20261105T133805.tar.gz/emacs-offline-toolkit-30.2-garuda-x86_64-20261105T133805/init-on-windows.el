;; -*- lexical-binding: t; -*-

;;
;; -> core-configuration
;;
(load-file "~/.emacs.d/Emacs-vanilla/init.el")

(custom-set-variables
 ;; custom-set-variables was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(column-number-mode t)
 '(custom-enabled-themes '(misterioso))
 '(ibuffer-display-summary nil)
 '(ibuffer-formats
   '((mark modified read-only locked " " (name 40 40 :left :elide) " "
           (size 9 -1 :right) " " (mode 16 16 :left :elide) " "
           filename-and-process)
     (mark " " (name 16 -1) " " filename)))
 '(image-dired-cmd-create-thumbnail-program "magick")
 '(org-agenda-files '("d:/source/MIMESIS-OVC/README_tasks.org"))
 '(package-selected-packages '(web-mode))
 '(tab-bar-mode t)
 '(tool-bar-mode nil)
 '(warning-suppress-log-types '((frameset)))
 '(warning-suppress-types '((frameset))))

;; `default' (when set) must use an absolute height (1/10 pt); every other
;; face uses a float relative to it, so global font-size changes and
;; `text-scale-mode' keep the UI proportional.  Tab faces inherit
;; `fixed-pitch' so a buffer-local `variable-pitch-mode' cannot change them.
(custom-set-faces
 ;; custom-set-faces was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(completions-common-part ((t (:foreground "#87ceeb"))))
 '(completions-first-difference ((t (:foreground "#ffb6c1"))))
 '(cursor ((t (:background "coral"))))
 '(ediff-current-diff-A ((t (:extend t :background "#b5daeb" :foreground "#000000"))))
 '(ediff-even-diff-A ((t (:background "#bafbba" :foreground "#000000" :extend t))))
 '(ediff-fine-diff-A ((t (:background "#f4bd92" :foreground "#000000" :extend t))))
 '(ediff-odd-diff-A ((t (:background "#b8fbb8" :foreground "#000000" :extend t))))
 '(fixed-pitch ((t (:family "Consolas" :height 1.1))))
 '(font-lock-warning-face ((t (:foreground "#930000" :inverse-video nil))))
 '(fringe ((t (:foreground "#2d3743" :background "#2d3743"))))
 '(highlight-indent-guides-character-face ((t (:foreground "#000000"))))
 '(highlight-indent-guides-odd-face ((t (:background "#222222"))))
 '(hl-line ((t (:background "#3d4753"))))
 '(icomplete-first-match ((t (:foreground "#7c7c75" :background "#3a3a3a" :weight bold))))
 '(icomplete-selected-match ((t (:foreground "#ffffff" :background "#5f87af" :weight bold))))
 '(indent-guide-face ((t (:background "#282828" :foreground "#666666"))))
 '(mode-line ((t (:height 1.4 :underline nil :overline nil :box nil))))
 '(mode-line-inactive ((t (:height 1.4 :underline nil :overline nil :box nil))))
 '(org-column ((t (:background "#1e1e1e" :foreground "#d4d4d4"))))
 '(org-level-1 ((t (:inherit default :weight regular :height 1.0))))
 '(org-level-2 ((t (:inherit default :weight light :height 1.0))))
 '(org-level-3 ((t (:inherit default :weight light :height 1.0))))
 '(org-level-4 ((t (:inherit default :weight light :height 1.0))))
 '(org-level-5 ((t (:inherit default :weight light :height 1.0))))
 '(org-level-6 ((t (:inherit default :weight light :height 1.0))))
 '(org-link ((t (:underline nil))))
 '(org-tag ((t (:height 0.9))))
 '(tab-bar ((t (:inherit fixed-pitch :background "#2d3743" :foreground "#e1e1e0"))))
 '(tab-bar-tab ((t (:inherit (highlight fixed-pitch) :background "coral" :foreground "#000000"))))
 '(tab-bar-tab-inactive ((t (:inherit fixed-pitch :background "#2d3743" :foreground "#e1e1e0" :box (:line-width 1 :color "#2d3743" :style flat-button)))))
 '(variable-pitch ((t (:family "Consolas" :height 1.1 :weight normal))))
 '(vertical-border ((t (:foreground "#000000"))))
 '(widget-button ((t (:inherit fixed-pitch :weight regular))))
 '(window-divider ((t (:foreground "black")))))

(when (eq system-type 'windows-nt)
  (let* ((bin (expand-file-name "bin" user-emacs-directory))
         (sys (getenv "SystemRoot"))
         (xPaths
          `(,bin
            ,(concat bin "/PortableGit/bin")
            ,(concat bin "/PortableGit/usr/bin")
            ,(concat bin "/netcoredbg")
            ,(concat bin "/csharp-ls/tools/net10.0/any")
            ,(concat bin "/hunspell/Hunspell/bin")
            ,(concat bin "/find")
            ,(concat bin "/clang/bin")
            ,(concat bin "/cmake/bin")
            ,(concat bin "/protoc")
            ,(concat bin "/ada_language_server/bin")
            ,(concat bin "/buf/bin")
            ,(concat bin "/kotlin-language-server/bin")
            ,(concat bin "/svn/bin")
            ,(concat bin "/omnisharp")
            ,(concat bin "/exiftool")
            ,(concat bin "/jdtls/bin")
            ,(concat bin "/ImageMagick-7.1.2-27-portable-Q16-x64")
            ,(concat bin "/ffmpeg-7.1.1-essentials_build/bin")
            ,(concat sys "/System32")
            ,(concat sys "/System32/Wbem")
            ,(concat sys "/System32/WindowsPowerShell/v1.0/")
            ,(concat sys "/System32/OpenSSH/")))
         (sysPath (getenv "PATH")))
    (setenv "PATH" (concat (mapconcat #'identity xPaths ";") ";" sysPath))
    (setq exec-path (append xPaths (split-string sysPath ";") (list "." exec-directory)))))

(add-hook 'csharp-mode-hook
          (lambda ()
            (define-key csharp-mode-map
                        (kbd "C-M-H") #'nil)))

(add-to-list 'display-buffer-alist
             '("\\*vc-dir\\*"
               (display-buffer-same-window)))

(require 'eglot)

(setq kill-buffer-query-functions nil)

;; Test basic geometric shapes
;; (mapcar (lambda (x) (insert (format "%c " x))) 
;;         (number-sequence #x25A0 #x25FF 5))

;; ;; Test mathematical symbols  
;; (mapcar (lambda (x) (insert (format "%c " x))) 
;;         (number-sequence #x2200 #x2220))

;; (mapcar (lambda (x) (insert (format "%c " x))) 
;;         (number-sequence #x0080 #x25FF 1))

;; MIMESIS Visual Solution Build System for Emacs
;; Adapted for modular architecture with IGM, MSS, DM, VDS, IGC components
(let* ((bin (expand-file-name "bin" user-emacs-directory))
        (csls-dll (car (file-expand-wildcards
                        (expand-file-name "csharp-ls/tools/*/any/CSharpLanguageServer.dll" bin)))))
  (setq eglot-server-programs
        `((csharp-mode . ("dotnet" ,csls-dll)))))

(use-package corfu
  :custom
  (corfu-auto nil)
  (corfu-auto-delay 0.1)
  (corfu-auto-prefix 2)
  (corfu-cycle t)
  (corfu-separator ?\s)
  (corfu-quit-at-boundary nil)
  (corfu-quit-no-match nil)
  (corfu-preview-current nil)
  (corfu-preselect 'first)
  (corfu-on-exact-match nil)
  (corfu-scroll-margin 5))

(define-key my-jump-keymap (kbd "k") (lambda ()
                                       (interactive)
                                       (find-file (concat user-emacs-directory "README.org"))))

(use-package simply-annotate
  :demand t
  :hook
  (find-file-hook . simply-annotate-mode)
  :custom
  (simply-annotate-author-list '("Rob Norris"
                                 "Pete Norton"
                                 "Andy Watson"
                                 "James Dyer"))
  (simply-annotate-prompt-for-author 'always)
  :bind
  ("C-c A" . simply-annotate-mode)
  ("C-c 0" . simply-annotate-show-all))

(setq tab-bar-auto-width-max '((120) 20))

(setq flymake-show-diagnostics-at-end-of-line nil)

(use-package protobuf-mode)

(with-eval-after-load 'dired
  (define-key dired-mode-map (kbd "C") 'dired-do-copy))

(use-package doom-themes)

(use-package highlight-indent-guides
  :mode "\\.cshtml?\\'"
  :hook (html-mode . highlight-indent-guides-mode)
  :config
  (setq highlight-indent-guides-method 'character)
  ;; (setq highlight-indent-guides-method 'fill)
  ;; highlight-indent-guides-character ?\|))
  ;; (setq highlight-indent-guides-auto-enabled nil)
  (setq highlight-indent-guides-auto-enabled nil)
  (set-face-background 'highlight-indent-guides-odd-face "#e8e8e8")
  (set-face-background 'highlight-indent-guides-even-face "#dedede")
  (set-face-foreground 'highlight-indent-guides-character-face "#4e535e"))

(defun insert-default-background-color ()
  "Insert the default background color at point."
  (interactive)
  (insert (downcase (face-attribute 'default :background))))

(use-package web-mode
  :mode "\\.cshtml?\\'"
  :hook (html-mode . web-mode)
  :bind (:map web-mode-map ("M-;" . nil)))

(add-to-list 'auto-mode-alist '("\\.cshtml\\'" . html-mode))
(add-to-list 'auto-mode-alist '("\\.proto\\'" . protobuf-mode))
(add-to-list 'auto-mode-alist '("\\.csproj\\'" . nxml-mode))

(setq eglot-ignored-server-capabilities
      '(
        ;; :hoverProvider                    ; Documentation on hover
        ;; :completionProvider               ; Code completion
        ;; :signatureHelpProvider            ; Function signature help
        ;; :definitionProvider               ; Go to definition
        ;; :typeDefinitionProvider           ; Go to type definition
        ;; :implementationProvider           ; Go to implementation
        ;; :declarationProvider              ; Go to declaration
        ;; :referencesProvider               ; Find references
        ;; :documentHighlightProvider        ; Highlight symbols automatically
        ;; :documentSymbolProvider           ; List symbols in buffer
        ;; :workspaceSymbolProvider          ; List symbols in workspace
        ;; :codeActionProvider               ; Execute code actions
        ;; :codeLensProvider                 ; Code lens
        ;; :documentFormattingProvider       ; Format buffer
        ;; :documentRangeFormattingProvider  ; Format portion of buffer
        ;; :documentOnTypeFormattingProvider ; On-type formatting
        ;; :renameProvider                   ; Rename symbol
        ;; :documentLinkProvider             ; Highlight links in document
        ;; :colorProvider                    ; Decorate color references
        ;; :foldingRangeProvider             ; Fold regions of buffer
        ;; :executeCommandProvider           ; Execute custom commands
        ;; :inlayHintProvider                ; Inlay hints
        ))

(use-package ibuffer)

(setq recentf-max-menu-items 40)
(setq recentf-max-saved-items 40)

;; ============================================================

(setq org-todo-keywords
      '((sequence "TODO(t)" "DOING(g)" "ORDR(o)" "SENT(s)" "|" "DONE(n)" "CANCELLED(c)" "CLOSED(x)")))
(setq org-todo-keyword-faces
      '(("TODO" . "#ee6273")
        ("DOING" . "#6e8baa")
        ("ORDR" . "#c96eee")
        ("SENT" . "#c86bee")
        ("DONE" . "#77aa66")
        ("CANCELLED" . "#426b3e")
        ("CLOSED" . "#426b3e")
        ))

(setq completion-auto-select t)

(use-package dape
  :init
  ;; Set key prefix BEFORE loading dape
  (setq dape-key-prefix (kbd "C-c d"))
  :config
  ;; Define common configuration
  (defvar mimesis-netcoredbg-path (expand-file-name "bin/netcoredbg/netcoredbg.exe" user-emacs-directory)
    "Path to netcoredbg executable.")
  (defvar mimesis-netcoredbg-log (expand-file-name "bin/netcoredbg/netcoredbg.log" user-emacs-directory)
    "Path to netcoredbg log file.")
  (defvar mimesis-project-root "d:/source/MIMESIS-OVC"
    "Root directory of MIMESIS-OVC project.")
  (defvar mimesis-build-config "Debug"
    "Build configuration (Debug or Release).")
  (defvar mimesis-target-arch "x64"
    "Target architecture (x64, x86, or AnyCPU).")
  (defvar mimesis-vsdbg-path "C:/Users/vm.j.dyer/.vscode/extensions/ms-dotnettools.csharp-2.80.16-win32-x64/.debugger/x86_64/vsdbg.exe"
    "Path to vsdbg from VSCode installation.")

  ;; Helper function to create component configs
  (defun mimesis-dape-config (component-name dll-name &optional stop-at-entry)
    "Create a dape configuration for a component.
COMPONENT-NAME is the component directory name
DLL-NAME is the DLL filename without extension.
STOP-AT-ENTRY if non-nil, stops at program entry point."
    (let* ((component-dir (format "%s/%s" mimesis-project-root component-name))
           (bin-path (format "%s/bin/%s/%s/net9.0"
                             component-dir
                             mimesis-target-arch
                             mimesis-build-config))
           (dll-path (format "%s/%s.dll" bin-path dll-name))
           (config-name (intern (format "netcoredbg-launch-%s" 
                                        (downcase component-name)))))
      `(,config-name
        modes (csharp-mode csharp-ts-mode)
        command ,mimesis-netcoredbg-path
        command-args (,(format "--interpreter=vscode")
                      ,(format "--engineLogging=%s" mimesis-netcoredbg-log))
        normalize-path-separator 'windows
        :type "coreclr"
        :request "launch"
        :program ,dll-path
        :cwd ,component-dir
        :console "externalTerminal"
        :internalConsoleOptions "neverOpen"
        :suppressJITOptimizations t
        :requireExactSource nil
        :justMyCode t
        :stopAtEntry ,(if stop-at-entry t :json-false))))

  ;; Register all component configurations
  (dolist (config (list
                   (mimesis-dape-config "IGC" "MIMESIS.IGC" t)
                   (mimesis-dape-config "MSS" "MIMESIS.MSS" t)
                   (mimesis-dape-config "IGM" "MIMESIS.IGM" t)
                   (mimesis-dape-config "VDS" "VDS.MSS" t)
                   (mimesis-dape-config "DM" "DM.MSS" t)
                   (mimesis-dape-config "Demo" "Demo.MSS" t)
                   (mimesis-dape-config "Test_001" "Test" t)))
    (add-to-list 'dape-configs config))
  
  ;; Set buffer arrangement and other options
  (setq dape-buffer-window-arrangement 'gud)
  (setq dape-debug t)
  (setq dape-repl-echo-shell-output t))

(use-package dired-video-thumbnail
  :bind (:map dired-mode-map
              ("C-t v" . dired-video-thumbnail))
  :custom
  (dired-video-thumbnail-size 250)
  (dired-video-thumbnail-display-height 180)
  (dired-video-thumbnail-columns 4)
  (dired-video-thumbnail-timestamp "00:00:02")
  (dired-video-thumbnail-video-player nil)
  (dired-video-thumbnail-mark-border-width 5)
  :custom-face
  (dired-video-thumbnail-mark ((t (:foreground "orange")))))

;; (setq dired-video-thumbnail-recursive t)

(use-package jira-to-org)

;;
;; -> org-ibullets — render Org heading stars as UTF-8 bullets
;;
;; Vendored under local-packages/org-ibullets; no ELPA archive needed.
;; Disabling font-cache compaction keeps the composed bullets fast.
;;
(unless (and (boundp 'my/org-ibullets-configured)
             my/org-ibullets-configured)
  (use-package org-ibullets
    :ensure nil
    :load-path ("offline-packages/local-packages/org-ibullets"
                "local-packages/org-ibullets")
    :commands org-ibullets-mode
    :init
    (setq my/org-ibullets-configured t
          inhibit-compacting-font-caches t)
    :hook (org-mode . org-ibullets-mode)))

;;
;; -> org-slides — present an Org buffer, one top-level heading per slide
;;
;; Vendored under local-packages/org-slides; no ELPA archive needed.
;; C-c P starts, n/SPC/right go forward, p/S-SPC/left go back, and q quits.
;;
(unless (and (boundp 'my/org-slides-configured)
             my/org-slides-configured)
  (use-package org-slides
    :ensure nil
    :load-path ("offline-packages/local-packages/org-slides"
                "local-packages/org-slides")
    :commands org-slides-start
    :init
    (setq my/org-slides-configured t)
    (with-eval-after-load 'org
      (define-key org-mode-map (kbd "C-c P") #'org-slides-start))))

(use-package selected-window-accent-mode
  :config (selected-window-accent-mode 1)
  :custom
  (selected-window-accent-fringe-thickness 10)
  (selected-window-accent-custom-color "#c1c1c1")
  (selected-window-accent-mode-style 'default))

(define-key my-overrides-mode-map (kbd "C-c w") selected-window-accent-map)

(require 'image-dired)
(use-package dired-image-thumbnail)
