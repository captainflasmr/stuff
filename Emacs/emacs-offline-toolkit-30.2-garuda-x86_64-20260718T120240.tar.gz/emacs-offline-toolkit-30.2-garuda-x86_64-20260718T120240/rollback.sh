#!/usr/bin/env bash
# rollback.sh — restore a setup.sh backup. Works with both:
#   (1) Directory-based backups under ~/.emacs.d/.backups/<STAMP>/
#   (2) Legacy flat .pre-toolkit-<STAMP> suffixes (from older setup.sh)
#
# Scans for both formats, picks the newest stamp, and swaps everything under
# that stamp back to its original name. The current (post-install) state is
# archived under .backups/<NOW>-rolledback/ so a re-rollforward is possible.
set -euo pipefail

EMACS_D="${HOME}/.emacs.d"
BACKUPS_DIR="${EMACS_D}/.backups"
NOW="$(date +%Y%m%dT%H%M%S)"

# Collect stamps from directory-based backups (.backups/<STAMP>/ dirs).
dir_stamps() {
  find "$BACKUPS_DIR" -maxdepth 1 -mindepth 1 -type d 2>/dev/null \
    | xargs -r -I{} basename '{}' \
    | grep -E '^[0-9]{8}T[0-9]{6}$' || true
}

# Collect stamps from legacy flat .pre-toolkit-<STAMP> suffixes.
legacy_stamps() {
  {
    find "$EMACS_D" -maxdepth 1 -mindepth 1 -name '*.pre-toolkit-*' 2>/dev/null
    find "$HOME"    -maxdepth 1 -mindepth 1 -name '*.pre-toolkit-*' 2>/dev/null
  } | sed -E 's/.*\.pre-toolkit-([0-9TZ]+).*/\1/' | sort -u || true
}

mapfile -t DIR_STAMPS < <(dir_stamps)
mapfile -t LEGACY_STAMPS < <(legacy_stamps)

ALL_STAMPS=()
for s in "${DIR_STAMPS[@]+"${DIR_STAMPS[@]}"}" "${LEGACY_STAMPS[@]+"${LEGACY_STAMPS[@]}"}"; do
  [[ -n "$s" ]] && ALL_STAMPS+=("$s")
done

if [[ "${#ALL_STAMPS[@]}" -eq 0 ]]; then
  echo "No backups found (neither .backups/ dirs nor .pre-toolkit-* entries)." >&2
  echo "Checked: ${BACKUPS_DIR}/, ${EMACS_D}/*.pre-toolkit-*, ~/elpa-mirror-emacs-*.pre-toolkit-*" >&2
  exit 1
fi

# Deduplicate and sort newest first.
mapfile -t SORTED < <(printf '%s\n' "${ALL_STAMPS[@]}" | sort -u -r)
LATEST="${SORTED[0]}"

echo "Available backup stamps (newest first):"
printf '  %s%s\n' "${SORTED[0]}" "  <- default" "${SORTED[@]:1}"
echo
read -r -p "Roll back to ${LATEST}? [y/N] " ans </dev/tty
[[ "$ans" =~ ^[yY] ]] || { echo "Aborted."; exit 0; }

# Archive current state so we can roll forward again if needed.
ROLLFORWARD_DIR="${BACKUPS_DIR}/${NOW}-rolledback"
mkdir -p "$ROLLFORWARD_DIR"

rollback_dir() {
  local stamp="$1"
  local bak_dir="${BACKUPS_DIR}/${stamp}"
  [[ -d "$bak_dir" ]] || return 0

  echo ">> Restoring from directory backup: ${bak_dir}"

  # Restore items that live directly under ~/.emacs.d/
  for item in init.el early-init.el abbrev_defs init-starter.el init-starter-coding.el init-on-windows.el \
              elpa local-packages bin docs Emacs-vanilla Emacs-DIYer; do
    local src="${bak_dir}/${item}"
    [[ -e "$src" ]] || continue
    local dest="${EMACS_D}/${item}"
    if [[ -e "$dest" ]]; then
      echo "   archiving current ${item} -> .backups/${NOW}-rolledback/${item}"
      mv "$dest" "${ROLLFORWARD_DIR}/${item}"
    fi
    echo "   restoring ${item}"
    mv "$src" "$dest"
  done

  # Restore mirror extractions from the home-mirrors/ subdirectory.
  local mirror_dir="${bak_dir}/home-mirrors"
  if [[ -d "$mirror_dir" ]]; then
    for mirror in "$mirror_dir"/elpa-mirror-emacs-*; do
      [[ -e "$mirror" ]] || continue
      local mirror_name="$(basename "$mirror")"
      local dest="${HOME}/${mirror_name}"
      if [[ -e "$dest" ]]; then
        echo "   archiving current ${mirror_name} -> .backups/${NOW}-rolledback/home-mirrors/${mirror_name}"
        mkdir -p "${ROLLFORWARD_DIR}/home-mirrors"
        mv "$dest" "${ROLLFORWARD_DIR}/home-mirrors/${mirror_name}"
      fi
      echo "   restoring ${mirror_name}"
      mv "$mirror" "$dest"
    done
  fi

  # Remove the now-empty backup directory.
  rmdir "$bak_dir" 2>/dev/null || true
}

rollback_legacy() {
  local stamp="$1"

  rollback_in() {
    local dir="$1"
    shopt -s nullglob
    for bak in "$dir"/*.pre-toolkit-"$stamp"; do
      [[ -e "$bak" ]] || continue
      local orig="${bak%.pre-toolkit-$stamp}"
      if [[ -e "$orig" ]]; then
        echo "   archiving current $(basename "$orig") -> $(basename "$orig").rolled-back-${NOW}"
        mv "$orig" "${orig}.rolled-back-${NOW}"
      fi
      echo "   restoring $(basename "$bak") -> $(basename "$orig")"
      mv "$bak" "$orig"
    done
  }

  echo ">> Restoring from legacy flat backup (stamp: ${stamp})"
  rollback_in "$EMACS_D"
  rollback_in "$HOME"
}

# Try directory-based first; fall back to legacy flat if no .backups/ dir.
if [[ -d "${BACKUPS_DIR}/${LATEST}" ]]; then
  rollback_dir "$LATEST"
else
  rollback_legacy "$LATEST"
fi

echo
echo "Rollback complete. Post-install state archived under ${ROLLFORWARD_DIR}."
echo "To roll forward again: restore items from that directory."
