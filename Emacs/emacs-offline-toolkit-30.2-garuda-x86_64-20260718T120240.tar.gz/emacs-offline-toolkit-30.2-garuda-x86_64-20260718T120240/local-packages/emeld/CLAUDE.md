# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```sh
# Run the ERT test suite
emacs --batch -l emeld-tests.el

# Interactive smoke test from the repo root (-L . so the parts resolve)
emacs -Q -L . -l emeld.el --eval '(emeld-diff "dir1" "dir2")'
# Git revision comparison (in a work tree): pick two revs, or a rev vs working tree
emacs -Q -L . -l emeld.el --eval '(emeld-git-diff default-directory "HEAD~3" "HEAD")'

# Byte-compile all modules (must pass with zero warnings)
emacs --batch -L . -f batch-byte-compile emeld-core.el emeld-git.el emeld-sidebar.el emeld-dired.el emeld.el

# Benchmarks
test/bench.sh small [N]   # synthetic tree, default 10000 files
test/bench.sh large       # Linux kernel v7.0 vs v6.19 (requires git clone)
# bench.sh appends each run to BENCHMARKS.org by default. Env vars:
#   EMELD_BENCH_RECORD=0  print only   EMELD_BENCH_SAME=1  also run the S pass
#   EMELD_BENCH_FILE=PATH redirect the log
```

`emeld-tests.el` puts the repo root on `load-path` and `(require 'emeld)`, which pulls in all modules — so tests must run from the repo root. There is no Makefile, no CI, and no package manager config.

`BENCHMARKS.org` is the timing log. `M-x emeld-benchmark-record` (with `emeld-benchmark` non-nil) and `test/bench.sh` both append dated entries stamped with machine specs and the emeld git revision (`emeld--system-info`), so runs can be compared across commits to catch regressions.

## Architecture

Multi-file Emacs Lisp package implementing a Meld-style side-by-side directory diff. Entrypoints: `emeld-diff` (and `emeld-diff-dwim`, which guesses dirs from open Dired buffers) for directory comparison, `emeld-git-diff` for git revision comparison, `emeld-sidebar` for a single-tree file explorer (see "Sidebar" below), and `emeld-dired` for a tree-navigable Dired-like file manager (see "Emeld-dired" below).

### File layout

- `emeld.el` — thin umbrella: `(require 'emeld-core/-git/-sidebar/-dired)` then `(provide 'emeld)`. Holds the package metadata. `(require 'emeld)` loads everything.
- `emeld-core.el` — the bulk: `emeld-node` struct, buffer-local state (incl. the `emeld--git-*` mode vars), faces, the async scan pipeline, filtering/gitignore, render, navigation, `emeld-mode`, file ops, presets, benchmarking, the transient, and **git utilities** shared with the others (`emeld--git-rev-label`, `emeld--git-toplevel`, `emeld--git-work-tree-p`, `emeld--git-rev-args`, `emeld--git-empty-tree`). `(provide 'emeld-core)`.
- `emeld-git.el` — `(require 'emeld-core)`. The git-diff *feature*: `emeld-git-diff`, `emeld-git-step-history`, the history stepping, `emeld--start-git-diff`/`emeld--build-git-tree`, blob/diff/commit helpers, `emeld--git-action`/`emeld--git-soft-diff`. `(provide 'emeld-git)`.
- `emeld-sidebar.el` — `(require 'emeld-core)`. The treemacs-style sidebar. `(provide 'emeld-sidebar)`.
- `emeld-dired.el` — `(require 'emeld-core)`. The tree-navigable Dired-like file manager. `(provide 'emeld-dired)`.

**Dependency direction:** core depends on nothing in the package; the feature files require core. Core *dispatches* into git from `emeld-refresh`, the file ops, `emeld--render` and the mode keymap/transient — those forward references are covered by a `declare-function` block near the top of `emeld-core.el` (runtime-safe because the umbrella loads `emeld-git` after core). The git buffer-local vars stay in core because core reads/writes them pervasively. When adding a git function that core must call, add a matching `declare-function` to that block.

### Scan pipeline

The scan is fully asynchronous to keep the UI responsive. The flow:

1. `emeld--start-diff` spawns `diff -rq` via `make-process`, passing active filter groups as `--exclude` args (built in `emeld--diff-exclude-args`).
2. The sentinel feeds raw `diff -rq` output lines to `emeld--build-tree-from-diff`, which parses lines (`emeld--parse-diff-line`) and progressively builds a node tree via `emeld--entries-to-nodes-progressive`. "Only in" directories are expanded with `directory-files-recursively`.
3. Toggling `emeld-show-same` on (after an initial `-rq` scan) runs `emeld--scan-same-async`, which merges identical files into the existing tree in chunked batches. Two methods (`emeld-same-files-method`): `list` (default) lists the left tree via `emeld-list-command` and treats as identical every left file the initial scan did not already classify as differing or left-only — reusing the initial content comparison instead of repeating it (`emeld--scan-same-list` → `emeld--process-same-files-worker`); `diff` re-runs `diff -rqs` (`emeld--scan-same-diff` → `emeld--process-same-chunk-worker`).
4. Rendering walks the `emeld-node` tree and attaches each node to its line via the `'emeld-node` text property. Standard `diff-*` faces are used so themes apply automatically.

`emeld--scan-generation` is a buffer-local counter incremented on each rescan; async callbacks check it and bail out if they belong to a stale generation. This is the cancellation mechanism — don't bypass it when adding new async work.

### Git mode (`emeld-git-diff`)

`emeld-git-diff` compares two git revisions (or a revision against the working tree / index) instead of two directories, rendering the identical node tree. It sets buffer-local `emeld--git-mode`, `emeld--git-repo`, `emeld--git-left-rev` and `emeld--git-right-rev` (each rev is a revision string or the symbol `working`/`staged`). The roots (`emeld--left-root`/`emeld--right-root`) are both pointed at the repo so directory-oriented helpers degrade gracefully.

- `emeld-refresh` branches in git mode to `emeld--start-git-diff`, which runs `git diff --name-status -z` (the rev pair → `git diff` selectors via `emeld--git-rev-args`/`emeld--git-diff-command`). `emeld--parse-git-name-status` maps `M`→different, `A`→right-only (added), `D`→left-only (deleted); a rename `R` splits into the old path (left-only) plus the new path (right-only), and a copy `C` adds only the new path. The entries feed the **same** `emeld--entries-to-nodes-progressive` builder and the same render/restore tail (`emeld--build-git-tree`).
- The tree builder probes the filesystem (`file-directory-p`, `directory-files`) to classify and unroll one-sided dirs — wrong for historical revisions, so `emeld--git-mode` guards in `emeld--make-file-node` and `emeld--entries-to-nodes(-progressive)` skip those probes. Git nodes carry the **relpath** (not an absolute path) as their side path; `git diff` reports only files, so intermediate dirs are synthesised and shown on both sides.
- File ops resolve content via git, not disk: `emeld--git-blob-buffer` (`git show REV:path`, or the on-disk file for the `working` side) backs view/ediff; `emeld--git-diff-show` shells out to `git diff` for quick diffs. Copy/delete and subdir rescan are disabled with a `user-error`. Header RET (`emeld--read-new-root`) re-selects a revision; `emeld-swap-panes` swaps the two revs and re-scans.
- `emeld--render` inserts a foldable commit-context block (`emeld--insert-git-commit-block`) between the revision header and the separator, carrying the `emeld-git-commit` text property. It is two-column: `emeld--git-commit-cell-lines` builds each side's lines and the left cell is truncated/padded to `emeld--column-width` so the right cell starts at the pane boundary, aligning each commit under its header. `emeld--git-commit-info` (`git show -s --date=iso`) fills `emeld--git-left-commit`/`emeld--git-right-commit` in `emeld--start-git-diff`; `emeld--git-commit-expanded` (toggled by `emeld-git-toggle-commit-message`, `c` or RET on the block) folds between subject-only and the full author/date/body.
- `emeld-git-step-history` walks history one commit at a time: `emeld--git-history` holds the first-parent SHA chain (newest first, capped at `emeld-git-history-limit`) and `emeld--git-history-index` the current position. `emeld--git-history-apply` sets right=`history[i]`, left=`history[i+1]` (or `emeld--git-parent-rev`, falling back to `emeld--git-empty-tree` for a root commit) and re-scans. `emeld-git-history-older` (`,`) increments the index, `emeld-git-history-newer` (`.`) decrements it; both auto-build a walk via `emeld--git-history-ensure` if none is active. The virtual index `-1` is the working-tree slot: `emeld--git-history-apply` sets left=`history[0]`, right=`working`, showing uncommitted changes on top of the newest commit. `emeld-git-history-newer` only steps into it when `emeld--git-history-head-p` confirms `history[0]` is the current HEAD (otherwise the working tree would be diffed against an arbitrary older commit); the header-line shows `[hist WT/N]` there. `emeld--git-rev-label` abbreviates full SHAs, renders the empty tree as `∅ (root)`, and shows a SHA that equals HEAD as `HEAD (SHA)` — HEAD is resolved by `emeld--git-resolve-head` and cached buffer-locally in `emeld--git-head-sha` (refreshed each scan in `emeld--start-git-diff`, which also re-derives the pane-header labels so the cache is always populated first), avoiding a git call on every header-line redisplay.
- `emeld-show-same` in git mode enumerates the left rev with `git ls-tree -r` (or `git ls-files`) and merges every path the diff did not flag as changed (`emeld--scan-same-git` → the shared `emeld--process-same-files-worker`). `.gitignore` filtering is moot for committed trees, so the gitignore pre-warm is skipped.

### Filter groups

`emeld-filter-groups` is a list of `(NAME [ACTIVE-BOOL] GLOBS...)`. If the second element is `t`/`nil` it sets the default active state; otherwise everything after NAME is a glob. The `safe-local-variable` predicate enforces this shape so projects can override via `.dir-locals.el`. Globs containing `/` match the relative path; others match the basename only (see `emeld--filtered-p`). Filters are pushed down to `diff` as `--exclude`, not applied post-hoc.

### Node model and rendering

- `emeld-node` is a cl-struct holding the whole tree; mutated in place during the scan.
- Buffer-local state (`emeld--root-node`, `emeld--left-root`, `emeld--right-root`, `emeld--marked-paths`, `emeld--saved-expanded`, etc.) is reset on each rescan.
- `emeld--saved-point-path` / `emeld--saved-point-col` preserve cursor location across rerenders.
- The view toggles (`emeld-show-same`, `emeld-show-different`, `emeld-show-added`, `emeld-show-strikethrough`, `emeld-show-tree-lines`) are `defcustom`s but treated as buffer-local in the mode.
- Inline diff peek (`TAB` on a file): `emeld-cycle-subtree` delegates a non-dir node to `emeld-toggle-inline-diff`, which caches propertized diff lines in the node's `inline-diff` slot (nil = collapsed). `emeld--inline-diff-text` produces the unified diff — `git diff` between the two revs in git mode (capturing `emeld--git-repo`/revs *before* `with-temp-buffer`, since those locals read nil inside it), else `emeld--write-patch-hunk` — and `emeld--inline-diff-faceify` tags each line with a `diff-*` face. `emeld--render-nodes` inserts the cached lines beneath the file row, indented and carrying the same `'emeld-node` (plus `'emeld-inline-diff`) so navigation and a second `TAB` act on the file. The cache is dropped naturally on rescan (the tree is rebuilt).

### Sidebar (`emeld-sidebar`)

A treemacs-style **single-tree** file explorer (not a diff), in `emeld-sidebar.el`. It reuses the `emeld-node` struct, the expand/collapse helpers (`emeld--walk-set-expanded`) and the tree-line/face conventions, but has its **own** render path (`emeld--sidebar-render` / `emeld--sidebar-render-nodes`, one column) so the diff renderer stays untouched. Its own major mode `emeld-sidebar-mode` (derived from `special-mode`) and keymap `emeld-sidebar-mode-map`. The current file is marked with an explicit overlay (`emeld--sidebar-hl-overlay`, face `emeld-sidebar-highlight-face`), **not** `hl-line-mode` — the latter only updates for the selected window, so it wouldn't track the file while you work in another window.

- One singleton buffer (`emeld--sidebar-buffer-name`) docked via `display-buffer-in-side-window` (`emeld-sidebar-position`/`-width`), dedicated with `no-delete-other-windows`. Re-running `emeld-sidebar` deletes the window.
- Root via `emeld--sidebar-project-root`: git toplevel (`emeld--git-toplevel`) → `project.el` → the file's directory; stored buffer-local in `emeld--sidebar-root`. The tree reuses buffer-local `emeld--root-node`.
- **Lazy** per-directory loading: the node's `scanned` slot doubles as "children loaded?"; `emeld--sidebar-populate` reads one level with `directory-files`. `emeld--sidebar-visible-p` hides dotfiles (unless `emeld-sidebar-show-hidden`) and applies default-active filter-group **basename** globs.
- `emeld--sidebar-node-for` descends to a path, populating+expanding each ancestor; `emeld--sidebar-reveal` uses it then sets `emeld--sidebar-current` and moves point. `emeld-sidebar-refresh` records expanded paths (`emeld--sidebar-expanded-paths`), rebuilds, and re-expands.
- Follow: global minor mode `emeld-sidebar-follow-mode` hooks **both** `window-selection-change-functions` (switching windows) and `window-buffer-change-functions` (opening a file in the current window — the selection-change hook alone misses this) → `emeld--sidebar-follow`, which reveals the active window's file (guarded by `emeld--sidebar-current` to avoid redundant re-renders and recursion). `emeld--sidebar-reveal` also calls `set-window-point` on the sidebar window so a non-selected sidebar still scrolls to the file. File ops resolve to the main window via `emeld--sidebar-main-window` (`get-mru-window` excluding the dedicated sidebar).

### Emeld-dired (`emeld-dired`)

A tree-navigable, **Dired-like** single-tree file manager, in `emeld-dired.el`. Like the sidebar it is a single tree (not a diff) reusing the `emeld-node` struct, the lazy per-directory load pattern (`scanned` slot = "children loaded?"), the tree-line/face conventions and `emeld--walk-set-expanded`, with its **own** one-column render path (`emeld--dired-render` / `emeld--dired-render-nodes`). Unlike the sidebar it is **not** a docked side window and does **not** follow the active file: it takes over its window via `pop-to-buffer-same-window` (like Dired) and is mark/operation oriented. Own major mode `emeld-dired-mode` (from `special-mode`) and keymap `emeld-dired-mode-map`.

- Entry points: `emeld-dired` roots at the current Dired directory (`emeld--dired-current-directory` → `dired-current-directory` when in `dired-mode`, else `default-directory`; prefix arg prompts), `emeld-dired-find` prompts for a directory. Both go through `emeld--dired-open`, which gives one buffer per root (`emeld--dired-buffer-name`). Root stored buffer-local in `emeld--dired-root`; the tree reuses buffer-local `emeld--root-node`. `^` (`emeld-dired-up-directory`) re-roots at the parent.
- Lazy load: `emeld--dired-populate` / `emeld--dired-dir-children` read one level with `directory-files`; `emeld--dired-visible-p` hides dotfiles unless `emeld-dired-show-hidden` (default **t**, unlike the sidebar — Dired shows dotfiles; filter groups are **not** applied here). `emeld--dired-node-for` / `emeld--dired-goto-path` mirror the sidebar's descend/seek helpers.
- **Marking** is Dired-style and single-column: buffer-local hash `emeld--dired-marks` maps an absolute path to a mark char — `emeld--dired-mark-char` (`*`) or `emeld--dired-flag-char` (`D`). The mark glyph is rendered in column 0 (faces `emeld-dired-mark-face` / `emeld-dired-flag-face`). This is independent of the diff view's two-sided `emeld--marked-paths`. `emeld--dired-targets` implements Dired semantics: ordinary `*` marks win, else the node at point.
- File ops (`emeld-dired-do-delete`/`-copy`/`-rename`, `-do-flagged-delete` for `D` flags, `-create-directory`/`-create-file`) use plain Emacs primitives (`emeld--delete-one` from core for trash-aware delete, `copy-file`/`copy-directory`, `rename-file`, `make-directory`). Every op ends in `emeld--dired-after-op`, which prunes marks for vanished paths (`emeld--dired-prune-missing-marks`), rebuilds the tree preserving expansion (`emeld--dired-expanded-paths`) and optionally reveals a result path. The header line shows live marked/flagged counts.

## Conventions specific to this package

- `lexical-binding: t` everywhere. In async chains, prefer `car`/`cdr` over `pop` (gv-let-place is incompatible with closures here — there's a comment in AGENTS.md about this).
- The differences scan is `diff -rq` only; filtering goes through `diff`'s `--exclude`. The show-same merge may additionally enumerate files via `emeld-list-command` (`find` by default, `fd` configurable) — see `emeld-same-files-method`.
- Requires Emacs 27+ (uses `make-process` and the 4-arg `copy-directory`). `file-equal-p` is used for content compare on Emacs 29+; the fallback path is bounded by `emeld-max-content-size`.
- The package is namespaced `emeld-` (public) and `emeld--` (private). Faces use `emeld-*-face`.
- `emeld-benchmark` (when non-nil) collects phase timings into `emeld--benchmark-data`; `emeld--bench-report` prints them. Used by `test/bench.sh`.
