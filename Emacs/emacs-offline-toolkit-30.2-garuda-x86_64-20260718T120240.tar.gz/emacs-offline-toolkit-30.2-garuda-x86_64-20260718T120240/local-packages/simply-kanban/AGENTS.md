# AGENTS.md

## Commands

```
make deps       # install package-lint into ./.elpa (required before `make lint`)
make compile    # byte-compile with warnings-as-errors
make test       # ERT suite
make checkdoc   # checkdoc
make lint       # package-lint (run `make deps` first)
make all        # compile + test + checkdoc (does NOT include lint)
```

CI runs `compile → test → checkdoc` on Emacs 27.2–30.1+snapshot, and `lint` separately on 30.1.

## Testing

- Tests are in `tests/simply-kanban-tests.el`, run via `tests/init.el` bootstrap.
- Tests that exercise TODO-keyword parsing **must** use the `sk-test-with-org` macro, which writes content to a temp file and opens it. Inserting text into an already-initialized Org buffer does not trigger `#+TODO:` parsing.
- No external runtime dependencies; Org is built in.

## Style

- `lexical-binding: t` is required in all `.el` files.
- `make compile` fails on any byte-compiler warning — fix warnings, don't suppress them.
- Follow checkdoc and package-lint conventions (header format, `;;; Commentary:`, `;;; Code:` sections, `provide` at end).
