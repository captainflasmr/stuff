#!/usr/bin/env bash
# setup.sh — install the bundled Emacs toolkit on an offline machine.
# Run from inside the extracted toolkit directory.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EMACS_D="${HOME}/.emacs.d"
STAMP="$(date +%Y%m%dT%H%M%S)"
BACKUP_DIR="${EMACS_D}/.backups/${STAMP}"

echo ">> Target: ${EMACS_D}"
mkdir -p "$EMACS_D"

# Back up existing files/directories into a single timestamped directory.
# This keeps ~/.emacs.d and ~/ clean — all backups for this install live
# under ~/.emacs.d/.backups/<STAMP>/, and rollback just swaps that set back.
backup_item() {
  local src="$1" dest_base="$2"
  if [[ ! -e "$src" ]]; then
    return 0
  fi
  mkdir -p "$(dirname "$dest_base")"
  echo "   backing up $(basename "$src") -> .backups/${STAMP}/$(basename "$dest_base")"
  mv "$src" "$dest_base"
}

mkdir -p "$BACKUP_DIR"

# Back up existing init files so we don't silently clobber an existing setup.
for f in init.el early-init.el abbrev_defs init-starter.el init-starter-coding.el init-on-windows.el; do
  if [[ -e "${EMACS_D}/${f}" && ! -L "${EMACS_D}/${f}" ]]; then
    backup_item "${EMACS_D}/${f}" "${BACKUP_DIR}/${f}"
  fi
done

# Move any existing ~/.emacs.d/elpa/ aside so `my/ensure-package' sees every
# package as not-installed on next launch and reinstalls from the freshly
# extracted mirror. Without this, stale .elc/.eln from the old mirror stay put.
if [[ -d "${EMACS_D}/elpa" ]]; then
  backup_item "${EMACS_D}/elpa" "${BACKUP_DIR}/elpa"
fi

# Move any pre-existing mirror extractions aside too — same reason, and avoids
# the init.el's `string>' sort silently picking up stale mirrors after upgrades.
# They go into a subdirectory so they don't collide with .emacs.d items.
_mirror_count=0
for old in "${HOME}"/elpa-mirror-emacs-*; do
  [[ -d "$old" ]] || continue
  _mirror_count=$(( _mirror_count + 1 ))
  backup_item "$old" "${BACKUP_DIR}/home-mirrors/$(basename "$old")"
done

# Extract ELPA mirror into $HOME (init.el auto-detects ~/elpa-mirror-emacs-*).
for m in "$HERE"/elpa-mirror-*.tar.gz; do
  [[ -f "$m" ]] || continue
  echo ">> Extracting $(basename "$m") into $HOME"
  tar -xzf "$m" -C "$HOME"
done

# Install the literate config directories.
for d in Emacs-vanilla Emacs-DIYer; do
  if [[ -d "${HERE}/${d}" ]]; then
    if [[ -d "${EMACS_D}/${d}" ]]; then
      backup_item "${EMACS_D}/${d}" "${BACKUP_DIR}/${d}"
    fi
    echo ">> Installing ${d} to ${EMACS_D}/${d}"
    mkdir -p "${EMACS_D}/${d}"
    cp -a "${HERE}/${d}/." "${EMACS_D}/${d}/"
  fi
done

# Install local-packages if bundled. Source only, no byte-compilation — the
# target Emacs will compile on first load if it wants to.
if [[ -d "${HERE}/local-packages" ]]; then
  if [[ -d "${EMACS_D}/local-packages" ]]; then
    backup_item "${EMACS_D}/local-packages" "${BACKUP_DIR}/local-packages"
  fi
  echo ">> Installing local-packages to ${EMACS_D}/local-packages"
  mkdir -p "${EMACS_D}/local-packages"
  cp -a "${HERE}/local-packages/." "${EMACS_D}/local-packages/"
fi

# Install init.el and (optional) early-init.el.
cp "${HERE}/init.el" "${EMACS_D}/init.el"
[[ -f "${HERE}/early-init.el" ]] && cp "${HERE}/early-init.el" "${EMACS_D}/early-init.el"
[[ -f "${HERE}/abbrev_defs" ]] && cp "${HERE}/abbrev_defs" "${EMACS_D}/abbrev_defs"

# Install starter snippet if bundled. Does NOT auto-load — opt in from init.el
# with: (load (expand-file-name "init-starter" user-emacs-directory) t t)
if [[ -f "${HERE}/init-starter.el" ]]; then
  cp "${HERE}/init-starter.el" "${EMACS_D}/init-starter.el"
  echo ">> Starter snippet installed at ${EMACS_D}/init-starter.el (not auto-loaded)"
fi

# Install coding companion starter if bundled. Also NOT auto-loaded — opt in
# with: (load (expand-file-name "init-starter-coding" user-emacs-directory) t t)
if [[ -f "${HERE}/init-starter-coding.el" ]]; then
  cp "${HERE}/init-starter-coding.el" "${EMACS_D}/init-starter-coding.el"
  echo ">> Coding companion installed at ${EMACS_D}/init-starter-coding.el (not auto-loaded)"
fi

# Install Windows starter if bundled. NOT auto-loaded — opt in from init.el
# with: (load (expand-file-name "init-on-windows" user-emacs-directory) t t)
if [[ -f "${HERE}/init-on-windows.el" ]]; then
  cp "${HERE}/init-on-windows.el" "${EMACS_D}/init-on-windows.el"
  echo ">> Windows starter installed at ${EMACS_D}/init-on-windows.el (not auto-loaded)"
fi

# Install docs/ drop-zone (coding guide, reference material).
if [[ -d "${HERE}/docs" ]]; then
  if [[ -d "${EMACS_D}/docs" ]]; then
    backup_item "${EMACS_D}/docs" "${BACKUP_DIR}/docs"
  fi
  echo ">> Installing docs/ to ${EMACS_D}/docs"
  mkdir -p "${EMACS_D}/docs"
  cp -a "${HERE}/docs/." "${EMACS_D}/docs/"
fi

# Install standalone tools (MicroEmacs, mg) if bundled.
if [[ -d "${HERE}/tools" ]]; then
  BIN_DIR="${EMACS_D}/bin"
  echo ">> Installing tools/ to ${BIN_DIR}"
  mkdir -p "${BIN_DIR}"
  cp -a "${HERE}/tools/." "${BIN_DIR}/"
fi

# Report on optional Emacs source.
SRC="$(ls "${HERE}"/emacs-*.tar.xz 2>/dev/null | head -n1 || true)"
if [[ -n "$SRC" && -f "$SRC" ]]; then
  echo
  echo ">> Bundled Emacs source: $(basename "$SRC")"
  echo "   To build from source:"
  echo "     tar -xf '$SRC' -C /tmp"
  echo "     cd /tmp/$(basename "$SRC" .tar.xz)"
  echo "     ./configure --prefix=\"\$HOME/.local\" && make -j\$(nproc) && make install"
fi

# Summarise backups so the user knows where to look.
_items="$(find "$BACKUP_DIR" -maxdepth 1 -mindepth 1 | wc -l)"
if [[ "$_items" -gt 0 ]]; then
  echo ">> Previous state backed up to ${EMACS_D}/.backups/${STAMP}/"
fi
# Old flat backups (pre-toolkit-<STAMP> suffix) are still present if setup
# was run with an older version of this script. List them as a reminder.
_old_count=0
for _old in "${EMACS_D}"/*.pre-toolkit-*; do
  [[ -e "$_old" ]] || continue
  _old_count=$(( _old_count + 1 ))
done
for _old in "${HOME}"/elpa-mirror-emacs-*.pre-toolkit-*; do
  [[ -e "$_old" ]] || continue
  _old_count=$(( _old_count + 1 ))
done
if [[ "$_old_count" -gt 0 ]]; then
  echo "!! ${_old_count} old .pre-toolkit-* backup(s) found under ${EMACS_D} and ${HOME}."
  echo "   To clean up: rm -rf ${EMACS_D}/*.pre-toolkit-* ${HOME}/elpa-mirror-emacs-*.pre-toolkit-*"
fi

echo
echo "Done. Launch Emacs; *Messages* should report:"
echo "  my/offline-packages=t  dir=/home/you/elpa-mirror-emacs-..."
