@echo off
setlocal enabledelayedexpansion

:: Ensure System32 is on PATH (robocopy, move, etc. live there).
set "WIN_PATH=%SystemRoot%\System32;%SystemRoot%;%SystemRoot%\System32\Wbem;%SystemRoot%\System32\WindowsPowerShell\v1.0\"
set "PATH=%WIN_PATH%;%PATH%"

:: Accept either EMACS_D path (ending with .emacs.d) or HOME path.
:: Must match the same resolution as setup.bat for correct rollback.
if not "%1"=="" (
  set "TARGET=%1"
  :: Strip trailing separator if present
  if "!TARGET:~-1!"=="\" set "TARGET=!TARGET:~0,-1!"
  if "!TARGET:~-1!"=="/" set "TARGET=!TARGET:~0,-1!"
  :: Check if it's an .emacs.d path (last 8 chars == ".emacs.d")
  if /i "!TARGET:~-8!"==".emacs.d" (
    set EMACS_D=!TARGET!
    set MY_HOME=!TARGET:~0,-8!
    :: Strip any separator left at the end of MY_HOME
    if "!MY_HOME:~-1!"=="\" set MY_HOME=!MY_HOME:~0,-1!
    if "!MY_HOME:~-1!"=="/" set MY_HOME=!MY_HOME:~0,-1!
  ) else (
    set MY_HOME=!TARGET!
    set EMACS_D=!TARGET!\.emacs.d
  )
) else (
  rem Use %APPDATA% as the default HOME — must match setup.bat.
  set "MY_HOME=%APPDATA%"
  set "EMACS_D=%APPDATA%\.emacs.d"
)
set BACKUPS_DIR=%EMACS_D%\.backups
for /f %%I in ('powershell -Command "Get-Date -Format 'yyyyMMddTHHmmss'"') do set NOW=%%I

:: Find newest backup stamp from directory-based backups.
set LATEST=
for /f %%s in ('dir "%BACKUPS_DIR%" /b /o-d 2^>nul ^| findstr /r "^[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]T[0-9][0-9][0-9][0-9][0-9][0-9]$"') do (
  if not defined LATEST set LATEST=%%s
)

if not defined LATEST (
  echo No backups found under %BACKUPS_DIR%\
  goto :eof
)

echo Available backup stamps (newest first^):
for /f %%s in ('dir "%BACKUPS_DIR%" /b /o-d 2^>nul ^| findstr /r "^[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]T[0-9][0-9][0-9][0-9][0-9][0-9]$"') do (
  if defined LATEST (
    if "%%s"=="!LATEST!" (
      echo   %%s ^<- default
    ) else (
      echo   %%s
    )
  )
)
echo.
set /p ans="Roll back to !LATEST!? [y/N] "
if /i not "!ans!"=="y" (
  echo Aborted.
  goto :eof
)

:: Archive current state so re-rollforward is possible.
set ROLLFORWARD_DIR=%BACKUPS_DIR%\!LATEST!-rolledback
mkdir "!ROLLFORWARD_DIR!" 2>nul

:: Restore from directory backup.
set bak_dir=%BACKUPS_DIR%\!LATEST!
if exist "!bak_dir!" (
  echo ^>^> Restoring from directory backup: !LATEST!

  for %%i in (init.el early-init.el abbrev_defs init-starter.el init-starter-coding.el init-on-windows.el elpa local-packages bin docs Emacs-vanilla Emacs-DIYer) do (
    if exist "!bak_dir!\%%i" (
      if exist "%EMACS_D%\%%i" (
        echo    archiving current %%i -^> !NOW!-rolledback\%%i
        move "%EMACS_D%\%%i" "!ROLLFORWARD_DIR!\%%i" >nul
      )
      echo    restoring %%i
      move "!bak_dir!\%%i" "%EMACS_D%\%%i" >nul
    )
  )

  :: Restore mirror extractions from the home-mirrors/ subdirectory.
  if exist "!bak_dir!\home-mirrors" (
    for /d %%d in ("!bak_dir!\home-mirrors\elpa-mirror-emacs-*") do (
      if exist "%%d" (
        set mirror_name=%%~nxd
        if exist "%MY_HOME%\!mirror_name!" (
          if not exist "!ROLLFORWARD_DIR!\home-mirrors" mkdir "!ROLLFORWARD_DIR!\home-mirrors"
          echo    archiving current !mirror_name! -^> !NOW!-rolledback\home-mirrors\!mirror_name!
          move "%MY_HOME%\!mirror_name!" "!ROLLFORWARD_DIR!\home-mirrors\!mirror_name!" >nul
        )
        echo    restoring !mirror_name!
        move "%%d" "%MY_HOME%\!mirror_name!" >nul
      )
    )
  )

  rmdir "!bak_dir!" 2>nul
)

echo.
echo Rollback complete. Post-install state archived under !ROLLFORWARD_DIR!.
