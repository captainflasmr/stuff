;; -*- lexical-binding: t; -*-
;;
;; Rendered from init.el.in by create-install.sh for Emacs 30.2.
;; Do not edit the rendered init.el by hand — edit the template or the
;; packages/emacs-<VER>.el list and re-render.

;;
;; -> core-configuration
;;
(let ((f (expand-file-name "~/.emacs.d/Emacs-vanilla/init.el")))
  (when (file-exists-p f) (load-file f)))

;;
;; -> package-archives
;;
(require 'package)

;; When my/offline-packages is t (default), init.el uses a local ELPA mirror
;; discovered by globbing ~/elpa-mirror-emacs-*/.  When no mirror is found but
;; my/offline-packages is still t, package-archives is left unset (nil) so
;; Emacs never reaches out to the network — safe for air-gapped machines.
;; Set to nil in early-init.el or via --eval to force online archives
;; (MELPA / ELPA / Org), e.g. during toolkit build:
;;   emacs --batch --eval '(setq my/offline-packages nil)' -l init.el
(unless (boundp 'my/offline-packages)
  (setq my/offline-packages t))

;; Primary: glob in HOME (~/) for the mirror directory.
;; Fallback: glob in the parent of user-emacs-directory (handles portable
;; Windows installs where HOME may not be set).
(setq my/offline-packages-dir
      (or (car (sort (file-expand-wildcards
                      (expand-file-name "~/elpa-mirror-emacs-*"))
                     #'string>))
          (car (sort (file-expand-wildcards
                      (expand-file-name
                       "../elpa-mirror-emacs-*"
                       (file-name-as-directory
                        (expand-file-name user-emacs-directory))))
                     #'string>))))

(message "my/offline-packages=%s  dir=%s"
         my/offline-packages
         (or my/offline-packages-dir "<none found>"))

(cond
 ((and my/offline-packages my/offline-packages-dir)
  (setq package-archives
        `(("local" . ,(file-name-as-directory my/offline-packages-dir)))))
 (my/offline-packages
  ;; offline mode but no mirror found — don't reach out to the network
  (setq package-archives nil)
  (message "my/offline-packages-dir not found; no package archives configured"))
 (t
  (setq package-archives '(("melpa"  . "https://melpa.org/packages/")
                           ("elpa"   . "https://elpa.gnu.org/packages/")
                           ("nongnu" . "https://elpa.nongnu.org/nongnu/")))))

(package-initialize)
(setq load-prefer-newer t)

;; Skip GPG signature verification on archive refresh — saves downloading
;; and verifying .sig files for every archive.  Safe in the build context:
;; first-build traffic goes over TLS to known-good archives; subsequent
;; builds use the self-controlled local mirror.
(setq package-check-signature nil)

;;
;; -> local-packages
;; Top-level dir + every immediate subdirectory under ~/.emacs.d/local-packages
;; joins load-path, so `foo.el' or `foo/foo.el' can be `require'd directly.
;;
(let ((dir (expand-file-name "~/.emacs.d/local-packages")))
  (when (file-directory-p dir)
    (add-to-list 'load-path dir)
    (dolist (sub (directory-files dir t "^[^.]"))
      (when (file-directory-p sub)
        (add-to-list 'load-path sub)))))

(defun my/ensure-package (pkg)
  "Install PKG from configured archives if it is not already present.
Failures (e.g. package requires a newer Emacs) are logged, not fatal."
  (unless (package-installed-p pkg)
    (unless package-archive-contents
      (package-refresh-contents))
    (condition-case err
        (package-install pkg)
      (error (message "my/ensure-package: skipping %s (%s)" pkg err)))))

;;
;; -> package-list (injected)
;;
(dolist (pkg '(async chess cmake-mode corfu csv-mode dape demap diff-hl doc-view-follow doom-themes dumb-jump ef-themes gnuplot gruvbox-theme highlight-indent-guides htmlize i3wm-config-mode magit markdown-mode modus-themes outline-indent ollama-buddy package-lint protobuf-mode selected-window-accent-mode simply-annotate timu-caribbean-theme timu-rouge-theme timu-spacegrey-theme typescript-mode web-mode yaml-mode kotlin-mode powershell zig-mode))
  (my/ensure-package pkg))

;;
;; -> dired-z (local package, see local-packages/)
;;
(use-package dired-z
  :load-path "~/.emacs.d/local-packages/dired-z"
  :demand t
  :bind (:map my-jump-keymap
         ("z" . dired-z-jump))
  :config
  (dired-z-dired-mode 1))

;;
;; -> custom-faces
;;
(condition-case err
    (custom-set-faces
     '(default ((t (:family "Monospace" :foundry "ADBO" :slant normal :weight regular :height 100 :width normal))))
     '(completions-common-part ((t (:foreground "#87ceeb"))))
     '(completions-first-difference ((t (:foreground "#ffb6c1"))))
     '(cursor ((t (:background "coral"))))
     '(ediff-current-diff-A ((t (:extend t :background "#b5daeb" :foreground "#000000"))))
     '(ediff-even-diff-A ((t (:background "#bafbba" :foreground "#000000" :extend t))))
     '(ediff-fine-diff-A ((t (:background "#f4bd92" :foreground "#000000" :extend t))))
     '(ediff-odd-diff-A ((t (:background "#b8fbb8" :foreground "#000000" :extend t))))
     '(fixed-pitch ((t (:family "Monospace" :height 110))))
     '(font-lock-warning-face ((t (:foreground "#930000" :inverse-video nil))))
     '(fringe ((t (:foreground "#2d3743" :background "#2d3743"))))
     '(hl-line ((t (:background "#3636424250b6"))))
     '(icomplete-first-match ((t (:foreground "#7c7c75" :background "#3a3a3a" :weight bold))))
     '(icomplete-selected-match ((t (:foreground "#ffffff" :background "#5f87af" :weight bold))))
     '(indent-guide-face ((t (:background "#282828" :foreground "#666666"))))
     '(mode-line ((t (:height 140 :underline nil :overline nil :box nil))))
     '(mode-line-inactive ((t (:height 140 :underline nil :overline nil :box nil))))
     '(org-level-1 ((t (:inherit default :weight regular :height 1.0))))
     '(org-level-2 ((t (:inherit default :weight light :height 1.0))))
     '(org-level-3 ((t (:inherit default :weight light :height 1.0))))
     '(org-level-4 ((t (:inherit default :weight light :height 1.0))))
     '(org-level-5 ((t (:inherit default :weight light :height 1.0))))
     '(org-level-6 ((t (:inherit default :weight light :height 1.0))))
     '(org-link ((t (:underline nil))))
     '(org-tag ((t (:height 0.9))))
     '(tab-bar ((t (:inherit default :background "#2d3743" :foreground "#e1e1e0"))))
     '(tab-bar-tab ((t (:inherit 'highlight :background "coral" :foreground "#000000"))))
     '(tab-bar-tab-inactive ((t (:inherit default :background "#2d3743" :foreground "#e1e1e0" :box (:line-width 1 :color "#2d3743" :style flat-button)))))
     '(variable-pitch ((t (:family "DejaVu Sans" :height 120 :weight normal))))
     '(vertical-border ((t (:foreground "#000000"))))
     '(widget-button ((t (:inherit fixed-pitch :weight regular))))
     '(window-divider ((t (:foreground "black")))))
  (error (message "custom-set-faces skipped: %s" err)))
