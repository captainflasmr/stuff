;;; dired-z.el --- Jump to frequently entered directories  -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Chen Yibin

;; Author: Chen Yibin
;; Version: 0.1.0
;; Package-Requires: ((emacs "29.1"))
;; Keywords: files, convenience
;; URL: https://github.com/yibie/dired-z

;; This file is not part of GNU Emacs.

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; dired-z records successfully entered local directories and opens the
;; highest-count match directly in Dired.
;;
;; Enable automatic recording with:
;;
;;   (dired-z-mode 1)
;;
;; Then call `dired-z-open', or `dired-z-jump' to pick from a ranked
;; minibuffer-completion list.  To accept the same indexed queries from the
;; ordinary `dired' prompt, additionally enable `dired-z-dired-mode'.
;; Loading this library alone does not install hooks or alter Dired.

;;; Code:

(defgroup dired-z nil
  "Jump to frequently entered directories."
  :group 'dired
  :prefix "dired-z-")

(defcustom dired-z-file (locate-user-emacs-file "dired-z.eld")
  "File used to persist the directory index."
  :type 'file
  :group 'dired-z)

(defconst dired-z--data-version 1)

(defvar dired-z--index (make-hash-table :test #'equal))
(defvar dired-z--loaded-file nil)
(defvar dired-z--inhibit-record nil)
(defvar dired-z--last-context nil)
(defvar dired-z--inhibit-dired-integration nil)

(defun dired-z--normalize (directory)
  "Return DIRECTORY as an absolute local directory name."
  (unless (file-remote-p directory)
    (file-name-as-directory (expand-file-name directory))))

(defun dired-z--entries ()
  "Return the current index as a path-sorted alist."
  (let (entries)
    (maphash (lambda (path count)
               (push (cons path count) entries))
             dired-z--index)
    (sort entries (lambda (a b) (string< (car a) (car b))))))

(defun dired-z--quarantine-corrupt-file (error-data)
  "Move the active data file aside after ERROR-DATA was signaled."
  (let ((broken (format "%s.broken-%s"
                        dired-z--loaded-file
                        (format-time-string "%Y%m%d%H%M%S%N"))))
    (rename-file dired-z--loaded-file broken)
    (display-warning
     'dired-z
     (format "Invalid data moved to %s: %s"
             broken (error-message-string error-data))
     :warning)))

;;;###autoload
(defun dired-z-load ()
  "Replace the in-memory index with the contents of `dired-z-file'.
Return the loaded entries as a path-sorted alist."
  (let ((dired-z--inhibit-record t))
    (setq dired-z--index (make-hash-table :test #'equal)
          dired-z--loaded-file (expand-file-name dired-z-file))
    (when (file-exists-p dired-z--loaded-file)
      (condition-case error-data
          (with-temp-buffer
            (insert-file-contents dired-z--loaded-file)
            (let* ((data (read (current-buffer)))
                   (entries (plist-get data :entries)))
              (unless (and (equal (plist-get data :version) dired-z--data-version)
                           (listp entries))
                (error "Invalid dired-z data"))
              (dolist (entry entries)
                (when (and (consp entry)
                           (stringp (car entry))
                           (file-name-absolute-p (car entry))
                           (integerp (cdr entry))
                           (> (cdr entry) 0))
                  (puthash (car entry) (cdr entry) dired-z--index)))))
        (error
         (setq dired-z--index (make-hash-table :test #'equal))
         (dired-z--quarantine-corrupt-file error-data))))
    (dired-z--entries)))

(defun dired-z--ensure-loaded ()
  "Load `dired-z-file' when it is not the active index file."
  (unless (equal dired-z--loaded-file (expand-file-name dired-z-file))
    (dired-z-load)))

;;;###autoload
(defun dired-z-save ()
  "Immediately and atomically save the in-memory directory index."
  (let ((dired-z--inhibit-record t))
    (let* ((file (expand-file-name dired-z-file))
           (directory (file-name-directory file))
           (temporary nil)
           (contents (concat
                      ";;; dired-z data -*- mode: emacs-lisp; -*-\n"
                      (prin1-to-string
                       (list :version dired-z--data-version
                             :entries (dired-z--entries)))
                      "\n")))
      (make-directory directory t)
      (unwind-protect
          (progn
            (setq temporary (make-temp-file
                             (expand-file-name ".dired-z-" directory)))
            (let ((coding-system-for-write 'utf-8-unix))
              (write-region contents nil temporary nil 'silent))
            (set-file-modes temporary #o600)
            (rename-file temporary file t)
            (setq temporary nil))
        (when (and temporary (file-exists-p temporary))
          (delete-file temporary))))
    (dired-z--entries)))

;;;###autoload
(defun dired-z-record-directory (directory)
  "Record one successful entrance to local DIRECTORY.
Return its new count, or nil when DIRECTORY is remote or unavailable."
  (let ((path (dired-z--normalize directory)))
    (when (and path (file-directory-p path))
      (let ((dired-z--inhibit-record t))
        (dired-z--ensure-loaded)
        (let ((count (1+ (gethash path dired-z--index 0))))
          (puthash path count dired-z--index)
          (condition-case error-data
              (dired-z-save)
            (error
             (display-warning
              'dired-z
              (format "Could not save directory index: %s"
                      (error-message-string error-data))
              :warning)))
          count)))))

(defun dired-z--current-context ()
  "Return the current buffer and its entered local directory."
  (let* ((directory (cond
                     ((derived-mode-p 'dired-mode) default-directory)
                     (buffer-file-name
                      (file-name-directory buffer-file-name))))
         (path (and directory (dired-z--normalize directory))))
    (and path (cons (current-buffer) path))))

(defun dired-z--track-current-buffer ()
  "Record a newly current Dired or file-visiting buffer."
  (unless dired-z--inhibit-record
    (let ((context (dired-z--current-context)))
      (unless (equal context dired-z--last-context)
        (setq dired-z--last-context context)
        (when context
          (dired-z--record-safely (cdr context)))))))

(defun dired-z--record-safely (directory)
  "Record DIRECTORY without interrupting the user's current command."
  (condition-case error-data
      (dired-z-record-directory directory)
    (error
     (display-warning
      'dired-z
      (format "Could not record directory: %s"
              (error-message-string error-data))
      :warning))))

(defun dired-z--project-switch (function directory)
  "Call FUNCTION for DIRECTORY and record the resulting project entry."
  (let ((result (let ((dired-z--inhibit-record t))
                  (funcall function directory))))
    (let ((root (dired-z--normalize directory))
          (context (dired-z--current-context)))
      (when root
        (dired-z--record-safely root))
      (when (and context (not (equal (cdr context) root)))
        (dired-z--record-safely (cdr context)))
      (setq dired-z--last-context context))
    result))

;;;###autoload
(define-minor-mode dired-z-mode
  "Record directories actually entered through Dired and file buffers."
  :global t
  :group 'dired-z
  (if dired-z-mode
      (unless (memq #'dired-z--track-current-buffer buffer-list-update-hook)
        (setq dired-z--last-context nil)
        (require 'project)
        (add-hook 'buffer-list-update-hook #'dired-z--track-current-buffer)
        (advice-add 'project-switch-project :around #'dired-z--project-switch)
        (dired-z--track-current-buffer))
    (remove-hook 'buffer-list-update-hook #'dired-z--track-current-buffer)
    (advice-remove 'project-switch-project #'dired-z--project-switch)))

(defun dired-z--match-p (query path)
  "Return non-nil when QUERY matches indexed PATH."
  (let* ((query (downcase query))
         (target (if (string-match-p "[/\\\\]" query)
                     path
                   (file-name-nondirectory (directory-file-name path)))))
    (string-match-p (regexp-quote query) (downcase target))))

(defun dired-z--resolve (query)
  "Return the highest-count existing directory matching QUERY."
  (dired-z--ensure-loaded)
  (let (best-path best-count)
    (maphash
     (lambda (path count)
       (when (and (file-directory-p path)
                  (dired-z--match-p query path)
                  (or (null best-count)
                      (> count best-count)
                      (and (= count best-count)
                           (string< path best-path))))
         (setq best-path path
               best-count count)))
     dired-z--index)
    best-path))

(defun dired-z--candidates ()
  "Return live indexed directories ranked by count, then path."
  (dired-z--ensure-loaded)
  (let (entries)
    (maphash (lambda (path count)
               (when (file-directory-p path)
                 (push (cons path count) entries)))
             dired-z--index)
    (mapcar
     #'car
     (sort entries
           (lambda (a b)
             (if (= (cdr a) (cdr b))
                 (string< (car a) (car b))
               (> (cdr a) (cdr b))))))))

(defun dired-z--fallback-to-dired ()
  "Read a directory using ordinary Dired."
  (let ((dired-z--inhibit-dired-integration t))
    (call-interactively #'dired)))

;;;###autoload
(defun dired-z-jump ()
  "Jump to an indexed directory chosen by minibuffer completion.
Candidates are ranked by entry count, then by absolute path; the
highest-ranked match is the default.  An empty index falls back to
ordinary Dired."
  (interactive)
  (let ((candidates (dired-z--candidates)))
    (if (null candidates)
        (dired-z--fallback-to-dired)
      (dired (completing-read
              "dired-z: " candidates nil t nil nil (car candidates))))))

;;;###autoload
(defun dired-z-open (query)
  "Open the highest-count directory matching QUERY in Dired.
An empty or unmatched query falls back to ordinary Dired."
  (interactive (list (read-string "Directory: ")))
  (cond
   ((string= query "")
    (dired-z--fallback-to-dired))
   ((file-directory-p (expand-file-name query))
    (dired (file-name-as-directory (expand-file-name query))))
   ((let ((directory (dired-z--resolve query)))
      (when directory
        (dired directory)
        t)))
   (t
    (message "dired-z: No indexed directory matches %S; falling back to Dired"
             query)
    (dired-z--fallback-to-dired))))

(defun dired-z--ordinary-read-file-name
    (prompt directory default-filename mustmatch initial predicate)
  "Read PROMPT using the ordinary file-name reader.
Pass DIRECTORY, DEFAULT-FILENAME, MUSTMATCH, INITIAL, and PREDICATE through."
  (let ((read-file-name-function nil)
        (dired-z--inhibit-dired-integration t))
    (read-file-name prompt directory default-filename
                    mustmatch initial predicate)))

(defun dired-z--read-file-name
    (prompt &optional directory default-filename mustmatch initial predicate)
  "Read PROMPT as a Dired directory query.
Fall back to ordinary file completion using DIRECTORY, DEFAULT-FILENAME,
MUSTMATCH, INITIAL, and PREDICATE."
  (let* ((query (read-string prompt initial))
         (expanded (and (not (string= query ""))
                        (expand-file-name query (or directory default-directory))))
         (match (and (not (string= query ""))
                     (not (and expanded (file-directory-p expanded)))
                     (dired-z--resolve query))))
    (cond
     ((string= query "")
      (dired-z--ordinary-read-file-name
       prompt directory default-filename mustmatch initial predicate))
     ((and expanded (file-directory-p expanded))
      (file-name-as-directory expanded))
     (match match)
     (t
      (message "dired-z: No indexed directory matches %S; falling back to Dired"
               query)
      (dired-z--ordinary-read-file-name
       prompt directory default-filename mustmatch query predicate)))))

(defun dired-z--dired-reader (function &rest arguments)
  "Call FUNCTION with ARGUMENTS and an indexed reader unless inhibited."
  (if dired-z--inhibit-dired-integration
      (apply function arguments)
    (let ((read-file-name-function #'dired-z--read-file-name))
      (apply function arguments))))

;;;###autoload
(define-minor-mode dired-z-dired-mode
  "Enhance the ordinary Dired directory prompt with dired-z queries."
  :global t
  :group 'dired-z
  (require 'dired)
  (if dired-z-dired-mode
      (progn
        (unless dired-z-mode
          (dired-z-mode 1))
        (unless (advice-member-p #'dired-z--dired-reader
                                 'dired-read-dir-and-switches)
          (advice-add 'dired-read-dir-and-switches
                      :around #'dired-z--dired-reader)))
    (advice-remove 'dired-read-dir-and-switches #'dired-z--dired-reader)))

(provide 'dired-z)
;;; dired-z.el ends here
