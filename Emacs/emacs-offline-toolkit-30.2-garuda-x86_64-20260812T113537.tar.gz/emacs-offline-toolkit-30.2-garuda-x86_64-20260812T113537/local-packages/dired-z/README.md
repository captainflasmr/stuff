# dired-z

`dired-z` brings the zoxide experience to Dired in native Emacs Lisp. It learns
which directories you actually enter, then lets you return to them by typing a
short directory name instead of completing the same path again and again.

The main interface is the ordinary `M-x dired` prompt. Enter a real path and
Dired behaves normally; enter a name from your history and `dired-z` jumps to
the best match. An unmatched query falls back to normal file-name completion,
so you can keep choosing a directory without restarting the command.

This gives Dired the same everyday convenience as zoxide while staying inside
Emacs. The index is implemented and maintained entirely in Emacs Lisp;
`dired-z` does not invoke zoxide or read or modify its database.

Requires Emacs 29.1 or later.

## Demo

![Jumping to a familiar directory from the ordinary Dired prompt](assets/PixPin_2026-08-09_10-06-15.gif)

## Setup

Put `dired-z.el` on `load-path`, then enable the Dired integration:

```elisp
(require 'dired-z)
(dired-z-dired-mode 1)
```

Now run `M-x dired` and enter either a normal path or a directory name that
`dired-z` has seen before. Recording starts automatically.

If you prefer not to change the ordinary Dired prompt, enable recording only:

```elisp
(require 'dired-z)
(dired-z-mode 1)
```

Then use `M-x dired-z-open` for indexed jumps, or `M-x dired-z-jump` to
select from all indexed directories through minibuffer completion, ranked
by visit count with the best match as the default. The package does not
bind a key.

## Comparison with zoxide.el

[`zoxide.el`](https://github.com/Vonfry/zoxide.el) is an Emacs frontend to the
external zoxide program. `dired-z` implements the directory index and the Dired
interaction entirely in Emacs Lisp.

|                   | `dired-z`                                                         | `zoxide.el`                                                                 |
|-------------------|-------------------------------------------------------------------|-----------------------------------------------------------------------------|
| Dependency        | Emacs only                                                        | The `zoxide` executable                                                     |
| Database          | Its own path and visit-count index                                | The zoxide database shared with your shell                                  |
| Recording         | Automatic while `dired-z-mode` is active                          | Call `zoxide-add`, usually from user-configured hooks                       |
| Dired interaction | Works inside the ordinary Dired prompt, or through `dired-z-open` | Uses generic callbacks; Dired integration is supplied by user configuration |
| Query result      | Opens the highest-count match directly                            | Selects from zoxide query results with `completing-read`                    |
| Ranking           | Simple visit count                                                | Delegated to zoxide                                                         |

Use `zoxide.el` when sharing one zoxide database with the shell matters. Use
`dired-z` when you want the shortest Dired workflow without an external
dependency.

## Matching

- A query without `/` matches the final directory name, ignoring case.
- A query containing `/` matches a continuous fragment of the absolute path,
  ignoring case.
- Matches are ordered by entry count descending, then by absolute path.
- Indexed directories that are currently unavailable are skipped, not
  deleted.
- An empty or unmatched query falls back to the ordinary Dired directory
  prompt.

Existing directory paths always use ordinary Dired behavior.

## Recording and data

`dired-z-mode` records actual transitions into:

- Dired directories;
- file-visiting buffers, using the file's parent directory;
- project roots selected by `project-switch-project`.

Refreshing a Dired buffer does not count as another entrance. Remote paths are
ignored. Symlinks are not resolved, so a symlink and its target remain distinct
entries.

The index stores only absolute paths and positive entry counts. It is written
immediately and atomically to `dired-z-file`, which defaults to
`dired-z.eld` under `user-emacs-directory`. The data file is designed for one
Emacs process; separate Emacs processes must not write the same file
concurrently.

## Tests

```sh
emacs -Q --batch -L . -l test/dired-z-test.el \
  -f ert-run-tests-batch-and-exit
```

## License

Copyright (C) 2026 Yibie.

`dired-z` is free software licensed under the [GNU General Public License,
version 3 or later](LICENSE).
