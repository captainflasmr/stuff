/*
 * The IEEE hereby grants a general, royalty-free license to copy, distribute,
 * display and make derivative works from this material, for all purposes,
 * provided that any use of the material contains the following
 * attribution: "Reprinted with permission from IEEE 1516.1(TM)-2025".
 * Should you require additional information, contact the Manager, Standards
 * Intellectual Property, IEEE Standards Association (stds-ipr@ieee.org).
 */

package hla.rti1516_2025.exceptions;


/**
 * Public exception class AttributeAlreadyOwned
 */

public final class AttributeAlreadyOwned extends RTIexception {
   public AttributeAlreadyOwned(String msg)
   {
      super(msg);
   }

   public AttributeAlreadyOwned(String message, Throwable cause)
   {
      super(message, cause);
   }
}
