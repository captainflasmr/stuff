;;; sysml-gen.el --- Generate MagicDraw Jython from SysML model files -*- lexical-binding: t; -*-

;; Author: James Dyer
;; Description: Parse a structured model file (Markdown or Org-mode) describing
;;   a SysML model and emit a Jython macro that builds the model in
;;   CATIA | MagicDraw via the Open API.

;;; Commentary:

;; Two-pass converter:
;;   Pass 1 (Parse): Line-by-line state machine reads Markdown into a plist AST.
;;   Validation: Cross-reference checks, duplicate IDs, required fields.
;;   Pass 2 (Emit): Walk AST in dependency order, emit Jython calls to helper functions.
;;
;; The generated Jython relies on a set of helper functions (create_package,
;; create_block, etc.) that wrap the MagicDraw Open API.  These helpers live
;; in sysml-gen-helpers.py and are automatically prepended to the output.
;;
;; User commands:
;;   M-x sysml-gen-convert   — Parse → validate → emit Jython to *SysML-Gen Output*
;;   M-x sysml-gen-validate  — Parse → validate → report only
;;   M-x sysml-gen-verify    — Parse → validate → emit → round-trip check

;;; Code:

(defvar sysml-gen--directory
  (file-name-directory (or load-file-name buffer-file-name))
  "Directory containing sysml-gen.el and sysml-gen-helpers.py.")

;;;; =========================================================================
;;;; Utility Functions
;;;; =========================================================================

(defun sysml-gen--trim (s)
  "Trim whitespace from string S."
  (string-trim s))

(defun sysml-gen--split-csv (s)
  "Split comma-separated string S into trimmed list."
  (when (and s (not (string-empty-p (sysml-gen--trim s))))
    (mapcar #'sysml-gen--trim (split-string s "," t "[ \t]+"))))

(defun sysml-gen--extract-backtick-content (s)
  "Extract content from backtick-delimited string S, e.g. `foo` → foo."
  (if (string-match "`\\([^`]+\\)`" s)
      (match-string 1 s)
    (sysml-gen--trim s)))

(defun sysml-gen--parse-table-rows (lines)
  "Parse Markdown table LINES into list of alists.
LINES should include the header row, separator row, and data rows.
Returns a list of alists keyed by header names."
  (when (>= (length lines) 3) ; header + separator + at least 1 data row
    (let* ((header-line (car lines))
           (headers (mapcar #'sysml-gen--trim
                            (seq-filter (lambda (s) (not (string-empty-p s)))
                                        (split-string header-line "|"))))
           (data-lines (cddr lines)) ; skip header and separator
           result)
      (dolist (line data-lines (nreverse result))
        (let* ((cells (mapcar #'sysml-gen--trim
                              (seq-filter (lambda (s) (not (string-empty-p s)))
                                          (split-string line "|"))))
               (alist nil))
          ;; Pad cells to header length with empty strings
          (dotimes (i (length headers))
            (push (cons (nth i headers)
                        (or (nth i cells) ""))
                  alist))
          (push (nreverse alist) result))))))

(defun sysml-gen--parse-key-value-line (line)
  "Extract key and value from `- **Key:** Value` pattern in LINE.
Returns (KEY . VALUE) or nil."
  (when (string-match "^- \\*\\*\\([^:*]+\\):\\*\\*\\s-*\\(.*\\)" line)
    (cons (sysml-gen--trim (match-string 1 line))
          (sysml-gen--trim (match-string 2 line)))))

(defun sysml-gen--varname (prefix name)
  "Generate Jython variable name from PREFIX and NAME.
Replaces spaces and non-alphanumeric chars with underscores."
  (let ((clean (replace-regexp-in-string "[^a-zA-Z0-9_]" "_" name)))
    (concat prefix clean)))

;;;; =========================================================================
;;;; Pass 1: Parse Markdown into AST
;;;; =========================================================================

(defun sysml-gen--parse-model (buffer)
  "Parse a SysML model Markdown BUFFER into a plist AST."
  (with-current-buffer buffer
    (save-excursion
      (goto-char (point-min))
      (let ((ast (list :packages nil :enumerations nil :datatypes nil
                       :blocks nil :interfaces nil :ports nil
                       :realizations nil :dependencies nil :usages nil
                       :constraint-blocks nil :constraint-props nil
                       :activities nil :state-machines nil :interactions nil))
            current-section)
        (while (not (eobp))
          (let ((line (sysml-gen--trim (buffer-substring-no-properties
                                   (line-beginning-position)
                                   (line-end-position)))))
            ;; Detect H2 sections
            (cond
             ((string-match "^## Packages$" line)
              (setq current-section :packages)
              (plist-put ast :packages (sysml-gen--parse-packages-section)))
             ((string-match "^## Enumerations$" line)
              (setq current-section :enumerations)
              (plist-put ast :enumerations (sysml-gen--parse-enumerations-section)))
             ((string-match "^## DataTypes$" line)
              (setq current-section :datatypes)
              (plist-put ast :datatypes (sysml-gen--parse-datatypes-section)))
             ((string-match "^## Blocks$" line)
              (setq current-section :blocks)
              (plist-put ast :blocks (sysml-gen--parse-blocks-section)))
             ((string-match "^## Interfaces$" line)
              (setq current-section :interfaces)
              (plist-put ast :interfaces (sysml-gen--parse-interfaces-section)))
             ((string-match "^## Ports$" line)
              (setq current-section :ports)
              (plist-put ast :ports (sysml-gen--parse-ports-section)))
             ((string-match "^## Relationships$" line)
              (setq current-section :relationships)
              (sysml-gen--parse-relationships-section ast))
             ((string-match "^## Constraints$" line)
              (setq current-section :constraints)
              (sysml-gen--parse-constraints-section ast))
             ((string-match "^## Activities$" line)
              (setq current-section :activities)
              (plist-put ast :activities (sysml-gen--parse-activities-section)))
             ((string-match "^## State Machines$" line)
              (setq current-section :state-machines)
              (plist-put ast :state-machines (sysml-gen--parse-state-machines-section)))
             ((string-match "^## Sequence Diagrams$" line)
              (setq current-section :interactions)
              (plist-put ast :interactions (sysml-gen--parse-interactions-section)))
             (t (forward-line 1)))))
        ast))))

(defun sysml-gen--collect-table-lines ()
  "Collect consecutive table lines starting from current position.
Moves point past the table."
  (let (lines)
    (while (and (not (eobp))
                (looking-at "^|"))
      (push (buffer-substring-no-properties
             (line-beginning-position) (line-end-position))
            lines)
      (forward-line 1))
    (nreverse lines)))

(defun sysml-gen--skip-blank-lines ()
  "Skip blank lines, moving point forward."
  (while (and (not (eobp))
              (looking-at "^[ \t]*$"))
    (forward-line 1)))

(defun sysml-gen--at-section-boundary-p ()
  "Return non-nil if current line starts a new H2 or H3 section."
  (looking-at "^##[# ]"))

;;; --- Packages ---

(defun sysml-gen--parse-packages-section ()
  "Parse the ## Packages table. Point is on the ## line."
  (forward-line 1)
  (sysml-gen--skip-blank-lines)
  (let ((lines (sysml-gen--collect-table-lines)))
    (sysml-gen--parse-table-rows lines)))

;;; --- Enumerations ---

(defun sysml-gen--parse-enumerations-section ()
  "Parse ## Enumerations section with H3 per enum."
  (forward-line 1)
  (let (enums)
    (while (and (not (eobp))
                (not (looking-at "^## [^#]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                               (line-beginning-position)
                               (line-end-position)))))
        (if (string-match "^### \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg literals desc)
              (forward-line 1)
              ;; Read key-value lines
              (while (and (not (eobp))
                          (not (looking-at "^##")))
                (let* ((kvline (sysml-gen--trim (buffer-substring-no-properties
                                            (line-beginning-position)
                                            (line-end-position))))
                       (kv (sysml-gen--parse-key-value-line kvline)))
                  (cond
                   ((and kv (string= (car kv) "Package"))
                    (setq pkg (cdr kv)))
                   ((and kv (string= (car kv) "Literals"))
                    (setq literals (sysml-gen--split-csv (cdr kv))))
                   ((and kv (string= (car kv) "Description"))
                    (setq desc (cdr kv)))
                   (t nil)))
                (forward-line 1))
              (push (list :name name :package pkg :literals literals :description desc) enums))
          (forward-line 1))))
    (nreverse enums)))

;;; --- DataTypes ---

(defun sysml-gen--parse-datatypes-section ()
  "Parse ## DataTypes section with H3 per datatype."
  (forward-line 1)
  (let (datatypes)
    (while (and (not (eobp))
                (not (looking-at "^## [^#]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                               (line-beginning-position)
                               (line-end-position)))))
        (if (string-match "^### \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg properties desc)
              (forward-line 1)
              ;; Read key-value and table
              (while (and (not (eobp))
                          (not (looking-at "^### \\|^## [^#]")))
                (let ((cur (sysml-gen--trim (buffer-substring-no-properties
                                        (line-beginning-position)
                                        (line-end-position)))))
                  (cond
                   ((let ((kv (sysml-gen--parse-key-value-line cur)))
                      (cond
                       ((and kv (string= (car kv) "Package"))
                        (setq pkg (cdr kv)) t)
                       ((and kv (string= (car kv) "Description"))
                        (setq desc (cdr kv)) t)
                       (t nil)))
                    (forward-line 1))
                   ((string-match "^|" cur)
                    (let ((tbl-lines (sysml-gen--collect-table-lines)))
                      (setq properties (sysml-gen--parse-table-rows tbl-lines))))
                   (t (forward-line 1)))))
              (push (list :name name :package pkg :properties properties :description desc) datatypes))
          (forward-line 1))))
    (nreverse datatypes)))

;;; --- Blocks ---

(defun sysml-gen--parse-blocks-section ()
  "Parse ## Blocks section with H3 per block, H4 property groups."
  (forward-line 1)
  (let (blocks)
    (while (and (not (eobp))
                (not (looking-at "^## [^#]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                               (line-beginning-position)
                               (line-end-position)))))
        (if (string-match "^### \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg value-props part-props ref-props
                  current-group desc)
              (forward-line 1)
              (while (and (not (eobp))
                          (not (looking-at "^### \\|^## [^#]")))
                (let ((cur (sysml-gen--trim (buffer-substring-no-properties
                                        (line-beginning-position)
                                        (line-end-position)))))
                  (cond
                   ((let ((kv (sysml-gen--parse-key-value-line cur)))
                      (cond
                       ((and kv (string= (car kv) "Package"))
                        (setq pkg (cdr kv)) t)
                       ((and kv (string= (car kv) "Description"))
                        (setq desc (cdr kv)) t)
                       (t nil)))
                    (forward-line 1))
                   ((string-match "^#### Value Properties$" cur)
                    (setq current-group :value)
                    (forward-line 1))
                   ((string-match "^#### Part Properties$" cur)
                    (setq current-group :part)
                    (forward-line 1))
                   ((string-match "^#### Reference Properties$" cur)
                    (setq current-group :ref)
                    (forward-line 1))
                   ((string-match "^_None_$" cur)
                    (forward-line 1))
                   ((string-match "^|" cur)
                    (let* ((tbl-lines (sysml-gen--collect-table-lines))
                           (rows (sysml-gen--parse-table-rows tbl-lines)))
                      (pcase current-group
                        (:value (setq value-props rows))
                        (:part (setq part-props rows))
                        (:ref (setq ref-props rows)))))
                   (t (forward-line 1)))))
              (push (list :name name :package pkg
                          :value-properties value-props
                          :part-properties part-props
                          :reference-properties ref-props
                          :description desc)
                    blocks))
          (forward-line 1))))
    (nreverse blocks)))

;;; --- Interfaces ---

(defun sysml-gen--parse-interfaces-section ()
  "Parse ## Interfaces section with H3 per interface."
  (forward-line 1)
  (let (interfaces)
    (while (and (not (eobp))
                (not (looking-at "^## [^#]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                               (line-beginning-position)
                               (line-end-position)))))
        (if (string-match "^### \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg operations desc)
              (forward-line 1)
              (while (and (not (eobp))
                          (not (looking-at "^### \\|^## [^#]")))
                (let* ((cur (sysml-gen--trim (buffer-substring-no-properties
                                         (line-beginning-position)
                                         (line-end-position))))
                       (kv (sysml-gen--parse-key-value-line cur)))
                  (cond
                   ((and kv (string= (car kv) "Package"))
                    (setq pkg (cdr kv)))
                   ((and kv (string= (car kv) "Operations"))
                    ;; Skip, operations follow as bullet sub-items
                    )
                   ((and kv (string= (car kv) "Description"))
                    (setq desc (cdr kv)))
                   ((string-match "^- \\([A-Za-z_][A-Za-z0-9_]*\\)$" cur)
                    (push (match-string 1 cur) operations))
                   (t nil)))
                (forward-line 1))
              (push (list :name name :package pkg
                          :operations (nreverse operations)
                          :description desc)
                    interfaces))
          (forward-line 1))))
    (nreverse interfaces)))

;;; --- Ports ---

(defun sysml-gen--parse-ports-section ()
  "Parse ## Ports table."
  (forward-line 1)
  (sysml-gen--skip-blank-lines)
  (let ((lines (sysml-gen--collect-table-lines)))
    (sysml-gen--parse-table-rows lines)))

;;; --- Relationships ---

(defun sysml-gen--parse-relationships-section (ast)
  "Parse ## Relationships with H3 sub-sections, storing into AST."
  (forward-line 1)
  (while (and (not (eobp))
              (not (looking-at "^## [^#]")))
    (let ((line (sysml-gen--trim (buffer-substring-no-properties
                             (line-beginning-position)
                             (line-end-position)))))
      (cond
       ((string-match "^### Realizations$" line)
        (forward-line 1)
        (sysml-gen--skip-blank-lines)
        (plist-put ast :realizations
                   (sysml-gen--parse-table-rows (sysml-gen--collect-table-lines))))
       ((string-match "^### Dependencies$" line)
        (forward-line 1)
        (sysml-gen--skip-blank-lines)
        (plist-put ast :dependencies
                   (sysml-gen--parse-table-rows (sysml-gen--collect-table-lines))))
       ((string-match "^### Usages$" line)
        (forward-line 1)
        (sysml-gen--skip-blank-lines)
        (plist-put ast :usages
                   (sysml-gen--parse-table-rows (sysml-gen--collect-table-lines))))
       (t (forward-line 1))))))

;;; --- Constraints ---

(defun sysml-gen--parse-constraints-section (ast)
  "Parse ## Constraints with H3/H4 sub-sections, storing into AST."
  (forward-line 1)
  (while (and (not (eobp))
              (not (looking-at "^## [^#]")))
    (let ((line (sysml-gen--trim (buffer-substring-no-properties
                             (line-beginning-position)
                             (line-end-position)))))
      (cond
       ((string-match "^### Constraint Blocks$" line)
        (forward-line 1)
        (plist-put ast :constraint-blocks
                   (sysml-gen--parse-constraint-blocks-subsection)))
       ((string-match "^### Constraint Properties$" line)
        (forward-line 1)
        (sysml-gen--skip-blank-lines)
        (plist-put ast :constraint-props
                   (sysml-gen--parse-table-rows (sysml-gen--collect-table-lines))))
       (t (forward-line 1))))))

(defun sysml-gen--parse-constraint-blocks-subsection ()
  "Parse H4 constraint blocks within ### Constraint Blocks."
  (let (blocks)
    (while (and (not (eobp))
                (not (looking-at "^### \\|^## [^#]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                               (line-beginning-position)
                               (line-end-position)))))
        (if (string-match "^#### \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg parameters expression desc)
              (forward-line 1)
              (while (and (not (eobp))
                          (not (looking-at "^####\\|^### \\|^## [^#]")))
                (let* ((cur (sysml-gen--trim (buffer-substring-no-properties
                                         (line-beginning-position)
                                         (line-end-position))))
                       (kv (sysml-gen--parse-key-value-line cur)))
                  (cond
                   ((and kv (string= (car kv) "Package"))
                    (setq pkg (cdr kv)))
                   ((and kv (string= (car kv) "Parameters"))
                    (setq parameters (sysml-gen--split-csv (cdr kv))))
                   ((and kv (string= (car kv) "Expression"))
                    (setq expression (sysml-gen--extract-backtick-content (cdr kv))))
                   ((and kv (string= (car kv) "Description"))
                    (setq desc (cdr kv)))
                   (t nil)))
                (forward-line 1))
              (push (list :name name :package pkg
                          :parameters parameters :expression expression
                          :description desc)
                    blocks))
          (forward-line 1))))
    (nreverse blocks)))

;;; --- Activities ---

(defun sysml-gen--parse-activities-section ()
  "Parse ## Activities with H3 per activity."
  (forward-line 1)
  (let (activities)
    (while (and (not (eobp))
                (not (looking-at "^## [^#]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                               (line-beginning-position)
                               (line-end-position)))))
        (if (string-match "^### Activity: \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg partitions nodes flows desc)
              (forward-line 1)
              (while (and (not (eobp))
                          (not (looking-at "^### \\|^## [^#]")))
                (let ((cur (sysml-gen--trim (buffer-substring-no-properties
                                        (line-beginning-position)
                                        (line-end-position)))))
                  (cond
                   ((let ((kv (sysml-gen--parse-key-value-line cur)))
                      (cond
                       ((and kv (string= (car kv) "Package"))
                        (setq pkg (cdr kv)) t)
                       ((and kv (string= (car kv) "Description"))
                        (setq desc (cdr kv)) t)
                       (t nil)))
                    (forward-line 1))
                   ((string-match "^#### Partitions$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq partitions (sysml-gen--parse-table-rows
                                     (sysml-gen--collect-table-lines))))
                   ((string-match "^#### Nodes$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq nodes (sysml-gen--parse-table-rows
                                 (sysml-gen--collect-table-lines))))
                   ((string-match "^#### Flows$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq flows (sysml-gen--parse-table-rows
                                 (sysml-gen--collect-table-lines))))
                   (t (forward-line 1)))))
              (push (list :name name :package pkg
                          :partitions partitions :nodes nodes :flows flows
                          :description desc)
                    activities))
          (forward-line 1))))
    (nreverse activities)))

;;; --- State Machines ---

(defun sysml-gen--parse-state-machines-section ()
  "Parse ## State Machines with H3 per state machine."
  (forward-line 1)
  (let (machines)
    (while (and (not (eobp))
                (not (looking-at "^## [^#]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                               (line-beginning-position)
                               (line-end-position)))))
        (if (string-match "^### State Machine: \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg regions states pseudostates final-states transitions desc)
              (forward-line 1)
              (while (and (not (eobp))
                          (not (looking-at "^### \\|^## [^#]")))
                (let ((cur (sysml-gen--trim (buffer-substring-no-properties
                                        (line-beginning-position)
                                        (line-end-position)))))
                  (cond
                   ((let ((kv (sysml-gen--parse-key-value-line cur)))
                      (cond
                       ((and kv (string= (car kv) "Package"))
                        (setq pkg (cdr kv)) t)
                       ((and kv (string= (car kv) "Description"))
                        (setq desc (cdr kv)) t)
                       (t nil)))
                    (forward-line 1))
                   ((string-match "^#### Regions$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq regions (sysml-gen--parse-table-rows
                                  (sysml-gen--collect-table-lines))))
                   ((string-match "^#### States$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq states (sysml-gen--parse-table-rows
                                 (sysml-gen--collect-table-lines))))
                   ((string-match "^#### Pseudostates$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq pseudostates (sysml-gen--parse-table-rows
                                       (sysml-gen--collect-table-lines))))
                   ((string-match "^#### Final States$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq final-states (sysml-gen--parse-table-rows
                                       (sysml-gen--collect-table-lines))))
                   ((string-match "^#### Transitions$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq transitions (sysml-gen--parse-table-rows
                                      (sysml-gen--collect-table-lines))))
                   (t (forward-line 1)))))
              (push (list :name name :package pkg
                          :regions regions :states states
                          :pseudostates pseudostates
                          :final-states final-states
                          :transitions transitions
                          :description desc)
                    machines))
          (forward-line 1))))
    (nreverse machines)))

;;; --- Sequence Diagrams ---

(defun sysml-gen--parse-interactions-section ()
  "Parse ## Sequence Diagrams with H3 per interaction."
  (forward-line 1)
  (let (interactions)
    (while (and (not (eobp))
                (not (looking-at "^## [^#]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                               (line-beginning-position)
                               (line-end-position)))))
        (if (string-match "^### Interaction: \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg lifelines messages desc)
              (forward-line 1)
              (while (and (not (eobp))
                          (not (looking-at "^### \\|^## [^#]")))
                (let ((cur (sysml-gen--trim (buffer-substring-no-properties
                                        (line-beginning-position)
                                        (line-end-position)))))
                  (cond
                   ((let ((kv (sysml-gen--parse-key-value-line cur)))
                      (cond
                       ((and kv (string= (car kv) "Package"))
                        (setq pkg (cdr kv)) t)
                       ((and kv (string= (car kv) "Description"))
                        (setq desc (cdr kv)) t)
                       (t nil)))
                    (forward-line 1))
                   ((string-match "^#### Lifelines$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq lifelines (sysml-gen--parse-table-rows
                                    (sysml-gen--collect-table-lines))))
                   ((string-match "^#### Messages$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq messages (sysml-gen--parse-table-rows
                                   (sysml-gen--collect-table-lines))))
                   (t (forward-line 1)))))
              (push (list :name name :package pkg
                          :lifelines lifelines :messages messages
                          :description desc)
                    interactions))
          (forward-line 1))))
    (nreverse interactions)))

;;;; =========================================================================
;;;; Parse Org-mode into AST
;;;; =========================================================================

(defun sysml-gen--org-read-property-drawer ()
  "Read org property drawer at point, returning alist of (KEY . VALUE).
Point should be on the :PROPERTIES: line.  Advances point past :END:.
Returns nil if point is not on a :PROPERTIES: line."
  (let (props)
    (when (looking-at "^[ \t]*:PROPERTIES:[ \t]*$")
      (forward-line 1)
      (while (and (not (eobp))
                  (not (looking-at "^[ \t]*:END:[ \t]*$")))
        (let ((line (sysml-gen--trim (buffer-substring-no-properties
                                      (line-beginning-position)
                                      (line-end-position)))))
          (when (string-match "^:\\([A-Z_]+\\):\\s-*\\(.*\\)" line)
            (push (cons (match-string 1 line)
                        (sysml-gen--trim (match-string 2 line)))
                  props)))
        (forward-line 1))
      (when (not (eobp))
        (forward-line 1)))
    (nreverse props)))

(defun sysml-gen--parse-org-model (buffer)
  "Parse a SysML model org-mode BUFFER into a plist AST.
Produces identical AST structure to `sysml-gen--parse-model'."
  (with-current-buffer buffer
    (save-excursion
      (goto-char (point-min))
      (let ((ast (list :packages nil :enumerations nil :datatypes nil
                       :blocks nil :interfaces nil :ports nil
                       :realizations nil :dependencies nil :usages nil
                       :constraint-blocks nil :constraint-props nil
                       :activities nil :state-machines nil :interactions nil)))
        (while (not (eobp))
          (let ((line (sysml-gen--trim (buffer-substring-no-properties
                                        (line-beginning-position)
                                        (line-end-position)))))
            (cond
             ((string-match "^\\* Packages$" line)
              (plist-put ast :packages (sysml-gen--parse-org-packages-section)))
             ((string-match "^\\* Enumerations$" line)
              (plist-put ast :enumerations (sysml-gen--parse-org-enumerations-section)))
             ((string-match "^\\* DataTypes$" line)
              (plist-put ast :datatypes (sysml-gen--parse-org-datatypes-section)))
             ((string-match "^\\* Blocks$" line)
              (plist-put ast :blocks (sysml-gen--parse-org-blocks-section)))
             ((string-match "^\\* Interfaces$" line)
              (plist-put ast :interfaces (sysml-gen--parse-org-interfaces-section)))
             ((string-match "^\\* Ports$" line)
              (plist-put ast :ports (sysml-gen--parse-org-ports-section)))
             ((string-match "^\\* Relationships$" line)
              (sysml-gen--parse-org-relationships-section ast))
             ((string-match "^\\* Constraints$" line)
              (sysml-gen--parse-org-constraints-section ast))
             ((string-match "^\\* Activities$" line)
              (plist-put ast :activities (sysml-gen--parse-org-activities-section)))
             ((string-match "^\\* State Machines$" line)
              (plist-put ast :state-machines (sysml-gen--parse-org-state-machines-section)))
             ((string-match "^\\* Sequence Diagrams$" line)
              (plist-put ast :interactions (sysml-gen--parse-org-interactions-section)))
             (t (forward-line 1)))))
        ast))))

;;; --- Org: Packages ---

(defun sysml-gen--parse-org-packages-section ()
  "Parse * Packages table in org format.  Point is on the * line."
  (forward-line 1)
  (sysml-gen--skip-blank-lines)
  (let ((lines (sysml-gen--collect-table-lines)))
    (sysml-gen--parse-table-rows lines)))

;;; --- Org: Enumerations ---

(defun sysml-gen--parse-org-enumerations-section ()
  "Parse * Enumerations section in org format."
  (forward-line 1)
  (let (enums)
    (while (and (not (eobp))
                (not (looking-at "^\\* [^*]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                                    (line-beginning-position)
                                    (line-end-position)))))
        (if (string-match "^\\*\\* \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg literals desc)
              (forward-line 1)
              (sysml-gen--skip-blank-lines)
              (when (looking-at "^[ \t]*:PROPERTIES:")
                (let ((props (sysml-gen--org-read-property-drawer)))
                  (setq pkg (cdr (assoc "PACKAGE" props)))
                  (setq literals (sysml-gen--split-csv
                                  (cdr (assoc "LITERALS" props))))
                  (setq desc (cdr (assoc "DESCRIPTION" props)))))
              (push (list :name name :package pkg :literals literals :description desc) enums))
          (forward-line 1))))
    (nreverse enums)))

;;; --- Org: DataTypes ---

(defun sysml-gen--parse-org-datatypes-section ()
  "Parse * DataTypes section in org format."
  (forward-line 1)
  (let (datatypes)
    (while (and (not (eobp))
                (not (looking-at "^\\* [^*]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                                    (line-beginning-position)
                                    (line-end-position)))))
        (if (string-match "^\\*\\* \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg properties desc)
              (forward-line 1)
              (sysml-gen--skip-blank-lines)
              (when (looking-at "^[ \t]*:PROPERTIES:")
                (let ((props (sysml-gen--org-read-property-drawer)))
                  (setq pkg (cdr (assoc "PACKAGE" props)))
                  (setq desc (cdr (assoc "DESCRIPTION" props)))))
              (sysml-gen--skip-blank-lines)
              (when (looking-at "^|")
                (setq properties (sysml-gen--parse-table-rows
                                  (sysml-gen--collect-table-lines))))
              (push (list :name name :package pkg :properties properties :description desc) datatypes))
          (forward-line 1))))
    (nreverse datatypes)))

;;; --- Org: Blocks ---

(defun sysml-gen--parse-org-blocks-section ()
  "Parse * Blocks section in org format with *** property groups."
  (forward-line 1)
  (let (blocks)
    (while (and (not (eobp))
                (not (looking-at "^\\* [^*]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                                    (line-beginning-position)
                                    (line-end-position)))))
        (if (string-match "^\\*\\* \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg value-props part-props ref-props current-group desc)
              (forward-line 1)
              (sysml-gen--skip-blank-lines)
              (when (looking-at "^[ \t]*:PROPERTIES:")
                (let ((props (sysml-gen--org-read-property-drawer)))
                  (setq pkg (cdr (assoc "PACKAGE" props)))
                  (setq desc (cdr (assoc "DESCRIPTION" props)))))
              (while (and (not (eobp))
                          (not (looking-at "^\\*\\* [^*]\\|^\\* [^*]")))
                (let ((cur (sysml-gen--trim (buffer-substring-no-properties
                                             (line-beginning-position)
                                             (line-end-position)))))
                  (cond
                   ((string-match "^\\*\\*\\* Value Properties$" cur)
                    (setq current-group :value)
                    (forward-line 1))
                   ((string-match "^\\*\\*\\* Part Properties$" cur)
                    (setq current-group :part)
                    (forward-line 1))
                   ((string-match "^\\*\\*\\* Reference Properties$" cur)
                    (setq current-group :ref)
                    (forward-line 1))
                   ((string-match "^|" cur)
                    (let* ((tbl-lines (sysml-gen--collect-table-lines))
                           (rows (sysml-gen--parse-table-rows tbl-lines)))
                      (pcase current-group
                        (:value (setq value-props rows))
                        (:part (setq part-props rows))
                        (:ref (setq ref-props rows)))))
                   (t (forward-line 1)))))
              (push (list :name name :package pkg
                          :value-properties value-props
                          :part-properties part-props
                          :reference-properties ref-props
                          :description desc)
                    blocks))
          (forward-line 1))))
    (nreverse blocks)))

;;; --- Org: Interfaces ---

(defun sysml-gen--parse-org-interfaces-section ()
  "Parse * Interfaces section in org format."
  (forward-line 1)
  (let (interfaces)
    (while (and (not (eobp))
                (not (looking-at "^\\* [^*]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                                    (line-beginning-position)
                                    (line-end-position)))))
        (if (string-match "^\\*\\* \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg operations desc)
              (forward-line 1)
              (sysml-gen--skip-blank-lines)
              (when (looking-at "^[ \t]*:PROPERTIES:")
                (let ((props (sysml-gen--org-read-property-drawer)))
                  (setq pkg (cdr (assoc "PACKAGE" props)))
                  (setq operations (sysml-gen--split-csv
                                    (cdr (assoc "OPERATIONS" props))))
                  (setq desc (cdr (assoc "DESCRIPTION" props)))))
              (push (list :name name :package pkg :operations operations :description desc)
                    interfaces))
          (forward-line 1))))
    (nreverse interfaces)))

;;; --- Org: Ports ---

(defun sysml-gen--parse-org-ports-section ()
  "Parse * Ports table in org format."
  (forward-line 1)
  (sysml-gen--skip-blank-lines)
  (let ((lines (sysml-gen--collect-table-lines)))
    (sysml-gen--parse-table-rows lines)))

;;; --- Org: Relationships ---

(defun sysml-gen--parse-org-relationships-section (ast)
  "Parse * Relationships with ** sub-sections, storing into AST."
  (forward-line 1)
  (while (and (not (eobp))
              (not (looking-at "^\\* [^*]")))
    (let ((line (sysml-gen--trim (buffer-substring-no-properties
                                  (line-beginning-position)
                                  (line-end-position)))))
      (cond
       ((string-match "^\\*\\* Realizations$" line)
        (forward-line 1)
        (sysml-gen--skip-blank-lines)
        (plist-put ast :realizations
                   (sysml-gen--parse-table-rows (sysml-gen--collect-table-lines))))
       ((string-match "^\\*\\* Dependencies$" line)
        (forward-line 1)
        (sysml-gen--skip-blank-lines)
        (plist-put ast :dependencies
                   (sysml-gen--parse-table-rows (sysml-gen--collect-table-lines))))
       ((string-match "^\\*\\* Usages$" line)
        (forward-line 1)
        (sysml-gen--skip-blank-lines)
        (plist-put ast :usages
                   (sysml-gen--parse-table-rows (sysml-gen--collect-table-lines))))
       (t (forward-line 1))))))

;;; --- Org: Constraints ---

(defun sysml-gen--parse-org-constraints-section (ast)
  "Parse * Constraints with ** sub-sections, storing into AST."
  (forward-line 1)
  (while (and (not (eobp))
              (not (looking-at "^\\* [^*]")))
    (let ((line (sysml-gen--trim (buffer-substring-no-properties
                                  (line-beginning-position)
                                  (line-end-position)))))
      (cond
       ((string-match "^\\*\\* Constraint Blocks$" line)
        (forward-line 1)
        (plist-put ast :constraint-blocks
                   (sysml-gen--parse-org-constraint-blocks-subsection)))
       ((string-match "^\\*\\* Constraint Properties$" line)
        (forward-line 1)
        (sysml-gen--skip-blank-lines)
        (plist-put ast :constraint-props
                   (sysml-gen--parse-table-rows (sysml-gen--collect-table-lines))))
       (t (forward-line 1))))))

(defun sysml-gen--parse-org-constraint-blocks-subsection ()
  "Parse *** constraint blocks within ** Constraint Blocks."
  (let (blocks)
    (while (and (not (eobp))
                (not (looking-at "^\\*\\* [^*]\\|^\\* [^*]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                                    (line-beginning-position)
                                    (line-end-position)))))
        (if (string-match "^\\*\\*\\* \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg parameters expression desc)
              (forward-line 1)
              (sysml-gen--skip-blank-lines)
              (when (looking-at "^[ \t]*:PROPERTIES:")
                (let ((props (sysml-gen--org-read-property-drawer)))
                  (setq pkg (cdr (assoc "PACKAGE" props)))
                  (setq parameters (sysml-gen--split-csv
                                    (cdr (assoc "PARAMETERS" props))))
                  (setq expression (cdr (assoc "EXPRESSION" props)))
                  (setq desc (cdr (assoc "DESCRIPTION" props)))))
              (push (list :name name :package pkg
                          :parameters parameters :expression expression
                          :description desc)
                    blocks))
          (forward-line 1))))
    (nreverse blocks)))

;;; --- Org: Activities ---

(defun sysml-gen--parse-org-activities-section ()
  "Parse * Activities with ** per activity."
  (forward-line 1)
  (let (activities)
    (while (and (not (eobp))
                (not (looking-at "^\\* [^*]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                                    (line-beginning-position)
                                    (line-end-position)))))
        (if (string-match "^\\*\\* \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg partitions nodes flows desc)
              (forward-line 1)
              (sysml-gen--skip-blank-lines)
              (when (looking-at "^[ \t]*:PROPERTIES:")
                (let ((props (sysml-gen--org-read-property-drawer)))
                  (setq pkg (cdr (assoc "PACKAGE" props)))
                  (setq desc (cdr (assoc "DESCRIPTION" props)))))
              (while (and (not (eobp))
                          (not (looking-at "^\\*\\* [^*]\\|^\\* [^*]")))
                (let ((cur (sysml-gen--trim (buffer-substring-no-properties
                                             (line-beginning-position)
                                             (line-end-position)))))
                  (cond
                   ((string-match "^\\*\\*\\* Partitions$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq partitions (sysml-gen--parse-table-rows
                                     (sysml-gen--collect-table-lines))))
                   ((string-match "^\\*\\*\\* Nodes$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq nodes (sysml-gen--parse-table-rows
                                 (sysml-gen--collect-table-lines))))
                   ((string-match "^\\*\\*\\* Flows$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq flows (sysml-gen--parse-table-rows
                                 (sysml-gen--collect-table-lines))))
                   (t (forward-line 1)))))
              (push (list :name name :package pkg
                          :partitions partitions :nodes nodes :flows flows
                          :description desc)
                    activities))
          (forward-line 1))))
    (nreverse activities)))

;;; --- Org: State Machines ---

(defun sysml-gen--parse-org-state-machines-section ()
  "Parse * State Machines with ** per state machine."
  (forward-line 1)
  (let (machines)
    (while (and (not (eobp))
                (not (looking-at "^\\* [^*]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                                    (line-beginning-position)
                                    (line-end-position)))))
        (if (string-match "^\\*\\* \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg regions states pseudostates final-states transitions desc)
              (forward-line 1)
              (sysml-gen--skip-blank-lines)
              (when (looking-at "^[ \t]*:PROPERTIES:")
                (let ((props (sysml-gen--org-read-property-drawer)))
                  (setq pkg (cdr (assoc "PACKAGE" props)))
                  (setq desc (cdr (assoc "DESCRIPTION" props)))))
              (while (and (not (eobp))
                          (not (looking-at "^\\*\\* [^*]\\|^\\* [^*]")))
                (let ((cur (sysml-gen--trim (buffer-substring-no-properties
                                             (line-beginning-position)
                                             (line-end-position)))))
                  (cond
                   ((string-match "^\\*\\*\\* Regions$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq regions (sysml-gen--parse-table-rows
                                  (sysml-gen--collect-table-lines))))
                   ((string-match "^\\*\\*\\* States$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq states (sysml-gen--parse-table-rows
                                 (sysml-gen--collect-table-lines))))
                   ((string-match "^\\*\\*\\* Pseudostates$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq pseudostates (sysml-gen--parse-table-rows
                                       (sysml-gen--collect-table-lines))))
                   ((string-match "^\\*\\*\\* Final States$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq final-states (sysml-gen--parse-table-rows
                                       (sysml-gen--collect-table-lines))))
                   ((string-match "^\\*\\*\\* Transitions$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq transitions (sysml-gen--parse-table-rows
                                      (sysml-gen--collect-table-lines))))
                   (t (forward-line 1)))))
              (push (list :name name :package pkg
                          :regions regions :states states
                          :pseudostates pseudostates
                          :final-states final-states
                          :transitions transitions
                          :description desc)
                    machines))
          (forward-line 1))))
    (nreverse machines)))

;;; --- Org: Sequence Diagrams ---

(defun sysml-gen--parse-org-interactions-section ()
  "Parse * Sequence Diagrams with ** per interaction."
  (forward-line 1)
  (let (interactions)
    (while (and (not (eobp))
                (not (looking-at "^\\* [^*]")))
      (let ((line (sysml-gen--trim (buffer-substring-no-properties
                                    (line-beginning-position)
                                    (line-end-position)))))
        (if (string-match "^\\*\\* \\(.+\\)$" line)
            (let ((name (sysml-gen--trim (match-string 1 line)))
                  pkg lifelines messages desc)
              (forward-line 1)
              (sysml-gen--skip-blank-lines)
              (when (looking-at "^[ \t]*:PROPERTIES:")
                (let ((props (sysml-gen--org-read-property-drawer)))
                  (setq pkg (cdr (assoc "PACKAGE" props)))
                  (setq desc (cdr (assoc "DESCRIPTION" props)))))
              (while (and (not (eobp))
                          (not (looking-at "^\\*\\* [^*]\\|^\\* [^*]")))
                (let ((cur (sysml-gen--trim (buffer-substring-no-properties
                                             (line-beginning-position)
                                             (line-end-position)))))
                  (cond
                   ((string-match "^\\*\\*\\* Lifelines$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq lifelines (sysml-gen--parse-table-rows
                                    (sysml-gen--collect-table-lines))))
                   ((string-match "^\\*\\*\\* Messages$" cur)
                    (forward-line 1)
                    (sysml-gen--skip-blank-lines)
                    (setq messages (sysml-gen--parse-table-rows
                                   (sysml-gen--collect-table-lines))))
                    (t (forward-line 1)))))
              (push (list :name name :package pkg
                          :lifelines lifelines :messages messages
                          :description desc)
                    interactions))
          (forward-line 1))))
    (nreverse interactions)))

;;;; =========================================================================
;;;; Format Dispatcher
;;;; =========================================================================

(defun sysml-gen--parse-buffer (buffer)
  "Parse model BUFFER, auto-detecting format (Markdown or Org).
Returns the same plist AST regardless of input format."
  (let ((file-name (buffer-file-name buffer)))
    (if (and file-name (string-suffix-p ".org" file-name))
        (sysml-gen--parse-org-model buffer)
      (sysml-gen--parse-model buffer))))

;;;; =========================================================================
;;;; Validation
;;;; =========================================================================

(defun sysml-gen--validate (ast)
  "Validate the parsed AST.  Return list of error strings, empty if valid."
  (let (errors
        ;; Build name sets for cross-reference checking
        (pkg-names (mapcar (lambda (p) (cdr (assoc "Name" p)))
                           (plist-get ast :packages)))
        (enum-names (mapcar (lambda (e) (plist-get e :name))
                            (plist-get ast :enumerations)))
        (dt-names (mapcar (lambda (d) (plist-get d :name))
                          (plist-get ast :datatypes)))
        (blk-names (mapcar (lambda (b) (plist-get b :name))
                           (plist-get ast :blocks)))
        (if-names (mapcar (lambda (i) (plist-get i :name))
                          (plist-get ast :interfaces)))
        (cb-names (mapcar (lambda (c) (plist-get c :name))
                          (plist-get ast :constraint-blocks))))
    (let ((all-type-names (append enum-names dt-names blk-names)))
      ;; Check packages reference valid parents
      (dolist (p (plist-get ast :packages))
        (let ((parent (cdr (assoc "Parent" p))))
          (unless (or (string= parent "_root_")
                      (member parent pkg-names))
            (push (format "Package '%s': parent '%s' not found"
                          (cdr (assoc "Name" p)) parent)
                  errors))))

      ;; Check datatype property types
      (dolist (dt (plist-get ast :datatypes))
        (dolist (prop (plist-get dt :properties))
          (let ((type (cdr (assoc "Type" prop))))
            (when (and type (not (string-empty-p type))
                       (not (member type all-type-names)))
              (push (format "DataType '%s' property '%s': type '%s' not found"
                            (plist-get dt :name)
                            (cdr (assoc "Property" prop))
                            type)
                    errors)))))

      ;; Check block property types
      (dolist (blk (plist-get ast :blocks))
        (dolist (prop (append (plist-get blk :value-properties)
                              (plist-get blk :part-properties)
                              (plist-get blk :reference-properties)))
          (let ((type (cdr (assoc "Type" prop))))
            (when (and type (not (string-empty-p type))
                       (not (member type all-type-names)))
              (push (format "Block '%s' property '%s': type '%s' not found"
                            (plist-get blk :name)
                            (cdr (assoc "Property" prop))
                            type)
                    errors)))))

      ;; Check ports reference valid owners and interfaces
      (dolist (port (plist-get ast :ports))
        (let ((owner (cdr (assoc "Owner" port)))
              (iface (cdr (assoc "Interface Type" port))))
          (unless (member owner blk-names)
            (push (format "Port '%s': owner '%s' not found in blocks"
                          (cdr (assoc "Port Name" port)) owner)
                  errors))
          (unless (member iface if-names)
            (push (format "Port '%s': interface '%s' not found"
                          (cdr (assoc "Port Name" port)) iface)
                  errors))))

      ;; Check realizations
      (dolist (r (plist-get ast :realizations))
        (let ((block (cdr (assoc "Block" r)))
              (iface (cdr (assoc "Interface" r))))
          (unless (member block blk-names)
            (push (format "Realization: block '%s' not found" block) errors))
          (unless (member iface if-names)
            (push (format "Realization: interface '%s' not found" iface) errors))))

      ;; Check dependencies
      (dolist (d (plist-get ast :dependencies))
        (let ((client (cdr (assoc "Client" d)))
              (supplier (cdr (assoc "Supplier" d))))
          (unless (member client blk-names)
            (push (format "Dependency: client '%s' not found" client) errors))
          (unless (member supplier blk-names)
            (push (format "Dependency: supplier '%s' not found" supplier) errors))))

      ;; Check usages (suppliers can be blocks or datatypes)
      (dolist (u (plist-get ast :usages))
        (let ((client (cdr (assoc "Client" u)))
              (supplier (cdr (assoc "Supplier" u))))
          (unless (member client blk-names)
            (push (format "Usage: client '%s' not found" client) errors))
          (unless (member supplier (append blk-names dt-names))
            (push (format "Usage: supplier '%s' not found" supplier) errors))))

      ;; Check constraint properties
      (dolist (cp (plist-get ast :constraint-props))
        (let ((owner (cdr (assoc "Owner Block" cp)))
              (cb (cdr (assoc "Constraint Block" cp))))
          (unless (member owner blk-names)
            (push (format "Constraint property: owner '%s' not found" owner) errors))
          (unless (member cb cb-names)
            (push (format "Constraint property: constraint block '%s' not found" cb) errors))))

      ;; Check activity node IDs are unique within each activity
      (dolist (act (plist-get ast :activities))
        (let ((ids (mapcar (lambda (n) (cdr (assoc "ID" n)))
                           (plist-get act :nodes)))
              (seen (make-hash-table :test 'equal)))
          (dolist (id ids)
            (if (gethash id seen)
                (push (format "Activity '%s': duplicate node ID '%s'"
                              (plist-get act :name) id)
                      errors)
              (puthash id t seen)))
          ;; Check flows reference valid IDs
          (dolist (flow (plist-get act :flows))
            (let ((src (cdr (assoc "Source" flow)))
                  (tgt (cdr (assoc "Target" flow))))
              (unless (member src ids)
                (push (format "Activity '%s': flow source '%s' not found"
                              (plist-get act :name) src)
                      errors))
              (unless (member tgt ids)
                (push (format "Activity '%s': flow target '%s' not found"
                              (plist-get act :name) tgt)
                      errors))))))

      ;; Check state machine IDs are unique within each SM
      (dolist (sm (plist-get ast :state-machines))
        (let ((all-ids (append
                        (mapcar (lambda (r) (cdr (assoc "ID" r)))
                                (plist-get sm :regions))
                        (mapcar (lambda (s) (cdr (assoc "ID" s)))
                                (plist-get sm :states))
                        (mapcar (lambda (p) (cdr (assoc "ID" p)))
                                (plist-get sm :pseudostates))
                        (mapcar (lambda (f) (cdr (assoc "ID" f)))
                                (plist-get sm :final-states))))
              (seen (make-hash-table :test 'equal)))
          (dolist (id all-ids)
            (if (gethash id seen)
                (push (format "State machine '%s': duplicate ID '%s'"
                              (plist-get sm :name) id)
                      errors)
              (puthash id t seen)))
          ;; Check transition source/target
          (dolist (tr (plist-get sm :transitions))
            (let ((src (cdr (assoc "Source" tr)))
                  (tgt (cdr (assoc "Target" tr))))
              (unless (member src all-ids)
                (push (format "State machine '%s': transition source '%s' not found"
                              (plist-get sm :name) src)
                      errors))
              (unless (member tgt all-ids)
                (push (format "State machine '%s': transition target '%s' not found"
                              (plist-get sm :name) tgt)
                      errors)))))))

    (nreverse errors)))

;;;; =========================================================================
;;;; Verification (round-trip check)
;;;; =========================================================================

(defun sysml-gen--extract-jython-names (text func-name)
  "Extract first string argument names from FUNC-NAME calls in TEXT.
Matches patterns like func_name(\"NAME\") and returns list of NAME strings."
  (let ((pattern (concat (regexp-quote func-name) "(\"\\([^\"]+\\)\""))
        (start 0)
        names)
    (while (string-match pattern text start)
      (push (match-string 1 text) names)
      (setq start (match-end 0)))
    (nreverse names)))

(defun sysml-gen--extract-jython-second-arg-names (text func-name)
  "Extract second string argument names from FUNC-NAME calls in TEXT.
Matches patterns like func_name(var, \"NAME\") and returns list of NAME strings."
  (let ((pattern (concat (regexp-quote func-name)
                         "([^,]+, *\"\\([^\"]+\\)\""))
        (start 0)
        names)
    (while (string-match pattern text start)
      (push (match-string 1 text) names)
      (setq start (match-end 0)))
    (nreverse names)))

(defun sysml-gen--extract-jython-call-count (text func-name)
  "Count occurrences of FUNC-NAME( in TEXT."
  (let ((pattern (concat (regexp-quote func-name) "("))
        (start 0)
        (count 0))
    (while (string-match pattern text start)
      (setq count (1+ count))
      (setq start (match-end 0)))
    count))

(defun sysml-gen--extract-jython-constraint-block-names (text)
  "Extract constraint block names from multiline create_constraint_block calls."
  (let ((pattern "create_constraint_block(\n[^\"]*\"\\([^\"]+\\)\"")
        (start 0)
        names)
    (while (string-match pattern text start)
      (push (match-string 1 text) names)
      (setq start (match-end 0)))
    (nreverse names)))

(defun sysml-gen--extract-jython-node-ids (text)
  "Extract activity node IDs from variable assignments in TEXT.
Matches node creation function calls and returns the assigned variable names."
  (let ((pattern (concat "    \\([A-Za-z_][A-Za-z0-9_]*\\) = create_"
                         "\\(?:initial_node\\|final_node\\|action\\|"
                         "decision_node\\|merge_node\\|fork_node\\|"
                         "join_node\\|send_signal_action\\|"
                         "accept_event_action\\)("))
        (start 0)
        ids)
    (while (string-match pattern text start)
      (push (match-string 1 text) ids)
      (setq start (match-end 0)))
    (nreverse ids)))

(defun sysml-gen--extract-jython-sections (text section-func)
  "Split TEXT into sections keyed by name of SECTION-FUNC calls.
Returns alist of (name . section-text)."
  (let ((pattern (concat (regexp-quote section-func) "(\"\\([^\"]+\\)\""))
        (starts nil)
        (start 0))
    (while (string-match pattern text start)
      (push (cons (match-string 1 text) (match-beginning 0)) starts)
      (setq start (match-end 0)))
    (setq starts (nreverse starts))
    (let (sections)
      (dotimes (i (length starts))
        (let ((name (car (nth i starts)))
              (beg (cdr (nth i starts)))
              (end (if (< i (1- (length starts)))
                       (cdr (nth (1+ i) starts))
                     (length text))))
          (push (cons name (substring text beg end)) sections)))
      (nreverse sections))))

(defun sysml-gen--verify-compare (category expected actual)
  "Compare EXPECTED vs ACTUAL name lists for CATEGORY.
Returns plist with :category, :passed, :missing, :extra."
  (let ((missing (seq-difference expected actual #'string=))
        (extra (seq-difference actual expected #'string=)))
    (list :category category
          :passed (and (null missing) (null extra))
          :missing missing
          :extra extra)))

(defun sysml-gen--verify-compare-counts (category expected-n actual-n)
  "Compare expected and actual counts for CATEGORY.
Returns plist with :category, :passed, :expected, :actual."
  (list :category category
        :passed (= expected-n actual-n)
        :expected expected-n
        :actual actual-n))

(defun sysml-gen--verify-ast-vs-jython (ast jython-text)
  "Compare AST against emitted JYTHON-TEXT.  Return list of result plists."
  (let (results)
    ;; Packages
    (push (sysml-gen--verify-compare
           "Packages"
           (mapcar (lambda (p) (cdr (assoc "Name" p)))
                   (plist-get ast :packages))
           (sysml-gen--extract-jython-names jython-text "create_package"))
          results)

    ;; Enumerations
    (push (sysml-gen--verify-compare
           "Enumerations"
           (mapcar (lambda (e) (plist-get e :name))
                   (plist-get ast :enumerations))
           (sysml-gen--extract-jython-names jython-text "create_enumeration"))
          results)

    ;; DataTypes
    (push (sysml-gen--verify-compare
           "DataTypes"
           (mapcar (lambda (d) (plist-get d :name))
                   (plist-get ast :datatypes))
           (sysml-gen--extract-jython-names jython-text "create_datatype"))
          results)

    ;; Blocks
    (push (sysml-gen--verify-compare
           "Blocks"
           (mapcar (lambda (b) (plist-get b :name))
                   (plist-get ast :blocks))
           (sysml-gen--extract-jython-names jython-text "create_block"))
          results)

    ;; Interfaces
    (push (sysml-gen--verify-compare
           "Interfaces"
           (mapcar (lambda (i) (plist-get i :name))
                   (plist-get ast :interfaces))
           (sysml-gen--extract-jython-names jython-text "create_interface"))
          results)

    ;; Operations (flattened from all interfaces)
    (push (sysml-gen--verify-compare
           "Operations"
           (apply #'append
                  (mapcar (lambda (i) (plist-get i :operations))
                          (plist-get ast :interfaces)))
           (sysml-gen--extract-jython-second-arg-names
            jython-text "add_operation"))
          results)

    ;; Ports
    (push (sysml-gen--verify-compare
           "Ports"
           (mapcar (lambda (p) (cdr (assoc "Port Name" p)))
                   (plist-get ast :ports))
           (sysml-gen--extract-jython-second-arg-names
            jython-text "add_flow_port"))
          results)

    ;; Realizations (count)
    (push (sysml-gen--verify-compare-counts
           "Realizations"
           (length (plist-get ast :realizations))
           (sysml-gen--extract-jython-call-count
            jython-text "add_realization"))
          results)

    ;; Dependencies (count)
    (push (sysml-gen--verify-compare-counts
           "Dependencies"
           (length (plist-get ast :dependencies))
           (sysml-gen--extract-jython-call-count
            jython-text "add_dependency"))
          results)

    ;; Usages (count)
    (push (sysml-gen--verify-compare-counts
           "Usages"
           (length (plist-get ast :usages))
           (sysml-gen--extract-jython-call-count
            jython-text "add_usage"))
          results)

    ;; Constraint Blocks
    (push (sysml-gen--verify-compare
           "Constraint Blocks"
           (mapcar (lambda (c) (plist-get c :name))
                   (plist-get ast :constraint-blocks))
           (sysml-gen--extract-jython-constraint-block-names jython-text))
          results)

    ;; Constraint Properties (count)
    (push (sysml-gen--verify-compare-counts
           "Constraint Properties"
           (length (plist-get ast :constraint-props))
           (sysml-gen--extract-jython-call-count
            jython-text "add_constraint_property"))
          results)

    ;; Activities
    (push (sysml-gen--verify-compare
           "Activities"
           (mapcar (lambda (a) (plist-get a :name))
                   (plist-get ast :activities))
           (sysml-gen--extract-jython-names jython-text "create_activity"))
          results)

    ;; Activity Nodes (per activity)
    (let ((act-sections (sysml-gen--extract-jython-sections
                         jython-text "create_activity")))
      (dolist (act (plist-get ast :activities))
        (let* ((name (plist-get act :name))
               (expected-ids (mapcar (lambda (n) (cdr (assoc "ID" n)))
                                     (plist-get act :nodes)))
               (section-text (cdr (assoc name act-sections)))
               (actual-ids (when section-text
                             (sysml-gen--extract-jython-node-ids
                              section-text))))
          (push (sysml-gen--verify-compare
                 (format "Activity Nodes [%s]" name)
                 expected-ids actual-ids)
                results))))

    ;; State Machines
    (push (sysml-gen--verify-compare
           "State Machines"
           (mapcar (lambda (s) (plist-get s :name))
                   (plist-get ast :state-machines))
           (sysml-gen--extract-jython-names
            jython-text "create_state_machine"))
          results)

    ;; States per SM
    (let ((sm-sections (sysml-gen--extract-jython-sections
                        jython-text "create_state_machine")))
      (dolist (sm (plist-get ast :state-machines))
        (let* ((name (plist-get sm :name))
               (expected-names
                (mapcar (lambda (s) (cdr (assoc "Name" s)))
                        (plist-get sm :states)))
               (section-text (cdr (assoc name sm-sections)))
               (actual-names
                (when section-text
                  (append
                   (sysml-gen--extract-jython-names
                    section-text "create_state")
                   (sysml-gen--extract-jython-names
                    section-text "create_composite_state")))))
          (push (sysml-gen--verify-compare
                 (format "States [%s]" name)
                 expected-names actual-names)
                results))))

    ;; Interactions
    (push (sysml-gen--verify-compare
           "Interactions"
           (mapcar (lambda (i) (plist-get i :name))
                   (plist-get ast :interactions))
           (sysml-gen--extract-jython-names
            jython-text "create_interaction"))
          results)

    ;; Lifelines per interaction
    (let ((int-sections (sysml-gen--extract-jython-sections
                         jython-text "create_interaction")))
      (dolist (interaction (plist-get ast :interactions))
        (let* ((name (plist-get interaction :name))
               (expected-names
                (mapcar (lambda (ll) (cdr (assoc "Name" ll)))
                        (plist-get interaction :lifelines)))
               (section-text (cdr (assoc name int-sections)))
               (actual-names
                (when section-text
                  (sysml-gen--extract-jython-names
                   section-text "create_lifeline"))))
          (push (sysml-gen--verify-compare
                 (format "Lifelines [%s]" name)
                 expected-names actual-names)
                results))))

    ;; Messages per interaction
    (let ((int-sections (sysml-gen--extract-jython-sections
                         jython-text "create_interaction")))
      (dolist (interaction (plist-get ast :interactions))
        (let* ((name (plist-get interaction :name))
               (expected-names
                (mapcar (lambda (m) (cdr (assoc "Name" m)))
                        (plist-get interaction :messages)))
               (section-text (cdr (assoc name int-sections)))
               (actual-names
                (when section-text
                  (sysml-gen--extract-jython-names
                   section-text "create_message"))))
          (push (sysml-gen--verify-compare
                 (format "Messages [%s]" name)
                 expected-names actual-names)
                results))))

    (nreverse results)))

(defun sysml-gen--verify-insert-report (results model-file)
  "Format verification RESULTS for MODEL-FILE into current buffer."
  (insert (format "Verification Report: %s\n" (abbreviate-file-name model-file)))
  (insert (format "Date: %s\n\n" (format-time-string "%Y-%m-%d %H:%M")))
  (let ((passed 0)
        (failed 0))
    (dolist (r results)
      (if (plist-get r :passed)
          (setq passed (1+ passed))
        (setq failed (1+ failed))))
    (insert (format "Summary: %d/%d checks passed" passed (+ passed failed)))
    (when (> failed 0)
      (insert (format ", %d FAILED" failed)))
    (insert "\n\n"))
  (dolist (r results)
    (let ((cat (plist-get r :category))
          (ok (plist-get r :passed)))
      (insert (format "  %s %s" (if ok "PASS" "FAIL") cat))
      (unless ok
        (when (plist-get r :missing)
          (insert (format "\n         Missing: %s"
                          (string-join (plist-get r :missing) ", "))))
        (when (plist-get r :extra)
          (insert (format "\n         Extra:   %s"
                          (string-join (plist-get r :extra) ", "))))
        (when (plist-get r :expected)
          (insert (format "\n         Expected: %d, Actual: %d"
                          (plist-get r :expected)
                          (plist-get r :actual)))))
      (insert "\n"))))

;;;; =========================================================================
;;;; Pass 2: Emit Jython
;;;; =========================================================================

(defun sysml-gen--root-package-name (ast)
  "Return the name of the root package (parent = _root_) from AST."
  (let ((root-pkg (seq-find (lambda (p) (string= (cdr (assoc "Parent" p)) "_root_"))
                            (plist-get ast :packages))))
    (if root-pkg (cdr (assoc "Name" root-pkg)) "Model")))

(defun sysml-gen--emit (ast)
  "Emit Jython code from AST into current buffer."
  (let ((symtab (make-hash-table :test 'equal))
        (root-name (sysml-gen--root-package-name ast)))

    ;; Session start
    (sysml-gen--emit-line
     (format "sm.createSession(\"Create %s Structure\")" root-name))
    (sysml-gen--emit-line "")
    (sysml-gen--emit-line "try:")

    ;; Packages
    (sysml-gen--emit-section-comment "Packages")
    (sysml-gen--emit-packages ast symtab)

    ;; Enumerations
    (sysml-gen--emit-section-comment "Enumerations")
    (sysml-gen--emit-enumerations ast symtab)

    ;; DataTypes
    (sysml-gen--emit-section-comment "Data Types")
    (sysml-gen--emit-datatypes ast symtab)

    ;; Blocks
    (sysml-gen--emit-section-comment "Blocks")
    (sysml-gen--emit-blocks ast symtab)

    ;; Interfaces
    (sysml-gen--emit-section-comment "Interfaces")
    (sysml-gen--emit-interfaces ast symtab)

    ;; Ports
    (sysml-gen--emit-section-comment "Ports")
    (sysml-gen--emit-ports ast symtab)

    ;; Relationships
    (sysml-gen--emit-section-comment "Relationships")
    (sysml-gen--emit-relationships ast symtab)

    ;; Constraints
    (sysml-gen--emit-section-comment "Constraints")
    (sysml-gen--emit-constraints ast symtab)

    ;; Activities
    (sysml-gen--emit-section-comment "Activity Diagrams")
    (sysml-gen--emit-activities ast symtab)

    ;; State Machines
    (sysml-gen--emit-section-comment "State Machines")
    (sysml-gen--emit-state-machines ast symtab)

    ;; Sequence Diagrams
    (sysml-gen--emit-section-comment "Sequence Diagrams")
    (sysml-gen--emit-interactions ast symtab)

    ;; Session end
    (sysml-gen--emit-section-comment "Done")
    (sysml-gen--emit-line "    sm.closeSession()")
    (sysml-gen--emit-line "    Application.getInstance().getGUILog().log(")
    (sysml-gen--emit-line
     (format "        \"SUCCESS: Model created in '%s'.\"" root-name))
    (sysml-gen--emit-line "    )")
    (sysml-gen--emit-line "")
    (sysml-gen--emit-line "except Exception, e:")
    (sysml-gen--emit-line "    sm.cancelSession()")
    (sysml-gen--emit-line "    Application.getInstance().getGUILog().log(\"ERROR: \" + str(e))")
    (sysml-gen--emit-line "    raise")))

(defun sysml-gen--emit-line (text)
  "Insert TEXT followed by newline."
  (insert text "\n"))

(defun sysml-gen--emit-documentation (var desc)
  "Emit set_documentation call for VAR with DESC if non-nil."
  (when (and desc (not (string-empty-p desc)))
    (sysml-gen--emit-line
     (format "    set_documentation(%s, \"%s\")"
             var (replace-regexp-in-string "\"" "\\\\\"" desc)))))

(defun sysml-gen--emit-section-comment (title)
  "Emit a section comment block with TITLE."
  (sysml-gen--emit-line "")
  (sysml-gen--emit-line "    # =========================================")
  (sysml-gen--emit-line (format "    # %s" title))
  (sysml-gen--emit-line "    # ========================================="))

(defun sysml-gen--emit-subsection-comment (title)
  "Emit a subsection comment with TITLE."
  (sysml-gen--emit-line "")
  (sysml-gen--emit-line "    # -----------------------------------------")
  (sysml-gen--emit-line (format "    # %s" title))
  (sysml-gen--emit-line "    # -----------------------------------------"))

;;; --- Packages Emitter ---

(defun sysml-gen--emit-packages (ast symtab)
  "Emit Jython for packages."
  (let ((packages (plist-get ast :packages)))
    (dolist (pkg packages)
      (let* ((name (cdr (assoc "Name" pkg)))
             (parent (cdr (assoc "Parent" pkg)))
             (var (if (string= parent "_root_") "pkg"
                    (concat "pkg" (replace-regexp-in-string
                                   "[^a-zA-Z0-9_]" "_" name)))))
        (puthash name var symtab)
        (sysml-gen--emit-line
         (format "    %s = create_package(\"%s\", %s)"
                 var name
                 (if (string= parent "_root_") "root"
                   (gethash parent symtab parent))))))))

;;; --- Enumerations Emitter ---

(defun sysml-gen--emit-enumerations (ast symtab)
  "Emit Jython for enumerations."
  (dolist (enum (plist-get ast :enumerations))
    (let* ((name (plist-get enum :name))
           (pkg (plist-get enum :package))
           (literals (plist-get enum :literals))
           (desc (plist-get enum :description))
           (var (sysml-gen--varname "enum" name)))
      (puthash name var symtab)
      (sysml-gen--emit-line
       (format "    %s = create_enumeration(\"%s\", %s, ["
               var name (gethash pkg symtab pkg)))
      (dotimes (i (length literals))
        (let ((lit (nth i literals))
              (last-p (= i (1- (length literals)))))
          (sysml-gen--emit-line
           (format "        \"%s\"%s" lit (if last-p "" ",")))))
      (sysml-gen--emit-line "    ])")
      (sysml-gen--emit-documentation var desc)
      (sysml-gen--emit-line ""))))

;;; --- DataTypes Emitter ---

(defun sysml-gen--emit-datatypes (ast symtab)
  "Emit Jython for datatypes."
  (dolist (dt (plist-get ast :datatypes))
    (let* ((name (plist-get dt :name))
           (pkg (plist-get dt :package))
           (props (plist-get dt :properties))
           (desc (plist-get dt :description))
           (var (sysml-gen--varname "dt" name)))
      (puthash name var symtab)
      (sysml-gen--emit-line
       (format "    %s = create_datatype(\"%s\", %s)"
               var name (gethash pkg symtab pkg)))
      ;; Use loop pattern for datatypes with many untyped properties
      (let ((all-untyped (seq-every-p
                          (lambda (p) (string-empty-p (or (cdr (assoc "Type" p)) "")))
                          props)))
        (if (and all-untyped (> (length props) 5))
            (progn
              (sysml-gen--emit-line "    for f in [")
              (let ((prop-names (mapcar (lambda (p) (cdr (assoc "Property" p))) props)))
                (dotimes (i (length prop-names))
                  (let ((pname (nth i prop-names))
                        (last-p (= i (1- (length prop-names)))))
                    (sysml-gen--emit-line
                     (format "        \"%s\"%s" pname (if last-p "" ","))))))
              (sysml-gen--emit-line "    ]:")
              (sysml-gen--emit-line (format "        add_value_property(%s, f)" var)))
          ;; Normal per-property emission
          (dolist (prop props)
            (let ((pname (cdr (assoc "Property" prop)))
                  (ptype (cdr (assoc "Type" prop))))
              (if (and ptype (not (string-empty-p ptype)))
                  (sysml-gen--emit-line
                   (format "    add_value_property(%s, \"%s\", %s)"
                           var pname (gethash ptype symtab ptype)))
                (sysml-gen--emit-line
                 (format "    add_value_property(%s, \"%s\")" var pname)))))))
      (sysml-gen--emit-documentation var desc)
      (sysml-gen--emit-line ""))))

;;; --- Blocks Emitter ---

(defun sysml-gen--emit-blocks (ast symtab)
  "Emit Jython for blocks: creation, value props, part props, ref props."
  (let ((blocks (plist-get ast :blocks))
        ;; We need to collect deferred properties for later emission
        all-part-props all-ref-props)

    ;; First: create all blocks and their value properties
    (dolist (blk blocks)
      (let* ((name (plist-get blk :name))
             (pkg (plist-get blk :package))
             (desc (plist-get blk :description))
             (var (sysml-gen--varname "blk" name)))
        (puthash name var symtab)
        (sysml-gen--emit-line
         (format "    %s = create_block(\"%s\", %s)"
                 var name (gethash pkg symtab pkg)))
        (sysml-gen--emit-documentation var desc)
        ;; Value properties
        (dolist (prop (plist-get blk :value-properties))
          (let ((pname (cdr (assoc "Property" prop)))
                (ptype (cdr (assoc "Type" prop))))
            (if (and ptype (not (string-empty-p ptype)))
                (sysml-gen--emit-line
                 (format "    add_value_property(%s, \"%s\", %s)"
                         var pname (gethash ptype symtab ptype)))
              (sysml-gen--emit-line
               (format "    add_value_property(%s, \"%s\")" var pname)))))
        ;; Collect part and ref properties for deferred emission
        (dolist (prop (plist-get blk :part-properties))
          (push (list :owner var
                      :prop-name (cdr (assoc "Property" prop))
                      :type-name (cdr (assoc "Type" prop)))
                all-part-props))
        (dolist (prop (plist-get blk :reference-properties))
          (push (list :owner var
                      :prop-name (cdr (assoc "Property" prop))
                      :type-name (cdr (assoc "Type" prop)))
                all-ref-props))
        (sysml-gen--emit-line "")))

    ;; Now emit part properties (all blocks exist, so types resolve)
    (when all-part-props
      (sysml-gen--emit-line "")
      (dolist (pp (nreverse all-part-props))
        (let ((type-var (gethash (plist-get pp :type-name) symtab
                                 (plist-get pp :type-name))))
          (sysml-gen--emit-line
           (format "    add_part_property(%s, \"%s\", %s)"
                   (plist-get pp :owner)
                   (plist-get pp :prop-name)
                   type-var)))))

    ;; Reference properties
    (when all-ref-props
      (sysml-gen--emit-section-comment "Reference properties (cross-cutting dependencies)")
      (dolist (rp (nreverse all-ref-props))
        (let ((type-var (gethash (plist-get rp :type-name) symtab
                                 (plist-get rp :type-name))))
          (sysml-gen--emit-line
           (format "    add_reference_property(%s, \"%s\", %s)"
                   (plist-get rp :owner)
                   (plist-get rp :prop-name)
                   type-var)))))))

;;; --- Interfaces Emitter ---

(defun sysml-gen--emit-interfaces (ast symtab)
  "Emit Jython for interfaces."
  (dolist (iface (plist-get ast :interfaces))
    (let* ((name (plist-get iface :name))
           (pkg (plist-get iface :package))
           (ops (plist-get iface :operations))
           (desc (plist-get iface :description))
           (var (sysml-gen--varname "if" name)))
      (puthash name var symtab)
      (sysml-gen--emit-line
       (format "    %s = create_interface(\"%s\", %s)"
               var name (gethash pkg symtab pkg)))
      (sysml-gen--emit-documentation var desc)
      ;; Emit operations as a list + loop
      (let ((ops-var (concat (downcase (substring name 0 1))
                             (substring name 1)
                             "_ops")))
        ;; Use a simpler approach: just emit add_operation calls
        (dolist (op ops)
          (sysml-gen--emit-line
           (format "    add_operation(%s, \"%s\")" var op))))
      (sysml-gen--emit-line ""))))

;;; --- Ports Emitter ---

(defun sysml-gen--emit-ports (ast symtab)
  "Emit Jython for ports."
  (dolist (port (plist-get ast :ports))
    (let ((owner (cdr (assoc "Owner" port)))
          (port-name (cdr (assoc "Port Name" port)))
          (iface-type (cdr (assoc "Interface Type" port))))
      (sysml-gen--emit-line
       (format "    add_flow_port(%s, \"%s\", %s)"
               (gethash owner symtab owner)
               port-name
               (gethash iface-type symtab iface-type))))))

;;; --- Relationships Emitter ---

(defun sysml-gen--emit-relationships (ast symtab)
  "Emit Jython for relationships: realizations, dependencies, usages."
  ;; Relationships package already in symtab from packages section
  (let ((rels-pkg (gethash "Relationships" symtab "pkgRels")))

    ;; Realizations
    (sysml-gen--emit-subsection-comment "Interface Realizations")
    (dolist (r (plist-get ast :realizations))
      (let ((block (cdr (assoc "Block" r)))
            (iface (cdr (assoc "Interface" r))))
        (sysml-gen--emit-line
         (format "    add_realization(%s, %s, %s)"
                 (gethash block symtab block)
                 (gethash iface symtab iface)
                 rels-pkg))))

    ;; Dependencies
    (sysml-gen--emit-subsection-comment "Dependencies")
    (dolist (d (plist-get ast :dependencies))
      (let ((client (cdr (assoc "Client" d)))
            (supplier (cdr (assoc "Supplier" d)))
            (name (cdr (assoc "Name" d))))
        (sysml-gen--emit-line
         (format "    add_dependency(%s, %s,"
                 (gethash client symtab client)
                 (gethash supplier symtab supplier)))
        (sysml-gen--emit-line
         (format "                   \"%s\", %s)" name rels-pkg))))

    ;; Usages
    (sysml-gen--emit-subsection-comment "Usage relationships (<<use>>)")
    (dolist (u (plist-get ast :usages))
      (let ((client (cdr (assoc "Client" u)))
            (supplier (cdr (assoc "Supplier" u)))
            (name (cdr (assoc "Name" u))))
        (sysml-gen--emit-line
         (format "    add_usage(%s, %s, \"%s\", %s)"
                 (gethash client symtab client)
                 (gethash supplier symtab supplier)
                 name rels-pkg))))))

;;; --- Constraints Emitter ---

(defun sysml-gen--emit-constraints (ast symtab)
  "Emit Jython for constraint blocks and properties."
  ;; Constraints package already in symtab
  (let ((pkg (gethash "Constraints" symtab "pkgConstraints")))

    ;; Constraint blocks
    (dolist (cb (plist-get ast :constraint-blocks))
      (let* ((name (plist-get cb :name))
             (params (plist-get cb :parameters))
             (expr (plist-get cb :expression))
             (desc (plist-get cb :description))
             (var (sysml-gen--varname "cb" name)))
        (puthash name var symtab)
        (sysml-gen--emit-line
         (format "    %s = create_constraint_block(" var))
        (sysml-gen--emit-line
         (format "        \"%s\", %s," name pkg))
        (sysml-gen--emit-line "        [")
        (dolist (p params)
          (sysml-gen--emit-line (format "            (\"%s\",)," p)))
        (sysml-gen--emit-line "        ],")
        (sysml-gen--emit-line (format "        \"%s\"" expr))
        (sysml-gen--emit-line "    )")
        (sysml-gen--emit-documentation var desc)
        (sysml-gen--emit-line "")))

    ;; Constraint properties
    (sysml-gen--emit-subsection-comment "Bind constraint properties to blocks")
    (dolist (cp (plist-get ast :constraint-props))
      (let ((owner (cdr (assoc "Owner Block" cp)))
            (prop-name (cdr (assoc "Property Name" cp)))
            (cb-name (cdr (assoc "Constraint Block" cp))))
        (sysml-gen--emit-line
         (format "    add_constraint_property(%s, \"%s\", %s)"
                 (gethash owner symtab owner)
                 prop-name
                 (gethash cb-name symtab cb-name)))))))

;;; --- Activities Emitter ---

(defun sysml-gen--emit-activities (ast symtab)
  "Emit Jython for activity diagrams."
  ;; Activities package already in symtab
  (let ((pkg (gethash "Activities" symtab "pkgActivities")))
    (dolist (act (plist-get ast :activities))
      (let* ((name (plist-get act :name))
             (desc (plist-get act :description))
             (act-var (sysml-gen--varname "act" name))
             (node-vars (make-hash-table :test 'equal))
             (partition-vars (make-hash-table :test 'equal)))
        (puthash name act-var symtab)

        ;; Create activity
        (sysml-gen--emit-subsection-comment name)
        (sysml-gen--emit-line
         (format "    %s = create_activity(\"%s\", %s)" act-var name pkg))
        (sysml-gen--emit-documentation act-var desc)
        (sysml-gen--emit-line "")

        ;; Partitions (swimlanes)
        (sysml-gen--emit-line "    # Swimlanes")
        (dolist (part (plist-get act :partitions))
          (let* ((pname (cdr (assoc "Name" part)))
                 (represents (cdr (assoc "Represents" part)))
                 (pvar (sysml-gen--varname "swim" pname)))
            (puthash pname pvar partition-vars)
            (if (and represents (not (string-empty-p represents)))
                (sysml-gen--emit-line
                 (format "    %s = create_activity_partition(\"%s\", %s, %s)"
                         pvar pname act-var
                         (gethash represents symtab represents)))
              (sysml-gen--emit-line
               (format "    %s = create_activity_partition(\"%s\", %s)"
                       pvar pname act-var)))))
        (sysml-gen--emit-line "")

        ;; Nodes
        (sysml-gen--emit-line "    # Nodes")
        (dolist (node (plist-get act :nodes))
          (let* ((id (cdr (assoc "ID" node)))
                 (type (cdr (assoc "Type" node)))
                 (nname (cdr (assoc "Name" node)))
                 (partition (cdr (assoc "Partition" node))))
            (puthash id id node-vars)
            ;; Create node based on type
            (cond
             ((string= type "initial")
              (sysml-gen--emit-line
               (format "    %s = create_initial_node(%s)" id act-var)))
             ((string= type "final")
              (if (and nname (not (string-empty-p nname))
                       (not (string= nname "final")))
                  (sysml-gen--emit-line
                   (format "    %s = create_final_node(%s, \"%s\")" id act-var nname))
                (sysml-gen--emit-line
                 (format "    %s = create_final_node(%s)" id act-var))))
             ((string= type "action")
              (sysml-gen--emit-line
               (format "    %s = create_action(\"%s\", %s)" id nname act-var)))
             ((string= type "decision")
              (sysml-gen--emit-line
               (format "    %s = create_decision_node(%s, \"%s\")" id act-var nname)))
             ((string= type "merge")
              (sysml-gen--emit-line
               (format "    %s = create_merge_node(%s, \"%s\")" id act-var nname)))
             ((string= type "fork")
              (sysml-gen--emit-line
               (format "    %s = create_fork_node(%s, \"%s\")" id act-var nname)))
             ((string= type "join")
              (sysml-gen--emit-line
               (format "    %s = create_join_node(%s, \"%s\")" id act-var nname)))
             ((string= type "send_signal")
              (sysml-gen--emit-line
               (format "    %s = create_send_signal_action(\"%s\", %s)" id nname act-var)))
             ((string= type "accept_event")
              (sysml-gen--emit-line
               (format "    %s = create_accept_event_action(\"%s\", %s)" id nname act-var))))
            ;; Assign partition
            (when (and partition (not (string-empty-p partition)))
              (sysml-gen--emit-line
               (format "    assign_partition(%s, %s)"
                       id (gethash partition partition-vars partition))))))
        (sysml-gen--emit-line "")

        ;; Control flows
        (sysml-gen--emit-line "    # Control flows")
        (dolist (flow (plist-get act :flows))
          (let ((src (cdr (assoc "Source" flow)))
                (tgt (cdr (assoc "Target" flow)))
                (guard (cdr (assoc "Guard" flow))))
            (if (and guard (not (string-empty-p guard)))
                (sysml-gen--emit-line
                 (format "    create_control_flow(%s, %s, %s, \"%s\")"
                         src tgt act-var guard))
              (sysml-gen--emit-line
               (format "    create_control_flow(%s, %s, %s)"
                       src tgt act-var)))))
        (sysml-gen--emit-line "")))))

;;; --- State Machines Emitter ---

(defun sysml-gen--emit-state-machines (ast symtab)
  "Emit Jython for state machines."
  (let ((pkg (gethash "StateMachines" symtab "pkgStateMachines")))
    (dolist (sm (plist-get ast :state-machines))
      (let* ((name (plist-get sm :name))
             (desc (plist-get sm :description))
             (sm-var (sysml-gen--varname "sm_" name))
             (id-vars (make-hash-table :test 'equal)))

        (sysml-gen--emit-subsection-comment name)
        (sysml-gen--emit-line
         (format "    %s = create_state_machine(\"%s\", %s)" sm-var name pkg))
        (sysml-gen--emit-documentation sm-var desc)

        ;; Collect composite state names to identify sub-regions
        (let ((composite-state-names
               (mapcar (lambda (s) (cdr (assoc "Name" s)))
                       (seq-filter (lambda (s) (string= (cdr (assoc "Type" s)) "composite"))
                                   (plist-get sm :states)))))
          ;; Regions — only emit top-level regions (owned by the SM itself).
          ;; Sub-regions of composite states are created by create_composite_state.
          (dolist (reg (plist-get sm :regions))
            (let* ((id (cdr (assoc "ID" reg)))
                   (rname (cdr (assoc "Name" reg)))
                   (owner (cdr (assoc "Owner" reg))))
              (puthash id id id-vars)
              (when (string= owner name)
                (sysml-gen--emit-line
                 (format "    %s = create_region(\"%s\", %s)" id rname sm-var))))))
        (sysml-gen--emit-line "")

        ;; States (must handle composite states specially)
        (dolist (state (plist-get sm :states))
          (let* ((id (cdr (assoc "ID" state)))
                 (sname (cdr (assoc "Name" state)))
                 (stype (cdr (assoc "Type" state)))
                 (region (cdr (assoc "Region" state)))
                 (entry (cdr (assoc "Entry Action" state)))
                 (exit-a (cdr (assoc "Exit Action" state)))
                 (do-act (cdr (assoc "Do Activity" state)))
                 (region-var (gethash region id-vars region)))
            (puthash id id id-vars)
            (if (string= stype "composite")
                ;; Composite state: returns tuple (state, sub_region)
                ;; The sub-region ID follows the naming convention: the region
                ;; whose Owner matches this state's Name
                (let ((sub-reg-id
                       (cdr (assoc "ID"
                                   (seq-find
                                    (lambda (r) (string= (cdr (assoc "Owner" r)) sname))
                                    (plist-get sm :regions))))))
                  (sysml-gen--emit-line
                   (format "    %s, %s = create_composite_state(\"%s\", %s)"
                           id (or sub-reg-id (concat id "_reg"))
                           sname region-var))
                  (when sub-reg-id
                    (puthash sub-reg-id sub-reg-id id-vars)))
              ;; Simple state
              (sysml-gen--emit-line
               (format "    %s = create_state(\"%s\", %s)" id sname region-var)))
            ;; Entry/exit/do actions
            (when (and entry (not (string-empty-p entry)))
              (sysml-gen--emit-line
               (format "    add_entry_action(%s, \"%s\")" id entry)))
            (when (and exit-a (not (string-empty-p exit-a)))
              (sysml-gen--emit-line
               (format "    add_exit_action(%s, \"%s\")" id exit-a)))
            (when (and do-act (not (string-empty-p do-act)))
              (sysml-gen--emit-line
               (format "    add_do_activity(%s, \"%s\")" id do-act)))
            (sysml-gen--emit-line "")))

        ;; Pseudostates
        (dolist (ps (plist-get sm :pseudostates))
          (let* ((id (cdr (assoc "ID" ps)))
                 (kind (cdr (assoc "Kind" ps)))
                 (region (cdr (assoc "Region" ps)))
                 (region-var (gethash region id-vars region)))
            (puthash id id id-vars)
            (sysml-gen--emit-line
             (format "    %s = create_pseudostate(%s, \"%s\")" id region-var kind))))
        (sysml-gen--emit-line "")

        ;; Final states
        (dolist (fs (plist-get sm :final-states))
          (let* ((id (cdr (assoc "ID" fs)))
                 (region (cdr (assoc "Region" fs)))
                 (region-var (gethash region id-vars region)))
            (puthash id id id-vars)
            (sysml-gen--emit-line
             (format "    %s = create_final_state(%s)" id region-var))))
        (sysml-gen--emit-line "")

        ;; Transitions
        (sysml-gen--emit-line "    # Transitions")
        (dolist (tr (plist-get sm :transitions))
          (let* ((src (cdr (assoc "Source" tr)))
                 (tgt (cdr (assoc "Target" tr)))
                 (region (cdr (assoc "Region" tr)))
                 (trigger (cdr (assoc "Trigger" tr)))
                 (guard (cdr (assoc "Guard" tr)))
                 (effect (cdr (assoc "Effect" tr)))
                 (region-var (gethash region id-vars region))
                 (has-trigger (and trigger (not (string-empty-p trigger))))
                 (has-guard (and guard (not (string-empty-p guard))))
                 (has-effect (and effect (not (string-empty-p effect)))))
            (cond
             ;; No optional args
             ((not (or has-trigger has-guard has-effect))
              (sysml-gen--emit-line
               (format "    create_transition(%s, %s, %s)" src tgt region-var)))
             ;; Has kwargs
             (t
              (let ((parts (list (format "    create_transition(%s, %s, %s" src tgt region-var))))
                (when has-trigger
                  (push (format "                      trigger_name=\"%s\"" trigger) parts))
                (when has-guard
                  (push (format "                      guard_expr=\"%s\"" guard) parts))
                (when has-effect
                  (push (format "                      effect_name=\"%s\"" effect) parts))
                ;; Join with commas
                (let* ((reversed (nreverse parts))
                       (first-line (concat (car reversed) ",")))
                  (sysml-gen--emit-line first-line)
                  (let ((rest (cdr reversed)))
                    (dotimes (i (length rest))
                      (let ((line (nth i rest))
                            (last-p (= i (1- (length rest)))))
                        (sysml-gen--emit-line (concat line (if last-p ")" ","))))))))))))
        (sysml-gen--emit-line "")))))

;;; --- Sequence Diagrams Emitter ---

(defun sysml-gen--emit-interactions (ast symtab)
  "Emit Jython for sequence diagrams (interactions)."
  (let ((pkg (gethash "SequenceDiagrams" symtab "pkgSequences")))
    (dolist (interaction (plist-get ast :interactions))
      (let* ((name (plist-get interaction :name))
             (desc (plist-get interaction :description))
             (int-var (sysml-gen--varname "sd" name))
             (ll-vars (make-hash-table :test 'equal)))

        (sysml-gen--emit-subsection-comment name)
        (sysml-gen--emit-line
         (format "    %s = create_interaction(\"%s\", %s)" int-var name pkg))
        (sysml-gen--emit-documentation int-var desc)
        (sysml-gen--emit-line "")

        ;; Lifelines
        (sysml-gen--emit-line "    # Lifelines")
        (dolist (ll (plist-get interaction :lifelines))
          (let* ((ll-name (cdr (assoc "Name" ll)))
                 (represents (cdr (assoc "Represents" ll)))
                 (ll-var (sysml-gen--varname "ll" (concat (capitalize (substring ll-name 0 1))
                                                     (substring ll-name 1)
                                                     "_"
                                                     (sysml-gen--interaction-suffix name)))))
            (puthash ll-name ll-var ll-vars)
            (if (and represents (not (string-empty-p represents)))
                (sysml-gen--emit-line
                 (format "    %s = create_lifeline(\"%s\", %s, %s)"
                         ll-var ll-name int-var
                         (gethash represents symtab represents)))
              (sysml-gen--emit-line
               (format "    %s = create_lifeline(\"%s\", %s)"
                       ll-var ll-name int-var)))))
        (sysml-gen--emit-line "")

        ;; Messages
        (sysml-gen--emit-line "    # Messages")
        (dolist (msg (plist-get interaction :messages))
          (let* ((msg-name (cdr (assoc "Name" msg)))
                 (sender (cdr (assoc "Sender" msg)))
                 (receiver (cdr (assoc "Receiver" msg)))
                 (sort (cdr (assoc "Sort" msg)))
                 (sender-var (gethash sender ll-vars sender))
                 (receiver-var (gethash receiver ll-vars receiver)))
            (sysml-gen--emit-line
             (format "    create_message(\"%s\"," msg-name))
            (sysml-gen--emit-line
             (format "                   %s, %s, %s, \"%s\")"
                     int-var sender-var receiver-var sort))))
        (sysml-gen--emit-line "")))))

(defun sysml-gen--interaction-suffix (name)
  "Generate a short suffix for lifeline variable names from interaction NAME.
Takes the first letter of each word (split on _ or spaces), lowercased."
  (let ((words (split-string name "[_ ]+" t)))
    (mapconcat (lambda (w) (downcase (substring w 0 1))) words "")))

;;;; =========================================================================
;;;; User-facing Commands
;;;; =========================================================================

;;;###autoload
(defun sysml-gen-validate (model-file)
  "Parse MODEL-FILE and validate cross-references.
Results shown in *SysML-Gen Validation* buffer.
When called interactively, prompts for the Markdown file."
  (interactive (list (sysml-gen--read-model-file)))
  (let* ((md-buf (find-file-noselect model-file))
         (ast (sysml-gen--parse-buffer md-buf))
         (errors (sysml-gen--validate ast))
         (buf (get-buffer-create "*SysML-Gen Validation*")))
    (with-current-buffer buf
      (erase-buffer)
      (insert (format "Model: %s\n\n" (abbreviate-file-name model-file)))
      (if errors
          (progn
            (insert (format "Validation: %d error(s)\n\n" (length errors)))
            (dolist (err errors)
              (insert (format "  ERROR: %s\n" err))))
        (insert "Validation: OK (no errors)\n")
        (insert (format "\nParsed: %d packages, %d enums, %d datatypes, %d blocks,\n"
                        (length (plist-get ast :packages))
                        (length (plist-get ast :enumerations))
                        (length (plist-get ast :datatypes))
                        (length (plist-get ast :blocks))))
        (insert (format "        %d interfaces, %d ports, %d realizations,\n"
                        (length (plist-get ast :interfaces))
                        (length (plist-get ast :ports))
                        (length (plist-get ast :realizations))))
        (insert (format "        %d dependencies, %d usages,\n"
                        (length (plist-get ast :dependencies))
                        (length (plist-get ast :usages))))
        (insert (format "        %d constraint blocks, %d constraint props,\n"
                        (length (plist-get ast :constraint-blocks))
                        (length (plist-get ast :constraint-props))))
        (insert (format "        %d activities, %d state machines, %d interactions\n"
                        (length (plist-get ast :activities))
                        (length (plist-get ast :state-machines))
                        (length (plist-get ast :interactions))))))
    (display-buffer buf)))

;;;###autoload
(defun sysml-gen-convert (model-file)
  "Parse MODEL-FILE, validate, and emit Jython to *SysML-Gen Output*.
When called interactively, prompts for the model file."
  (interactive (list (sysml-gen--read-model-file)))
  (let* ((md-buf (find-file-noselect model-file))
         (ast (sysml-gen--parse-buffer md-buf))
         (errors (sysml-gen--validate ast)))
    (if errors
        (progn
          (sysml-gen-validate model-file)
          (message "sysml-gen: %d validation error(s) — see *SysML-Gen Validation*"
                   (length errors)))
      (let ((out-buf (get-buffer-create "*SysML-Gen Output*"))
            (helpers-file (expand-file-name "sysml-gen-helpers.py"
                                            sysml-gen--directory)))
        (with-current-buffer out-buf
          (erase-buffer)
          (when (file-exists-p helpers-file)
            (insert-file-contents helpers-file)
            (goto-char (point-max))
            (insert "\n# =========================================\n")
            (insert "# Main block — generated by sysml-gen.el\n")
            (insert "# =========================================\n\n"))
          (sysml-gen--emit ast)
          (python-mode))
        (display-buffer out-buf)
        (message "sysml-gen: Jython generated (%d lines)"
                 (with-current-buffer out-buf
                   (count-lines (point-min) (point-max))))))))

;;;###autoload
(defun sysml-gen-verify (model-file)
  "Parse MODEL-FILE, validate, emit to temp buffer, and verify round-trip.
Results shown in *SysML-Gen Verification* buffer."
  (interactive (list (sysml-gen--read-model-file)))
  (let* ((md-buf (find-file-noselect model-file))
         (ast (sysml-gen--parse-buffer md-buf))
         (errors (sysml-gen--validate ast)))
    (if errors
        (progn
          (sysml-gen-validate model-file)
          (message "sysml-gen: %d validation error(s) — see *SysML-Gen Validation*"
                   (length errors)))
      (let ((jython-text
             (with-temp-buffer
               (sysml-gen--emit ast)
               (buffer-string)))
            (results-buf (get-buffer-create "*SysML-Gen Verification*")))
        (let ((results (sysml-gen--verify-ast-vs-jython ast jython-text)))
          (with-current-buffer results-buf
            (erase-buffer)
            (sysml-gen--verify-insert-report results model-file))
          (when noninteractive
            (princ (with-current-buffer results-buf (buffer-string))))
          (display-buffer results-buf)
          (let ((failed (seq-count (lambda (r) (not (plist-get r :passed)))
                                   results)))
            (message "sysml-gen: verification complete — %d/%d passed%s"
                     (- (length results) failed) (length results)
                     (if (> failed 0) " (FAILURES)" ""))))))))

(defun sysml-gen--find-model-candidates ()
  "Find candidate model files (.md and .org) in current dir and immediate subdirs.
Filters out README, CHANGELOG, CLAUDE, LICENSE, and CONTRIBUTING files."
  (let ((excluded '("README.md" "CHANGELOG.md" "CLAUDE.md"
                     "LICENSE.md" "CONTRIBUTING.md" "README.org"))
        candidates)
    ;; Current directory — .md and .org
    (dolist (pattern '("*.md" "*.org"))
      (dolist (f (file-expand-wildcards
                  (expand-file-name pattern default-directory)))
        (unless (member (file-name-nondirectory f) excluded)
          (push f candidates))))
    ;; Immediate subdirectories
    (dolist (dir (seq-filter #'file-directory-p
                             (directory-files default-directory t "^[^.]")))
      (dolist (pattern '("*.md" "*.org"))
        (dolist (f (file-expand-wildcards (expand-file-name pattern dir)))
          (unless (member (file-name-nondirectory f) excluded)
            (push f candidates)))))
    (nreverse candidates)))

(defun sysml-gen--read-model-file ()
  "Prompt for a model file (.md or .org) with smart defaults.
Searches current directory and immediate subdirectories for model files,
filtering out common non-model files."
  (let ((candidates (sysml-gen--find-model-candidates)))
    (cond
     ((null candidates)
      (read-file-name "Model file: "))
     ((= (length candidates) 1)
      (read-file-name "Model file: " nil (car candidates) t
                      (file-name-nondirectory (car candidates))))
     (t
      (let ((relative (mapcar (lambda (f)
                                (file-relative-name f default-directory))
                              candidates)))
        (expand-file-name
         (completing-read "Model file: " relative nil t)
         default-directory))))))

(provide 'sysml-gen)

;;; sysml-gen.el ends here
