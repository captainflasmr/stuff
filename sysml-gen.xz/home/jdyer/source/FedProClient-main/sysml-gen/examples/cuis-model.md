# CUIS SysML Model Definition

This file defines the complete SysML model for the Common User Interface Server (CUIS).
It is consumed by `cuis-jython-gen.el` to produce the Jython main block that runs in MagicDraw.

## Packages

| Name | Parent |
|------|--------|
| CUIS_High_Level_Design | _root_ |
| Blocks | CUIS_High_Level_Design |
| Interfaces | CUIS_High_Level_Design |
| DataTypes | CUIS_High_Level_Design |
| Enumerations | CUIS_High_Level_Design |
| Relationships | CUIS_High_Level_Design |
| Constraints | CUIS_High_Level_Design |
| Activities | CUIS_High_Level_Design |
| StateMachines | CUIS_High_Level_Design |
| SequenceDiagrams | CUIS_High_Level_Design |

## Enumerations

### ClientState

- **Package:** Enumerations
- **Literals:** DISCONNECTED, CONNECTED, SUBSCRIBING, ACTIVE, ERROR

### UpdatePolicy

- **Package:** Enumerations
- **Literals:** ON_CHANGE, PERIODIC, ON_REQUEST

### TransportStatus

- **Package:** Enumerations
- **Literals:** OK, TIMEOUT, DISCONNECTED, ERROR

### Endianness

- **Package:** Enumerations
- **Literals:** BIG_ENDIAN, LITTLE_ENDIAN

## DataTypes

### HLAhandle

- **Package:** DataTypes

| Property | Type |
|----------|------|
| opaque_bytes | |

### HLAtimestamp

- **Package:** DataTypes

| Property | Type |
|----------|------|
| seconds | |
| fractional_seconds | |

### HLAduration

- **Package:** DataTypes

| Property | Type |
|----------|------|
| seconds | |
| fractional_seconds | |

### Attributes

- **Package:** DataTypes

| Property | Type |
|----------|------|
| attribute_handles | HLAhandle |

### Attribute_Values

- **Package:** DataTypes

| Property | Type |
|----------|------|
| name | |
| value | |

### Parameter_Values

- **Package:** DataTypes

| Property | Type |
|----------|------|
| name | |
| value | |

### Data_Value

- **Package:** DataTypes

| Property | Type |
|----------|------|
| hla_octet | |
| hla_int16 | |
| hla_int32 | |
| hla_int64 | |
| hla_float32 | |
| hla_float64 | |
| hla_ascii_string | |
| hla_unicode_string | |
| hla_opaque_data | |

### ObjectReference

- **Package:** DataTypes

| Property | Type |
|----------|------|
| object_class_name | |
| instance_handle | HLAhandle |

### SubscriptionRecord

- **Package:** DataTypes

| Property | Type |
|----------|------|
| object_class_name | |
| attribute_names | |
| client_id | |
| update_policy | UpdatePolicy |

### ClientInfo

- **Package:** DataTypes

| Property | Type |
|----------|------|
| client_id | |
| client_name | |
| endpoint_address | |
| state | ClientState |
| endianness | Endianness |

## Blocks

### CommonUI_Server

- **Package:** Blocks

#### Value Properties

_None_

#### Part Properties

| Property | Type |
|----------|------|
| rtiAdapter | RTIAdapter |
| routingEngine | RoutingEngine |
| clientRegistry | ClientRegistry |
| sessionManager | SessionManager |
| grpcServices | GRPCServices |
| encodingLayer | EncodingLayer |

#### Reference Properties

_None_

### RTIAdapter

- **Package:** Blocks

#### Value Properties

_None_

#### Part Properties

| Property | Type |
|----------|------|
| federationConnection | FederationConnection |
| objectManager | ObjectManager |
| interactionManager | InteractionManager |
| callbackDispatcher | CallbackDispatcher |

#### Reference Properties

| Property | Type |
|----------|------|
| encodingLayer | EncodingLayer |

### FederationConnection

- **Package:** Blocks

#### Value Properties

| Property | Type |
|----------|------|
| federation_name | |
| federate_name | |
| fom_path | |
| rti_host | |
| rti_port | |

#### Part Properties

_None_

#### Reference Properties

_None_

### ObjectManager

- **Package:** Blocks

#### Value Properties

_None_

#### Part Properties

_None_

#### Reference Properties

_None_

### InteractionManager

- **Package:** Blocks

#### Value Properties

_None_

#### Part Properties

_None_

#### Reference Properties

_None_

### CallbackDispatcher

- **Package:** Blocks

#### Value Properties

_None_

#### Part Properties

_None_

#### Reference Properties

| Property | Type |
|----------|------|
| routingEngine | RoutingEngine |

### RoutingEngine

- **Package:** Blocks

#### Value Properties

_None_

#### Part Properties

| Property | Type |
|----------|------|
| subscriptionTable | SubscriptionTable |
| attributeFilter | AttributeFilter |

#### Reference Properties

| Property | Type |
|----------|------|
| clientRegistry | ClientRegistry |

### SubscriptionTable

- **Package:** Blocks

#### Value Properties

_None_

#### Part Properties

_None_

#### Reference Properties

_None_

### AttributeFilter

- **Package:** Blocks

#### Value Properties

_None_

#### Part Properties

_None_

#### Reference Properties

_None_

### ClientRegistry

- **Package:** Blocks

#### Value Properties

| Property | Type |
|----------|------|
| max_clients | |

#### Part Properties

_None_

#### Reference Properties

_None_

### SessionManager

- **Package:** Blocks

#### Value Properties

| Property | Type |
|----------|------|
| session_timeout_ms | |
| heartbeat_interval_ms | |

#### Part Properties

_None_

#### Reference Properties

| Property | Type |
|----------|------|
| clientRegistry | ClientRegistry |

### GRPCServices

- **Package:** Blocks

#### Value Properties

| Property | Type |
|----------|------|
| listen_port | |
| max_concurrent_streams | |

#### Part Properties

_None_

#### Reference Properties

| Property | Type |
|----------|------|
| routingEngine | RoutingEngine |
| sessionManager | SessionManager |
| encodingLayer | EncodingLayer |

### EncodingLayer

- **Package:** Blocks

#### Value Properties

| Property | Type |
|----------|------|
| default_endianness | Endianness |

#### Part Properties

| Property | Type |
|----------|------|
| dataValueCodec | DataValueCodec |
| tagEncoder | TagEncoder |
| timeCodec | TimeCodec |

#### Reference Properties

| Property | Type |
|----------|------|
| clientRegistry | ClientRegistry |

### DataValueCodec

- **Package:** Blocks

#### Value Properties

| Property | Type |
|----------|------|
| supported_types | |

#### Part Properties

_None_

#### Reference Properties

_None_

### TagEncoder

- **Package:** Blocks

#### Value Properties

_None_

#### Part Properties

_None_

#### Reference Properties

_None_

### TimeCodec

- **Package:** Blocks

#### Value Properties

_None_

#### Part Properties

_None_

#### Reference Properties

_None_

## Interfaces

### UFCommonUIService

- **Package:** Interfaces
- **Operations:**
  - Publish_Object_Attributes
  - Unpublish_Object
  - Subscribe_Object_Attributes
  - Unsubscribe_Object
  - Update_Attribute_Values
  - Request_Object_Update
  - Publish_Interaction
  - Subscribe_Interaction
  - Send_Interaction

### UFCommonUIClientService

- **Package:** Interfaces
- **Operations:**
  - Discover_Object_Instance
  - Reflect_Attribute_Values
  - Remove_Object_Instance
  - Provide_Attribute_Value_Update
  - Receive_Interaction

### ISessionManagement

- **Package:** Interfaces
- **Operations:**
  - Connect_Client
  - Disconnect_Client
  - Heartbeat
  - Get_Client_State

### IRTIFederationOps

- **Package:** Interfaces
- **Operations:**
  - Join_Federation
  - Resign_Federation
  - Register_Object_Instance
  - Delete_Object_Instance
  - Update_Object_Attributes
  - Send_RTI_Interaction
  - Subscribe_Object_Class
  - Unsubscribe_Object_Class
  - Subscribe_Interaction_Class
  - Unsubscribe_Interaction_Class

### IEncodingService

- **Package:** Interfaces
- **Operations:**
  - Encode_Data_Value
  - Decode_Data_Value
  - Encode_Tag
  - Decode_Tag
  - Encode_Timestamp
  - Decode_Timestamp
  - Encode_Duration
  - Decode_Duration
  - Swap_Endianness

## Ports

| Owner | Port Name | Interface Type |
|-------|-----------|----------------|
| CommonUI_Server | serverPort | UFCommonUIService |
| CommonUI_Server | clientCallbackPort | UFCommonUIClientService |
| GRPCServices | grpcServerPort | UFCommonUIService |
| GRPCServices | sessionPort | ISessionManagement |
| RTIAdapter | rtiPort | IRTIFederationOps |
| EncodingLayer | encodingPort | IEncodingService |

## Relationships

### Realizations

| Block | Interface |
|-------|-----------|
| GRPCServices | UFCommonUIService |
| GRPCServices | ISessionManagement |
| RTIAdapter | IRTIFederationOps |
| CommonUI_Server | UFCommonUIClientService |
| EncodingLayer | IEncodingService |

### Dependencies

| Client | Supplier | Name |
|--------|----------|------|
| CallbackDispatcher | RoutingEngine | routes_callbacks_via |
| RoutingEngine | ClientRegistry | resolves_subscribers_via |
| SessionManager | ClientRegistry | manages_clients_in |
| GRPCServices | RoutingEngine | dispatches_pubsub_to |
| GRPCServices | SessionManager | delegates_sessions_to |
| RTIAdapter | EncodingLayer | converts_hla_types_via |
| GRPCServices | EncodingLayer | marshals_values_via |
| EncodingLayer | ClientRegistry | reads_endianness_from |

### Usages

| Client | Supplier | Name |
|--------|----------|------|
| RTIAdapter | Data_Value | marshals_data_via |
| RTIAdapter | Attribute_Values | marshals_attributes_via |
| RTIAdapter | Parameter_Values | marshals_parameters_via |
| RTIAdapter | HLAhandle | passes_handles_as |
| RTIAdapter | HLAtimestamp | timestamps_updates_with |
| RTIAdapter | HLAduration | measures_durations_with |
| RTIAdapter | Attributes | declares_attribute_sets_with |
| RoutingEngine | SubscriptionRecord | tracks_subscriptions_with |
| ClientRegistry | ClientInfo | stores_clients_as |
| ObjectManager | ObjectReference | tracks_instances_with |
| EncodingLayer | Data_Value | encodes_decodes_via |
| EncodingLayer | HLAtimestamp | encodes_timestamps_via |
| EncodingLayer | HLAduration | encodes_durations_via |
| EncodingLayer | HLAhandle | serialises_handles_via |

## Constraints

### Constraint Blocks

#### CallbackLatencyConstraint

- **Package:** Constraints
- **Parameters:** rti_callback_arrival_ms, client_notification_ms, max_latency_budget_ms
- **Expression:** `client_notification_ms - rti_callback_arrival_ms <= max_latency_budget_ms`

#### GrpcRoundTripConstraint

- **Package:** Constraints
- **Parameters:** request_sent_ms, response_received_ms, max_round_trip_ms
- **Expression:** `response_received_ms - request_sent_ms <= max_round_trip_ms`

#### HeartbeatTimingConstraint

- **Package:** Constraints
- **Parameters:** heartbeat_interval_ms, session_timeout_ms, missed_beats_before_disconnect
- **Expression:** `heartbeat_interval_ms * missed_beats_before_disconnect <= session_timeout_ms`

#### EncodingLatencyConstraint

- **Package:** Constraints
- **Parameters:** encode_start_ms, encode_complete_ms, max_encoding_latency_ms
- **Expression:** `encode_complete_ms - encode_start_ms <= max_encoding_latency_ms`

#### UpdateThroughputConstraint

- **Package:** Constraints
- **Parameters:** num_subscribed_objects, updates_per_second_per_object, max_updates_per_second
- **Expression:** `num_subscribed_objects * updates_per_second_per_object <= max_updates_per_second`

#### InteractionThroughputConstraint

- **Package:** Constraints
- **Parameters:** num_interaction_subscriptions, interactions_per_second, max_dispatch_rate
- **Expression:** `num_interaction_subscriptions * interactions_per_second <= max_dispatch_rate`

#### StreamCapacityConstraint

- **Package:** Constraints
- **Parameters:** active_clients, streams_per_client, max_concurrent_streams
- **Expression:** `active_clients * streams_per_client <= max_concurrent_streams`

#### ClientCapacityConstraint

- **Package:** Constraints
- **Parameters:** connected_clients, max_clients
- **Expression:** `connected_clients <= max_clients`

#### SubscriptionCapacityConstraint

- **Package:** Constraints
- **Parameters:** num_clients, avg_subscriptions_per_client, max_total_subscriptions
- **Expression:** `num_clients * avg_subscriptions_per_client <= max_total_subscriptions`

#### ObjectInstanceCapacityConstraint

- **Package:** Constraints
- **Parameters:** registered_objects, discovered_objects, max_tracked_objects
- **Expression:** `registered_objects + discovered_objects <= max_tracked_objects`

### Constraint Properties

| Owner Block | Property Name | Constraint Block |
|-------------|---------------|------------------|
| CommonUI_Server | callbackLatency | CallbackLatencyConstraint |
| CommonUI_Server | updateThroughput | UpdateThroughputConstraint |
| CommonUI_Server | interactionThroughput | InteractionThroughputConstraint |
| GRPCServices | grpcRoundTrip | GrpcRoundTripConstraint |
| GRPCServices | streamCapacity | StreamCapacityConstraint |
| SessionManager | heartbeatTiming | HeartbeatTimingConstraint |
| ClientRegistry | clientCapacity | ClientCapacityConstraint |
| SubscriptionTable | subscriptionCapacity | SubscriptionCapacityConstraint |
| ObjectManager | objectCapacity | ObjectInstanceCapacityConstraint |
| EncodingLayer | encodingLatency | EncodingLatencyConstraint |

## Activities

### Activity: Object_PubSub_Flow

- **Package:** Activities

#### Partitions

| Name | Represents |
|------|------------|
| UIClient | |
| GRPCServices | GRPCServices |
| RoutingEngine | RoutingEngine |
| ClientRegistry | ClientRegistry |
| EncodingLayer | EncodingLayer |
| RTIAdapter | RTIAdapter |
| HLA_Federation | |

#### Nodes

| ID | Type | Name | Partition |
|----|------|------|-----------|
| ps_init | initial | | UIClient |
| ps_publish_req | action | Client calls Publish_Object_Attributes | UIClient |
| ps_grpc_recv_pub | action | Receive gRPC publish request | GRPCServices |
| ps_register_pub | action | Register publication in SubscriptionTable | RoutingEngine |
| ps_rti_publish | action | Publish object class to RTI | RTIAdapter |
| ps_rti_register | action | Register object instance with RTI | RTIAdapter |
| ps_fed_publish | send_signal | Object published in federation | HLA_Federation |
| ps_fork | fork | pub_sub_fork | UIClient |
| ps_subscribe_req | action | Client calls Subscribe_Object_Attributes | UIClient |
| ps_grpc_recv_sub | action | Receive gRPC subscribe request | GRPCServices |
| ps_lookup_client | action | Validate client in registry | ClientRegistry |
| ps_register_sub | action | Record subscription in SubscriptionTable | RoutingEngine |
| ps_rti_subscribe | action | Subscribe to object class at RTI | RTIAdapter |
| ps_join | join | pub_sub_join | RoutingEngine |
| ps_update | action | Publisher calls Update_Attribute_Values | UIClient |
| ps_grpc_recv_upd | action | Receive gRPC update | GRPCServices |
| ps_encode_update | action | Encode Data_Values to HLA representation | EncodingLayer |
| ps_rti_update | action | Forward attribute update to RTI | RTIAdapter |
| ps_fed_reflect | accept_event | RTI delivers Reflect callback | RTIAdapter |
| ps_decode_reflect | action | Decode HLA values to Data_Value representation | EncodingLayer |
| ps_route_reflect | action | Match reflection to subscriptions | RoutingEngine |
| ps_filter_attrs | action | Filter attributes per subscriber | RoutingEngine |
| ps_grpc_callback | action | Stream Reflect_Attribute_Values to client | GRPCServices |
| ps_client_reflect | action | Client receives reflected values | UIClient |
| ps_final | final | | UIClient |

#### Flows

| Source | Target | Guard |
|--------|--------|-------|
| ps_init | ps_fork | |
| ps_fork | ps_publish_req | |
| ps_publish_req | ps_grpc_recv_pub | |
| ps_grpc_recv_pub | ps_register_pub | |
| ps_register_pub | ps_rti_publish | |
| ps_rti_publish | ps_rti_register | |
| ps_rti_register | ps_fed_publish | |
| ps_fed_publish | ps_join | |
| ps_fork | ps_subscribe_req | |
| ps_subscribe_req | ps_grpc_recv_sub | |
| ps_grpc_recv_sub | ps_lookup_client | |
| ps_lookup_client | ps_register_sub | |
| ps_register_sub | ps_rti_subscribe | |
| ps_rti_subscribe | ps_join | |
| ps_join | ps_update | |
| ps_update | ps_grpc_recv_upd | |
| ps_grpc_recv_upd | ps_encode_update | |
| ps_encode_update | ps_rti_update | |
| ps_rti_update | ps_fed_reflect | |
| ps_fed_reflect | ps_decode_reflect | |
| ps_decode_reflect | ps_route_reflect | |
| ps_route_reflect | ps_filter_attrs | |
| ps_filter_attrs | ps_grpc_callback | |
| ps_grpc_callback | ps_client_reflect | |
| ps_client_reflect | ps_final | |

### Activity: Interaction_SendReceive_Flow

- **Package:** Activities

#### Partitions

| Name | Represents |
|------|------------|
| SenderClient | |
| GRPCServices | GRPCServices |
| EncodingLayer | EncodingLayer |
| RoutingEngine | RoutingEngine |
| RTIAdapter | RTIAdapter |
| ReceiverClient | |

#### Nodes

| ID | Type | Name | Partition |
|----|------|------|-----------|
| i_init | initial | | SenderClient |
| i_send_req | action | Client calls Send_Interaction | SenderClient |
| i_grpc_recv | action | Receive gRPC Send_Interaction request | GRPCServices |
| i_validate | action | Validate interaction class is published | RoutingEngine |
| i_decision | decision | valid_interaction? | RoutingEngine |
| i_encode_params | action | Encode Parameter_Values to HLA representation | EncodingLayer |
| i_rti_send | action | Send interaction to RTI | RTIAdapter |
| i_error | action | Return error to sender | GRPCServices |
| i_rti_callback | accept_event | RTI delivers Receive_Interaction callback | RTIAdapter |
| i_decode_params | action | Decode HLA parameters to Parameter_Values | EncodingLayer |
| i_route | action | Resolve subscribed receivers | RoutingEngine |
| i_decision_subs | decision | has_subscribers? | RoutingEngine |
| i_grpc_dispatch | action | Stream Receive_Interaction to each subscriber | GRPCServices |
| i_client_recv | action | Receiver client processes interaction | ReceiverClient |
| i_merge | merge | interaction_merge | RoutingEngine |
| i_final | final | | RoutingEngine |

#### Flows

| Source | Target | Guard |
|--------|--------|-------|
| i_init | i_send_req | |
| i_send_req | i_grpc_recv | |
| i_grpc_recv | i_validate | |
| i_validate | i_decision | |
| i_decision | i_encode_params | valid |
| i_encode_params | i_rti_send | |
| i_decision | i_error | invalid |
| i_error | i_merge | |
| i_rti_send | i_rti_callback | |
| i_rti_callback | i_decode_params | |
| i_decode_params | i_route | |
| i_route | i_decision_subs | |
| i_decision_subs | i_grpc_dispatch | subscribers exist |
| i_decision_subs | i_merge | no subscribers |
| i_grpc_dispatch | i_client_recv | |
| i_client_recv | i_merge | |
| i_merge | i_final | |

### Activity: Client_Session_Lifecycle

- **Package:** Activities

#### Partitions

| Name | Represents |
|------|------------|
| UIClient | |
| GRPCServices | GRPCServices |
| SessionManager | SessionManager |
| ClientRegistry | ClientRegistry |

#### Nodes

| ID | Type | Name | Partition |
|----|------|------|-----------|
| s_init | initial | | UIClient |
| s_connect_req | action | Client calls Connect_Client | UIClient |
| s_grpc_recv_conn | action | Receive gRPC connect request | GRPCServices |
| s_validate | action | Validate client credentials | SessionManager |
| s_decision_auth | decision | auth_valid? | SessionManager |
| s_reject | action | Return connection rejected | GRPCServices |
| s_register | action | Create client entry in registry | ClientRegistry |
| s_assign_id | action | Assign client_id and session token | SessionManager |
| s_ack_connect | action | Return connection acknowledged | GRPCServices |
| s_client_connected | action | Client enters ACTIVE state | UIClient |
| s_heartbeat_decision | decision | session_active? | SessionManager |
| s_wait_heartbeat | accept_event | Wait for heartbeat | SessionManager |
| s_heartbeat_check | decision | heartbeat_received? | SessionManager |
| s_update_timestamp | action | Update last-seen timestamp | SessionManager |
| s_timeout_disconnect | action | Mark client as timed-out | SessionManager |
| s_disconnect_req | action | Client calls Disconnect_Client | UIClient |
| s_grpc_recv_disc | action | Receive gRPC disconnect request | GRPCServices |
| s_cleanup_merge | merge | cleanup_merge | SessionManager |
| s_remove_subs | action | Remove all client subscriptions | SessionManager |
| s_remove_client | action | Remove client from registry | ClientRegistry |
| s_notify_disconnect | action | Notify RTIAdapter of withdrawn publications | SessionManager |
| s_final | final | | ClientRegistry |
| s_reject_final | final | reject_final | GRPCServices |

#### Flows

| Source | Target | Guard |
|--------|--------|-------|
| s_init | s_connect_req | |
| s_connect_req | s_grpc_recv_conn | |
| s_grpc_recv_conn | s_validate | |
| s_validate | s_decision_auth | |
| s_decision_auth | s_reject | invalid |
| s_reject | s_reject_final | |
| s_decision_auth | s_register | valid |
| s_register | s_assign_id | |
| s_assign_id | s_ack_connect | |
| s_ack_connect | s_client_connected | |
| s_client_connected | s_heartbeat_decision | |
| s_heartbeat_decision | s_wait_heartbeat | active |
| s_wait_heartbeat | s_heartbeat_check | |
| s_heartbeat_check | s_update_timestamp | received |
| s_update_timestamp | s_heartbeat_decision | |
| s_heartbeat_check | s_timeout_disconnect | timed out |
| s_timeout_disconnect | s_cleanup_merge | |
| s_heartbeat_decision | s_disconnect_req | disconnect requested |
| s_disconnect_req | s_grpc_recv_disc | |
| s_grpc_recv_disc | s_cleanup_merge | |
| s_cleanup_merge | s_remove_subs | |
| s_remove_subs | s_remove_client | |
| s_remove_client | s_notify_disconnect | |
| s_notify_disconnect | s_final | |

## State Machines

### State Machine: ClientSessionLifecycle

- **Package:** StateMachines

#### Regions

| ID | Name | Owner |
|----|------|-------|
| regClient | main | ClientSessionLifecycle |
| regConnected | CONNECTED_region | CONNECTED |
| regActive | ACTIVE_region | ACTIVE |

#### States

| ID | Name | Type | Region | Entry Action | Exit Action | Do Activity |
|----|------|------|--------|--------------|-------------|-------------|
| csDisconnected | DISCONNECTED | simple | regClient | Reset client context | | |
| csConnected | CONNECTED | composite | regClient | Allocate client_id and session token | Log connection event | |
| csAuthenticating | Authenticating | simple | regConnected | | | Validate client credentials |
| csAuthenticated | Authenticated | simple | regConnected | Register in ClientRegistry | | |
| csSubscribing | SUBSCRIBING | simple | regClient | Begin processing subscription requests | | Register subscriptions with RoutingEngine and RTI |
| csActive | ACTIVE | composite | regClient | Client fully operational | | |
| csIdle | Idle | simple | regActive | | | Await heartbeat or client request |
| csProcessing | Processing | simple | regActive | Handle pub/sub or interaction request | | |
| csHeartbeatOverdue | HeartbeatOverdue | simple | regActive | Start timeout countdown | | |
| csError | ERROR | simple | regClient | Log error and notify monitoring | | Attempt recovery or await admin intervention |

#### Pseudostates

| ID | Kind | Region |
|----|------|--------|
| csInit | initial | regClient |
| csConnInit | initial | regConnected |
| csActiveInit | initial | regActive |

#### Final States

| ID | Region |
|----|--------|
| csFinal | regClient |

#### Transitions

| Source | Target | Region | Trigger | Guard | Effect |
|--------|--------|--------|---------|-------|--------|
| csInit | csDisconnected | regClient | | | |
| csConnInit | csAuthenticating | regConnected | | | |
| csAuthenticating | csAuthenticated | regConnected | auth_success | | Create registry entry |
| csAuthenticating | csDisconnected | regClient | auth_failure | credentials invalid | Return rejection to client |
| csActiveInit | csIdle | regActive | | | |
| csIdle | csProcessing | regActive | client_request | | Dispatch to GRPCServices handler |
| csProcessing | csIdle | regActive | request_complete | | Return response to client |
| csIdle | csHeartbeatOverdue | regActive | heartbeat_timeout | heartbeat_interval exceeded | |
| csHeartbeatOverdue | csIdle | regActive | heartbeat_received | | Update last-seen timestamp |
| csDisconnected | csConnected | regClient | Connect_Client | | Open gRPC channel |
| csConnected | csSubscribing | regClient | Subscribe_Object_Attributes | authenticated | Forward to RoutingEngine |
| csConnected | csActive | regClient | activation_complete | no subscriptions requested | |
| csSubscribing | csActive | regClient | subscriptions_confirmed | | Notify client ready |
| csSubscribing | csSubscribing | regClient | Subscribe_additional | | Add subscription to RoutingEngine |
| csActive | csSubscribing | regClient | Subscribe_Object_Attributes | | Process new subscription |
| csActive | csDisconnected | regClient | Disconnect_Client | | Cleanup subscriptions and registry entry |
| csHeartbeatOverdue | csError | regClient | timeout_expired | missed_beats >= threshold | Mark client as timed-out |
| csError | csDisconnected | regClient | error_cleanup | | Remove subscriptions and registry entry |
| csError | csFinal | regClient | unrecoverable_error | | Force-close gRPC channel |
| csDisconnected | csFinal | regClient | session_terminated | no reconnect within grace period | |
| csConnected | csError | regClient | connection_error | | Log transport failure |
| csSubscribing | csError | regClient | subscription_error | | Log RTI subscription failure |

### State Machine: RTIFederationLifecycle

- **Package:** StateMachines

#### Regions

| ID | Name | Owner |
|----|------|-------|
| regRTI | main | RTIFederationLifecycle |
| regJoined | JOINED_region | JOINED |

#### States

| ID | Name | Type | Region | Entry Action | Exit Action | Do Activity |
|----|------|------|--------|--------------|-------------|-------------|
| rtiIdle | IDLE | simple | regRTI | RTI ambassador not initialised | | |
| rtiConnecting | CONNECTING | simple | regRTI | Create RTI ambassador instance | | Attempt createFederationExecution and joinFederationExecution |
| rtiJoined | JOINED | composite | regRTI | Federation joined successfully | | |
| rtiPublishing | PublishingAndSubscribing | simple | regJoined | Declare publications and subscriptions to RTI | | Process publishObjectClassAttributes and subscribeObjectClassAttributes |
| rtiOperational | Operational | simple | regJoined | Begin processing callbacks | | Dispatch RTI callbacks via CallbackDispatcher |
| rtiUpdating | UpdatingAttributes | simple | regJoined | Process updateAttributeValues batch | | |
| rtiResigning | RESIGNING | simple | regRTI | Begin resignFederationExecution | | Unpublish all, unsubscribe all, resign |
| rtiError | RTI_ERROR | simple | regRTI | Log RTI exception | | Attempt reconnection or notify SessionManager |

#### Pseudostates

| ID | Kind | Region |
|----|------|--------|
| rtiInit | initial | regRTI |
| rtiJoinInit | initial | regJoined |

#### Final States

| ID | Region |
|----|--------|
| rtiFinal | regRTI |

#### Transitions

| Source | Target | Region | Trigger | Guard | Effect |
|--------|--------|--------|---------|-------|--------|
| rtiInit | rtiIdle | regRTI | | | |
| rtiJoinInit | rtiPublishing | regJoined | | | |
| rtiPublishing | rtiOperational | regJoined | pub_sub_complete | | Enable callback processing |
| rtiOperational | rtiUpdating | regJoined | update_requested | | Marshal attribute values |
| rtiUpdating | rtiOperational | regJoined | update_sent | | Resume callback processing |
| rtiOperational | rtiPublishing | regJoined | new_pub_sub_request | | Process additional declarations |
| rtiIdle | rtiConnecting | regRTI | start_federation | | Read FOM path and federation name from config |
| rtiConnecting | rtiJoined | regRTI | join_success | | Store federation handle |
| rtiConnecting | rtiError | regRTI | join_failure | | Log connection failure details |
| rtiJoined | rtiResigning | regRTI | shutdown_requested | | Begin orderly withdrawal |
| rtiJoined | rtiError | regRTI | rti_exception | | Capture exception context |
| rtiResigning | rtiIdle | regRTI | resign_complete | | Destroy RTI ambassador |
| rtiResigning | rtiError | regRTI | resign_failure | | Force ambassador cleanup |
| rtiError | rtiConnecting | regRTI | retry_connection | retry_count < max_retries | Increment retry counter |
| rtiError | rtiIdle | regRTI | max_retries_exceeded | | Notify all clients of federation loss |
| rtiError | rtiFinal | regRTI | fatal_rti_error | | Shutdown CUIS |

## Sequence Diagrams

### Interaction: SD_Object_Publish_Reflect

- **Package:** SequenceDiagrams

#### Lifelines

| Name | Represents |
|------|------------|
| Publisher | |
| grpcServices | GRPCServices |
| routingEngine | RoutingEngine |
| subscriptionTable | SubscriptionTable |
| clientRegistry | ClientRegistry |
| encodingLayer | EncodingLayer |
| rtiAdapter | RTIAdapter |
| objectManager | ObjectManager |
| HLA_Federation | |
| Subscriber | |

#### Messages

| Name | Sender | Receiver | Sort |
|------|--------|----------|------|
| 1: Publish_Object_Attributes(className, attrList) | Publisher | grpcServices | synchCall |
| 1.1: registerPublication(className, attrList) | grpcServices | routingEngine | synchCall |
| 1.1.1: addEntry(className, attrList, clientId) | routingEngine | subscriptionTable | synchCall |
| 1.2: publishObjectClassAttributes(className, attrList) | routingEngine | rtiAdapter | synchCall |
| 1.2.1: registerObjectInstance(className) | rtiAdapter | objectManager | synchCall |
| 1.2.2: RTI_publishObjectClassAttributes | rtiAdapter | HLA_Federation | asynchCall |
| 1.3: publishAck | grpcServices | Publisher | reply |
| 2: Subscribe_Object_Attributes(className, attrList) | Subscriber | grpcServices | synchCall |
| 2.1: validateClient(clientId) | grpcServices | clientRegistry | synchCall |
| 2.2: registerSubscription(className, attrList, clientId) | grpcServices | routingEngine | synchCall |
| 2.2.1: addEntry(className, attrList, clientId) | routingEngine | subscriptionTable | synchCall |
| 2.3: subscribeObjectClassAttributes(className, attrList) | routingEngine | rtiAdapter | synchCall |
| 2.3.1: RTI_subscribeObjectClassAttributes | rtiAdapter | HLA_Federation | asynchCall |
| 2.4: subscribeAck | grpcServices | Subscriber | reply |
| 3: discoverObjectInstance callback | HLA_Federation | rtiAdapter | asynchSignal |
| 3.1: recordDiscoveredObject(handle, className) | rtiAdapter | objectManager | synchCall |
| 3.2: resolveSubscribers(className) | rtiAdapter | routingEngine | synchCall |
| 3.2.1: lookupSubscribers(className) | routingEngine | subscriptionTable | synchCall |
| 3.3: Discover_Object_Instance(handle, className) | grpcServices | Subscriber | asynchSignal |
| 4: Update_Attribute_Values(handle, attrValues) | Publisher | grpcServices | synchCall |
| 4.1: routeUpdate(handle, attrValues) | grpcServices | routingEngine | synchCall |
| 4.1.1: encodeAttributeValues(attrValues, endianness) | routingEngine | encodingLayer | synchCall |
| 4.2: updateAttributeValues(handle, encodedValues) | routingEngine | rtiAdapter | synchCall |
| 4.2.1: RTI_updateAttributeValues | rtiAdapter | HLA_Federation | asynchCall |
| 4.3: reflectAttributeValues callback | HLA_Federation | rtiAdapter | asynchSignal |
| 4.3.1: decodeAttributeValues(rawValues) | rtiAdapter | encodingLayer | synchCall |
| 4.4: resolveSubscribers(className) | rtiAdapter | routingEngine | synchCall |
| 4.4.1: filterAttributes(subscription, attrValues) | routingEngine | routingEngine | synchCall |
| 4.5: Reflect_Attribute_Values(handle, filteredValues) | grpcServices | Subscriber | asynchSignal |
| 4.6: updateAck | grpcServices | Publisher | reply |

### Interaction: SD_Interaction_SendReceive

- **Package:** SequenceDiagrams

#### Lifelines

| Name | Represents |
|------|------------|
| Sender | |
| grpcServices | GRPCServices |
| routingEngine | RoutingEngine |
| subscriptionTable | SubscriptionTable |
| encodingLayer | EncodingLayer |
| rtiAdapter | RTIAdapter |
| interactionManager | InteractionManager |
| HLA_Federation | |
| Receiver | |

#### Messages

| Name | Sender | Receiver | Sort |
|------|--------|----------|------|
| 1: Publish_Interaction(interactionClass) | Sender | grpcServices | synchCall |
| 1.1: registerInteractionPublication(interactionClass, clientId) | grpcServices | routingEngine | synchCall |
| 1.1.1: addEntry(interactionClass, clientId) | routingEngine | subscriptionTable | synchCall |
| 1.2: publishInteractionClass(interactionClass) | routingEngine | rtiAdapter | synchCall |
| 1.2.1: RTI_publishInteractionClass | rtiAdapter | HLA_Federation | asynchCall |
| 1.3: publishInteractionAck | grpcServices | Sender | reply |
| 2: Subscribe_Interaction(interactionClass) | Receiver | grpcServices | synchCall |
| 2.1: registerInteractionSubscription(interactionClass, clientId) | grpcServices | routingEngine | synchCall |
| 2.1.1: addEntry(interactionClass, clientId) | routingEngine | subscriptionTable | synchCall |
| 2.2: subscribeInteractionClass(interactionClass) | routingEngine | rtiAdapter | synchCall |
| 2.2.1: RTI_subscribeInteractionClass | rtiAdapter | HLA_Federation | asynchCall |
| 2.3: subscribeInteractionAck | grpcServices | Receiver | reply |
| 3: Send_Interaction(interactionClass, paramValues) | Sender | grpcServices | synchCall |
| 3.1: validateInteraction(interactionClass, clientId) | grpcServices | routingEngine | synchCall |
| 3.1.1: encodeParameterValues(paramValues, endianness) | routingEngine | encodingLayer | synchCall |
| 3.2: sendInteraction(interactionClass, encodedParams) | routingEngine | rtiAdapter | synchCall |
| 3.2.1: marshalParameters(encodedParams) | rtiAdapter | interactionManager | synchCall |
| 3.2.2: RTI_sendInteraction | rtiAdapter | HLA_Federation | asynchCall |
| 3.3: sendAck | grpcServices | Sender | reply |
| 4: receiveInteraction callback | HLA_Federation | rtiAdapter | asynchSignal |
| 4.1: unmarshalParameters(rawParams) | rtiAdapter | interactionManager | synchCall |
| 4.1.1: decodeParameterValues(rawParams) | rtiAdapter | encodingLayer | synchCall |
| 4.2: resolveInteractionSubscribers(interactionClass) | rtiAdapter | routingEngine | synchCall |
| 4.2.1: lookupSubscribers(interactionClass) | routingEngine | subscriptionTable | synchCall |
| 4.3: Receive_Interaction(interactionClass, paramValues) | grpcServices | Receiver | asynchSignal |

### Interaction: SD_Client_Session_Lifecycle

- **Package:** SequenceDiagrams

#### Lifelines

| Name | Represents |
|------|------------|
| UIClient | |
| grpcServices | GRPCServices |
| sessionManager | SessionManager |
| clientRegistry | ClientRegistry |
| routingEngine | RoutingEngine |
| rtiAdapter | RTIAdapter |

#### Messages

| Name | Sender | Receiver | Sort |
|------|--------|----------|------|
| 1: Connect_Client(clientName, endpoint) | UIClient | grpcServices | synchCall |
| 1.1: validateAndCreateSession(clientName, endpoint) | grpcServices | sessionManager | synchCall |
| 1.1.1: checkCapacity() | sessionManager | clientRegistry | synchCall |
| 1.1.2: createEntry(clientId, clientName, endpoint) | sessionManager | clientRegistry | synchCall |
| 1.2: sessionToken | grpcServices | UIClient | reply |
| 2: Heartbeat(clientId, sessionToken) | UIClient | grpcServices | synchCall |
| 2.1: refreshSession(clientId) | grpcServices | sessionManager | synchCall |
| 2.1.1: updateLastSeen(clientId) | sessionManager | clientRegistry | synchCall |
| 2.2: heartbeatAck | grpcServices | UIClient | reply |
| 3: Disconnect_Client(clientId, sessionToken) | UIClient | grpcServices | synchCall |
| 3.1: terminateSession(clientId) | grpcServices | sessionManager | synchCall |
| 3.1.1: getClientSubscriptions(clientId) | sessionManager | routingEngine | synchCall |
| 3.1.2: removeAllSubscriptions(clientId) | sessionManager | routingEngine | synchCall |
| 3.1.3: unsubscribeFromRTI(objectClasses) | routingEngine | rtiAdapter | synchCall |
| 3.1.4: unpublishFromRTI(objectClasses) | routingEngine | rtiAdapter | synchCall |
| 3.1.5: removeEntry(clientId) | sessionManager | clientRegistry | synchCall |
| 3.2: disconnectAck | grpcServices | UIClient | reply |
| 4: heartbeatTimeout(clientId) | sessionManager | sessionManager | synchCall |
| 4.1: getClientSubscriptions(clientId) | sessionManager | routingEngine | synchCall |
| 4.2: removeAllSubscriptions(clientId) | sessionManager | routingEngine | synchCall |
| 4.2.1: unsubscribeFromRTI(objectClasses) | routingEngine | rtiAdapter | synchCall |
| 4.2.2: unpublishFromRTI(objectClasses) | routingEngine | rtiAdapter | synchCall |
| 4.3: removeEntry(clientId) | sessionManager | clientRegistry | synchCall |
| 4.4: notifyClientDisconnected(clientId) | sessionManager | grpcServices | asynchSignal |
