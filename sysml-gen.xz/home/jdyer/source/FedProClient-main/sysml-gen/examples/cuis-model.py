# MagicDraw Jython macro - Generate CUIS High Level Design (Enhanced)
# Compatible with CATIA | MagicDraw 2024x Refresh2
#
# Enhancement 1: Sub-block internal structure, reference properties,
#                 and SessionManager block.
# Enhancement 2: Interface realizations and dependency relationships.
# Enhancement 3: Constraint blocks for timing, throughput, and capacity.
# Enhancement 4: Activity diagrams for pub/sub, interaction, and session flows.
# Enhancement 5: State machines for client session and RTI federation lifecycles.
# Enhancement 6: Sequence diagrams for pub/sub, interaction, and session flows.
# Enhancement 7: EncodingLayer block, Attributes datatype, Endianness enum,
#                 HLAhandle/Timestamp/Duration datatypes, and relationships.

from com.nomagic.magicdraw.core import Application
from com.nomagic.magicdraw.openapi.uml import SessionManager, ModelElementsManager
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper
from com.nomagic.uml2.ext.jmi.helpers import ModelHelper
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import AggregationKindEnum

# -----------------------------------------
# Setup
# -----------------------------------------
app = Application.getInstance()
project = app.getProject()
ef = project.getElementsFactory()
mem = ModelElementsManager.getInstance()
sm = SessionManager.getInstance()

if project is None:
    Application.getInstance().getGUILog().log("ERROR: No project open.")
    raise SystemExit

root = project.getPrimaryModel()

# -----------------------------------------
# Helper functions
# -----------------------------------------

def create_package(name, owner):
    """Create a SysML package."""
    pkg = ef.createPackageInstance()
    pkg.setName(name)
    pkg.setOwner(owner)
    return pkg

def create_block(name, owner_pkg):
    """Create a SysML Block (Class with <<Block>> stereotype)."""
    blk = ef.createClassInstance()
    blk.setName(name)
    blk.setOwner(owner_pkg)
    StereotypesHelper.addStereotypeByString(blk, "Block")
    return blk

def create_interface(name, owner_pkg):
    """Create a UML Interface."""
    iface = ef.createInterfaceInstance()
    iface.setName(name)
    iface.setOwner(owner_pkg)
    return iface

def create_datatype(name, owner_pkg):
    """Create a UML DataType."""
    dt = ef.createDataTypeInstance()
    dt.setName(name)
    dt.setOwner(owner_pkg)
    return dt

def create_enumeration(name, owner_pkg, literals):
    """Create a UML Enumeration with literal values."""
    enum = ef.createEnumerationInstance()
    enum.setName(name)
    enum.setOwner(owner_pkg)
    for lit_name in literals:
        lit = ef.createEnumerationLiteralInstance()
        lit.setName(lit_name)
        lit.setOwner(enum)
    return enum

def add_part_property(owner_block, prop_name, type_block):
    """Add a <<PartProperty>> (composite aggregation) to a block."""
    prop = ef.createPropertyInstance()
    prop.setName(prop_name)
    prop.setOwner(owner_block)
    prop.setType(type_block)
    prop.setAggregation(AggregationKindEnum.COMPOSITE)
    StereotypesHelper.addStereotypeByString(prop, "PartProperty")
    return prop

def add_reference_property(owner_block, prop_name, type_block):
    """Add a reference property (shared aggregation) to a block.
    This models a 'uses' / 'depends on' relationship without ownership."""
    prop = ef.createPropertyInstance()
    prop.setName(prop_name)
    prop.setOwner(owner_block)
    prop.setType(type_block)
    prop.setAggregation(AggregationKindEnum.SHARED)
    return prop

def add_value_property(owner_block, prop_name, type_block=None):
    """Add a <<ValueProperty>> to a block or datatype."""
    prop = ef.createPropertyInstance()
    prop.setName(prop_name)
    prop.setOwner(owner_block)
    if type_block is not None:
        prop.setType(type_block)
    prop.setAggregation(AggregationKindEnum.COMPOSITE)
    StereotypesHelper.addStereotypeByString(prop, "ValueProperty")
    return prop

def add_operation(owner, op_name, params=None):
    """Add an operation to an interface or block.
    params: optional list of (param_name, direction) tuples.
    direction: 'in', 'out', 'inout', 'return'."""
    op = ef.createOperationInstance()
    op.setName(op_name)
    op.setOwner(owner)
    if params:
        for pname, pdir in params:
            p = ef.createParameterInstance()
            p.setName(pname)
            p.setOwner(op)
            # Direction enum: IN, OUT, INOUT, RETURN
            if pdir == "out":
                p.setDirection(com.nomagic.uml2.ext.magicdraw.classes.mdkernel.ParameterDirectionKindEnum.OUT)
            elif pdir == "inout":
                p.setDirection(com.nomagic.uml2.ext.magicdraw.classes.mdkernel.ParameterDirectionKindEnum.INOUT)
            elif pdir == "return":
                p.setDirection(com.nomagic.uml2.ext.magicdraw.classes.mdkernel.ParameterDirectionKindEnum.RETURN)
            # default is IN, no need to set explicitly
    return op

def add_flow_port(owner_block, port_name, type_element, is_conjugated=False):
    """Add a <<FlowPort>> to a block for interface exposure."""
    port = ef.createPortInstance()
    port.setName(port_name)
    port.setOwner(owner_block)
    if type_element is not None:
        port.setType(type_element)
    StereotypesHelper.addStereotypeByString(port, "FlowPort")
    return port

def add_realization(block, interface, owner_pkg):
    """Create an InterfaceRealization: block realizes interface.
    In MagicDraw, the realization is owned by the implementing classifier."""
    real = ef.createInterfaceRealizationInstance()
    real.setImplementingClassifier(block)
    real.setContract(interface)
    real.setOwner(block)
    return real

def add_dependency(client_el, supplier_el, name, owner_pkg):
    """Create a named Dependency from client to supplier.
    client depends on (uses) supplier."""
    dep = ef.createDependencyInstance()
    dep.setName(name)
    dep.getClient().add(client_el)
    dep.getSupplier().add(supplier_el)
    dep.setOwner(owner_pkg)
    return dep

def add_usage(client_el, supplier_el, name, owner_pkg):
    """Create a <<use>> dependency (stronger form of dependency).
    Indicates that client requires supplier for its implementation."""
    usage = ef.createUsageInstance()
    usage.setName(name)
    usage.getClient().add(client_el)
    usage.getSupplier().add(supplier_el)
    usage.setOwner(owner_pkg)
    return usage

def create_constraint_block(name, owner_pkg, parameters, constraint_expr):
    """Create a SysML ConstraintBlock with constraint parameters and
    a specification expression (the parametric equation).
    parameters: list of (param_name,) or (param_name, type_block) tuples.
    constraint_expr: string expression for the OpaqueExpression body."""
    cb = ef.createClassInstance()
    cb.setName(name)
    cb.setOwner(owner_pkg)
    StereotypesHelper.addStereotypeByString(cb, "Block")
    StereotypesHelper.addStereotypeByString(cb, "ConstraintBlock")

    # Add constraint parameters as properties with <<ConstraintParameter>>
    for param in parameters:
        p = ef.createPropertyInstance()
        if len(param) >= 2 and param[1] is not None:
            p.setName(param[0])
            p.setType(param[1])
        else:
            p.setName(param[0])
        p.setOwner(cb)
        StereotypesHelper.addStereotypeByString(p, "ConstraintParameter")

    # Add the constraint specification as an OpaqueExpression on a Constraint
    constr = ef.createConstraintInstance()
    constr.setName(name + "_spec")
    constr.setOwner(cb)
    constr.getConstrainedElement().add(cb)

    oe = ef.createOpaqueExpressionInstance()
    oe.setOwner(constr)
    oe.getBody().add(constraint_expr)
    oe.getLanguage().add("OCL")  # or "English" / "Natural"
    constr.setSpecification(oe)

    return cb

def add_constraint_property(owner_block, prop_name, constraint_block):
    """Add a constraint property to a block - used in parametric diagrams
    to bind constraint blocks to the owning block's value properties."""
    prop = ef.createPropertyInstance()
    prop.setName(prop_name)
    prop.setOwner(owner_block)
    prop.setType(constraint_block)
    prop.setAggregation(AggregationKindEnum.COMPOSITE)
    StereotypesHelper.addStereotypeByString(prop, "ConstraintProperty")
    return prop

# -----------------------------------------
# Activity diagram helper functions
# -----------------------------------------

def create_activity(name, owner_pkg):
    """Create a UML Activity (the container for an activity diagram)."""
    act = ef.createActivityInstance()
    act.setName(name)
    act.setOwner(owner_pkg)
    return act

def create_initial_node(activity):
    """Create an InitialNode inside an activity."""
    node = ef.createInitialNodeInstance()
    node.setName("initial")
    node.setOwner(activity)
    return node

def create_final_node(activity, name="final"):
    """Create an ActivityFinalNode inside an activity."""
    node = ef.createActivityFinalNodeInstance()
    node.setName(name)
    node.setOwner(activity)
    return node

def create_action(name, activity):
    """Create an OpaqueAction (a simple named action step) in an activity."""
    action = ef.createOpaqueActionInstance()
    action.setName(name)
    action.setOwner(activity)
    return action

def create_call_behavior_action(name, activity, behavior=None):
    """Create a CallBehaviorAction referencing another activity/behavior."""
    cba = ef.createCallBehaviorActionInstance()
    cba.setName(name)
    cba.setOwner(activity)
    if behavior is not None:
        cba.setBehavior(behavior)
    return cba

def create_decision_node(activity, name="decision"):
    """Create a DecisionNode (diamond) in an activity."""
    node = ef.createDecisionNodeInstance()
    node.setName(name)
    node.setOwner(activity)
    return node

def create_merge_node(activity, name="merge"):
    """Create a MergeNode in an activity."""
    node = ef.createMergeNodeInstance()
    node.setName(name)
    node.setOwner(activity)
    return node

def create_fork_node(activity, name="fork"):
    """Create a ForkNode (horizontal bar, parallel split) in an activity."""
    node = ef.createForkNodeInstance()
    node.setName(name)
    node.setOwner(activity)
    return node

def create_join_node(activity, name="join"):
    """Create a JoinNode (horizontal bar, parallel sync) in an activity."""
    node = ef.createJoinNodeInstance()
    node.setName(name)
    node.setOwner(activity)
    return node

def create_send_signal_action(name, activity):
    """Create a SendSignalAction in an activity."""
    ssa = ef.createSendSignalActionInstance()
    ssa.setName(name)
    ssa.setOwner(activity)
    return ssa

def create_accept_event_action(name, activity):
    """Create an AcceptEventAction (wait for signal/event) in an activity."""
    aea = ef.createAcceptEventActionInstance()
    aea.setName(name)
    aea.setOwner(activity)
    return aea

def create_control_flow(source, target, activity, guard=None):
    """Create a ControlFlow (arrow) between two activity nodes.
    Optionally add a guard condition string."""
    flow = ef.createControlFlowInstance()
    flow.setSource(source)
    flow.setTarget(target)
    flow.setOwner(activity)
    if guard is not None:
        oe = ef.createOpaqueExpressionInstance()
        oe.getBody().add(guard)
        oe.getLanguage().add("English")
        oe.setOwner(flow)
        flow.setGuard(oe)
    return flow

def create_activity_partition(name, activity, represents=None):
    """Create an ActivityPartition (swimlane) in an activity.
    'represents' can be a block/classifier that the partition maps to."""
    part = ef.createActivityPartitionInstance()
    part.setName(name)
    part.setOwner(activity)
    if represents is not None:
        part.setRepresents(represents)
    return part

def assign_partition(node, partition):
    """Assign an activity node to an ActivityPartition (swimlane)."""
    node.getInPartition().add(partition)

# -----------------------------------------
# State machine helper functions
# -----------------------------------------

def create_state_machine(name, owner):
    """Create a UML StateMachine owned by a block or package."""
    stm = ef.createStateMachineInstance()
    stm.setName(name)
    stm.setOwner(owner)
    return stm

def create_region(name, owner_stm):
    """Create a Region inside a StateMachine or composite State.
    Every StateMachine needs at least one Region to hold states."""
    reg = ef.createRegionInstance()
    reg.setName(name)
    reg.setOwner(owner_stm)
    return reg

def create_state(name, region):
    """Create a simple State inside a Region."""
    st = ef.createStateInstance()
    st.setName(name)
    st.setOwner(region)
    return st

def create_composite_state(name, region):
    """Create a composite State (one that contains its own sub-region)
    inside a Region. Returns (state, sub_region) tuple."""
    st = ef.createStateInstance()
    st.setName(name)
    st.setOwner(region)
    sub_reg = ef.createRegionInstance()
    sub_reg.setName(name + "_region")
    sub_reg.setOwner(st)
    return st, sub_reg

def create_pseudostate(region, kind="initial"):
    """Create a Pseudostate in a Region.
    kind: 'initial', 'choice', 'junction', 'fork', 'join',
          'shallowHistory', 'deepHistory'."""
    try:
        from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import PseudostateKindEnum
    except ImportError:
        from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import PseudostateKindEnum
    ps = ef.createPseudostateInstance()
    ps.setOwner(region)
    # MagicDraw 2024x uses concatenated names (no underscores):
    #   INITIAL, CHOICE, JUNCTION, FORK, JOIN, SHALLOWHISTORY, DEEPHISTORY
    kind_name_map = {
        "initial":        "INITIAL",
        "choice":         "CHOICE",
        "junction":       "JUNCTION",
        "fork":           "FORK",
        "join":           "JOIN",
        "shallowHistory": "SHALLOWHISTORY",
        "deepHistory":    "DEEPHISTORY",
    }
    enum_name = kind_name_map.get(kind, "INITIAL")
    ps.setKind(getattr(PseudostateKindEnum, enum_name))
    return ps

def create_final_state(region):
    """Create a FinalState in a Region."""
    fs = ef.createFinalStateInstance()
    fs.setName("final")
    fs.setOwner(region)
    return fs

def create_transition(source, target, region, trigger_name=None,
                      guard_expr=None, effect_name=None):
    """Create a Transition between two states/pseudostates.
    trigger_name: optional string for the trigger event name.
    guard_expr:   optional string for the guard condition.
    effect_name:  optional string for the effect/action."""
    tr = ef.createTransitionInstance()
    tr.setSource(source)
    tr.setTarget(target)
    tr.setOwner(region)

    if trigger_name is not None:
        # Create a trigger with a SignalEvent or ChangeEvent
        # For simplicity, use a TimeEvent with an opaque expression
        # as MagicDraw Jython can be fiddly with signal/event creation.
        # Instead, encode trigger as a named opaque behavior effect label.
        # The cleanest portable approach: set trigger name via an
        # OpaqueExpression on a Constraint, or just name the transition.
        tr.setName(trigger_name)

    if guard_expr is not None:
        constraint = ef.createConstraintInstance()
        constraint.setOwner(tr)
        oe = ef.createOpaqueExpressionInstance()
        oe.getBody().add(guard_expr)
        oe.getLanguage().add("English")
        oe.setOwner(constraint)
        constraint.setSpecification(oe)
        tr.setGuard(constraint)

    if effect_name is not None:
        effect = ef.createOpaqueBehaviorInstance()
        effect.setName(effect_name)
        effect.getBody().add(effect_name)
        effect.setOwner(tr)
        tr.setEffect(effect)

    return tr

def add_entry_action(state, action_text):
    """Add an entry behavior to a State."""
    entry = ef.createOpaqueBehaviorInstance()
    entry.setName("entry/" + action_text)
    entry.getBody().add(action_text)
    entry.setOwner(state)
    state.setEntry(entry)

def add_exit_action(state, action_text):
    """Add an exit behavior to a State."""
    exit_b = ef.createOpaqueBehaviorInstance()
    exit_b.setName("exit/" + action_text)
    exit_b.getBody().add(action_text)
    exit_b.setOwner(state)
    state.setExit(exit_b)

def add_do_activity(state, activity_text):
    """Add a do-activity (ongoing behavior) to a State."""
    do_act = ef.createOpaqueBehaviorInstance()
    do_act.setName("do/" + activity_text)
    do_act.getBody().add(activity_text)
    do_act.setOwner(state)
    state.setDoActivity(do_act)

# -----------------------------------------
# Sequence diagram helper functions
# -----------------------------------------

def create_interaction(name, owner_pkg):
    """Create a UML Interaction (the container for a sequence diagram)."""
    interaction = ef.createInteractionInstance()
    interaction.setName(name)
    interaction.setOwner(owner_pkg)
    return interaction

def create_lifeline(name, interaction, represents_type=None):
    """Create a Lifeline inside an Interaction.
    represents_type: optional block/class that the lifeline represents.
    In MagicDraw we set the type via a Property that the lifeline represents."""
    ll = ef.createLifelineInstance()
    ll.setName(name)
    ll.setOwner(interaction)
    try:
        ll.setInteraction(interaction)
    except AttributeError:
        pass  # ownership is sufficient in some MagicDraw versions
    if represents_type is not None:
        # Create a Property typed to the block for the lifeline to represent
        prop = ef.createPropertyInstance()
        prop.setName(name)
        prop.setType(represents_type)
        prop.setOwner(interaction)
        ll.setRepresents(prop)
    return ll

def create_message(name, interaction, send_ll, recv_ll, sort="synchCall"):
    """Create a Message between two lifelines.
    sort: 'synchCall', 'asynchCall', 'asynchSignal', 'reply', 'createMessage'.
    Creates the required MessageOccurrenceSpecification endpoints."""
    try:
        from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import MessageSortEnum
    except ImportError:
        from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import MessageSortEnum

    sort_map = {
        "synchCall":      "SYNCHCALL",
        "asynchCall":     "ASYNCHCALL",
        "asynchSignal":   "ASYNCHSIGNAL",
        "reply":          "REPLY",
        "createMessage":  "CREATEMESSAGE",
    }

    # Create send occurrence
    send_mos = ef.createMessageOccurrenceSpecificationInstance()
    send_mos.setName(name + "_send")
    send_mos.setOwner(interaction)
    try:
        send_mos.setCovered(send_ll)
    except AttributeError:
        send_mos.getCovered().add(send_ll)

    # Create receive occurrence
    recv_mos = ef.createMessageOccurrenceSpecificationInstance()
    recv_mos.setName(name + "_recv")
    recv_mos.setOwner(interaction)
    try:
        recv_mos.setCovered(recv_ll)
    except AttributeError:
        recv_mos.getCovered().add(recv_ll)

    # Create the message
    msg = ef.createMessageInstance()
    msg.setName(name)
    msg.setOwner(interaction)
    msg.setSendEvent(send_mos)
    msg.setReceiveEvent(recv_mos)

    enum_name = sort_map.get(sort, "SYNCHCALL")
    msg.setMessageSort(getattr(MessageSortEnum, enum_name))

    # Link occurrences back to the message
    send_mos.setMessage(msg)
    recv_mos.setMessage(msg)

    return msg

def create_combined_fragment(name, interaction, operator, covered_lifelines):
    """Create a CombinedFragment (alt, opt, loop, par, etc.) in an interaction.
    operator: 'alt', 'opt', 'loop', 'par', 'break', 'critical', 'neg'.
    covered_lifelines: list of lifelines covered by this fragment.
    Returns (fragment, first_operand) - add more operands for 'alt'."""
    try:
        from com.nomagic.uml2.ext.magicdraw.interactions.mdfragments import InteractionOperatorKindEnum
    except ImportError:
        from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import InteractionOperatorKindEnum

    op_map = {
        "alt":      "ALT",
        "opt":      "OPT",
        "loop":     "LOOP",
        "par":      "PAR",
        "break":    "BREAK_",  # 'break' is reserved in some versions
        "critical": "CRITICAL",
        "neg":      "NEG",
    }

    cf = ef.createCombinedFragmentInstance()
    cf.setName(name)
    cf.setOwner(interaction)

    enum_name = op_map.get(operator, "ALT")
    # Handle the BREAK special case - try both BREAK_ and BREAK
    try:
        cf.setInteractionOperator(getattr(InteractionOperatorKindEnum, enum_name))
    except AttributeError:
        cf.setInteractionOperator(getattr(InteractionOperatorKindEnum, enum_name.rstrip("_")))

    for ll in covered_lifelines:
        cf.getCovered().add(ll)

    # Create the first operand (every combined fragment needs at least one)
    operand = ef.createInteractionOperandInstance()
    operand.setName(name + "_operand")
    operand.setOwner(cf)

    return cf, operand

def add_operand(combined_fragment, guard_text=None):
    """Add an InteractionOperand to a CombinedFragment (e.g. 'else' branch of alt).
    Returns the new operand."""
    operand = ef.createInteractionOperandInstance()
    operand.setOwner(combined_fragment)
    if guard_text is not None:
        constraint = ef.createConstraintInstance()
        constraint.setOwner(operand)
        oe = ef.createOpaqueExpressionInstance()
        oe.getBody().add(guard_text)
        oe.getLanguage().add("English")
        oe.setOwner(constraint)
        constraint.setSpecification(oe)
        operand.setGuard(constraint)
    return operand

# -----------------------------------------
# MAIN EXECUTION
# -----------------------------------------

sm.createSession("Create CUIS Structure (Enhanced)")

try:
    # =========================================
    # Top-level package
    # =========================================
    pkg = create_package("CUIS_High_Level_Design", root)

    # Sub-packages for organisation
    pkgBlocks = create_package("Blocks", pkg)
    pkgInterfaces = create_package("Interfaces", pkg)
    pkgDataTypes = create_package("DataTypes", pkg)
    pkgEnums = create_package("Enumerations", pkg)

    # =========================================
    # Enumerations
    # =========================================
    enumClientState = create_enumeration("ClientState", pkgEnums, [
        "DISCONNECTED",
        "CONNECTED",
        "SUBSCRIBING",
        "ACTIVE",
        "ERROR"
    ])

    enumUpdatePolicy = create_enumeration("UpdatePolicy", pkgEnums, [
        "ON_CHANGE",
        "PERIODIC",
        "ON_REQUEST"
    ])

    enumTransportStatus = create_enumeration("TransportStatus", pkgEnums, [
        "OK",
        "TIMEOUT",
        "DISCONNECTED",
        "ERROR"
    ])

    # NEW: Endianness enumeration
    # Design: "Session Registry - Client registration, endian prefs"
    # Design: "Honor client endianess setting"
    enumEndianness = create_enumeration("Endianness", pkgEnums, [
        "BIG_ENDIAN",
        "LITTLE_ENDIAN"
    ])

    # =========================================
    # Data Types (protobuf message types)
    # =========================================
    # NEW: HLA opaque handle type
    # Design: "Handles are passed as bytes (opaque)"
    dtHLAhandle = create_datatype("HLAhandle", pkgDataTypes)
    add_value_property(dtHLAhandle, "opaque_bytes")

    # NEW: HLA Timestamp
    # Design: "CUIS handles all endianness, timestamps, durations"
    dtTimestamp = create_datatype("HLAtimestamp", pkgDataTypes)
    add_value_property(dtTimestamp, "seconds")
    add_value_property(dtTimestamp, "fractional_seconds")

    # NEW: HLA Duration
    # Design: "CUIS handles all endianness, timestamps, durations"
    dtDuration = create_datatype("HLAduration", pkgDataTypes)
    add_value_property(dtDuration, "seconds")
    add_value_property(dtDuration, "fractional_seconds")

    # NEW: Attributes type (list of attribute handles)
    # Design: hla_common.proto defines "Attributes" separately from "Attribute_Values"
    dtAttributes = create_datatype("Attributes", pkgDataTypes)
    add_value_property(dtAttributes, "attribute_handles", dtHLAhandle)

    dtAV = create_datatype("Attribute_Values", pkgDataTypes)
    add_value_property(dtAV, "name")
    add_value_property(dtAV, "value")

    dtPV = create_datatype("Parameter_Values", pkgDataTypes)
    add_value_property(dtPV, "name")
    add_value_property(dtPV, "value")

    dtDV = create_datatype("Data_Value", pkgDataTypes)
    for f in [
        "hla_octet", "hla_int16", "hla_int32", "hla_int64",
        "hla_float32", "hla_float64",
        "hla_ascii_string", "hla_unicode_string",
        "hla_opaque_data"
    ]:
        add_value_property(dtDV, f)

    dtObjectRef = create_datatype("ObjectReference", pkgDataTypes)
    add_value_property(dtObjectRef, "object_class_name")
    add_value_property(dtObjectRef, "instance_handle", dtHLAhandle)

    dtSubscription = create_datatype("SubscriptionRecord", pkgDataTypes)
    add_value_property(dtSubscription, "object_class_name")
    add_value_property(dtSubscription, "attribute_names")
    add_value_property(dtSubscription, "client_id")
    add_value_property(dtSubscription, "update_policy", enumUpdatePolicy)

    dtClientInfo = create_datatype("ClientInfo", pkgDataTypes)
    add_value_property(dtClientInfo, "client_id")
    add_value_property(dtClientInfo, "client_name")
    add_value_property(dtClientInfo, "endpoint_address")
    add_value_property(dtClientInfo, "state", enumClientState)
    # NEW: Per-client endianness preference
    # Design: "Session Registry - Client registration, endian prefs"
    add_value_property(dtClientInfo, "endianness", enumEndianness)

    # =========================================
    # Blocks - Top level
    # =========================================
    blkCUIS = create_block("CommonUI_Server", pkgBlocks)

    # --- RTIAdapter and its internals ---
    blkRTI = create_block("RTIAdapter", pkgBlocks)
    blkFedConn = create_block("FederationConnection", pkgBlocks)
    blkObjMgr = create_block("ObjectManager", pkgBlocks)
    blkIntMgr = create_block("InteractionManager", pkgBlocks)
    blkCallbackDispatcher = create_block("CallbackDispatcher", pkgBlocks)

    add_value_property(blkFedConn, "federation_name")
    add_value_property(blkFedConn, "federate_name")
    add_value_property(blkFedConn, "fom_path")
    add_value_property(blkFedConn, "rti_host")
    add_value_property(blkFedConn, "rti_port")

    # RTIAdapter internal composition
    add_part_property(blkRTI, "federationConnection", blkFedConn)
    add_part_property(blkRTI, "objectManager", blkObjMgr)
    add_part_property(blkRTI, "interactionManager", blkIntMgr)
    add_part_property(blkRTI, "callbackDispatcher", blkCallbackDispatcher)

    # --- RoutingEngine and its internals ---
    blkRouting = create_block("RoutingEngine", pkgBlocks)
    blkSubTable = create_block("SubscriptionTable", pkgBlocks)
    blkAttrFilter = create_block("AttributeFilter", pkgBlocks)

    add_part_property(blkRouting, "subscriptionTable", blkSubTable)
    add_part_property(blkRouting, "attributeFilter", blkAttrFilter)

    # --- ClientRegistry ---
    blkRegistry = create_block("ClientRegistry", pkgBlocks)
    add_value_property(blkRegistry, "max_clients")

    # --- SessionManager ---
    blkSessMgr = create_block("SessionManager", pkgBlocks)
    add_value_property(blkSessMgr, "session_timeout_ms")
    add_value_property(blkSessMgr, "heartbeat_interval_ms")

    # --- GRPCServices ---
    blkGRPC = create_block("GRPCServices", pkgBlocks)
    add_value_property(blkGRPC, "listen_port")
    add_value_property(blkGRPC, "max_concurrent_streams")

    # NEW: EncodingLayer block
    # Design: "Encoding Layer - Data_Value helpers, tags, time"
    blkEncoding = create_block("EncodingLayer", pkgBlocks)
    add_value_property(blkEncoding, "default_endianness", enumEndianness)

    # EncodingLayer sub-blocks for the three responsibilities
    blkDataValueCodec = create_block("DataValueCodec", pkgBlocks)
    add_value_property(blkDataValueCodec, "supported_types")
    blkTagEncoder = create_block("TagEncoder", pkgBlocks)
    blkTimeCodec = create_block("TimeCodec", pkgBlocks)

    add_part_property(blkEncoding, "dataValueCodec", blkDataValueCodec)
    add_part_property(blkEncoding, "tagEncoder", blkTagEncoder)
    add_part_property(blkEncoding, "timeCodec", blkTimeCodec)

    # =========================================
    # CUIS top-level composition
    # =========================================
    add_part_property(blkCUIS, "rtiAdapter", blkRTI)
    add_part_property(blkCUIS, "routingEngine", blkRouting)
    add_part_property(blkCUIS, "clientRegistry", blkRegistry)
    add_part_property(blkCUIS, "sessionManager", blkSessMgr)
    add_part_property(blkCUIS, "grpcServices", blkGRPC)
    # NEW: EncodingLayer as top-level part of CUIS
    add_part_property(blkCUIS, "encodingLayer", blkEncoding)

    # =========================================
    # Reference properties (cross-cutting dependencies)
    # =========================================
    # CallbackDispatcher needs to push data into RoutingEngine
    add_reference_property(blkCallbackDispatcher, "routingEngine", blkRouting)

    # RoutingEngine looks up clients via ClientRegistry
    add_reference_property(blkRouting, "clientRegistry", blkRegistry)

    # SessionManager manages entries in ClientRegistry
    add_reference_property(blkSessMgr, "clientRegistry", blkRegistry)

    # GRPCServices dispatches to RoutingEngine for pub/sub ops
    add_reference_property(blkGRPC, "routingEngine", blkRouting)

    # GRPCServices registers/deregisters via SessionManager
    add_reference_property(blkGRPC, "sessionManager", blkSessMgr)

    # NEW: RTIAdapter references EncodingLayer for HLA type conversion
    # Design: "RTI Adapter - Conversion (HLA ↔ protobuf)"
    add_reference_property(blkRTI, "encodingLayer", blkEncoding)

    # NEW: GRPCServices references EncodingLayer for protobuf marshalling
    add_reference_property(blkGRPC, "encodingLayer", blkEncoding)

    # NEW: EncodingLayer references ClientRegistry to look up endianness prefs
    # Design: "Honor client endianess setting"
    add_reference_property(blkEncoding, "clientRegistry", blkRegistry)

    # =========================================
    # Interfaces
    # =========================================

    # --- Server-side interface (clients call these via gRPC) ---
    ifServer = create_interface("UFCommonUIService", pkgInterfaces)
    server_ops = [
        "Publish_Object_Attributes",
        "Unpublish_Object",
        "Subscribe_Object_Attributes",
        "Unsubscribe_Object",
        "Update_Attribute_Values",
        "Request_Object_Update",
        "Publish_Interaction",
        "Subscribe_Interaction",
        "Send_Interaction",
    ]
    for op in server_ops:
        add_operation(ifServer, op)

    # --- Client callback interface (CUIS calls back to clients) ---
    ifClient = create_interface("UFCommonUIClientService", pkgInterfaces)
    client_ops = [
        "Discover_Object_Instance",
        "Reflect_Attribute_Values",
        "Remove_Object_Instance",
        "Provide_Attribute_Value_Update",
        "Receive_Interaction",
    ]
    for op in client_ops:
        add_operation(ifClient, op)

    # --- Session management interface ---
    ifSession = create_interface("ISessionManagement", pkgInterfaces)
    session_ops = [
        "Connect_Client",
        "Disconnect_Client",
        "Heartbeat",
        "Get_Client_State",
    ]
    for op in session_ops:
        add_operation(ifSession, op)

    # --- RTI federation interface (internal, wraps RTI ambassador calls) ---
    ifRTI = create_interface("IRTIFederationOps", pkgInterfaces)
    rti_ops = [
        "Join_Federation",
        "Resign_Federation",
        "Register_Object_Instance",
        "Delete_Object_Instance",
        "Update_Object_Attributes",
        "Send_RTI_Interaction",
        "Subscribe_Object_Class",
        "Unsubscribe_Object_Class",
        "Subscribe_Interaction_Class",
        "Unsubscribe_Interaction_Class",
    ]
    for op in rti_ops:
        add_operation(ifRTI, op)

    # NEW: Encoding interface
    # Design: "Encoding Layer - Data_Value helpers, tags, time"
    ifEncoding = create_interface("IEncodingService", pkgInterfaces)
    encoding_ops = [
        "Encode_Data_Value",
        "Decode_Data_Value",
        "Encode_Tag",
        "Decode_Tag",
        "Encode_Timestamp",
        "Decode_Timestamp",
        "Encode_Duration",
        "Decode_Duration",
        "Swap_Endianness",
    ]
    for op in encoding_ops:
        add_operation(ifEncoding, op)

    # =========================================
    # Ports on blocks (expose interfaces)
    # =========================================
    add_flow_port(blkCUIS, "serverPort", ifServer)
    add_flow_port(blkCUIS, "clientCallbackPort", ifClient)
    add_flow_port(blkGRPC, "grpcServerPort", ifServer)
    add_flow_port(blkGRPC, "sessionPort", ifSession)
    add_flow_port(blkRTI, "rtiPort", ifRTI)
    # NEW: Encoding port on EncodingLayer
    add_flow_port(blkEncoding, "encodingPort", ifEncoding)

    # =========================================
    # Relationships sub-package
    # =========================================
    pkgRels = create_package("Relationships", pkg)

    # -----------------------------------------
    # Interface Realizations
    # (block ---▷ interface: "I implement this")
    # -----------------------------------------

    # GRPCServices implements the server-facing gRPC API
    add_realization(blkGRPC, ifServer, pkgRels)

    # GRPCServices implements session management
    add_realization(blkGRPC, ifSession, pkgRels)

    # RTIAdapter implements the RTI federation operations
    add_realization(blkRTI, ifRTI, pkgRels)

    # CommonUI_Server as a whole realises the client callback
    # interface (it is responsible for pushing updates to clients)
    add_realization(blkCUIS, ifClient, pkgRels)

    # NEW: EncodingLayer realizes the encoding interface
    add_realization(blkEncoding, ifEncoding, pkgRels)

    # -----------------------------------------
    # Dependencies
    # (client - - -> supplier: "I need this")
    # -----------------------------------------

    # CallbackDispatcher depends on RoutingEngine to route
    # incoming RTI callbacks to the correct subscribers
    add_dependency(blkCallbackDispatcher, blkRouting,
                   "routes_callbacks_via", pkgRels)

    # RoutingEngine depends on ClientRegistry to resolve
    # which clients are subscribed to which objects
    add_dependency(blkRouting, blkRegistry,
                   "resolves_subscribers_via", pkgRels)

    # SessionManager depends on ClientRegistry to
    # add/remove/query client entries
    add_dependency(blkSessMgr, blkRegistry,
                   "manages_clients_in", pkgRels)

    # GRPCServices depends on RoutingEngine for pub/sub dispatch
    add_dependency(blkGRPC, blkRouting,
                   "dispatches_pubsub_to", pkgRels)

    # GRPCServices depends on SessionManager for connect/disconnect
    add_dependency(blkGRPC, blkSessMgr,
                   "delegates_sessions_to", pkgRels)

    # NEW: RTIAdapter depends on EncodingLayer for HLA ↔ protobuf conversion
    # Design: "RTI Adapter - Conversion (HLA ↔ protobuf)"
    add_dependency(blkRTI, blkEncoding,
                   "converts_hla_types_via", pkgRels)

    # NEW: GRPCServices depends on EncodingLayer for marshalling
    add_dependency(blkGRPC, blkEncoding,
                   "marshals_values_via", pkgRels)

    # NEW: EncodingLayer depends on ClientRegistry for endianness lookup
    add_dependency(blkEncoding, blkRegistry,
                   "reads_endianness_from", pkgRels)

    # -----------------------------------------
    # Usage relationships (<<use>>)
    # (stronger than dependency - implementation requirement)
    # -----------------------------------------

    # RTIAdapter uses the HLA DataTypes for marshalling
    add_usage(blkRTI, dtDV, "marshals_data_via", pkgRels)
    add_usage(blkRTI, dtAV, "marshals_attributes_via", pkgRels)
    add_usage(blkRTI, dtPV, "marshals_parameters_via", pkgRels)

    # NEW: RTIAdapter uses HLAhandle for opaque handle passing
    add_usage(blkRTI, dtHLAhandle, "passes_handles_as", pkgRels)

    # NEW: RTIAdapter uses Timestamp and Duration
    add_usage(blkRTI, dtTimestamp, "timestamps_updates_with", pkgRels)
    add_usage(blkRTI, dtDuration, "measures_durations_with", pkgRels)

    # NEW: RTIAdapter uses Attributes for pub/sub handle sets
    add_usage(blkRTI, dtAttributes, "declares_attribute_sets_with", pkgRels)

    # RoutingEngine uses SubscriptionRecord to track subscriptions
    add_usage(blkRouting, dtSubscription,
              "tracks_subscriptions_with", pkgRels)

    # ClientRegistry uses ClientInfo to store client state
    add_usage(blkRegistry, dtClientInfo,
              "stores_clients_as", pkgRels)

    # ObjectManager uses ObjectReference for instance tracking
    add_usage(blkObjMgr, dtObjectRef,
              "tracks_instances_with", pkgRels)

    # NEW: EncodingLayer uses the core encoding data types
    add_usage(blkEncoding, dtDV, "encodes_decodes_via", pkgRels)
    add_usage(blkEncoding, dtTimestamp, "encodes_timestamps_via", pkgRels)
    add_usage(blkEncoding, dtDuration, "encodes_durations_via", pkgRels)
    add_usage(blkEncoding, dtHLAhandle, "serialises_handles_via", pkgRels)

    # =========================================
    # Constraint Blocks
    # =========================================
    pkgConstraints = create_package("Constraints", pkg)

    # -----------------------------------------
    # Timing constraints
    # -----------------------------------------

    # RTI callback latency: time from RTI callback arrival to
    # client notification must be within budget
    cbCallbackLatency = create_constraint_block(
        "CallbackLatencyConstraint", pkgConstraints,
        [
            ("rti_callback_arrival_ms",),
            ("client_notification_ms",),
            ("max_latency_budget_ms",),
        ],
        "client_notification_ms - rti_callback_arrival_ms <= max_latency_budget_ms"
    )

    # gRPC round-trip: client request to server response
    cbGrpcRoundTrip = create_constraint_block(
        "GrpcRoundTripConstraint", pkgConstraints,
        [
            ("request_sent_ms",),
            ("response_received_ms",),
            ("max_round_trip_ms",),
        ],
        "response_received_ms - request_sent_ms <= max_round_trip_ms"
    )

    # Heartbeat timing: heartbeat must arrive within session timeout
    cbHeartbeatTiming = create_constraint_block(
        "HeartbeatTimingConstraint", pkgConstraints,
        [
            ("heartbeat_interval_ms",),
            ("session_timeout_ms",),
            ("missed_beats_before_disconnect",),
        ],
        "heartbeat_interval_ms * missed_beats_before_disconnect <= session_timeout_ms"
    )

    # NEW: Encoding latency constraint
    # Design: encoding/decoding is on the critical path for all data flow
    cbEncodingLatency = create_constraint_block(
        "EncodingLatencyConstraint", pkgConstraints,
        [
            ("encode_start_ms",),
            ("encode_complete_ms",),
            ("max_encoding_latency_ms",),
        ],
        "encode_complete_ms - encode_start_ms <= max_encoding_latency_ms"
    )

    # -----------------------------------------
    # Throughput constraints
    # -----------------------------------------

    # Attribute update throughput: system must handle required
    # update rate across all subscribed objects
    cbUpdateThroughput = create_constraint_block(
        "UpdateThroughputConstraint", pkgConstraints,
        [
            ("num_subscribed_objects",),
            ("updates_per_second_per_object",),
            ("max_updates_per_second",),
        ],
        "num_subscribed_objects * updates_per_second_per_object <= max_updates_per_second"
    )

    # Interaction throughput: rate of interactions dispatched
    cbInteractionThroughput = create_constraint_block(
        "InteractionThroughputConstraint", pkgConstraints,
        [
            ("num_interaction_subscriptions",),
            ("interactions_per_second",),
            ("max_dispatch_rate",),
        ],
        "num_interaction_subscriptions * interactions_per_second <= max_dispatch_rate"
    )

    # gRPC stream capacity
    cbStreamCapacity = create_constraint_block(
        "StreamCapacityConstraint", pkgConstraints,
        [
            ("active_clients",),
            ("streams_per_client",),
            ("max_concurrent_streams",),
        ],
        "active_clients * streams_per_client <= max_concurrent_streams"
    )

    # -----------------------------------------
    # Capacity constraints
    # -----------------------------------------

    # Max concurrent clients
    cbClientCapacity = create_constraint_block(
        "ClientCapacityConstraint", pkgConstraints,
        [
            ("connected_clients",),
            ("max_clients",),
        ],
        "connected_clients <= max_clients"
    )

    # Subscription table size: total subscriptions across all clients
    cbSubscriptionCapacity = create_constraint_block(
        "SubscriptionCapacityConstraint", pkgConstraints,
        [
            ("num_clients",),
            ("avg_subscriptions_per_client",),
            ("max_total_subscriptions",),
        ],
        "num_clients * avg_subscriptions_per_client <= max_total_subscriptions"
    )

    # RTI object instance tracking capacity
    cbObjectCapacity = create_constraint_block(
        "ObjectInstanceCapacityConstraint", pkgConstraints,
        [
            ("registered_objects",),
            ("discovered_objects",),
            ("max_tracked_objects",),
        ],
        "registered_objects + discovered_objects <= max_tracked_objects"
    )

    # -----------------------------------------
    # Bind constraint properties to blocks
    # (these appear on parametric diagrams)
    # -----------------------------------------

    # CommonUI_Server owns the top-level timing/throughput constraints
    add_constraint_property(blkCUIS, "callbackLatency", cbCallbackLatency)
    add_constraint_property(blkCUIS, "updateThroughput", cbUpdateThroughput)
    add_constraint_property(blkCUIS, "interactionThroughput", cbInteractionThroughput)

    # GRPCServices owns stream and round-trip constraints
    add_constraint_property(blkGRPC, "grpcRoundTrip", cbGrpcRoundTrip)
    add_constraint_property(blkGRPC, "streamCapacity", cbStreamCapacity)

    # SessionManager owns heartbeat timing constraint
    add_constraint_property(blkSessMgr, "heartbeatTiming", cbHeartbeatTiming)

    # ClientRegistry owns client capacity constraint
    add_constraint_property(blkRegistry, "clientCapacity", cbClientCapacity)

    # SubscriptionTable owns subscription capacity constraint
    add_constraint_property(blkSubTable, "subscriptionCapacity", cbSubscriptionCapacity)

    # ObjectManager owns object instance tracking constraint
    add_constraint_property(blkObjMgr, "objectCapacity", cbObjectCapacity)

    # NEW: EncodingLayer owns encoding latency constraint
    add_constraint_property(blkEncoding, "encodingLatency", cbEncodingLatency)

    # =========================================
    # Activity Diagrams
    # =========================================
    pkgActivities = create_package("Activities", pkg)

    # -----------------------------------------
    # Activity 1: Object Attribute Publish / Subscribe / Reflect
    # The core pub/sub flow through CUIS
    # -----------------------------------------
    actPubSub = create_activity("Object_PubSub_Flow", pkgActivities)

    # Swimlanes
    swimClient = create_activity_partition("UIClient", actPubSub)
    swimGRPC = create_activity_partition("GRPCServices", actPubSub, blkGRPC)
    swimRouting = create_activity_partition("RoutingEngine", actPubSub, blkRouting)
    swimRegistry = create_activity_partition("ClientRegistry", actPubSub, blkRegistry)
    swimEncoding = create_activity_partition("EncodingLayer", actPubSub, blkEncoding)
    swimRTI = create_activity_partition("RTIAdapter", actPubSub, blkRTI)
    swimFederation = create_activity_partition("HLA_Federation", actPubSub)

    # Nodes - publish path (client registers interest to publish)
    ps_init = create_initial_node(actPubSub)
    assign_partition(ps_init, swimClient)

    ps_publish_req = create_action("Client calls Publish_Object_Attributes", actPubSub)
    assign_partition(ps_publish_req, swimClient)

    ps_grpc_recv_pub = create_action("Receive gRPC publish request", actPubSub)
    assign_partition(ps_grpc_recv_pub, swimGRPC)

    ps_register_pub = create_action("Register publication in SubscriptionTable", actPubSub)
    assign_partition(ps_register_pub, swimRouting)

    ps_rti_publish = create_action("Publish object class to RTI", actPubSub)
    assign_partition(ps_rti_publish, swimRTI)

    ps_rti_register = create_action("Register object instance with RTI", actPubSub)
    assign_partition(ps_rti_register, swimRTI)

    ps_fed_publish = create_send_signal_action("Object published in federation", actPubSub)
    assign_partition(ps_fed_publish, swimFederation)

    # Nodes - subscribe path (another client wants to receive updates)
    ps_fork = create_fork_node(actPubSub, "pub_sub_fork")
    assign_partition(ps_fork, swimClient)

    ps_subscribe_req = create_action("Client calls Subscribe_Object_Attributes", actPubSub)
    assign_partition(ps_subscribe_req, swimClient)

    ps_grpc_recv_sub = create_action("Receive gRPC subscribe request", actPubSub)
    assign_partition(ps_grpc_recv_sub, swimGRPC)

    ps_lookup_client = create_action("Validate client in registry", actPubSub)
    assign_partition(ps_lookup_client, swimRegistry)

    ps_register_sub = create_action("Record subscription in SubscriptionTable", actPubSub)
    assign_partition(ps_register_sub, swimRouting)

    ps_rti_subscribe = create_action("Subscribe to object class at RTI", actPubSub)
    assign_partition(ps_rti_subscribe, swimRTI)

    # Nodes - update/reflect path (data flows through)
    ps_join = create_join_node(actPubSub, "pub_sub_join")
    assign_partition(ps_join, swimRouting)

    ps_update = create_action("Publisher calls Update_Attribute_Values", actPubSub)
    assign_partition(ps_update, swimClient)

    ps_grpc_recv_upd = create_action("Receive gRPC update", actPubSub)
    assign_partition(ps_grpc_recv_upd, swimGRPC)

    # NEW: Encoding step for outbound update
    ps_encode_update = create_action("Encode Data_Values to HLA representation", actPubSub)
    assign_partition(ps_encode_update, swimEncoding)

    ps_rti_update = create_action("Forward attribute update to RTI", actPubSub)
    assign_partition(ps_rti_update, swimRTI)

    ps_fed_reflect = create_accept_event_action("RTI delivers Reflect callback", actPubSub)
    assign_partition(ps_fed_reflect, swimRTI)

    # NEW: Decoding step for inbound reflection
    ps_decode_reflect = create_action("Decode HLA values to Data_Value representation", actPubSub)
    assign_partition(ps_decode_reflect, swimEncoding)

    ps_route_reflect = create_action("Match reflection to subscriptions", actPubSub)
    assign_partition(ps_route_reflect, swimRouting)

    ps_filter_attrs = create_action("Filter attributes per subscriber", actPubSub)
    assign_partition(ps_filter_attrs, swimRouting)

    ps_grpc_callback = create_action("Stream Reflect_Attribute_Values to client", actPubSub)
    assign_partition(ps_grpc_callback, swimGRPC)

    ps_client_reflect = create_action("Client receives reflected values", actPubSub)
    assign_partition(ps_client_reflect, swimClient)

    ps_final = create_final_node(actPubSub)
    assign_partition(ps_final, swimClient)

    # Control flows - publish path
    create_control_flow(ps_init, ps_fork, actPubSub)
    create_control_flow(ps_fork, ps_publish_req, actPubSub)
    create_control_flow(ps_publish_req, ps_grpc_recv_pub, actPubSub)
    create_control_flow(ps_grpc_recv_pub, ps_register_pub, actPubSub)
    create_control_flow(ps_register_pub, ps_rti_publish, actPubSub)
    create_control_flow(ps_rti_publish, ps_rti_register, actPubSub)
    create_control_flow(ps_rti_register, ps_fed_publish, actPubSub)
    create_control_flow(ps_fed_publish, ps_join, actPubSub)

    # Control flows - subscribe path
    create_control_flow(ps_fork, ps_subscribe_req, actPubSub)
    create_control_flow(ps_subscribe_req, ps_grpc_recv_sub, actPubSub)
    create_control_flow(ps_grpc_recv_sub, ps_lookup_client, actPubSub)
    create_control_flow(ps_lookup_client, ps_register_sub, actPubSub)
    create_control_flow(ps_register_sub, ps_rti_subscribe, actPubSub)
    create_control_flow(ps_rti_subscribe, ps_join, actPubSub)

    # Control flows - update/reflect path (MODIFIED: encoding steps inserted)
    create_control_flow(ps_join, ps_update, actPubSub)
    create_control_flow(ps_update, ps_grpc_recv_upd, actPubSub)
    create_control_flow(ps_grpc_recv_upd, ps_encode_update, actPubSub)
    create_control_flow(ps_encode_update, ps_rti_update, actPubSub)
    create_control_flow(ps_rti_update, ps_fed_reflect, actPubSub)
    create_control_flow(ps_fed_reflect, ps_decode_reflect, actPubSub)
    create_control_flow(ps_decode_reflect, ps_route_reflect, actPubSub)
    create_control_flow(ps_route_reflect, ps_filter_attrs, actPubSub)
    create_control_flow(ps_filter_attrs, ps_grpc_callback, actPubSub)
    create_control_flow(ps_grpc_callback, ps_client_reflect, actPubSub)
    create_control_flow(ps_client_reflect, ps_final, actPubSub)

    # -----------------------------------------
    # Activity 2: Interaction Send / Receive
    # -----------------------------------------
    actInteraction = create_activity("Interaction_SendReceive_Flow", pkgActivities)

    # Swimlanes
    iSwimSender = create_activity_partition("SenderClient", actInteraction)
    iSwimGRPC = create_activity_partition("GRPCServices", actInteraction, blkGRPC)
    iSwimEncoding = create_activity_partition("EncodingLayer", actInteraction, blkEncoding)
    iSwimRouting = create_activity_partition("RoutingEngine", actInteraction, blkRouting)
    iSwimRTI = create_activity_partition("RTIAdapter", actInteraction, blkRTI)
    iSwimReceiver = create_activity_partition("ReceiverClient", actInteraction)

    # Nodes - sender side
    i_init = create_initial_node(actInteraction)
    assign_partition(i_init, iSwimSender)

    i_send_req = create_action("Client calls Send_Interaction", actInteraction)
    assign_partition(i_send_req, iSwimSender)

    i_grpc_recv = create_action("Receive gRPC Send_Interaction request", actInteraction)
    assign_partition(i_grpc_recv, iSwimGRPC)

    i_validate = create_action("Validate interaction class is published", actInteraction)
    assign_partition(i_validate, iSwimRouting)

    i_decision = create_decision_node(actInteraction, "valid_interaction?")
    assign_partition(i_decision, iSwimRouting)

    # NEW: Encode parameters before sending to RTI
    i_encode_params = create_action("Encode Parameter_Values to HLA representation", actInteraction)
    assign_partition(i_encode_params, iSwimEncoding)

    i_rti_send = create_action("Send interaction to RTI", actInteraction)
    assign_partition(i_rti_send, iSwimRTI)

    i_error = create_action("Return error to sender", actInteraction)
    assign_partition(i_error, iSwimGRPC)

    # Nodes - receiver side (RTI callback path)
    i_rti_callback = create_accept_event_action("RTI delivers Receive_Interaction callback", actInteraction)
    assign_partition(i_rti_callback, iSwimRTI)

    # NEW: Decode parameters from RTI callback
    i_decode_params = create_action("Decode HLA parameters to Parameter_Values", actInteraction)
    assign_partition(i_decode_params, iSwimEncoding)

    i_route = create_action("Resolve subscribed receivers", actInteraction)
    assign_partition(i_route, iSwimRouting)

    i_decision_subs = create_decision_node(actInteraction, "has_subscribers?")
    assign_partition(i_decision_subs, iSwimRouting)

    i_grpc_dispatch = create_action("Stream Receive_Interaction to each subscriber", actInteraction)
    assign_partition(i_grpc_dispatch, iSwimGRPC)

    i_client_recv = create_action("Receiver client processes interaction", actInteraction)
    assign_partition(i_client_recv, iSwimReceiver)

    i_merge = create_merge_node(actInteraction, "interaction_merge")
    assign_partition(i_merge, iSwimRouting)

    i_final = create_final_node(actInteraction)
    assign_partition(i_final, iSwimRouting)

    # Control flows - send path (MODIFIED: encoding step inserted)
    create_control_flow(i_init, i_send_req, actInteraction)
    create_control_flow(i_send_req, i_grpc_recv, actInteraction)
    create_control_flow(i_grpc_recv, i_validate, actInteraction)
    create_control_flow(i_validate, i_decision, actInteraction)
    create_control_flow(i_decision, i_encode_params, actInteraction, "valid")
    create_control_flow(i_encode_params, i_rti_send, actInteraction)
    create_control_flow(i_decision, i_error, actInteraction, "invalid")
    create_control_flow(i_error, i_merge, actInteraction)

    # Control flows - receive path (MODIFIED: decoding step inserted)
    create_control_flow(i_rti_send, i_rti_callback, actInteraction)
    create_control_flow(i_rti_callback, i_decode_params, actInteraction)
    create_control_flow(i_decode_params, i_route, actInteraction)
    create_control_flow(i_route, i_decision_subs, actInteraction)
    create_control_flow(i_decision_subs, i_grpc_dispatch, actInteraction, "subscribers exist")
    create_control_flow(i_decision_subs, i_merge, actInteraction, "no subscribers")
    create_control_flow(i_grpc_dispatch, i_client_recv, actInteraction)
    create_control_flow(i_client_recv, i_merge, actInteraction)
    create_control_flow(i_merge, i_final, actInteraction)

    # -----------------------------------------
    # Activity 3: Client Session Lifecycle
    # -----------------------------------------
    actSession = create_activity("Client_Session_Lifecycle", pkgActivities)

    # Swimlanes
    sSwimClient = create_activity_partition("UIClient", actSession)
    sSwimGRPC = create_activity_partition("GRPCServices", actSession, blkGRPC)
    sSwimSession = create_activity_partition("SessionManager", actSession, blkSessMgr)
    sSwimRegistry = create_activity_partition("ClientRegistry", actSession, blkRegistry)

    # Nodes - connect
    s_init = create_initial_node(actSession)
    assign_partition(s_init, sSwimClient)

    s_connect_req = create_action("Client calls Connect_Client", actSession)
    assign_partition(s_connect_req, sSwimClient)

    s_grpc_recv_conn = create_action("Receive gRPC connect request", actSession)
    assign_partition(s_grpc_recv_conn, sSwimGRPC)

    s_validate = create_action("Validate client credentials", actSession)
    assign_partition(s_validate, sSwimSession)

    s_decision_auth = create_decision_node(actSession, "auth_valid?")
    assign_partition(s_decision_auth, sSwimSession)

    s_reject = create_action("Return connection rejected", actSession)
    assign_partition(s_reject, sSwimGRPC)

    s_register = create_action("Create client entry in registry", actSession)
    assign_partition(s_register, sSwimRegistry)

    s_assign_id = create_action("Assign client_id and session token", actSession)
    assign_partition(s_assign_id, sSwimSession)

    s_ack_connect = create_action("Return connection acknowledged", actSession)
    assign_partition(s_ack_connect, sSwimGRPC)

    s_client_connected = create_action("Client enters ACTIVE state", actSession)
    assign_partition(s_client_connected, sSwimClient)

    # Nodes - heartbeat loop
    s_heartbeat_decision = create_decision_node(actSession, "session_active?")
    assign_partition(s_heartbeat_decision, sSwimSession)

    s_wait_heartbeat = create_accept_event_action("Wait for heartbeat", actSession)
    assign_partition(s_wait_heartbeat, sSwimSession)

    s_heartbeat_check = create_decision_node(actSession, "heartbeat_received?")
    assign_partition(s_heartbeat_check, sSwimSession)

    s_update_timestamp = create_action("Update last-seen timestamp", actSession)
    assign_partition(s_update_timestamp, sSwimSession)

    s_timeout_disconnect = create_action("Mark client as timed-out", actSession)
    assign_partition(s_timeout_disconnect, sSwimSession)

    # Nodes - graceful disconnect
    s_disconnect_req = create_action("Client calls Disconnect_Client", actSession)
    assign_partition(s_disconnect_req, sSwimClient)

    s_grpc_recv_disc = create_action("Receive gRPC disconnect request", actSession)
    assign_partition(s_grpc_recv_disc, sSwimGRPC)

    # Nodes - cleanup (shared by timeout and graceful disconnect)
    s_cleanup_merge = create_merge_node(actSession, "cleanup_merge")
    assign_partition(s_cleanup_merge, sSwimSession)

    s_remove_subs = create_action("Remove all client subscriptions", actSession)
    assign_partition(s_remove_subs, sSwimSession)

    s_remove_client = create_action("Remove client from registry", actSession)
    assign_partition(s_remove_client, sSwimRegistry)

    s_notify_disconnect = create_action("Notify RTIAdapter of withdrawn publications", actSession)
    assign_partition(s_notify_disconnect, sSwimSession)

    s_final = create_final_node(actSession)
    assign_partition(s_final, sSwimRegistry)

    s_reject_final = create_final_node(actSession, "reject_final")
    assign_partition(s_reject_final, sSwimGRPC)

    # Control flows - connect
    create_control_flow(s_init, s_connect_req, actSession)
    create_control_flow(s_connect_req, s_grpc_recv_conn, actSession)
    create_control_flow(s_grpc_recv_conn, s_validate, actSession)
    create_control_flow(s_validate, s_decision_auth, actSession)
    create_control_flow(s_decision_auth, s_reject, actSession, "invalid")
    create_control_flow(s_reject, s_reject_final, actSession)
    create_control_flow(s_decision_auth, s_register, actSession, "valid")
    create_control_flow(s_register, s_assign_id, actSession)
    create_control_flow(s_assign_id, s_ack_connect, actSession)
    create_control_flow(s_ack_connect, s_client_connected, actSession)

    # Control flows - heartbeat loop
    create_control_flow(s_client_connected, s_heartbeat_decision, actSession)
    create_control_flow(s_heartbeat_decision, s_wait_heartbeat, actSession, "active")
    create_control_flow(s_wait_heartbeat, s_heartbeat_check, actSession)
    create_control_flow(s_heartbeat_check, s_update_timestamp, actSession, "received")
    create_control_flow(s_update_timestamp, s_heartbeat_decision, actSession)
    create_control_flow(s_heartbeat_check, s_timeout_disconnect, actSession, "timed out")
    create_control_flow(s_timeout_disconnect, s_cleanup_merge, actSession)

    # Control flows - graceful disconnect
    create_control_flow(s_heartbeat_decision, s_disconnect_req, actSession, "disconnect requested")
    create_control_flow(s_disconnect_req, s_grpc_recv_disc, actSession)
    create_control_flow(s_grpc_recv_disc, s_cleanup_merge, actSession)

    # Control flows - cleanup
    create_control_flow(s_cleanup_merge, s_remove_subs, actSession)
    create_control_flow(s_remove_subs, s_remove_client, actSession)
    create_control_flow(s_remove_client, s_notify_disconnect, actSession)
    create_control_flow(s_notify_disconnect, s_final, actSession)

    # =========================================
    # State Machines
    # =========================================
    pkgStateMachines = create_package("StateMachines", pkg)

    # -----------------------------------------
    # State Machine 1: Client Session Lifecycle
    # Maps to the ClientState enumeration:
    #   DISCONNECTED -> CONNECTED -> SUBSCRIBING -> ACTIVE -> (ERROR)
    # -----------------------------------------
    smClient = create_state_machine("ClientSessionLifecycle", pkgStateMachines)
    regClient = create_region("main", smClient)

    # Pseudostate: initial
    csInit = create_pseudostate(regClient, "initial")

    # State: DISCONNECTED
    csDisconnected = create_state("DISCONNECTED", regClient)
    add_entry_action(csDisconnected, "Reset client context")

    # State: CONNECTED (composite - contains authentication sub-states)
    csConnected, regConnected = create_composite_state("CONNECTED", regClient)
    add_entry_action(csConnected, "Allocate client_id and session token")
    add_exit_action(csConnected, "Log connection event")

    #   Sub-states within CONNECTED
    csConnInit = create_pseudostate(regConnected, "initial")
    csAuthenticating = create_state("Authenticating", regConnected)
    add_do_activity(csAuthenticating, "Validate client credentials")
    csAuthenticated = create_state("Authenticated", regConnected)
    add_entry_action(csAuthenticated, "Register in ClientRegistry")

    #   Sub-transitions within CONNECTED
    create_transition(csConnInit, csAuthenticating, regConnected)
    create_transition(csAuthenticating, csAuthenticated, regConnected,
                      trigger_name="auth_success",
                      effect_name="Create registry entry")
    create_transition(csAuthenticating, csDisconnected, regClient,
                      trigger_name="auth_failure",
                      guard_expr="credentials invalid",
                      effect_name="Return rejection to client")

    # State: SUBSCRIBING
    csSubscribing = create_state("SUBSCRIBING", regClient)
    add_entry_action(csSubscribing, "Begin processing subscription requests")
    add_do_activity(csSubscribing, "Register subscriptions with RoutingEngine and RTI")

    # State: ACTIVE (composite - contains heartbeat monitoring)
    csActive, regActive = create_composite_state("ACTIVE", regClient)
    add_entry_action(csActive, "Client fully operational")

    #   Sub-states within ACTIVE
    csActiveInit = create_pseudostate(regActive, "initial")
    csIdle = create_state("Idle", regActive)
    add_do_activity(csIdle, "Await heartbeat or client request")
    csProcessing = create_state("Processing", regActive)
    add_entry_action(csProcessing, "Handle pub/sub or interaction request")
    csHeartbeatOverdue = create_state("HeartbeatOverdue", regActive)
    add_entry_action(csHeartbeatOverdue, "Start timeout countdown")

    #   Sub-transitions within ACTIVE
    create_transition(csActiveInit, csIdle, regActive)
    create_transition(csIdle, csProcessing, regActive,
                      trigger_name="client_request",
                      effect_name="Dispatch to GRPCServices handler")
    create_transition(csProcessing, csIdle, regActive,
                      trigger_name="request_complete",
                      effect_name="Return response to client")
    create_transition(csIdle, csHeartbeatOverdue, regActive,
                      trigger_name="heartbeat_timeout",
                      guard_expr="heartbeat_interval exceeded")
    create_transition(csHeartbeatOverdue, csIdle, regActive,
                      trigger_name="heartbeat_received",
                      effect_name="Update last-seen timestamp")

    # State: ERROR
    csError = create_state("ERROR", regClient)
    add_entry_action(csError, "Log error and notify monitoring")
    add_do_activity(csError, "Attempt recovery or await admin intervention")

    # Final state
    csFinal = create_final_state(regClient)

    # -----------------------------------------
    # Top-level transitions (client lifecycle)
    # -----------------------------------------

    # initial -> DISCONNECTED
    create_transition(csInit, csDisconnected, regClient)

    # DISCONNECTED -> CONNECTED: client initiates connection
    create_transition(csDisconnected, csConnected, regClient,
                      trigger_name="Connect_Client",
                      effect_name="Open gRPC channel")

    # CONNECTED -> SUBSCRIBING: client starts subscribing
    create_transition(csConnected, csSubscribing, regClient,
                      trigger_name="Subscribe_Object_Attributes",
                      guard_expr="authenticated",
                      effect_name="Forward to RoutingEngine")

    # CONNECTED -> ACTIVE: client connects without subscriptions
    create_transition(csConnected, csActive, regClient,
                      trigger_name="activation_complete",
                      guard_expr="no subscriptions requested")

    # SUBSCRIBING -> ACTIVE: all subscriptions processed
    create_transition(csSubscribing, csActive, regClient,
                      trigger_name="subscriptions_confirmed",
                      effect_name="Notify client ready")

    # SUBSCRIBING -> SUBSCRIBING: additional subscription
    create_transition(csSubscribing, csSubscribing, regClient,
                      trigger_name="Subscribe_additional",
                      effect_name="Add subscription to RoutingEngine")

    # ACTIVE -> SUBSCRIBING: client adds more subscriptions while active
    create_transition(csActive, csSubscribing, regClient,
                      trigger_name="Subscribe_Object_Attributes",
                      effect_name="Process new subscription")

    # ACTIVE -> DISCONNECTED: graceful disconnect
    create_transition(csActive, csDisconnected, regClient,
                      trigger_name="Disconnect_Client",
                      effect_name="Cleanup subscriptions and registry entry")

    # HeartbeatOverdue -> ERROR: timeout fully expired
    create_transition(csHeartbeatOverdue, csError, regClient,
                      trigger_name="timeout_expired",
                      guard_expr="missed_beats >= threshold",
                      effect_name="Mark client as timed-out")

    # ERROR -> DISCONNECTED: cleanup after error
    create_transition(csError, csDisconnected, regClient,
                      trigger_name="error_cleanup",
                      effect_name="Remove subscriptions and registry entry")

    # ERROR -> final: unrecoverable
    create_transition(csError, csFinal, regClient,
                      trigger_name="unrecoverable_error",
                      effect_name="Force-close gRPC channel")

    # DISCONNECTED -> final: session ended
    create_transition(csDisconnected, csFinal, regClient,
                      trigger_name="session_terminated",
                      guard_expr="no reconnect within grace period")

    # Any state -> ERROR (via CONNECTED and ACTIVE)
    create_transition(csConnected, csError, regClient,
                      trigger_name="connection_error",
                      effect_name="Log transport failure")
    create_transition(csSubscribing, csError, regClient,
                      trigger_name="subscription_error",
                      effect_name="Log RTI subscription failure")

    # -----------------------------------------
    # State Machine 2: RTI Federation Connection
    # Lifecycle of the RTIAdapter's federation membership
    # -----------------------------------------
    smRTI = create_state_machine("RTIFederationLifecycle", pkgStateMachines)
    regRTI = create_region("main", smRTI)

    # Pseudostate: initial
    rtiInit = create_pseudostate(regRTI, "initial")

    # State: IDLE (not connected to any federation)
    rtiIdle = create_state("IDLE", regRTI)
    add_entry_action(rtiIdle, "RTI ambassador not initialised")

    # State: CONNECTING
    rtiConnecting = create_state("CONNECTING", regRTI)
    add_entry_action(rtiConnecting, "Create RTI ambassador instance")
    add_do_activity(rtiConnecting, "Attempt createFederationExecution and joinFederationExecution")

    # State: JOINED (composite - federation is active)
    rtiJoined, regJoined = create_composite_state("JOINED", regRTI)
    add_entry_action(rtiJoined, "Federation joined successfully")

    #   Sub-states within JOINED
    rtiJoinInit = create_pseudostate(regJoined, "initial")
    rtiPublishing = create_state("PublishingAndSubscribing", regJoined)
    add_entry_action(rtiPublishing, "Declare publications and subscriptions to RTI")
    add_do_activity(rtiPublishing, "Process publishObjectClassAttributes and subscribeObjectClassAttributes")
    rtiOperational = create_state("Operational", regJoined)
    add_entry_action(rtiOperational, "Begin processing callbacks")
    add_do_activity(rtiOperational, "Dispatch RTI callbacks via CallbackDispatcher")
    rtiUpdating = create_state("UpdatingAttributes", regJoined)
    add_entry_action(rtiUpdating, "Process updateAttributeValues batch")

    #   Sub-transitions within JOINED
    create_transition(rtiJoinInit, rtiPublishing, regJoined)
    create_transition(rtiPublishing, rtiOperational, regJoined,
                      trigger_name="pub_sub_complete",
                      effect_name="Enable callback processing")
    create_transition(rtiOperational, rtiUpdating, regJoined,
                      trigger_name="update_requested",
                      effect_name="Marshal attribute values")
    create_transition(rtiUpdating, rtiOperational, regJoined,
                      trigger_name="update_sent",
                      effect_name="Resume callback processing")
    # New pub/sub request while operational
    create_transition(rtiOperational, rtiPublishing, regJoined,
                      trigger_name="new_pub_sub_request",
                      effect_name="Process additional declarations")

    # State: RESIGNING
    rtiResigning = create_state("RESIGNING", regRTI)
    add_entry_action(rtiResigning, "Begin resignFederationExecution")
    add_do_activity(rtiResigning, "Unpublish all, unsubscribe all, resign")

    # State: ERROR
    rtiError = create_state("RTI_ERROR", regRTI)
    add_entry_action(rtiError, "Log RTI exception")
    add_do_activity(rtiError, "Attempt reconnection or notify SessionManager")

    # Final state
    rtiFinal = create_final_state(regRTI)

    # -----------------------------------------
    # Top-level transitions (RTI lifecycle)
    # -----------------------------------------

    # initial -> IDLE
    create_transition(rtiInit, rtiIdle, regRTI)

    # IDLE -> CONNECTING: CUIS starts up
    create_transition(rtiIdle, rtiConnecting, regRTI,
                      trigger_name="start_federation",
                      effect_name="Read FOM path and federation name from config")

    # CONNECTING -> JOINED: successfully joined
    create_transition(rtiConnecting, rtiJoined, regRTI,
                      trigger_name="join_success",
                      effect_name="Store federation handle")

    # CONNECTING -> ERROR: join failed
    create_transition(rtiConnecting, rtiError, regRTI,
                      trigger_name="join_failure",
                      effect_name="Log connection failure details")

    # JOINED -> RESIGNING: shutdown requested
    create_transition(rtiJoined, rtiResigning, regRTI,
                      trigger_name="shutdown_requested",
                      effect_name="Begin orderly withdrawal")

    # JOINED -> ERROR: RTI exception during operation
    create_transition(rtiJoined, rtiError, regRTI,
                      trigger_name="rti_exception",
                      effect_name="Capture exception context")

    # RESIGNING -> IDLE: resigned successfully
    create_transition(rtiResigning, rtiIdle, regRTI,
                      trigger_name="resign_complete",
                      effect_name="Destroy RTI ambassador")

    # RESIGNING -> ERROR: resign failed
    create_transition(rtiResigning, rtiError, regRTI,
                      trigger_name="resign_failure",
                      effect_name="Force ambassador cleanup")

    # ERROR -> CONNECTING: retry
    create_transition(rtiError, rtiConnecting, regRTI,
                      trigger_name="retry_connection",
                      guard_expr="retry_count < max_retries",
                      effect_name="Increment retry counter")

    # ERROR -> IDLE: give up
    create_transition(rtiError, rtiIdle, regRTI,
                      trigger_name="max_retries_exceeded",
                      effect_name="Notify all clients of federation loss")

    # ERROR -> final: unrecoverable
    create_transition(rtiError, rtiFinal, regRTI,
                      trigger_name="fatal_rti_error",
                      effect_name="Shutdown CUIS")

    # =========================================
    # Sequence Diagrams
    # =========================================
    pkgSequences = create_package("SequenceDiagrams", pkg)

    # -----------------------------------------
    # SD 1: Object Publish and Reflect
    # A publisher registers an object, a subscriber receives
    # reflected attribute values via CUIS.
    # -----------------------------------------
    sdPubReflect = create_interaction("SD_Object_Publish_Reflect", pkgSequences)

    # Lifelines
    llPublisher = create_lifeline("Publisher", sdPubReflect)
    llGRPC_pr = create_lifeline("grpcServices", sdPubReflect, blkGRPC)
    llRouting_pr = create_lifeline("routingEngine", sdPubReflect, blkRouting)
    llSubTable_pr = create_lifeline("subscriptionTable", sdPubReflect, blkSubTable)
    llRegistry_pr = create_lifeline("clientRegistry", sdPubReflect, blkRegistry)
    llEncoding_pr = create_lifeline("encodingLayer", sdPubReflect, blkEncoding)
    llRTI_pr = create_lifeline("rtiAdapter", sdPubReflect, blkRTI)
    llObjMgr_pr = create_lifeline("objectManager", sdPubReflect, blkObjMgr)
    llFederation_pr = create_lifeline("HLA_Federation", sdPubReflect)
    llSubscriber = create_lifeline("Subscriber", sdPubReflect)

    # Messages - publish path
    create_message("1: Publish_Object_Attributes(className, attrList)",
                   sdPubReflect, llPublisher, llGRPC_pr, "synchCall")
    create_message("1.1: registerPublication(className, attrList)",
                   sdPubReflect, llGRPC_pr, llRouting_pr, "synchCall")
    create_message("1.1.1: addEntry(className, attrList, clientId)",
                   sdPubReflect, llRouting_pr, llSubTable_pr, "synchCall")
    create_message("1.2: publishObjectClassAttributes(className, attrList)",
                   sdPubReflect, llRouting_pr, llRTI_pr, "synchCall")
    create_message("1.2.1: registerObjectInstance(className)",
                   sdPubReflect, llRTI_pr, llObjMgr_pr, "synchCall")
    create_message("1.2.2: RTI_publishObjectClassAttributes",
                   sdPubReflect, llRTI_pr, llFederation_pr, "asynchCall")
    create_message("1.3: publishAck",
                   sdPubReflect, llGRPC_pr, llPublisher, "reply")

    # Messages - subscriber subscribes
    create_message("2: Subscribe_Object_Attributes(className, attrList)",
                   sdPubReflect, llSubscriber, llGRPC_pr, "synchCall")
    create_message("2.1: validateClient(clientId)",
                   sdPubReflect, llGRPC_pr, llRegistry_pr, "synchCall")
    create_message("2.2: registerSubscription(className, attrList, clientId)",
                   sdPubReflect, llGRPC_pr, llRouting_pr, "synchCall")
    create_message("2.2.1: addEntry(className, attrList, clientId)",
                   sdPubReflect, llRouting_pr, llSubTable_pr, "synchCall")
    create_message("2.3: subscribeObjectClassAttributes(className, attrList)",
                   sdPubReflect, llRouting_pr, llRTI_pr, "synchCall")
    create_message("2.3.1: RTI_subscribeObjectClassAttributes",
                   sdPubReflect, llRTI_pr, llFederation_pr, "asynchCall")
    create_message("2.4: subscribeAck",
                   sdPubReflect, llGRPC_pr, llSubscriber, "reply")

    # Messages - discover (RTI notifies subscriber of existing object)
    create_message("3: discoverObjectInstance callback",
                   sdPubReflect, llFederation_pr, llRTI_pr, "asynchSignal")
    create_message("3.1: recordDiscoveredObject(handle, className)",
                   sdPubReflect, llRTI_pr, llObjMgr_pr, "synchCall")
    create_message("3.2: resolveSubscribers(className)",
                   sdPubReflect, llRTI_pr, llRouting_pr, "synchCall")
    create_message("3.2.1: lookupSubscribers(className)",
                   sdPubReflect, llRouting_pr, llSubTable_pr, "synchCall")
    create_message("3.3: Discover_Object_Instance(handle, className)",
                   sdPubReflect, llGRPC_pr, llSubscriber, "asynchSignal")

    # Messages - update/reflect flow (MODIFIED: encoding steps added)
    create_message("4: Update_Attribute_Values(handle, attrValues)",
                   sdPubReflect, llPublisher, llGRPC_pr, "synchCall")
    create_message("4.1: routeUpdate(handle, attrValues)",
                   sdPubReflect, llGRPC_pr, llRouting_pr, "synchCall")
    # NEW: Encode values before RTI call
    create_message("4.1.1: encodeAttributeValues(attrValues, endianness)",
                   sdPubReflect, llRouting_pr, llEncoding_pr, "synchCall")
    create_message("4.2: updateAttributeValues(handle, encodedValues)",
                   sdPubReflect, llRouting_pr, llRTI_pr, "synchCall")
    create_message("4.2.1: RTI_updateAttributeValues",
                   sdPubReflect, llRTI_pr, llFederation_pr, "asynchCall")
    create_message("4.3: reflectAttributeValues callback",
                   sdPubReflect, llFederation_pr, llRTI_pr, "asynchSignal")
    # NEW: Decode values from RTI callback
    create_message("4.3.1: decodeAttributeValues(rawValues)",
                   sdPubReflect, llRTI_pr, llEncoding_pr, "synchCall")
    create_message("4.4: resolveSubscribers(className)",
                   sdPubReflect, llRTI_pr, llRouting_pr, "synchCall")
    create_message("4.4.1: filterAttributes(subscription, attrValues)",
                   sdPubReflect, llRouting_pr, llRouting_pr, "synchCall")
    create_message("4.5: Reflect_Attribute_Values(handle, filteredValues)",
                   sdPubReflect, llGRPC_pr, llSubscriber, "asynchSignal")
    create_message("4.6: updateAck",
                   sdPubReflect, llGRPC_pr, llPublisher, "reply")

    # -----------------------------------------
    # SD 2: Interaction Send and Receive
    # -----------------------------------------
    sdInteraction = create_interaction("SD_Interaction_SendReceive", pkgSequences)

    # Lifelines
    llSender = create_lifeline("Sender", sdInteraction)
    llGRPC_ir = create_lifeline("grpcServices", sdInteraction, blkGRPC)
    llRouting_ir = create_lifeline("routingEngine", sdInteraction, blkRouting)
    llSubTable_ir = create_lifeline("subscriptionTable", sdInteraction, blkSubTable)
    llEncoding_ir = create_lifeline("encodingLayer", sdInteraction, blkEncoding)
    llRTI_ir = create_lifeline("rtiAdapter", sdInteraction, blkRTI)
    llIntMgr_ir = create_lifeline("interactionManager", sdInteraction, blkIntMgr)
    llFederation_ir = create_lifeline("HLA_Federation", sdInteraction)
    llReceiver = create_lifeline("Receiver", sdInteraction)

    # Messages - sender publishes interaction class
    create_message("1: Publish_Interaction(interactionClass)",
                   sdInteraction, llSender, llGRPC_ir, "synchCall")
    create_message("1.1: registerInteractionPublication(interactionClass, clientId)",
                   sdInteraction, llGRPC_ir, llRouting_ir, "synchCall")
    create_message("1.1.1: addEntry(interactionClass, clientId)",
                   sdInteraction, llRouting_ir, llSubTable_ir, "synchCall")
    create_message("1.2: publishInteractionClass(interactionClass)",
                   sdInteraction, llRouting_ir, llRTI_ir, "synchCall")
    create_message("1.2.1: RTI_publishInteractionClass",
                   sdInteraction, llRTI_ir, llFederation_ir, "asynchCall")
    create_message("1.3: publishInteractionAck",
                   sdInteraction, llGRPC_ir, llSender, "reply")

    # Messages - receiver subscribes to interaction class
    create_message("2: Subscribe_Interaction(interactionClass)",
                   sdInteraction, llReceiver, llGRPC_ir, "synchCall")
    create_message("2.1: registerInteractionSubscription(interactionClass, clientId)",
                   sdInteraction, llGRPC_ir, llRouting_ir, "synchCall")
    create_message("2.1.1: addEntry(interactionClass, clientId)",
                   sdInteraction, llRouting_ir, llSubTable_ir, "synchCall")
    create_message("2.2: subscribeInteractionClass(interactionClass)",
                   sdInteraction, llRouting_ir, llRTI_ir, "synchCall")
    create_message("2.2.1: RTI_subscribeInteractionClass",
                   sdInteraction, llRTI_ir, llFederation_ir, "asynchCall")
    create_message("2.3: subscribeInteractionAck",
                   sdInteraction, llGRPC_ir, llReceiver, "reply")

    # Messages - send interaction (MODIFIED: encoding step added)
    create_message("3: Send_Interaction(interactionClass, paramValues)",
                   sdInteraction, llSender, llGRPC_ir, "synchCall")
    create_message("3.1: validateInteraction(interactionClass, clientId)",
                   sdInteraction, llGRPC_ir, llRouting_ir, "synchCall")
    # NEW: Encode parameters before RTI call
    create_message("3.1.1: encodeParameterValues(paramValues, endianness)",
                   sdInteraction, llRouting_ir, llEncoding_ir, "synchCall")
    create_message("3.2: sendInteraction(interactionClass, encodedParams)",
                   sdInteraction, llRouting_ir, llRTI_ir, "synchCall")
    create_message("3.2.1: marshalParameters(encodedParams)",
                   sdInteraction, llRTI_ir, llIntMgr_ir, "synchCall")
    create_message("3.2.2: RTI_sendInteraction",
                   sdInteraction, llRTI_ir, llFederation_ir, "asynchCall")
    create_message("3.3: sendAck",
                   sdInteraction, llGRPC_ir, llSender, "reply")

    # Messages - receive callback (MODIFIED: decoding step added)
    create_message("4: receiveInteraction callback",
                   sdInteraction, llFederation_ir, llRTI_ir, "asynchSignal")
    create_message("4.1: unmarshalParameters(rawParams)",
                   sdInteraction, llRTI_ir, llIntMgr_ir, "synchCall")
    # NEW: Decode parameters from RTI callback
    create_message("4.1.1: decodeParameterValues(rawParams)",
                   sdInteraction, llRTI_ir, llEncoding_ir, "synchCall")
    create_message("4.2: resolveInteractionSubscribers(interactionClass)",
                   sdInteraction, llRTI_ir, llRouting_ir, "synchCall")
    create_message("4.2.1: lookupSubscribers(interactionClass)",
                   sdInteraction, llRouting_ir, llSubTable_ir, "synchCall")
    create_message("4.3: Receive_Interaction(interactionClass, paramValues)",
                   sdInteraction, llGRPC_ir, llReceiver, "asynchSignal")

    # -----------------------------------------
    # SD 3: Client Session Connect / Disconnect
    # -----------------------------------------
    sdSession = create_interaction("SD_Client_Session_Lifecycle", pkgSequences)

    # Lifelines
    llClient_s = create_lifeline("UIClient", sdSession)
    llGRPC_s = create_lifeline("grpcServices", sdSession, blkGRPC)
    llSessMgr_s = create_lifeline("sessionManager", sdSession, blkSessMgr)
    llRegistry_s = create_lifeline("clientRegistry", sdSession, blkRegistry)
    llRouting_s = create_lifeline("routingEngine", sdSession, blkRouting)
    llRTI_s = create_lifeline("rtiAdapter", sdSession, blkRTI)

    # Messages - connect
    create_message("1: Connect_Client(clientName, endpoint)",
                   sdSession, llClient_s, llGRPC_s, "synchCall")
    create_message("1.1: validateAndCreateSession(clientName, endpoint)",
                   sdSession, llGRPC_s, llSessMgr_s, "synchCall")
    create_message("1.1.1: checkCapacity()",
                   sdSession, llSessMgr_s, llRegistry_s, "synchCall")
    create_message("1.1.2: createEntry(clientId, clientName, endpoint)",
                   sdSession, llSessMgr_s, llRegistry_s, "synchCall")
    create_message("1.2: sessionToken",
                   sdSession, llGRPC_s, llClient_s, "reply")

    # Messages - heartbeat (steady-state)
    create_message("2: Heartbeat(clientId, sessionToken)",
                   sdSession, llClient_s, llGRPC_s, "synchCall")
    create_message("2.1: refreshSession(clientId)",
                   sdSession, llGRPC_s, llSessMgr_s, "synchCall")
    create_message("2.1.1: updateLastSeen(clientId)",
                   sdSession, llSessMgr_s, llRegistry_s, "synchCall")
    create_message("2.2: heartbeatAck",
                   sdSession, llGRPC_s, llClient_s, "reply")

    # Messages - graceful disconnect
    create_message("3: Disconnect_Client(clientId, sessionToken)",
                   sdSession, llClient_s, llGRPC_s, "synchCall")
    create_message("3.1: terminateSession(clientId)",
                   sdSession, llGRPC_s, llSessMgr_s, "synchCall")
    create_message("3.1.1: getClientSubscriptions(clientId)",
                   sdSession, llSessMgr_s, llRouting_s, "synchCall")
    create_message("3.1.2: removeAllSubscriptions(clientId)",
                   sdSession, llSessMgr_s, llRouting_s, "synchCall")
    create_message("3.1.3: unsubscribeFromRTI(objectClasses)",
                   sdSession, llRouting_s, llRTI_s, "synchCall")
    create_message("3.1.4: unpublishFromRTI(objectClasses)",
                   sdSession, llRouting_s, llRTI_s, "synchCall")
    create_message("3.1.5: removeEntry(clientId)",
                   sdSession, llSessMgr_s, llRegistry_s, "synchCall")
    create_message("3.2: disconnectAck",
                   sdSession, llGRPC_s, llClient_s, "reply")

    # Messages - timeout disconnect (SessionManager-initiated)
    create_message("4: heartbeatTimeout(clientId)",
                   sdSession, llSessMgr_s, llSessMgr_s, "synchCall")
    create_message("4.1: getClientSubscriptions(clientId)",
                   sdSession, llSessMgr_s, llRouting_s, "synchCall")
    create_message("4.2: removeAllSubscriptions(clientId)",
                   sdSession, llSessMgr_s, llRouting_s, "synchCall")
    create_message("4.2.1: unsubscribeFromRTI(objectClasses)",
                   sdSession, llRouting_s, llRTI_s, "synchCall")
    create_message("4.2.2: unpublishFromRTI(objectClasses)",
                   sdSession, llRouting_s, llRTI_s, "synchCall")
    create_message("4.3: removeEntry(clientId)",
                   sdSession, llSessMgr_s, llRegistry_s, "synchCall")
    create_message("4.4: notifyClientDisconnected(clientId)",
                   sdSession, llSessMgr_s, llGRPC_s, "asynchSignal")

    # =========================================
    # Done
    # =========================================
    sm.closeSession()
    Application.getInstance().getGUILog().log(
        "SUCCESS: CUIS enhanced model created in 'CUIS_High_Level_Design'."
    )

except Exception, e:
    sm.cancelSession()
    Application.getInstance().getGUILog().log("ERROR: " + str(e))
    raise
