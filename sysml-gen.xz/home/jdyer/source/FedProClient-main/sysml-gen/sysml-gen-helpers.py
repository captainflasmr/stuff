# sysml-gen-helpers.py — MagicDraw Open API helper functions for sysml-gen
# Compatible with CATIA | MagicDraw 2024x Refresh2
#
from com.nomagic.magicdraw.core import Application
from com.nomagic.magicdraw.openapi.uml import SessionManager, ModelElementsManager
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper
from com.nomagic.uml2.ext.jmi.helpers import ModelHelper
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import AggregationKindEnum

# -----------------------------------------
# Setup
# -----------------------------------------
app = Application.getInstance()
project = app.getProject()
ef = project.getElementsFactory()
mem = ModelElementsManager.getInstance()
sm = SessionManager.getInstance()

if project is None:
    Application.getInstance().getGUILog().log("ERROR: No project open.")
    raise SystemExit

root = project.getPrimaryModel()

# -----------------------------------------
# Helper functions
# -----------------------------------------

def create_package(name, owner):
    """Create a SysML package."""
    pkg = ef.createPackageInstance()
    pkg.setName(name)
    pkg.setOwner(owner)
    return pkg

def create_block(name, owner_pkg):
    """Create a SysML Block (Class with <<Block>> stereotype)."""
    blk = ef.createClassInstance()
    blk.setName(name)
    blk.setOwner(owner_pkg)
    StereotypesHelper.addStereotypeByString(blk, "Block")
    return blk

def create_interface(name, owner_pkg):
    """Create a UML Interface."""
    iface = ef.createInterfaceInstance()
    iface.setName(name)
    iface.setOwner(owner_pkg)
    return iface

def create_datatype(name, owner_pkg):
    """Create a UML DataType."""
    dt = ef.createDataTypeInstance()
    dt.setName(name)
    dt.setOwner(owner_pkg)
    return dt

def create_enumeration(name, owner_pkg, literals):
    """Create a UML Enumeration with literal values."""
    enum = ef.createEnumerationInstance()
    enum.setName(name)
    enum.setOwner(owner_pkg)
    for lit_name in literals:
        lit = ef.createEnumerationLiteralInstance()
        lit.setName(lit_name)
        lit.setOwner(enum)
    return enum

def add_part_property(owner_block, prop_name, type_block):
    """Add a <<PartProperty>> (composite aggregation) to a block."""
    prop = ef.createPropertyInstance()
    prop.setName(prop_name)
    prop.setOwner(owner_block)
    prop.setType(type_block)
    prop.setAggregation(AggregationKindEnum.COMPOSITE)
    StereotypesHelper.addStereotypeByString(prop, "PartProperty")
    return prop

def add_reference_property(owner_block, prop_name, type_block):
    """Add a reference property (shared aggregation) to a block.
    This models a 'uses' / 'depends on' relationship without ownership."""
    prop = ef.createPropertyInstance()
    prop.setName(prop_name)
    prop.setOwner(owner_block)
    prop.setType(type_block)
    prop.setAggregation(AggregationKindEnum.SHARED)
    return prop

def add_value_property(owner_block, prop_name, type_block=None):
    """Add a <<ValueProperty>> to a block or datatype."""
    prop = ef.createPropertyInstance()
    prop.setName(prop_name)
    prop.setOwner(owner_block)
    if type_block is not None:
        prop.setType(type_block)
    prop.setAggregation(AggregationKindEnum.COMPOSITE)
    StereotypesHelper.addStereotypeByString(prop, "ValueProperty")
    return prop

def add_operation(owner, op_name, params=None):
    """Add an operation to an interface or block.
    params: optional list of (param_name, direction) tuples.
    direction: 'in', 'out', 'inout', 'return'."""
    op = ef.createOperationInstance()
    op.setName(op_name)
    op.setOwner(owner)
    if params:
        for pname, pdir in params:
            p = ef.createParameterInstance()
            p.setName(pname)
            p.setOwner(op)
            # Direction enum: IN, OUT, INOUT, RETURN
            if pdir == "out":
                p.setDirection(com.nomagic.uml2.ext.magicdraw.classes.mdkernel.ParameterDirectionKindEnum.OUT)
            elif pdir == "inout":
                p.setDirection(com.nomagic.uml2.ext.magicdraw.classes.mdkernel.ParameterDirectionKindEnum.INOUT)
            elif pdir == "return":
                p.setDirection(com.nomagic.uml2.ext.magicdraw.classes.mdkernel.ParameterDirectionKindEnum.RETURN)
            # default is IN, no need to set explicitly
    return op

def add_flow_port(owner_block, port_name, type_element, is_conjugated=False):
    """Add a <<FlowPort>> to a block for interface exposure."""
    port = ef.createPortInstance()
    port.setName(port_name)
    port.setOwner(owner_block)
    if type_element is not None:
        port.setType(type_element)
    StereotypesHelper.addStereotypeByString(port, "FlowPort")
    return port

def add_realization(block, interface, owner_pkg):
    """Create an InterfaceRealization: block realizes interface.
    In MagicDraw, the realization is owned by the implementing classifier."""
    real = ef.createInterfaceRealizationInstance()
    real.setImplementingClassifier(block)
    real.setContract(interface)
    real.setOwner(block)
    return real

def add_dependency(client_el, supplier_el, name, owner_pkg):
    """Create a named Dependency from client to supplier.
    client depends on (uses) supplier."""
    dep = ef.createDependencyInstance()
    dep.setName(name)
    dep.getClient().add(client_el)
    dep.getSupplier().add(supplier_el)
    dep.setOwner(owner_pkg)
    return dep

def add_usage(client_el, supplier_el, name, owner_pkg):
    """Create a <<use>> dependency (stronger form of dependency).
    Indicates that client requires supplier for its implementation."""
    usage = ef.createUsageInstance()
    usage.setName(name)
    usage.getClient().add(client_el)
    usage.getSupplier().add(supplier_el)
    usage.setOwner(owner_pkg)
    return usage

def create_constraint_block(name, owner_pkg, parameters, constraint_expr):
    """Create a SysML ConstraintBlock with constraint parameters and
    a specification expression (the parametric equation).
    parameters: list of (param_name,) or (param_name, type_block) tuples.
    constraint_expr: string expression for the OpaqueExpression body."""
    cb = ef.createClassInstance()
    cb.setName(name)
    cb.setOwner(owner_pkg)
    StereotypesHelper.addStereotypeByString(cb, "Block")
    StereotypesHelper.addStereotypeByString(cb, "ConstraintBlock")

    # Add constraint parameters as properties with <<ConstraintParameter>>
    for param in parameters:
        p = ef.createPropertyInstance()
        if len(param) >= 2 and param[1] is not None:
            p.setName(param[0])
            p.setType(param[1])
        else:
            p.setName(param[0])
        p.setOwner(cb)
        StereotypesHelper.addStereotypeByString(p, "ConstraintParameter")

    # Add the constraint specification as an OpaqueExpression on a Constraint
    constr = ef.createConstraintInstance()
    constr.setName(name + "_spec")
    constr.setOwner(cb)
    constr.getConstrainedElement().add(cb)

    oe = ef.createOpaqueExpressionInstance()
    oe.setOwner(constr)
    oe.getBody().add(constraint_expr)
    oe.getLanguage().add("OCL")  # or "English" / "Natural"
    constr.setSpecification(oe)

    return cb

def add_constraint_property(owner_block, prop_name, constraint_block):
    """Add a constraint property to a block - used in parametric diagrams
    to bind constraint blocks to the owning block's value properties."""
    prop = ef.createPropertyInstance()
    prop.setName(prop_name)
    prop.setOwner(owner_block)
    prop.setType(constraint_block)
    prop.setAggregation(AggregationKindEnum.COMPOSITE)
    StereotypesHelper.addStereotypeByString(prop, "ConstraintProperty")
    return prop

# -----------------------------------------
# Activity diagram helper functions
# -----------------------------------------

def create_activity(name, owner_pkg):
    """Create a UML Activity (the container for an activity diagram)."""
    act = ef.createActivityInstance()
    act.setName(name)
    act.setOwner(owner_pkg)
    return act

def create_initial_node(activity):
    """Create an InitialNode inside an activity."""
    node = ef.createInitialNodeInstance()
    node.setName("initial")
    node.setOwner(activity)
    return node

def create_final_node(activity, name="final"):
    """Create an ActivityFinalNode inside an activity."""
    node = ef.createActivityFinalNodeInstance()
    node.setName(name)
    node.setOwner(activity)
    return node

def create_action(name, activity):
    """Create an OpaqueAction (a simple named action step) in an activity."""
    action = ef.createOpaqueActionInstance()
    action.setName(name)
    action.setOwner(activity)
    return action

def create_call_behavior_action(name, activity, behavior=None):
    """Create a CallBehaviorAction referencing another activity/behavior."""
    cba = ef.createCallBehaviorActionInstance()
    cba.setName(name)
    cba.setOwner(activity)
    if behavior is not None:
        cba.setBehavior(behavior)
    return cba

def create_decision_node(activity, name="decision"):
    """Create a DecisionNode (diamond) in an activity."""
    node = ef.createDecisionNodeInstance()
    node.setName(name)
    node.setOwner(activity)
    return node

def create_merge_node(activity, name="merge"):
    """Create a MergeNode in an activity."""
    node = ef.createMergeNodeInstance()
    node.setName(name)
    node.setOwner(activity)
    return node

def create_fork_node(activity, name="fork"):
    """Create a ForkNode (horizontal bar, parallel split) in an activity."""
    node = ef.createForkNodeInstance()
    node.setName(name)
    node.setOwner(activity)
    return node

def create_join_node(activity, name="join"):
    """Create a JoinNode (horizontal bar, parallel sync) in an activity."""
    node = ef.createJoinNodeInstance()
    node.setName(name)
    node.setOwner(activity)
    return node

def create_send_signal_action(name, activity):
    """Create a SendSignalAction in an activity."""
    ssa = ef.createSendSignalActionInstance()
    ssa.setName(name)
    ssa.setOwner(activity)
    return ssa

def create_accept_event_action(name, activity):
    """Create an AcceptEventAction (wait for signal/event) in an activity."""
    aea = ef.createAcceptEventActionInstance()
    aea.setName(name)
    aea.setOwner(activity)
    return aea

def create_control_flow(source, target, activity, guard=None):
    """Create a ControlFlow (arrow) between two activity nodes.
    Optionally add a guard condition string."""
    flow = ef.createControlFlowInstance()
    flow.setSource(source)
    flow.setTarget(target)
    flow.setOwner(activity)
    if guard is not None:
        oe = ef.createOpaqueExpressionInstance()
        oe.getBody().add(guard)
        oe.getLanguage().add("English")
        oe.setOwner(flow)
        flow.setGuard(oe)
    return flow

def create_activity_partition(name, activity, represents=None):
    """Create an ActivityPartition (swimlane) in an activity.
    'represents' can be a block/classifier that the partition maps to."""
    part = ef.createActivityPartitionInstance()
    part.setName(name)
    part.setOwner(activity)
    if represents is not None:
        part.setRepresents(represents)
    return part

def assign_partition(node, partition):
    """Assign an activity node to an ActivityPartition (swimlane)."""
    node.getInPartition().add(partition)

# -----------------------------------------
# State machine helper functions
# -----------------------------------------

def create_state_machine(name, owner):
    """Create a UML StateMachine owned by a block or package."""
    stm = ef.createStateMachineInstance()
    stm.setName(name)
    stm.setOwner(owner)
    return stm

def create_region(name, owner_stm):
    """Create a Region inside a StateMachine or composite State.
    Every StateMachine needs at least one Region to hold states."""
    reg = ef.createRegionInstance()
    reg.setName(name)
    reg.setOwner(owner_stm)
    return reg

def create_state(name, region):
    """Create a simple State inside a Region."""
    st = ef.createStateInstance()
    st.setName(name)
    st.setOwner(region)
    return st

def create_composite_state(name, region):
    """Create a composite State (one that contains its own sub-region)
    inside a Region. Returns (state, sub_region) tuple."""
    st = ef.createStateInstance()
    st.setName(name)
    st.setOwner(region)
    sub_reg = ef.createRegionInstance()
    sub_reg.setName(name + "_region")
    sub_reg.setOwner(st)
    return st, sub_reg

def create_pseudostate(region, kind="initial"):
    """Create a Pseudostate in a Region.
    kind: 'initial', 'choice', 'junction', 'fork', 'join',
          'shallowHistory', 'deepHistory'."""
    try:
        from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import PseudostateKindEnum
    except ImportError:
        from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import PseudostateKindEnum
    ps = ef.createPseudostateInstance()
    ps.setOwner(region)
    # MagicDraw 2024x uses concatenated names (no underscores):
    #   INITIAL, CHOICE, JUNCTION, FORK, JOIN, SHALLOWHISTORY, DEEPHISTORY
    kind_name_map = {
        "initial":        "INITIAL",
        "choice":         "CHOICE",
        "junction":       "JUNCTION",
        "fork":           "FORK",
        "join":           "JOIN",
        "shallowHistory": "SHALLOWHISTORY",
        "deepHistory":    "DEEPHISTORY",
    }
    enum_name = kind_name_map.get(kind, "INITIAL")
    ps.setKind(getattr(PseudostateKindEnum, enum_name))
    return ps

def create_final_state(region):
    """Create a FinalState in a Region."""
    fs = ef.createFinalStateInstance()
    fs.setName("final")
    fs.setOwner(region)
    return fs

def create_transition(source, target, region, trigger_name=None,
                      guard_expr=None, effect_name=None):
    """Create a Transition between two states/pseudostates.
    trigger_name: optional string for the trigger event name.
    guard_expr:   optional string for the guard condition.
    effect_name:  optional string for the effect/action."""
    tr = ef.createTransitionInstance()
    tr.setSource(source)
    tr.setTarget(target)
    tr.setOwner(region)

    if trigger_name is not None:
        # Create a trigger with a SignalEvent or ChangeEvent
        # For simplicity, use a TimeEvent with an opaque expression
        # as MagicDraw Jython can be fiddly with signal/event creation.
        # Instead, encode trigger as a named opaque behavior effect label.
        # The cleanest portable approach: set trigger name via an
        # OpaqueExpression on a Constraint, or just name the transition.
        tr.setName(trigger_name)

    if guard_expr is not None:
        constraint = ef.createConstraintInstance()
        constraint.setOwner(tr)
        oe = ef.createOpaqueExpressionInstance()
        oe.getBody().add(guard_expr)
        oe.getLanguage().add("English")
        oe.setOwner(constraint)
        constraint.setSpecification(oe)
        tr.setGuard(constraint)

    if effect_name is not None:
        effect = ef.createOpaqueBehaviorInstance()
        effect.setName(effect_name)
        effect.getBody().add(effect_name)
        effect.setOwner(tr)
        tr.setEffect(effect)

    return tr

def add_entry_action(state, action_text):
    """Add an entry behavior to a State."""
    entry = ef.createOpaqueBehaviorInstance()
    entry.setName("entry/" + action_text)
    entry.getBody().add(action_text)
    entry.setOwner(state)
    state.setEntry(entry)

def add_exit_action(state, action_text):
    """Add an exit behavior to a State."""
    exit_b = ef.createOpaqueBehaviorInstance()
    exit_b.setName("exit/" + action_text)
    exit_b.getBody().add(action_text)
    exit_b.setOwner(state)
    state.setExit(exit_b)

def add_do_activity(state, activity_text):
    """Add a do-activity (ongoing behavior) to a State."""
    do_act = ef.createOpaqueBehaviorInstance()
    do_act.setName("do/" + activity_text)
    do_act.getBody().add(activity_text)
    do_act.setOwner(state)
    state.setDoActivity(do_act)

# -----------------------------------------
# Sequence diagram helper functions
# -----------------------------------------

def create_interaction(name, owner_pkg):
    """Create a UML Interaction (the container for a sequence diagram)."""
    interaction = ef.createInteractionInstance()
    interaction.setName(name)
    interaction.setOwner(owner_pkg)
    return interaction

def create_lifeline(name, interaction, represents_type=None):
    """Create a Lifeline inside an Interaction.
    represents_type: optional block/class that the lifeline represents.
    In MagicDraw we set the type via a Property that the lifeline represents."""
    ll = ef.createLifelineInstance()
    ll.setName(name)
    ll.setOwner(interaction)
    try:
        ll.setInteraction(interaction)
    except AttributeError:
        pass  # ownership is sufficient in some MagicDraw versions
    if represents_type is not None:
        # Create a Property typed to the block for the lifeline to represent
        prop = ef.createPropertyInstance()
        prop.setName(name)
        prop.setType(represents_type)
        prop.setOwner(interaction)
        ll.setRepresents(prop)
    return ll

def create_message(name, interaction, send_ll, recv_ll, sort="synchCall"):
    """Create a Message between two lifelines.
    sort: 'synchCall', 'asynchCall', 'asynchSignal', 'reply', 'createMessage'.
    Creates the required MessageOccurrenceSpecification endpoints."""
    try:
        from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import MessageSortEnum
    except ImportError:
        from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import MessageSortEnum

    sort_map = {
        "synchCall":      "SYNCHCALL",
        "asynchCall":     "ASYNCHCALL",
        "asynchSignal":   "ASYNCHSIGNAL",
        "reply":          "REPLY",
        "createMessage":  "CREATEMESSAGE",
    }

    # Create send occurrence
    send_mos = ef.createMessageOccurrenceSpecificationInstance()
    send_mos.setName(name + "_send")
    send_mos.setOwner(interaction)
    try:
        send_mos.setCovered(send_ll)
    except AttributeError:
        send_mos.getCovered().add(send_ll)

    # Create receive occurrence
    recv_mos = ef.createMessageOccurrenceSpecificationInstance()
    recv_mos.setName(name + "_recv")
    recv_mos.setOwner(interaction)
    try:
        recv_mos.setCovered(recv_ll)
    except AttributeError:
        recv_mos.getCovered().add(recv_ll)

    # Create the message
    msg = ef.createMessageInstance()
    msg.setName(name)
    msg.setOwner(interaction)
    msg.setSendEvent(send_mos)
    msg.setReceiveEvent(recv_mos)

    enum_name = sort_map.get(sort, "SYNCHCALL")
    msg.setMessageSort(getattr(MessageSortEnum, enum_name))

    # Link occurrences back to the message
    send_mos.setMessage(msg)
    recv_mos.setMessage(msg)

    return msg

def create_combined_fragment(name, interaction, operator, covered_lifelines):
    """Create a CombinedFragment (alt, opt, loop, par, etc.) in an interaction.
    operator: 'alt', 'opt', 'loop', 'par', 'break', 'critical', 'neg'.
    covered_lifelines: list of lifelines covered by this fragment.
    Returns (fragment, first_operand) - add more operands for 'alt'."""
    try:
        from com.nomagic.uml2.ext.magicdraw.interactions.mdfragments import InteractionOperatorKindEnum
    except ImportError:
        from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import InteractionOperatorKindEnum

    op_map = {
        "alt":      "ALT",
        "opt":      "OPT",
        "loop":     "LOOP",
        "par":      "PAR",
        "break":    "BREAK_",  # 'break' is reserved in some versions
        "critical": "CRITICAL",
        "neg":      "NEG",
    }

    cf = ef.createCombinedFragmentInstance()
    cf.setName(name)
    cf.setOwner(interaction)

    enum_name = op_map.get(operator, "ALT")
    # Handle the BREAK special case - try both BREAK_ and BREAK
    try:
        cf.setInteractionOperator(getattr(InteractionOperatorKindEnum, enum_name))
    except AttributeError:
        cf.setInteractionOperator(getattr(InteractionOperatorKindEnum, enum_name.rstrip("_")))

    for ll in covered_lifelines:
        cf.getCovered().add(ll)

    # Create the first operand (every combined fragment needs at least one)
    operand = ef.createInteractionOperandInstance()
    operand.setName(name + "_operand")
    operand.setOwner(cf)

    return cf, operand

def add_operand(combined_fragment, guard_text=None):
    """Add an InteractionOperand to a CombinedFragment (e.g. 'else' branch of alt).
    Returns the new operand."""
    operand = ef.createInteractionOperandInstance()
    operand.setOwner(combined_fragment)
    if guard_text is not None:
        constraint = ef.createConstraintInstance()
        constraint.setOwner(operand)
        oe = ef.createOpaqueExpressionInstance()
        oe.getBody().add(guard_text)
        oe.getLanguage().add("English")
        oe.setOwner(constraint)
        constraint.setSpecification(oe)
        operand.setGuard(constraint)
    return operand

# -----------------------------------------
# Documentation helper
# -----------------------------------------

def set_documentation(element, text):
    """Set the documentation text on any model element.

    Adds a Comment to the element's ownedComment collection, which appears
    in the Documentation/Comments tab of the element's Specification dialog.
    This is the approach recommended by the MagicGrid tutorial: right-click
    the element, select Specification, then edit Documentation/Comments."""
    comment = ef.createCommentInstance()
    comment.setBody(text)
    element.getOwnedComment().add(comment)
