# Traffic Light Controller — SysML Model

Example model for `sysml-gen.el`.  Demonstrates all supported section types.

## Packages

| Name                   | Parent                 |
|------------------------|------------------------|
| TrafficLightController | _root_                 |
| Blocks                 | TrafficLightController |
| Interfaces             | TrafficLightController |
| DataTypes              | TrafficLightController |
| Enumerations           | TrafficLightController |
| Relationships          | TrafficLightController |
| Constraints            | TrafficLightController |
| Activities             | TrafficLightController |
| StateMachines          | TrafficLightController |
| SequenceDiagrams       | TrafficLightController |

## Enumerations

### LightColour

- **Package:** Enumerations
- **Literals:** RED, AMBER, GREEN

### IntersectionMode

- **Package:** Enumerations
- **Literals:** NORMAL, FLASHING, OFF

### PedestrianRequest

- **Package:** Enumerations
- **Literals:** NONE, PENDING, ACTIVE

### Direction

- **Package:** Enumerations
- **Literals:** NORTH_SOUTH, EAST_WEST

## DataTypes

### TimingConfig

- **Package:** DataTypes

| Property          | Type |
|-------------------|------|
| green_duration_ms |      |
| amber_duration_ms |      |
| red_clearance_ms  |      |

### SensorReading

- **Package:** DataTypes

| Property      | Type |
|---------------|------|
| sensor_id     |      |
| vehicle_count |      |
| timestamp     |      |

### PhaseSchedule

- **Package:** DataTypes

| Property    | Type        |
|-------------|-------------|
| direction   | Direction   |
| colour      | LightColour |
| duration_ms |             |

## Blocks

### Controller

- **Package:** Blocks

#### Value Properties

| Property        | Type |
|-----------------|------|
| intersection_id |      |

#### Part Properties

| Property       | Type           |
|----------------|----------------|
| signalManager  | SignalManager  |
| sensorHub      | SensorHub      |
| phaseEngine    | PhaseEngine    |
| pedestrianUnit | PedestrianUnit |

#### Reference Properties

_None_

### SignalManager

- **Package:** Blocks

#### Value Properties

| Property       | Type        |
|----------------|-------------|
| current_colour | LightColour |

#### Part Properties

_None_

#### Reference Properties

_None_

### SensorHub

- **Package:** Blocks

#### Value Properties

| Property         | Type |
|------------------|------|
| poll_interval_ms |      |

#### Part Properties

_None_

#### Reference Properties

_None_

### PhaseEngine

- **Package:** Blocks

#### Value Properties

_None_

#### Part Properties

_None_

#### Reference Properties

| Property      | Type          |
|---------------|---------------|
| signalManager | SignalManager |
| sensorHub     | SensorHub     |

### PedestrianUnit

- **Package:** Blocks

#### Value Properties

| Property      | Type              |
|---------------|-------------------|
| request_state | PedestrianRequest |

#### Part Properties

_None_

#### Reference Properties

| Property      | Type          |
|---------------|---------------|
| signalManager | SignalManager |

### ExternalTimer

- **Package:** Blocks

#### Value Properties

| Property         | Type |
|------------------|------|
| tick_interval_ms |      |

#### Part Properties

_None_

#### Reference Properties

_None_

## Interfaces

### ISignalControl

- **Package:** Interfaces
- **Operations:**
  - Set_Colour
  - Get_Colour
  - Flash_Amber

### ISensorInput

- **Package:** Interfaces
- **Operations:**
  - Read_Sensor
  - Reset_Count

### IPedestrianRequest

- **Package:** Interfaces
- **Operations:**
  - Request_Crossing
  - Cancel_Request
  - Get_Request_State

## Ports

| Owner          | Port Name             | Interface Type     |
|----------------|-----------------------|--------------------|
| Controller     | signalPort            | ISignalControl     |
| SignalManager  | signalMgrPort         | ISignalControl     |
| SensorHub      | sensorPort            | ISensorInput       |
| PedestrianUnit | pedestrianPort        | IPedestrianRequest |
| Controller     | pedestrianRequestPort | IPedestrianRequest |

## Relationships

### Realizations

| Block          | Interface          |
|----------------|--------------------|
| SignalManager  | ISignalControl     |
| SensorHub      | ISensorInput       |
| PedestrianUnit | IPedestrianRequest |

### Dependencies

| Client         | Supplier      | Name                  |
|----------------|---------------|-----------------------|
| PhaseEngine    | SignalManager | controls_signals_via  |
| PhaseEngine    | SensorHub     | reads_sensors_via     |
| PedestrianUnit | SignalManager | interrupts_signal_via |

### Usages

| Client      | Supplier      | Name                   |
|-------------|---------------|------------------------|
| PhaseEngine | TimingConfig  | configures_phases_with |
| PhaseEngine | PhaseSchedule | schedules_phases_with  |
| SensorHub   | SensorReading | produces_readings_as   |

## Constraints

### Constraint Blocks

#### CycleTimeConstraint

- **Package:** Constraints
- **Parameters:** green_duration_ms, amber_duration_ms, red_clearance_ms, max_cycle_ms
- **Expression:** `green_duration_ms + amber_duration_ms + red_clearance_ms <= max_cycle_ms`

#### PedestrianSafetyConstraint

- **Package:** Constraints
- **Parameters:** min_crossing_time_ms, green_duration_ms
- **Expression:** `green_duration_ms >= min_crossing_time_ms`

### Constraint Properties

| Owner Block    | Property Name  | Constraint Block           |
|----------------|----------------|----------------------------|
| PhaseEngine    | cycleTime      | CycleTimeConstraint        |
| PedestrianUnit | crossingSafety | PedestrianSafetyConstraint |

## Activities

### Activity: Normal_Cycle_Flow

- **Package:** Activities

#### Partitions

| Name           | Represents     |
|----------------|----------------|
| ExternalTimer  | ExternalTimer  |
| PhaseEngine    | PhaseEngine    |
| SignalManager  | SignalManager  |
| SensorHub      | SensorHub      |
| PedestrianUnit | PedestrianUnit |

#### Nodes

| ID              | Type         | Name                               | Partition      |
|-----------------|--------------|------------------------------------|----------------|
| nc_init         | initial      |                                    | ExternalTimer  |
| nc_tick         | accept_event | Timer tick received                | ExternalTimer  |
| nc_read_sensor  | action       | Read vehicle sensor counts         | SensorHub      |
| nc_evaluate     | action       | Evaluate phase schedule            | PhaseEngine    |
| nc_ped_check    | decision     | pedestrian_pending?                | PhaseEngine    |
| nc_extend_green | action       | Extend green phase for pedestrians | PhaseEngine    |
| nc_set_colour   | action       | Set signal colour                  | SignalManager  |
| nc_merge        | merge        | cycle_merge                        | PhaseEngine    |
| nc_ped_ack      | action       | Acknowledge pedestrian crossing    | PedestrianUnit |
| nc_final        | final        |                                    | PhaseEngine    |

#### Flows

| Source          | Target          | Guard              |
|-----------------|-----------------|--------------------|
| nc_init         | nc_tick         |                    |
| nc_tick         | nc_read_sensor  |                    |
| nc_read_sensor  | nc_evaluate     |                    |
| nc_evaluate     | nc_ped_check    |                    |
| nc_ped_check    | nc_extend_green | pedestrian pending |
| nc_ped_check    | nc_set_colour   | no pedestrian      |
| nc_extend_green | nc_ped_ack      |                    |
| nc_ped_ack      | nc_set_colour   |                    |
| nc_set_colour   | nc_merge        |                    |
| nc_merge        | nc_final        |                    |

## State Machines

### State Machine: SignalCycleLifecycle

- **Package:** StateMachines

#### Regions

| ID        | Name          | Owner                |
|-----------|---------------|----------------------|
| regSignal | main          | SignalCycleLifecycle |
| regNormal | NORMAL_region | NORMAL               |

#### States

| ID          | Name     | Type      | Region    | Entry Action       | Exit Action | Do Activity                    |
|-------------|----------|-----------|-----------|--------------------|-------------|--------------------------------|
| sigOff      | OFF      | simple    | regSignal | All signals dark   |             |                                |
| sigNormal   | NORMAL   | composite | regSignal | Begin normal cycle |             |                                |
| sigGreen    | Green    | simple    | regNormal | Illuminate green   |             | Count down green timer         |
| sigAmber    | Amber    | simple    | regNormal | Illuminate amber   |             | Count down amber timer         |
| sigRed      | Red      | simple    | regNormal | Illuminate red     |             | Count down red clearance timer |
| sigFlashing | FLASHING | simple    | regSignal | Flash amber at 1Hz |             |                                |

#### Pseudostates

| ID          | Kind    | Region    |
|-------------|---------|-----------|
| sigInit     | initial | regSignal |
| sigNormInit | initial | regNormal |

#### Final States

| ID       | Region    |
|----------|-----------|
| sigFinal | regSignal |

#### Transitions

| Source      | Target      | Region    | Trigger            | Guard         | Effect                |
|-------------|-------------|-----------|--------------------|---------------|-----------------------|
| sigInit     | sigOff      | regSignal |                    |               |                       |
| sigOff      | sigNormal   | regSignal | power_on           |               |                       |
| sigNormInit | sigRed      | regNormal |                    |               |                       |
| sigRed      | sigGreen    | regNormal | red_timeout        |               | Reset timer           |
| sigGreen    | sigAmber    | regNormal | green_timeout      |               | Reset timer           |
| sigAmber    | sigRed      | regNormal | amber_timeout      |               | Reset timer           |
| sigGreen    | sigGreen    | regNormal | pedestrian_request | crossing safe | Extend green duration |
| sigNormal   | sigFlashing | regSignal | fault_detected     |               |                       |
| sigFlashing | sigNormal   | regSignal | fault_cleared      |               |                       |
| sigNormal   | sigOff      | regSignal | power_off          |               |                       |
| sigFlashing | sigOff      | regSignal | power_off          |               |                       |
| sigOff      | sigFinal    | regSignal | decommission       |               |                       |

## Sequence Diagrams

### Interaction: SD_Pedestrian_Crossing_Request

- **Package:** SequenceDiagrams

#### Lifelines

| Name           | Represents     |
|----------------|----------------|
| Pedestrian     |                |
| pedestrianUnit | PedestrianUnit |
| phaseEngine    | PhaseEngine    |
| signalManager  | SignalManager  |
| sensorHub      | SensorHub      |

#### Messages

| Name                                    | Sender         | Receiver       | Sort         |
|-----------------------------------------|----------------|----------------|--------------|
| 1: Request_Crossing()                   | Pedestrian     | pedestrianUnit | synchCall    |
| 1.1: Read_Sensor(ped_sensor_id)         | pedestrianUnit | sensorHub      | synchCall    |
| 1.2: sensorAck                          | sensorHub      | pedestrianUnit | reply        |
| 2: notify_pedestrian_pending(direction) | pedestrianUnit | phaseEngine    | asynchSignal |
| 2.1: evaluate_extension(direction)      | phaseEngine    | phaseEngine    | synchCall    |
| 2.2: Set_Colour(direction, GREEN)       | phaseEngine    | signalManager  | synchCall    |
| 2.3: colourAck                          | signalManager  | phaseEngine    | reply        |
| 3: crossing_granted                     | phaseEngine    | pedestrianUnit | asynchSignal |
| 3.1: Get_Request_State()                | pedestrianUnit | pedestrianUnit | synchCall    |
| 4: crossing_active                      | pedestrianUnit | Pedestrian     | asynchSignal |
