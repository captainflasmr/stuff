#!/usr/bin/env bash
# setup.sh — install the bundled Emacs toolkit on an offline machine.
# Run from inside the extracted toolkit directory.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EMACS_D="${HOME}/.emacs.d"
BACKUP_SUFFIX=".pre-toolkit-$(date +%Y%m%dT%H%M%S)"

echo ">> Target: ${EMACS_D}"
mkdir -p "$EMACS_D"

# Back up existing init files so we don't silently clobber an existing setup.
for f in init.el early-init.el; do
  if [[ -e "${EMACS_D}/${f}" && ! -L "${EMACS_D}/${f}" ]]; then
    echo "   backing up existing ${f} -> ${f}${BACKUP_SUFFIX}"
    mv "${EMACS_D}/${f}" "${EMACS_D}/${f}${BACKUP_SUFFIX}"
  fi
done

# Move any existing ~/.emacs.d/elpa/ aside so `my/ensure-package' sees every
# package as not-installed on next launch and reinstalls from the freshly
# extracted mirror. Without this, stale .elc/.eln from the old mirror stay put.
if [[ -d "${EMACS_D}/elpa" ]]; then
  echo "   backing up existing elpa/ -> elpa${BACKUP_SUFFIX}/"
  mv "${EMACS_D}/elpa" "${EMACS_D}/elpa${BACKUP_SUFFIX}"
fi

# Move any pre-existing mirror extractions aside too — same reason, and avoids
# the init.el's `string>' sort silently picking up stale mirrors after upgrades.
for old in "${HOME}"/elpa-mirror-emacs-*; do
  [[ -d "$old" ]] || continue
  echo "   backing up existing $(basename "$old")/ -> $(basename "$old")${BACKUP_SUFFIX}/"
  mv "$old" "${old}${BACKUP_SUFFIX}"
done

# Extract ELPA mirror into $HOME (init.el auto-detects ~/elpa-mirror-emacs-*).
for m in "$HERE"/elpa-mirror-*.tar.gz; do
  [[ -f "$m" ]] || continue
  echo ">> Extracting $(basename "$m") into $HOME"
  tar -xzf "$m" -C "$HOME"
done

# Install the literate config directories.
for d in Emacs-vanilla Emacs-DIYer; do
  if [[ -d "${HERE}/${d}" ]]; then
    if [[ -d "${EMACS_D}/${d}" ]]; then
      echo "   backing up existing ${d}/ -> ${d}${BACKUP_SUFFIX}/"
      mv "${EMACS_D}/${d}" "${EMACS_D}/${d}${BACKUP_SUFFIX}"
    fi
    echo ">> Installing ${d} to ${EMACS_D}/${d}"
    mkdir -p "${EMACS_D}/${d}"
    cp -a "${HERE}/${d}/." "${EMACS_D}/${d}/"
  fi
done

# Install local-packages if bundled. Source only, no byte-compilation — the
# target Emacs will compile on first load if it wants to.
if [[ -d "${HERE}/local-packages" ]]; then
  if [[ -d "${EMACS_D}/local-packages" ]]; then
    echo "   backing up existing local-packages/ -> local-packages${BACKUP_SUFFIX}/"
    mv "${EMACS_D}/local-packages" "${EMACS_D}/local-packages${BACKUP_SUFFIX}"
  fi
  echo ">> Installing local-packages to ${EMACS_D}/local-packages"
  mkdir -p "${EMACS_D}/local-packages"
  cp -a "${HERE}/local-packages/." "${EMACS_D}/local-packages/"
fi

# Install init.el and (optional) early-init.el.
cp "${HERE}/init.el" "${EMACS_D}/init.el"
[[ -f "${HERE}/early-init.el" ]] && cp "${HERE}/early-init.el" "${EMACS_D}/early-init.el"

# Install starter snippet if bundled. Does NOT auto-load — opt in from init.el
# with: (load (expand-file-name "init-starter" user-emacs-directory) t t)
if [[ -f "${HERE}/init-starter.el" ]]; then
  if [[ -e "${EMACS_D}/init-starter.el" && ! -L "${EMACS_D}/init-starter.el" ]]; then
    echo "   backing up existing init-starter.el -> init-starter.el${BACKUP_SUFFIX}"
    mv "${EMACS_D}/init-starter.el" "${EMACS_D}/init-starter.el${BACKUP_SUFFIX}"
  fi
  cp "${HERE}/init-starter.el" "${EMACS_D}/init-starter.el"
  echo ">> Starter snippet installed at ${EMACS_D}/init-starter.el (not auto-loaded)"
fi

# Install coding companion starter if bundled. Also NOT auto-loaded — opt in
# with: (load (expand-file-name "coding-starter" user-emacs-directory) t t)
if [[ -f "${HERE}/coding-starter.el" ]]; then
  if [[ -e "${EMACS_D}/coding-starter.el" && ! -L "${EMACS_D}/coding-starter.el" ]]; then
    echo "   backing up existing coding-starter.el -> coding-starter.el${BACKUP_SUFFIX}"
    mv "${EMACS_D}/coding-starter.el" "${EMACS_D}/coding-starter.el${BACKUP_SUFFIX}"
  fi
  cp "${HERE}/coding-starter.el" "${EMACS_D}/coding-starter.el"
  echo ">> Coding companion installed at ${EMACS_D}/coding-starter.el (not auto-loaded)"
fi

# Install tools/ drop-zone (language servers, debug adapters) to ~/.emacs.d/bin/.
# `cp -a' keeps the executable bits. Users can either add ~/.emacs.d/bin to PATH
# or reference binaries by absolute path from their eglot-server-programs.
if [[ -d "${HERE}/tools" ]]; then
  if [[ -d "${EMACS_D}/bin" ]]; then
    echo "   backing up existing bin/ -> bin${BACKUP_SUFFIX}/"
    mv "${EMACS_D}/bin" "${EMACS_D}/bin${BACKUP_SUFFIX}"
  fi
  echo ">> Installing tools/ to ${EMACS_D}/bin"
  mkdir -p "${EMACS_D}/bin"
  cp -a "${HERE}/tools/." "${EMACS_D}/bin/"
fi

# Install docs/ drop-zone (coding guide, reference material).
if [[ -d "${HERE}/docs" ]]; then
  if [[ -d "${EMACS_D}/docs" ]]; then
    echo "   backing up existing docs/ -> docs${BACKUP_SUFFIX}/"
    mv "${EMACS_D}/docs" "${EMACS_D}/docs${BACKUP_SUFFIX}"
  fi
  echo ">> Installing docs/ to ${EMACS_D}/docs"
  mkdir -p "${EMACS_D}/docs"
  cp -a "${HERE}/docs/." "${EMACS_D}/docs/"
fi

# Report on optional Emacs source.
SRC="$(ls "${HERE}"/emacs-*.tar.xz 2>/dev/null | head -n1 || true)"
if [[ -n "$SRC" && -f "$SRC" ]]; then
  echo
  echo ">> Bundled Emacs source: $(basename "$SRC")"
  echo "   To build from source:"
  echo "     tar -xf '$SRC' -C /tmp"
  echo "     cd /tmp/$(basename "$SRC" .tar.xz)"
  echo "     ./configure --prefix=\"\$HOME/.local\" && make -j\$(nproc) && make install"
fi

echo
echo "Done. Launch Emacs; *Messages* should report:"
echo "  my/offline-packages=t  dir=/home/you/elpa-mirror-emacs-..."
