#!/usr/bin/env bash
# rollback.sh — restore the most recent `.pre-toolkit-<STAMP>' backup created
# by setup.sh. Scans ~/.emacs.d/ and ~/ for backup entries, picks the newest
# stamp, and swaps everything under that stamp back to its original name. The
# current (post-install) state is not discarded — it's archived with a
# `.rolled-back-<STAMP>' suffix so a re-rollforward is still possible.
set -euo pipefail

EMACS_D="${HOME}/.emacs.d"
NOW="$(date +%Y%m%dT%H%M%S)"

collect_stamps() {
  {
    find "$EMACS_D" -maxdepth 1 -mindepth 1 -name '*.pre-toolkit-*' 2>/dev/null
    find "$HOME"    -maxdepth 1 -mindepth 1 -name '*.pre-toolkit-*' 2>/dev/null
  } | sed -E 's/.*\.pre-toolkit-([0-9TZ]+).*/\1/' | sort -u
}

mapfile -t STAMPS < <(collect_stamps)
if [[ "${#STAMPS[@]}" -eq 0 ]]; then
  echo "No .pre-toolkit-* backups found under $HOME or $EMACS_D." >&2
  exit 1
fi

# Newest first — lexical sort works because stamps are YYYYmmddTHHMMSS.
LATEST="$(printf '%s\n' "${STAMPS[@]}" | sort -r | head -n1)"

echo "Backup stamps available (newest first):"
printf '%s\n' "${STAMPS[@]}" | sort -r | sed 's/^/  /'
echo
read -r -p "Roll back to ${LATEST}? [y/N] " ans </dev/tty
[[ "$ans" =~ ^[yY] ]] || { echo "Aborted."; exit 0; }

rollback_in() {
  local dir="$1"
  shopt -s nullglob
  for bak in "$dir"/*.pre-toolkit-"$LATEST"; do
    [[ -e "$bak" ]] || continue
    local orig="${bak%.pre-toolkit-$LATEST}"
    if [[ -e "$orig" ]]; then
      echo "   archiving current $(basename "$orig") -> $(basename "$orig").rolled-back-${NOW}"
      mv "$orig" "${orig}.rolled-back-${NOW}"
    fi
    echo "   restoring $(basename "$bak") -> $(basename "$orig")"
    mv "$bak" "$orig"
  done
}

rollback_in "$EMACS_D"
rollback_in "$HOME"

echo
echo "Rollback complete. Post-install state preserved under *.rolled-back-${NOW}."
