;;; dired-image-thumbnail.el --- Enhanced workflow for image-dired -*- lexical-binding: t; -*-

;; Copyright (C) 2025 James Dyer

;; Author: James Dyer
;; Version: 2.0.0
;; Package-Requires: ((emacs "28.1"))
;; Keywords: multimedia, files, dired, images
;; URL: https://github.com/captainflasmr/dired-image-thumbnail

;; This file is not part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; This package extends `image-dired' with an improved workflow inspired by
;; `dired-video-thumbnail'.  It adds:
;;
;; - Sorting: Sort thumbnails by name, date, size
;; - Filtering: Filter by name regexp, file size range
;; - Subdirectory support: Works with inserted subdirectories
;; - Wrap display mode: Thumbnails flow naturally and wrap to window width
;; - Enhanced header line: Shows current image info with sort/filter status
;; - Marking: Uses built-in image-dired marking with visual border
;; - File operations: Delete images, navigate to dired buffer
;; - Window layout: Automatic split-screen layout (thumbnails left, image right)
;; - Auto-display: Navigate with n/p to automatically show full-size images
;;
;; Usage:
;;
;; From a Dired buffer, call `M-x dired-image-thumbnail' to display
;; thumbnails with enhanced features. You can also use the standard
;; `M-x image-dired' and the enhanced features will be available.
;;
;; To include images from subdirectories, use 'i' (`dired-maybe-insert-subdir`)
;; to insert subdirectories before calling `dired-image-thumbnail', or use
;; the helper commands:
;; - `dired-image-thumbnail-insert-subdir-recursive' - Insert all subdirectories
;; - `dired-image-thumbnail-insert-image-subdirs' - Insert only subdirs with images
;; - `dired-image-thumbnail-kill-all-subdirs' - Remove all inserted subdirectories
;;
;; The package uses the standard *image-dired* buffer, so all native
;; image-dired marking commands work as expected.
;;
;; Key bindings in thumbnail buffer:
;;
;;   s   - Sorting prefix (s n: name, s d: date, s s: size, s r: reverse)
;;   S   - Interactive sort selection
;;   /   - Filtering prefix (/ n: name, / s: size, / c: clear)
;;   w   - Toggle wrap display mode
;;   r   - Refresh display
;;   n/p - Next/previous image (with auto-display when enabled)
;;   +/- - Increase/decrease size
;;   m   - Mark image (uses image-dired's native marking with border)
;;   u   - Unmark image
;;   M   - Mark all
;;   U   - Unmark all
;;   t   - Toggle all marks
;;   d   - Go to Dired buffer
;;   D   - Delete image at point
;;   C-d - Delete image and move to next
;;   x   - Delete marked images
;;   ?/h - Help
;;

;;; Code:

(require 'image-dired)
(require 'image-dired-util)
(require 'image)
(require 'dired)
(require 'cl-lib)

(declare-function image-size "image.c" (spec &optional pixels frame))

;;; Customization

(defgroup dired-image-thumbnail nil
  "Enhanced workflow for image-dired."
  :group 'image-dired
  :prefix "dired-image-thumbnail-")

(defcustom dired-image-thumbnail-sort-by 'dired
  "Default sorting criteria for thumbnails."
  :type '(choice (const :tag "Dired Order" dired)
                 (const :tag "Name" name)
                 (const :tag "Date modified" date)
                 (const :tag "Size" size)
                 (const :tag "Dimensions" dimensions))
  :safe #'symbolp
  :group 'dired-image-thumbnail)

(defcustom dired-image-thumbnail-sort-order 'ascending
  "Default sort order for thumbnails."
  :type '(choice (const :tag "Ascending" ascending)
                 (const :tag "Descending" descending))
  :safe #'symbolp
  :group 'dired-image-thumbnail)

(defcustom dired-image-thumbnail-wrap-display nil
  "Whether to wrap thumbnails to fill the buffer width.
When non-nil, thumbnails flow naturally and wrap based on window width.
When nil, the standard `image-dired' line-up method is used."
  :type 'boolean
  :safe #'booleanp
  :group 'dired-image-thumbnail)

(defcustom dired-image-thumbnail-window-layout 'left-right
  "Window layout used when launching `dired-image-thumbnail'.

  `left-right'  - Thumbnails on the left, image on the right (default).
  `right-left'  - Image on the left, thumbnails on the right.
  `top-bottom'  - Thumbnails on top, image on the bottom.
  `bottom-top'  - Image on top, thumbnails on the bottom.
  `thumb-only'  - Only show the thumbnail buffer; no image window.
  nil           - Do not manage windows; use Emacs default placement
                  or your own `display-buffer-alist' rules.

The thumbnail/image size ratio is controlled by
`dired-image-thumbnail-window-ratio'."
  :type '(choice (const :tag "Thumbnails left, image right" left-right)
                 (const :tag "Image left, thumbnails right" right-left)
                 (const :tag "Thumbnails top, image bottom" top-bottom)
                 (const :tag "Image top, thumbnails bottom" bottom-top)
                 (const :tag "Thumbnails only" thumb-only)
                 (const :tag "Manual (use display-buffer-alist)" nil))
  :safe #'symbolp
  :group 'dired-image-thumbnail)

(defcustom dired-image-thumbnail-window-ratio 0.4
  "Fraction of the frame given to the thumbnail buffer.
The image buffer gets the remainder.  Only used when
`dired-image-thumbnail-window-layout' is non-nil."
  :type 'float
  :safe #'numberp
  :group 'dired-image-thumbnail)

(defcustom dired-image-thumbnail-auto-display-on-navigate t
  "Whether to automatically display full-size image when navigating thumbnails.
When non-nil, pressing `n` or `p` in the thumbnail buffer automatically
updates the image display buffer. When nil, you must press RET or
C-<return> to view the full-size image."
  :type 'boolean
  :safe #'booleanp
  :group 'dired-image-thumbnail)

(defcustom dired-image-thumbnail-auto-accept nil
  "Whether to skip confirmation for file actions like deletion.
When non-nil, actions that normally ask for confirmation (like
deleting files) will proceed without prompting."
  :type 'boolean
  :safe #'booleanp
  :group 'dired-image-thumbnail)

(defcustom dired-image-thumbnail-image-extensions
  '("jpg" "jpeg" "png" "gif" "bmp" "tiff" "tif" "webp" "svg" "ico" "heic" "heif")
  "List of image file extensions to recognise."
  :type '(repeat string)
  :safe (lambda (v) (and (listp v) (cl-every #'stringp v)))
  :group 'dired-image-thumbnail)

(defcustom dired-image-thumbnail-minimum-file-size 100
  "Minimum file size in bytes for an image to be included.
Files smaller than this are assumed to be corrupt or empty and
are silently excluded from the thumbnail display.  Set to 0 to
disable this check."
  :type 'natnum
  :safe #'natnump
  :group 'dired-image-thumbnail)

(defcustom dired-image-thumbnail-validate-headers t
  "Whether to check image file magic bytes before including them.
When non-nil, each candidate file is opened briefly to verify
that its first few bytes match a known image format signature.
This catches files that have an image extension but contain
garbage or are truncated.  The check reads only the first 12
bytes per file, so the overhead is small.  Set to nil if you
trust all files in your directories or want maximum speed."
  :type 'boolean
  :safe #'booleanp
  :group 'dired-image-thumbnail)

(defcustom dired-image-thumbnail-external-editor nil
  "External program used to open images with \\`W'.
When nil, the system default application is used via `xdg-open'
on Linux, `open' on macOS, or `start' on Windows."
  :type '(choice (const :tag "System default" nil)
                 (string :tag "Program name"))
  :safe (lambda (v) (or (null v) (stringp v)))
  :group 'dired-image-thumbnail)

(defcustom dired-image-thumbnail-display-quality 'fast
  "Display quality when navigating thumbnails with n/p.
Controls the trade-off between image quality and navigation speed.

  `full'   - Original resolution via `image-dired-display-image'.
             Slowest, but pixel-perfect.
  `high'   - Scaled to fit the display window (1:1 window pixels).
  `fast'   - Half the window dimensions.  Good balance.
  `faster' - Quarter the window dimensions.  Noticeably quicker.
  `draft'  - 1/8 the window dimensions.  Very fast, visibly soft.

Changing this takes effect on the next n/p keypress."
  :type '(choice (const :tag "Full resolution (slowest)" full)
                 (const :tag "High - window size" high)
                 (const :tag "Fast - 1/2 window (default)" fast)
                 (const :tag "Faster - 1/4 window" faster)
                 (const :tag "Draft - 1/8 window (fastest)" draft))
  :safe #'symbolp
  :group 'dired-image-thumbnail)

;;; Internal variables

(defvar-local dired-image-thumbnail--all-images nil
  "List of all images before filtering/sorting.")

(defvar-local dired-image-thumbnail--current-images nil
  "List of images after filtering/sorting.")

(defvar-local dired-image-thumbnail--source-dir nil
  "Source directory for the current thumbnail buffer.")

(defvar-local dired-image-thumbnail--dired-buffer nil
  "The Dired buffer associated with this thumbnail buffer.")

(defvar-local dired-image-thumbnail--sort-by nil
  "Current sort criteria for this buffer.")

(defvar-local dired-image-thumbnail--sort-order nil
  "Current sort order for this buffer.")

(defvar-local dired-image-thumbnail--filter-name nil
  "Current name filter regexp.")

(defvar-local dired-image-thumbnail--filter-size-min nil
  "Minimum size filter in bytes.")

(defvar-local dired-image-thumbnail--filter-size-max nil
  "Maximum size filter in bytes.")

(defvar-local dired-image-thumbnail--display-size 150
  "Current display size for thumbnails (for zoom).")

(defvar-local dired-image-thumbnail--dimension-cache (make-hash-table :test 'equal)
  "Cache for image dimensions keyed by file name.")

(defvar-local dired-image-thumbnail--dimension-pending (make-hash-table :test 'equal)
  "Files pending dimension calculation. Value is t if process is running.")

(defvar-local dired-image-thumbnail--recursive nil
  "Non-nil if thumbnails include images from subdirectories.")

(defun dired-image-thumbnail--get-image-dimensions (file)
  "Get dimensions of image FILE as (width . height), or (0 . 0) if unknown.
If not cached, launch an async process (`identify`) to fill the cache."
  (or (gethash file dired-image-thumbnail--dimension-cache)
      (progn
        (unless (gethash file dired-image-thumbnail--dimension-pending)
          (puthash file t dired-image-thumbnail--dimension-pending)
          (dired-image-thumbnail--start-identify-process file))
        ;; Fallback until process finishes
        (cons 0 0))))

(defun dired-image-thumbnail--nearest-image-original-file-name (&optional pos)
  "Return the 'original-file-name property at POS, or search nearby if not found."
  (let ((pos (or pos (point))))
    (or (get-text-property pos 'original-file-name)
        ;; Search backward then forward for nearest image property
        (save-excursion
          (let ((found nil)
                (limit (point-min)))
            (goto-char pos)
            (while (and (not found) (> (point) limit))
              (setq found (get-text-property (point) 'original-file-name))
              (unless found (backward-char)))
            found))
        (save-excursion
          (let ((found nil)
                (limit (point-max)))
            (goto-char pos)
            (while (and (not found) (< (point) limit))
              (setq found (get-text-property (point) 'original-file-name))
              (unless found (forward-char)))
            found)))))

(defun dired-image-thumbnail--start-identify-process (file)
  "Start an async process to get dimensions for FILE."
  (let ((proc-buf (generate-new-buffer " *dired-image-thumb-identify*"))
        (thumb-buf (current-buffer))
        (file-attr file))
    (make-process
     :name "dired-image-thumb-identify"
     :buffer proc-buf
     :command (list "identify" "-format" "%w %h" (expand-file-name file))
     :noquery t
     :sentinel
     (lambda (proc _event)
       (when (eq (process-status proc) 'exit)
         (unwind-protect
             (when (and (zerop (process-exit-status proc))
                        (buffer-live-p (process-buffer proc)))
               (with-current-buffer (process-buffer proc)
                 (goto-char (point-min))
                 (let* ((line (buffer-substring-no-properties (point-min) (point-max)))
                        (nums (split-string line)))
                   (when (and (= (length nums) 2)
                              (string-match-p "^[0-9]+$" (car nums))
                              (string-match-p "^[0-9]+$" (cadr nums)))
                     (let ((w (string-to-number (car nums)))
                           (h (string-to-number (cadr nums))))
                       (when (buffer-live-p thumb-buf)
                         (with-current-buffer thumb-buf
                           (puthash file-attr (cons w h) dired-image-thumbnail--dimension-cache)
                           (remhash file-attr dired-image-thumbnail--dimension-pending)))
                       (dolist (b (buffer-list))
                         (with-current-buffer b
                           (when (derived-mode-p 'image-dired-thumbnail-mode)
                             (image-dired--update-header-line)))))))))
           (when (buffer-live-p (process-buffer proc))
             (kill-buffer (process-buffer proc)))))))))

;;; Utility functions

(defun dired-image-thumbnail--valid-header-p (file)
  "Return non-nil if FILE begins with a recognised image magic signature.
Reads only the first 12 bytes.  Recognised formats: JPEG, PNG, GIF,
BMP, TIFF, WEBP, ICO, HEIC/HEIF.  SVG is accepted without a byte
check since it is XML text."
  (let ((ext (downcase (or (file-name-extension file) ""))))
    (if (equal ext "svg")
        t
      (condition-case nil
          (with-temp-buffer
            (set-buffer-multibyte nil)
            (insert-file-contents-literally file nil 0 12)
            (let ((bytes (buffer-string)))
              (when (>= (length bytes) 2)
                (let ((b0 (aref bytes 0))
                      (b1 (aref bytes 1)))
                  (cond
                   ;; JPEG: FF D8
                   ((and (= b0 #xFF) (= b1 #xD8)) t)
                   ;; PNG: 89 50 4E 47
                   ((and (>= (length bytes) 4)
                         (= b0 #x89) (= b1 #x50)
                         (= (aref bytes 2) #x4E) (= (aref bytes 3) #x47))
                    t)
                   ;; GIF: "GIF8"
                   ((and (>= (length bytes) 4)
                         (= b0 ?G) (= b1 ?I)
                         (= (aref bytes 2) ?F) (= (aref bytes 3) ?8))
                    t)
                   ;; BMP: "BM"
                   ((and (= b0 ?B) (= b1 ?M)) t)
                   ;; TIFF: "II" (little-endian) or "MM" (big-endian)
                   ((and (>= (length bytes) 4)
                         (or (and (= b0 #x49) (= b1 #x49)
                                  (= (aref bytes 2) #x2A) (= (aref bytes 3) #x00))
                             (and (= b0 #x4D) (= b1 #x4D)
                                  (= (aref bytes 2) #x00) (= (aref bytes 3) #x2A))))
                    t)
                   ;; WEBP: "RIFF" + 4 bytes + "WEBP"
                   ((and (>= (length bytes) 12)
                         (= b0 ?R) (= b1 ?I)
                         (= (aref bytes 2) ?F) (= (aref bytes 3) ?F)
                         (= (aref bytes 8) ?W) (= (aref bytes 9) ?E)
                         (= (aref bytes 10) ?B) (= (aref bytes 11) ?P))
                    t)
                   ;; ICO: 00 00 01 00
                   ((and (>= (length bytes) 4)
                         (= b0 #x00) (= b1 #x00)
                         (= (aref bytes 2) #x01) (= (aref bytes 3) #x00))
                    t)
                   ;; HEIC/HEIF: bytes 4-11 contain "ftyp" for ISO BMFF
                   ((and (>= (length bytes) 8)
                         (= (aref bytes 4) ?f) (= (aref bytes 5) ?t)
                         (= (aref bytes 6) ?y) (= (aref bytes 7) ?p))
                    t))))))
        (file-error nil)))))

(defun dired-image-thumbnail--image-p (file)
  "Return non-nil if FILE is a valid image file.
Checks extension, minimum file size, and optionally magic bytes."
  (and (file-regular-p file)
       (member (downcase (or (file-name-extension file) ""))
               dired-image-thumbnail-image-extensions)
       (or (zerop dired-image-thumbnail-minimum-file-size)
           (let ((attrs (file-attributes file)))
             (and attrs
                  (>= (file-attribute-size attrs)
                      dired-image-thumbnail-minimum-file-size))))
       (or (not dired-image-thumbnail-validate-headers)
           (dired-image-thumbnail--valid-header-p file))))

(defun dired-image-thumbnail--find-images (directory &optional recursive)
  "Find all image files in DIRECTORY.
If RECURSIVE is non-nil, search subdirectories as well."
  (if recursive
      (let ((images nil)
            (regexp (concat "\\." (regexp-opt dired-image-thumbnail-image-extensions) "\\'")))
        (dolist (file (directory-files-recursively directory regexp nil))
          (when (dired-image-thumbnail--image-p file)
            (push file images)))
        (nreverse images))
    (seq-filter #'dired-image-thumbnail--image-p
                (directory-files directory t nil t))))

(defun dired-image-thumbnail--get-dired-marked-set ()
  "Return a hash set of all marked files in the associated dired buffer.
This collects all marks in a single pass through the dired buffer."
  (let ((marked (make-hash-table :test 'equal)))
    (when (and dired-image-thumbnail--dired-buffer
               (buffer-live-p dired-image-thumbnail--dired-buffer))
      (with-current-buffer dired-image-thumbnail--dired-buffer
        (save-excursion
          (goto-char (point-min))
          (while (not (eobp))
            (when (image-dired-dired-file-marked-p)
              (let ((file (dired-get-filename nil t)))
                (when file
                  (puthash file t marked))))
            (forward-line 1)))))
    marked))

(defun dired-image-thumbnail--file-marked-p (file)
  "Return non-nil if FILE is marked in the associated dired buffer."
  (when (and dired-image-thumbnail--dired-buffer
             (buffer-live-p dired-image-thumbnail--dired-buffer))
    (with-current-buffer dired-image-thumbnail--dired-buffer
      (save-excursion
        (goto-char (point-min))
        (when (dired-goto-file file)
          (image-dired-dired-file-marked-p))))))

(defun dired-image-thumbnail--relative-name (file)
  "Return FILE name relative to the source directory."
  (if (and dired-image-thumbnail--source-dir
           (string-prefix-p (expand-file-name dired-image-thumbnail--source-dir)
                            (expand-file-name file)))
      (file-relative-name file dired-image-thumbnail--source-dir)
    (file-name-nondirectory file)))

(defun dired-image-thumbnail--format-file-size (file)
  "Return human-readable file size for FILE."
  (let ((attrs (file-attributes file)))
    (if attrs
        (file-size-human-readable (file-attribute-size attrs))
      "?")))

(defun dired-image-thumbnail--format-image-dimensions (file)
  "Return formatted dimensions string for image FILE (e.g., \"1920x1080\")."
  (let ((dims (dired-image-thumbnail--get-image-dimensions file)))
    (if (and dims (> (car dims) 0) (> (cdr dims) 0))
        (format "%dx%d" (car dims) (cdr dims))
      "?")))

(defun dired-image-thumbnail--count-marked ()
  "Count the number of marked images."
  (if dired-image-thumbnail--current-images
      (let ((marked-set (dired-image-thumbnail--get-dired-marked-set))
            (count 0))
        (dolist (file dired-image-thumbnail--current-images)
          (when (gethash file marked-set)
            (setq count (1+ count))))
        count)
    0))

;;; Sorting functions

(defun dired-image-thumbnail--sort-images (images)
  "Sort IMAGES according to current sort settings."
  (let* ((sort-by (or dired-image-thumbnail--sort-by dired-image-thumbnail-sort-by))
         (sort-order (or dired-image-thumbnail--sort-order dired-image-thumbnail-sort-order))
         (sorted
          (pcase sort-by
            ('dired (copy-sequence images))
            ('name
             (sort (copy-sequence images)
                   (lambda (a b)
                     (string< (downcase (file-name-nondirectory a))
                              (downcase (file-name-nondirectory b))))))
            ('date
             (let ((decorated (mapcar (lambda (f)
                                        (cons (file-attribute-modification-time (file-attributes f)) f))
                                      images)))
               (mapcar #'cdr (sort decorated (lambda (a b) (time-less-p (car a) (car b)))))))
            ('size
             (let ((decorated (mapcar (lambda (f)
                                        (cons (or (file-attribute-size (file-attributes f)) 0) f))
                                      images)))
               (mapcar #'cdr (sort decorated (lambda (a b) (< (car a) (car b)))))))
            (_ (copy-sequence images)))))
    (if (eq sort-order 'descending)
        (nreverse sorted)
      sorted)))

;;; Filtering functions

(defun dired-image-thumbnail--filter-images (images)
  "Filter IMAGES according to current filter settings."
  (let ((result images))
    ;; Filter by name
    (when dired-image-thumbnail--filter-name
      (setq result
            (seq-filter
             (lambda (file)
               (string-match-p dired-image-thumbnail--filter-name
                               (file-name-nondirectory file)))
             result)))
    ;; Filter by size
    (when (or dired-image-thumbnail--filter-size-min
              dired-image-thumbnail--filter-size-max)
      (setq result
            (seq-filter
             (lambda (file)
               (let ((size (file-attribute-size (file-attributes file))))
                 (and (or (null dired-image-thumbnail--filter-size-min)
                          (>= size dired-image-thumbnail--filter-size-min))
                      (or (null dired-image-thumbnail--filter-size-max)
                          (<= size dired-image-thumbnail--filter-size-max)))))
             result)))
    result))

(defun dired-image-thumbnail--format-active-filters ()
  "Return a string describing active filters."
  (let ((filters nil))
    (when dired-image-thumbnail--filter-name
      (push (format "name:/%s/" dired-image-thumbnail--filter-name) filters))
    (when (or dired-image-thumbnail--filter-size-min
              dired-image-thumbnail--filter-size-max)
      (push (format "size:%s-%s"
                    (if dired-image-thumbnail--filter-size-min
                        (file-size-human-readable dired-image-thumbnail--filter-size-min)
                      "0")
                    (if dired-image-thumbnail--filter-size-max
                        (file-size-human-readable dired-image-thumbnail--filter-size-max)
                      "∞"))
            filters))
    (if filters
        (mapconcat #'identity (nreverse filters) " ")
      "")))

;;; Apply sort and filter

(defun dired-image-thumbnail--apply-sort-and-filter ()
  "Apply current sort and filter settings and refresh display."
  ;; Initialize if not already done
  (unless dired-image-thumbnail--all-images
    (dired-image-thumbnail--initialize-buffer))
  (when dired-image-thumbnail--all-images
    (let ((filtered (dired-image-thumbnail--filter-images dired-image-thumbnail--all-images)))
      (setq dired-image-thumbnail--current-images
            (dired-image-thumbnail--sort-images filtered))))
  (dired-image-thumbnail-refresh))

;;; Initialization for standard image-dired

(defun dired-image-thumbnail--initialize-buffer ()
  "Initialize dired-image-thumbnail variables in the current thumbnail buffer.
This is called via hook when entering `image-dired-thumbnail-mode'."
  ;; Skip if already initialized and has images
  (unless (and dired-image-thumbnail--all-images
               dired-image-thumbnail--dired-buffer)
    ;; Small delay to ensure image-dired has started inserting properties
    ;; though we prefer finding the dired buffer through other means if possible
    (let ((images nil)
          (dired-buf dired-image-thumbnail--dired-buffer)
          (source-dir dired-image-thumbnail--source-dir))
      
      ;; If not explicitly passed, try to find from text properties
      (unless dired-buf
        (save-excursion
          (goto-char (point-min))
          (let ((found nil))
            (while (and (not found) (not (eobp)))
              (when-let ((buf (get-text-property (point) 'associated-dired-buffer)))
                (setq dired-buf buf)
                (setq found t))
              (forward-char)))))

      ;; If still not found, look for any live dired buffer that might be relevant
      (unless dired-buf
        (let ((buffers (buffer-list)))
          (while (and (not dired-buf) buffers)
            (let ((buf (pop buffers)))
              (with-current-buffer buf
                (when (and (derived-mode-p 'dired-mode)
                           (boundp 'dired-image-thumbnail--source-dir)
                           (equal default-directory (buffer-local-value 'default-directory (current-buffer))))
                  (setq dired-buf buf)))))))

      (save-excursion
        (goto-char (point-min))
        (while (not (eobp))
          (when-let ((file (get-text-property (point) 'original-file-name)))
            (when (dired-image-thumbnail--image-p file)
              (push file images))
            (unless source-dir
              (setq source-dir (file-name-directory file))))
          (forward-char)))

      ;; Get source-dir from dired buffer if available
      (when (and dired-buf (buffer-live-p dired-buf))
        (with-current-buffer dired-buf
          (unless source-dir
            (setq source-dir dired-image-thumbnail--source-dir))))
      
      (when images
        (setq dired-image-thumbnail--all-images (nreverse images))
        (setq dired-image-thumbnail--current-images dired-image-thumbnail--all-images)
        (setq dired-image-thumbnail--dired-buffer dired-buf)
        (setq dired-image-thumbnail--source-dir (or source-dir default-directory))
        (setq dired-image-thumbnail--sort-by dired-image-thumbnail-sort-by)
        (setq dired-image-thumbnail--sort-order dired-image-thumbnail-sort-order)))))

;;; Header line

(defun dired-image-thumbnail--format-properties-string (orig-fun buf file image-count props comment)
  "Advice around `image-dired-format-properties-string' for enhanced header line.
ORIG-FUN is the original function.
BUF, FILE, IMAGE-COUNT, PROPS, and COMMENT are passed to the original function.
When `dired-image-thumbnail--all-images' is set, return our enhanced header line.
Otherwise, fall back to the original function."
  (if dired-image-thumbnail--all-images
      ;; Use our enhanced header line
      (let* ((sort-info (format "[%s %s]"
                                (or dired-image-thumbnail--sort-by dired-image-thumbnail-sort-by)
                                (if (eq (or dired-image-thumbnail--sort-order
                                            dired-image-thumbnail-sort-order)
                                        'ascending)
                                    "<" ">")))
             (filter-info (dired-image-thumbnail--format-active-filters))
             (marked-count (dired-image-thumbnail--count-marked))
             (marked-info (if (> marked-count 0)
                              (format " [%d marked]" marked-count)
                            ""))
             (rel-name (dired-image-thumbnail--relative-name file))
             (size (dired-image-thumbnail--format-file-size file))
             (dimensions (dired-image-thumbnail--format-image-dimensions file))
             (quality (symbol-name dired-image-thumbnail-display-quality)))
        (concat
         "  "
         (propertize rel-name 'face 'image-dired-thumb-header-file-name)
         "  "
         (propertize image-count 'face 'image-dired-thumb-header-image-count)
         "  "
         (propertize size 'face 'image-dired-thumb-header-file-size)
         "  "
         (propertize dimensions 'face 'shadow)
         "  "
         sort-info
         "  "
         (propertize (format "[%s]" quality) 'face 'shadow)
         (if (string-empty-p filter-info) "" (format "  %s" filter-info))
         marked-info))
    ;; Fall back to original function
    (funcall orig-fun buf file image-count props comment)))

;;; Display functions

(defun dired-image-thumbnail-refresh ()
  "Refresh the thumbnail display with current images."
  (interactive)
  ;; Initialize if not already done
  (unless dired-image-thumbnail--all-images
    (dired-image-thumbnail--initialize-buffer))
  (when dired-image-thumbnail--all-images
    (let ((current-file (image-dired-original-file-name))
          (dired-buf dired-image-thumbnail--dired-buffer)
          (source-dir dired-image-thumbnail--source-dir)
          (sort-by dired-image-thumbnail--sort-by)
          (sort-order dired-image-thumbnail--sort-order)
          (filter-name dired-image-thumbnail--filter-name)
          (filter-size-min dired-image-thumbnail--filter-size-min)
          (filter-size-max dired-image-thumbnail--filter-size-max)
          (display-size dired-image-thumbnail--display-size)
          (all-images dired-image-thumbnail--all-images)
          (inhibit-read-only t))
      (erase-buffer)
      ;; Restore state
      (setq dired-image-thumbnail--all-images all-images)
      (setq dired-image-thumbnail--source-dir source-dir)
      (setq dired-image-thumbnail--dired-buffer dired-buf)
      (setq dired-image-thumbnail--display-size display-size)
      (setq dired-image-thumbnail--sort-by sort-by)
      (setq dired-image-thumbnail--sort-order sort-order)
      (setq dired-image-thumbnail--filter-name filter-name)
      (setq dired-image-thumbnail--filter-size-min filter-size-min)
      (setq dired-image-thumbnail--filter-size-max filter-size-max)
      ;; Apply filter and sort
      (let ((filtered (dired-image-thumbnail--filter-images all-images)))
        (setq dired-image-thumbnail--current-images
              (dired-image-thumbnail--sort-images filtered)))
      ;; Temporarily override thumb size if needed
      (let ((standard-size image-dired-thumb-size))
        (when (and display-size (/= display-size standard-size))
          (setq-local image-dired-thumb-size display-size))
        ;; Insert thumbnails using image-dired's standard function
        ;; This ensures proper marking support
        (dolist (file dired-image-thumbnail--current-images)
          (let ((thumb-file (image-dired-thumb-name file)))
            ;; Create thumbnail if it doesn't exist
            (unless (file-exists-p thumb-file)
              (image-dired-create-thumb file thumb-file))
            ;; Insert with all three required arguments
            (image-dired-insert-thumbnail thumb-file file dired-buf))))
      ;; Line up
      (if dired-image-thumbnail-wrap-display
          (progn
            (setq-local word-wrap t)
            (setq-local truncate-lines nil))
        (image-dired--line-up-with-method))
      ;; Restore mark display
      (image-dired--thumb-update-marks)
      ;; Restore position before updating header line, so point is on a
      ;; valid thumbnail when the header line reads the file at point.
      (if current-file
          (progn
            (goto-char (point-min))
            (let ((found nil))
              (while (and (not found) (not (eobp)))
                (when (equal (get-text-property (point) 'original-file-name) current-file)
                  (setq found t))
                (unless found (forward-char)))
              (unless found (goto-char (point-min)))))
        (goto-char (point-min)))
      (image-dired--update-header-line))))

(defun dired-image-thumbnail-hard-refresh ()
  "Refresh thumbnails by clearing the cache and reloading.
This deletes the contents of `image-dired-dir' and then calls
`dired-image-thumbnail-refresh'."
  (interactive)
  (unless (file-directory-p image-dired-dir)
    (make-directory image-dired-dir t))
  (when (or dired-image-thumbnail-auto-accept
            (yes-or-no-p (format "Deep refresh: Clear all thumbnails in %s? " image-dired-dir)))
    (message "Clearing thumbnail cache...")
    ;; Delete all files in image-dired-dir
    (let ((files (directory-files image-dired-dir t directory-files-no-dot-files-regexp)))
      (dolist (file files)
        (if (file-directory-p file)
            (delete-directory file t)
          (delete-file file))))
    (dired-image-thumbnail-refresh)
    (message "Thumbnail cache cleared and buffer refreshed.")))

(defun dired-image-thumbnail-sort-by-dired ()
  "Sort thumbnails by Dired buffer order."
  (interactive)
  (setq dired-image-thumbnail--sort-by 'dired)
  (dired-image-thumbnail--apply-sort-and-filter)
  (message "Sorted by Dired order"))

(defun dired-image-thumbnail-sort-by-name ()
  "Sort thumbnails by name."
  (interactive)
  (setq dired-image-thumbnail--sort-by 'name)
  (dired-image-thumbnail--apply-sort-and-filter)
  (message "Sorted by name"))

(defun dired-image-thumbnail-sort-by-date ()
  "Sort thumbnails by date."
  (interactive)
  (setq dired-image-thumbnail--sort-by 'date)
  (dired-image-thumbnail--apply-sort-and-filter)
  (message "Sorted by date"))

(defun dired-image-thumbnail-sort-by-size ()
  "Sort thumbnails by size."
  (interactive)
  (setq dired-image-thumbnail--sort-by 'size)
  (dired-image-thumbnail--apply-sort-and-filter)
  (message "Sorted by size"))

(defun dired-image-thumbnail-sort-reverse ()
  "Reverse current sort order."
  (interactive)
  (setq dired-image-thumbnail--sort-order
        (if (eq dired-image-thumbnail--sort-order 'ascending)
            'descending
          'ascending))
  (dired-image-thumbnail--apply-sort-and-filter)
  (message "Sort order: %s" dired-image-thumbnail--sort-order))

(defun dired-image-thumbnail-sort ()
  "Interactively choose sort criteria."
  (interactive)
  (let ((choice (completing-read "Sort by: "
                                 '("dired" "name" "date" "size" "reverse")
                                 nil t)))
    (pcase choice
      ("dired" (dired-image-thumbnail-sort-by-dired))
      ("name" (dired-image-thumbnail-sort-by-name))
      ("date" (dired-image-thumbnail-sort-by-date))
      ("size" (dired-image-thumbnail-sort-by-size))
      ("reverse" (dired-image-thumbnail-sort-reverse)))))

;;; Filtering commands

(defun dired-image-thumbnail-filter-by-name (regexp)
  "Filter thumbnails by name matching REGEXP."
  (interactive "sFilter by name (regexp): ")
  (setq dired-image-thumbnail--filter-name
        (if (string-empty-p regexp) nil regexp))
  (dired-image-thumbnail--apply-sort-and-filter)
  (message "Name filter: %s" (or dired-image-thumbnail--filter-name "none")))

(defun dired-image-thumbnail-filter-by-size (min max)
  "Filter thumbnails by size between MIN and MAX bytes.
Enter size in human-readable format (e.g., 100k, 1M)."
  (interactive
   (list (read-string "Minimum size (e.g., 100k, 1M, empty for none): ")
         (read-string "Maximum size (e.g., 100k, 1M, empty for none): ")))
  (setq dired-image-thumbnail--filter-size-min
        (if (string-empty-p min) nil (dired-image-thumbnail--parse-size min)))
  (setq dired-image-thumbnail--filter-size-max
        (if (string-empty-p max) nil (dired-image-thumbnail--parse-size max)))
  (dired-image-thumbnail--apply-sort-and-filter)
  (message "Size filter: %s - %s"
           (if dired-image-thumbnail--filter-size-min
               (file-size-human-readable dired-image-thumbnail--filter-size-min)
             "none")
           (if dired-image-thumbnail--filter-size-max
               (file-size-human-readable dired-image-thumbnail--filter-size-max)
             "none")))

(defun dired-image-thumbnail--parse-size (str)
  "Parse human-readable size STR to bytes."
  (let ((str (downcase (string-trim str))))
    (cond
     ((string-match "\\`\\([0-9.]+\\)g\\'" str)
      (* (string-to-number (match-string 1 str)) 1073741824))
     ((string-match "\\`\\([0-9.]+\\)m\\'" str)
      (* (string-to-number (match-string 1 str)) 1048576))
     ((string-match "\\`\\([0-9.]+\\)k\\'" str)
      (* (string-to-number (match-string 1 str)) 1024))
     (t (string-to-number str)))))

(defun dired-image-thumbnail-filter-clear ()
  "Clear all filters."
  (interactive)
  (setq dired-image-thumbnail--filter-name nil)
  (setq dired-image-thumbnail--filter-size-min nil)
  (setq dired-image-thumbnail--filter-size-max nil)
  (dired-image-thumbnail--apply-sort-and-filter)
  (message "Filters cleared"))

(defun dired-image-thumbnail-filter ()
  "Interactively choose filter type."
  (interactive)
  (let ((choice (completing-read "Filter by: "
                                 '("name" "size" "clear")
                                 nil t)))
    (pcase choice
      ("name" (call-interactively #'dired-image-thumbnail-filter-by-name))
      ("size" (call-interactively #'dired-image-thumbnail-filter-by-size))
      ("clear" (dired-image-thumbnail-filter-clear)))))

(defun dired-image-thumbnail-increase-size ()
  "Increase thumbnail display size.
When size exceeds the cached thumbnail size, images are scaled from
the original files for crisp display (slower but higher quality)."
  (interactive)
  (let ((current (or dired-image-thumbnail--display-size 128)))
    (setq dired-image-thumbnail--display-size (min 512 (+ current 32)))
    (dired-image-thumbnail-refresh)
    (if (> dired-image-thumbnail--display-size image-dired-thumb-height)
        (message "Thumbnail size: %d (using original images for quality)"
                 dired-image-thumbnail--display-size)
      (message "Thumbnail size: %d" dired-image-thumbnail--display-size))))

(defun dired-image-thumbnail-decrease-size ()
  "Decrease thumbnail display size."
  (interactive)
  (let ((current (or dired-image-thumbnail--display-size 128)))
    (setq dired-image-thumbnail--display-size (max 32 (- current 32)))
    (dired-image-thumbnail-refresh)
    (message "Thumbnail size: %d" dired-image-thumbnail--display-size)))

(defun dired-image-thumbnail-mark-all ()
  "Mark all visible images in the thumbnail buffer."
  (interactive)
  (unless dired-image-thumbnail--all-images
    (dired-image-thumbnail--initialize-buffer))
  (when dired-image-thumbnail--current-images
    ;; Mark each file in dired
    (dolist (file dired-image-thumbnail--current-images)
      ;; Ensure subdir is in dired for recursive mode
      ;; Mark in dired buffer
      (when (and dired-image-thumbnail--dired-buffer
                 (buffer-live-p dired-image-thumbnail--dired-buffer))
        (with-current-buffer dired-image-thumbnail--dired-buffer
          (save-excursion
            (goto-char (point-min))
            (when (dired-goto-file file)
              (dired-mark 1))))))
    ;; Update all thumbnail marks using image-dired's function
    (image-dired--thumb-update-marks)
    (message "Marked all %d images" (length dired-image-thumbnail--current-images))))

(defun dired-image-thumbnail-toggle-all-marks ()
  "Toggle mark on all visible images."
  (interactive)
  (unless dired-image-thumbnail--all-images
    (dired-image-thumbnail--initialize-buffer))
  (dolist (file dired-image-thumbnail--current-images)
    (let ((is-marked (dired-image-thumbnail--file-marked-p file)))
      (if is-marked
          ;; Unmark
          (when (and dired-image-thumbnail--dired-buffer
                     (buffer-live-p dired-image-thumbnail--dired-buffer))
            (with-current-buffer dired-image-thumbnail--dired-buffer
              (save-excursion
                (goto-char (point-min))
                (when (dired-goto-file file)
                  (dired-unmark 1)))))
        ;; Mark
        (when (and dired-image-thumbnail--dired-buffer
                   (buffer-live-p dired-image-thumbnail--dired-buffer))
          (with-current-buffer dired-image-thumbnail--dired-buffer
            (save-excursion
              (goto-char (point-min))
              (when (dired-goto-file file)
                (dired-mark 1))))))))
  ;; Update all thumbnail marks using image-dired's function
  (image-dired--thumb-update-marks)
  (message "%d images now marked" (dired-image-thumbnail--count-marked)))

;;; File operations

(defun dired-image-thumbnail-goto-dired ()
  "Switch to the associated Dired buffer."
  (interactive)
  (if (and dired-image-thumbnail--dired-buffer
           (buffer-live-p dired-image-thumbnail--dired-buffer))
      (pop-to-buffer dired-image-thumbnail--dired-buffer)
    (when dired-image-thumbnail--source-dir
      (dired dired-image-thumbnail--source-dir))))

(defun dired-image-thumbnail-get-marked ()
  "Return list of marked images, or image at/near point if none marked."
  (unless dired-image-thumbnail--all-images
    (dired-image-thumbnail--initialize-buffer))
  (let ((marked (when dired-image-thumbnail--current-images
                  (let ((marked-set (dired-image-thumbnail--get-dired-marked-set)))
                    (seq-filter (lambda (file) (gethash file marked-set))
                                dired-image-thumbnail--current-images)))))
    (or marked
        (when-let ((file (dired-image-thumbnail--nearest-image-original-file-name)))
          (list file)))))

(defun dired-image-thumbnail-delete-marked ()
  "Delete marked images (or image at point if none marked)."
  (interactive)
  (let ((files (dired-image-thumbnail-get-marked)))
    (unless files
      (user-error "No images to delete"))
    (when (or dired-image-thumbnail-auto-accept
              (yes-or-no-p (format "Delete %d image(s)? " (length files))))
      (dolist (file files)
        (delete-file file t)
        (setq dired-image-thumbnail--current-images
              (remove file dired-image-thumbnail--current-images))
        (setq dired-image-thumbnail--all-images
              (remove file dired-image-thumbnail--all-images)))
      ;; Refresh dired buffer
      (when (and dired-image-thumbnail--dired-buffer
                 (buffer-live-p dired-image-thumbnail--dired-buffer))
        (with-current-buffer dired-image-thumbnail--dired-buffer
          (revert-buffer)))
      (dired-image-thumbnail-refresh)
      (message "Deleted %d image(s)" (length files)))))

(defun dired-image-thumbnail-open-external ()
  "Open the image at point in an external editor.
Uses `dired-image-thumbnail-external-editor' if set, otherwise
the system default application."
  (interactive)
  (if-let ((file (dired-image-thumbnail--nearest-image-original-file-name)))
      (let ((program dired-image-thumbnail-external-editor)
            (expanded (expand-file-name file)))
        (if program
            (start-process "dit-external" nil program expanded)
          (cond
           ((eq system-type 'gnu/linux)
            (start-process "dit-external" nil "xdg-open" expanded))
           ((eq system-type 'darwin)
            (start-process "dit-external" nil "open" expanded))
           ((memq system-type '(windows-nt cygwin ms-dos))
            (w32-shell-execute "open" expanded))
           (t (start-process "dit-external" nil "xdg-open" expanded))))
        (message "Opened %s externally" (file-name-nondirectory file)))
    (message "No image at point")))

(defun dired-image-thumbnail-delete ()
  "Delete the image at or near point."
  (interactive)
  (if-let ((file (dired-image-thumbnail--nearest-image-original-file-name)))
      (when (or dired-image-thumbnail-auto-accept
                (yes-or-no-p (format "Delete %s? " (file-name-nondirectory file))))
        ;; Find the next image to move to after deletion
        (let ((index (cl-position file dired-image-thumbnail--current-images :test #'equal)))
          (delete-file file t)
          (setq dired-image-thumbnail--current-images
                (remove file dired-image-thumbnail--current-images))
          (setq dired-image-thumbnail--all-images
                (remove file dired-image-thumbnail--all-images))
          ;; Refresh dired buffer
          (when (and dired-image-thumbnail--dired-buffer
                     (buffer-live-p dired-image-thumbnail--dired-buffer))
            (with-current-buffer dired-image-thumbnail--dired-buffer
              (revert-buffer)))
          (dired-image-thumbnail-refresh)
          ;; Move to the same index position (or last if we deleted the last one)
          (when dired-image-thumbnail--current-images
            (let ((target-index (min index (1- (length dired-image-thumbnail--current-images)))))
              (dired-image-thumbnail--goto-nth target-index)))
          (message "Deleted %s" (file-name-nondirectory file))))
    (user-error "No image at point")))

(defun dired-image-thumbnail--goto-nth (n)
  "Move point to the Nth thumbnail (0-indexed)."
  (goto-char (point-min))
  (dotimes (_ n)
    (image-dired-forward-image)))

(defun dired-image-thumbnail-toggle-wrap ()
  "Toggle between wrap display and standard line-up."
  (interactive)
  (unless dired-image-thumbnail--all-images
    (dired-image-thumbnail--initialize-buffer))
  (setq dired-image-thumbnail-wrap-display (not dired-image-thumbnail-wrap-display))
  (dired-image-thumbnail-refresh)
  (message "Wrap display: %s" (if dired-image-thumbnail-wrap-display "ON" "OFF")))

;;; Other commands

(defun dired-image-thumbnail-help ()
  "Show help for image thumbnail commands."
  (interactive)
  (with-help-window "*Image Thumbnail Help*"
    (princ "Image Thumbnail Mode Commands:\n\n")
    (princ "Navigation:\n")
    (princ "  n, →         Next image")
    (when dired-image-thumbnail-auto-display-on-navigate
      (princ " (auto-display)"))
    (princ "\n")
    (princ "  p, ←         Previous image")
    (when dired-image-thumbnail-auto-display-on-navigate
      (princ " (auto-display)"))
    (princ "\n")
    (princ "  +/-          Increase/decrease size\n\n")
    (princ "Marking:\n")
    (princ "  m            Mark image (visual border)\n")
    (princ "  u            Unmark image\n")
    (princ "  U            Unmark all\n")
    (princ "  M            Mark all\n")
    (princ "  t            Toggle all marks\n\n")
    (princ "File Operations:\n")
    (princ "  D            Delete image at point\n")
    (princ "  C-d          Delete image and move to next\n")
    (princ "  x            Delete marked images\n")
    (princ "  d            Go to Dired buffer\n\n")
    (princ "Display:\n")
    (princ "  r, g         Refresh display\n")
    (princ "  G            Hard refresh (clear cache and reload)\n")
    (princ "  w            Toggle wrap mode\n")
    (princ "  Q            Cycle display quality (full/high/fast/faster/draft)\n\n")
    (princ "Sorting (s prefix):\n")
    (princ "  sb           Sort by Dired buffer order\n")
    (princ "  sn           Sort by name\n")
    (princ "  sd           Sort by date\n")
    (princ "  ss           Sort by size\n")
    (princ "  sr           Reverse sort order\n\n")
    (princ "Filtering (/ prefix):\n")
    (princ "  /n           Filter by name\n")
    (princ "  /s           Filter by size\n")
    (princ "  /c           Clear filters\n\n")
    (princ "Subdirectories:\n")
    (princ "  Use 'i' in dired to insert subdirectories, or:\n")
    (princ "  M-x dired-image-thumbnail-insert-subdir-recursive\n")
    (princ "  M-x dired-image-thumbnail-insert-image-subdirs\n")
    (princ "  M-x dired-image-thumbnail-kill-all-subdirs\n\n")
    (princ "In Image Display Buffer:\n")
    (princ "  C-d          Delete image and move to next\n\n")
    (princ "Other:\n")
    (princ "  W            Open in external editor\n")
    (princ "  q            Quit window\n")
    (princ "  h, ?         This help\n")))

;;; Main entry point

(defun dired-image-thumbnail--find-subdirs (directory &optional max-depth)
  "Return a list of all subdirectories under DIRECTORY.
Does not include DIRECTORY itself.
Optional MAX-DEPTH limits recursion (nil means unlimited, 1 means direct children only)."
  (let ((subdirs nil)
        (dirs-to-process (list (cons directory 0))))
    (while dirs-to-process
      (let* ((item (pop dirs-to-process))
             (current-dir (car item))
             (current-depth (cdr item)))
        (dolist (file (directory-files current-dir t "^[^.]" t))
          (when (and (file-directory-p file)
                     (not (member (file-name-nondirectory file) '("." ".."))))
            (push file subdirs)
            ;; Only recurse if we haven't hit max depth
            (when (or (null max-depth) (< (1+ current-depth) max-depth))
              (push (cons file (1+ current-depth)) dirs-to-process))))))
    (nreverse subdirs)))

(defun dired-image-thumbnail--find-image-subdirs (directory &optional max-depth)
  "Return subdirectories under DIRECTORY that contain image files.
Optional MAX-DEPTH limits recursion depth."
  (let ((all-subdirs (dired-image-thumbnail--find-subdirs directory max-depth))
        (image-subdirs nil))
    (dolist (subdir all-subdirs)
      (when (dired-image-thumbnail--directory-has-images-p subdir)
        (push subdir image-subdirs)))
    (nreverse image-subdirs)))

(defun dired-image-thumbnail--directory-has-images-p (directory)
  "Return non-nil if DIRECTORY contains image files (non-recursive check)."
  (cl-some (lambda (file)
             (and (not (file-directory-p file))
                  (dired-image-thumbnail--image-p file)))
           (directory-files directory t "^[^.]" t)))

(defun dired-image-thumbnail--insert-subdirs (subdirs)
  "Insert SUBDIRS into the current dired buffer.
SUBDIRS should be a list of directory paths."
  (let ((inserted 0))
    (dolist (subdir subdirs)
      (let ((subdir-path (file-name-as-directory subdir)))
        (condition-case err
            (progn
              (save-excursion
                ;; Check if this subdir is already inserted
                (goto-char (point-min))
                (unless (re-search-forward 
                        (concat "^  " (regexp-quote subdir-path) ":$") 
                        nil t)
                  (goto-char (point-max))
                  (dired-insert-subdir subdir-path)
                  (setq inserted (1+ inserted)))))
          (error
           (message "Could not insert subdir %s: %s" subdir-path err)))))
    inserted))

;;;###autoload
(defun dired-image-thumbnail ()
  "Display thumbnails for image files in current dired buffer.
If files are marked, show thumbnails for marked images only.
Otherwise, show thumbnails for all images visible in the dired buffer.

This works with inserted subdirectories - use 'i' (`dired-maybe-insert-subdir`)
to insert subdirectories before calling this command to include images from
those subdirectories. See `dired-image-thumbnail-insert-subdir-recursive'
for a helper to insert all subdirectories at once.

This function calls vanilla `image-dired' which triggers our hooks for
enhanced features like sorting and filtering."
  (interactive)
  (unless (derived-mode-p 'dired-mode)
    (user-error "Not in a dired buffer"))
  (let ((dired-buf (current-buffer))
        (source-dir default-directory))
    ;; Store state for our hooks to use
    (setq-local dired-image-thumbnail--source-dir source-dir)
    (setq-local dired-image-thumbnail--dired-buffer dired-buf)
    
    ;; Call vanilla image-dired which will trigger our hooks and enhancements
    (call-interactively 'image-dired)
    
    ;; Now refresh the thumbnail buffer with our enhancements
    ;; We need to find the thumbnail buffer first
    (when-let ((thumb-buf (get-buffer image-dired-thumbnail-buffer)))
      (with-current-buffer thumb-buf
        ;; Reset state so initialization re-scans from the new dired buffer
        (setq dired-image-thumbnail--all-images nil)
        (setq dired-image-thumbnail--current-images nil)
        (setq dired-image-thumbnail--dired-buffer dired-buf)
        (setq dired-image-thumbnail--source-dir source-dir)
        (setq dired-image-thumbnail--filter-name nil)
        (setq dired-image-thumbnail--filter-size-min nil)
        (setq dired-image-thumbnail--filter-size-max nil))
      ;; Apply the layout BEFORE refresh so that line-up sees the
      ;; correct (narrower) window width for column calculation.
      (dired-image-thumbnail--apply-layout)
      (with-current-buffer thumb-buf
        (dired-image-thumbnail-refresh)
        (goto-char (point-min))
        ;; Display the first image
        (dired-image-thumbnail--display-this)))))

;;;###autoload
(defun dired-image-thumbnail-insert-subdir-recursive (&optional max-depth)
  "Insert all subdirectories recursively into the current dired buffer.
Optional MAX-DEPTH limits recursion depth (nil means unlimited).
This makes images in subdirectories visible to `dired-image-thumbnail'.

Note: This can be slow for directories with many subdirectories.
Consider using `dired-image-thumbnail-insert-image-subdirs' instead,
which only inserts subdirectories that contain images."
  (interactive "P")
  (unless (derived-mode-p 'dired-mode)
    (user-error "Not in a dired buffer"))
  (let* ((depth (if max-depth (prefix-numeric-value max-depth) nil))
         (subdirs (dired-image-thumbnail--find-subdirs default-directory depth)))
    (if subdirs
        (progn
          (message "Inserting %d subdirectories..." (length subdirs))
          (dired-image-thumbnail--insert-subdirs subdirs)
          (message "Inserted %d subdirectories" (length subdirs)))
      (message "No subdirectories found"))))

;;;###autoload
(defun dired-image-thumbnail-insert-image-subdirs (&optional max-depth)
  "Insert only subdirectories that contain image files.
Optional MAX-DEPTH limits recursion depth (nil means unlimited).
This is more efficient than `dired-image-thumbnail-insert-subdir-recursive'
for directories with many non-image subdirectories."
  (interactive "P")
  (unless (derived-mode-p 'dired-mode)
    (user-error "Not in a dired buffer"))
  (let* ((depth (if max-depth (prefix-numeric-value max-depth) nil))
         (subdirs (dired-image-thumbnail--find-image-subdirs default-directory depth)))
    (if subdirs
        (progn
          (message "Inserting %d subdirectories with images..." (length subdirs))
          (dired-image-thumbnail--insert-subdirs subdirs)
          (message "Inserted %d subdirectories" (length subdirs)))
      (message "No subdirectories with images found"))))

;;;###autoload
(defun dired-image-thumbnail-kill-all-subdirs ()
  "Remove all inserted subdirectories from the current dired buffer.
This returns the view to just the top-level directory."
  (interactive)
  (unless (derived-mode-p 'dired-mode)
    (user-error "Not in a dired buffer"))
  (let ((count 0))
    (save-excursion
      (goto-char (point-max))
      ;; Work backwards to avoid position issues
      (while (dired-get-subdir)
        (dired-kill-subdir)
        (setq count (1+ count))))
    (if (> count 0)
        (message "Removed %d subdirectories" count)
      (message "No subdirectories to remove"))))

;;; Keymaps

(defvar dired-image-thumbnail-sort-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "b") #'dired-image-thumbnail-sort-by-dired)
    (define-key map (kbd "n") #'dired-image-thumbnail-sort-by-name)
    (define-key map (kbd "d") #'dired-image-thumbnail-sort-by-date)
    (define-key map (kbd "s") #'dired-image-thumbnail-sort-by-size)
    (define-key map (kbd "r") #'dired-image-thumbnail-sort-reverse)
    map)
  "Keymap for sorting commands.")

(defvar dired-image-thumbnail-filter-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "n") #'dired-image-thumbnail-filter-by-name)
    (define-key map (kbd "s") #'dired-image-thumbnail-filter-by-size)
    (define-key map (kbd "/") #'dired-image-thumbnail-filter-clear)
    (define-key map (kbd "c") #'dired-image-thumbnail-filter-clear)
    map)
  "Keymap for filtering commands.")

;;;###autoload
(defun dired-image-thumbnail-setup-keys ()
  "Add dired-image-thumbnail keybindings to `image-dired-thumbnail-mode-map'."
  (define-key image-dired-thumbnail-mode-map (kbd "s") dired-image-thumbnail-sort-map)
  (define-key image-dired-thumbnail-mode-map (kbd "S") #'dired-image-thumbnail-sort)
  (define-key image-dired-thumbnail-mode-map (kbd "/") dired-image-thumbnail-filter-map)
  (define-key image-dired-thumbnail-mode-map (kbd "\\") #'dired-image-thumbnail-filter)
  (define-key image-dired-thumbnail-mode-map (kbd "w") #'dired-image-thumbnail-toggle-wrap)
  (define-key image-dired-thumbnail-mode-map (kbd "r") #'dired-image-thumbnail-refresh)
  (define-key image-dired-thumbnail-mode-map (kbd "g") #'dired-image-thumbnail-refresh)
  (define-key image-dired-thumbnail-mode-map (kbd "G") #'dired-image-thumbnail-hard-refresh)
  (define-key image-dired-thumbnail-mode-map (kbd "+") #'dired-image-thumbnail-increase-size)
  (define-key image-dired-thumbnail-mode-map (kbd "-") #'dired-image-thumbnail-decrease-size)
  ;; Marking
  (define-key image-dired-thumbnail-mode-map (kbd "M") #'dired-image-thumbnail-mark-all)
  (define-key image-dired-thumbnail-mode-map (kbd "t") #'dired-image-thumbnail-toggle-all-marks)
  ;; File operations
  (define-key image-dired-thumbnail-mode-map (kbd "d") #'dired-image-thumbnail-goto-dired)
  (define-key image-dired-thumbnail-mode-map (kbd "D") #'dired-image-thumbnail-delete)
  (define-key image-dired-thumbnail-mode-map (kbd "C-d") #'dired-image-thumbnail-delete-and-next)
  (define-key image-dired-thumbnail-mode-map (kbd "x") #'dired-image-thumbnail-delete-marked)
  ;; Enhanced navigation (auto-display checked at runtime)
  (define-key image-dired-thumbnail-mode-map (kbd "n") #'dired-image-thumbnail-next-image)
  (define-key image-dired-thumbnail-mode-map (kbd "p") #'dired-image-thumbnail-previous-image)
  ;; Display quality
  (define-key image-dired-thumbnail-mode-map (kbd "Q") #'dired-image-thumbnail-cycle-display-quality)
  ;; External
  (define-key image-dired-thumbnail-mode-map (kbd "W") #'dired-image-thumbnail-open-external)
  ;; Other
  (define-key image-dired-thumbnail-mode-map (kbd "?") #'dired-image-thumbnail-help)
  (define-key image-dired-thumbnail-mode-map (kbd "h") #'dired-image-thumbnail-help))

;;; Fast image display

(defun dired-image-thumbnail--quality-scale ()
  "Return the scale factor for `dired-image-thumbnail-display-quality'."
  (pcase dired-image-thumbnail-display-quality
    ('high  1.0)
    ('fast  0.5)
    ('faster 0.25)
    ('draft 0.125)
    (_ nil)))

(defvar dired-image-thumbnail--preview-dir nil
  "Temporary directory for preview images.")

(defun dired-image-thumbnail--preview-dir ()
  "Return the temporary directory for preview images, creating it if needed."
  (unless (and dired-image-thumbnail--preview-dir
               (file-directory-p dired-image-thumbnail--preview-dir))
    (setq dired-image-thumbnail--preview-dir
          (make-temp-file "dired-image-preview-" t)))
  dired-image-thumbnail--preview-dir)

(defun dired-image-thumbnail--jpeg-p (file)
  "Return non-nil if FILE is a JPEG."
  (member (downcase (or (file-name-extension file) ""))
          '("jpg" "jpeg")))

(defun dired-image-thumbnail--djpeg-scale (quality-scale)
  "Return the best djpeg DCT scale fraction for QUALITY-SCALE.
djpeg supports 1/1, 1/2, 1/4, 1/8.  Maps the quality scale factor
directly to the nearest djpeg fraction."
  (cond ((<= quality-scale 0.125) "1/8")
        ((<= quality-scale 0.25)  "1/4")
        ((<= quality-scale 0.5)   "1/2")
        (t                         "1/1")))

(defun dired-image-thumbnail--make-preview (file width height)
  "Create a preview of FILE at WIDTH x HEIGHT pixels.
Returns the path to the preview file.
For JPEGs, uses djpeg/cjpeg with DCT scaling (very fast).
For other formats, uses magick/convert with -thumbnail."
  (let* ((preview-name (concat (sha1 (concat file (number-to-string width)))
                               ".jpg"))
         (preview-path (expand-file-name preview-name
                                         (dired-image-thumbnail--preview-dir))))
    (unless (file-exists-p preview-path)
      (let ((expanded (expand-file-name file)))
        (if (and (dired-image-thumbnail--jpeg-p file)
                 (executable-find "djpeg")
                 (executable-find "cjpeg"))
            ;; Fast path: djpeg DCT scaling + cjpeg (skips full decode)
            (let ((scale-str (dired-image-thumbnail--djpeg-scale
                              (dired-image-thumbnail--quality-scale))))
              (call-process-shell-command
               (format "djpeg -scale %s %s | cjpeg -quality 50 > %s"
                       scale-str
                       (shell-quote-argument expanded)
                       (shell-quote-argument preview-path))
               nil nil nil))
          ;; Fallback: magick/convert -thumbnail
          (let ((magick (or (executable-find "magick")
                            (executable-find "convert"))))
            (when magick
              (call-process magick nil nil nil
                            expanded
                            "-thumbnail" (format "%dx%d" width height)
                            "-quality" "50"
                            preview-path))))))
    (if (file-exists-p preview-path)
        preview-path
      file)))

(defun dired-image-thumbnail--display-image-fast (file)
  "Display FILE scaled according to `dired-image-thumbnail-display-quality'.
For `high' quality, loads the file directly with window-fitting constraints.
For lower qualities, produces a small preview via an external tool so that
Emacs never decodes the full image."
  (setq file (expand-file-name file))
  (unless (file-exists-p file)
    (error "No such file: %s" file))
  (let* ((scale (dired-image-thumbnail--quality-scale))
         (buf (get-buffer-create image-dired-display-image-buffer))
         (cur-win (selected-window))
         (display-win (or (get-buffer-window buf)
                          (progn
                            (display-buffer buf)
                            (get-buffer-window buf))))
         (win-width (or (and display-win (window-body-width display-win t)) 800))
         (win-height (or (and display-win (window-body-height display-win t)) 600))
         (decode-w (max 1 (truncate (* win-width scale))))
         (decode-h (max 1 (truncate (* win-height scale))))
         ;; For high quality, load original; otherwise make a small preview
         (display-file (if (>= scale 1.0)
                           file
                         (dired-image-thumbnail--make-preview file decode-w decode-h)))
         ;; Load the (possibly small) file and fit to window
         (img (create-image display-file nil nil
                            :max-width win-width
                            :max-height win-height)))
    (with-current-buffer buf
      ;; Use special-mode for a clean read-only buffer with q to quit.
      ;; Do NOT use image-dired-image-mode or image-mode here — they
      ;; set up image-fit-to-window timers that expect a file-visiting
      ;; buffer and fail on our manually inserted image descriptor.
      (unless (derived-mode-p 'special-mode)
        (special-mode))
      (let ((inhibit-read-only t))
        (erase-buffer)
        (insert-image img)
        (goto-char (point-min)))
      (setq cursor-type nil))
    (when display-win
      (set-window-buffer display-win buf))
    (select-window cur-win)))

(defun dired-image-thumbnail--display-this ()
  "Display the current thumbnail's image.
Uses fast scaled display unless quality is `full'."
  (if (dired-image-thumbnail--quality-scale)
      (let ((file (image-dired-original-file-name)))
        (cond ((not (image-dired-image-at-point-p))
               (message "No thumbnail at point"))
              ((not file)
               (message "No original file name found"))
              (t
               (dired-image-thumbnail--display-image-fast file))))
    (image-dired-display-this)))

;;; Enhanced navigation and deletion

(defun dired-image-thumbnail-cycle-display-quality ()
  "Cycle through display quality levels.
Order: fast -> faster -> draft -> high -> full -> fast ..."
  (interactive)
  (setq dired-image-thumbnail-display-quality
        (pcase dired-image-thumbnail-display-quality
          ('full   'high)
          ('high   'fast)
          ('fast   'faster)
          ('faster 'draft)
          ('draft  'full)
          (_       'fast)))
  (message "Display quality: %s" dired-image-thumbnail-display-quality)
  (image-dired--update-header-line)
  (dired-image-thumbnail--display-this))

(defun dired-image-thumbnail-next-image ()
  "Move to next thumbnail and optionally display full-size image.
When `dired-image-thumbnail-auto-display-on-navigate' is non-nil,
the full-size image is automatically displayed."
  (interactive)
  (image-dired-forward-image)
  (when dired-image-thumbnail-auto-display-on-navigate
    (dired-image-thumbnail--display-this)))

(defun dired-image-thumbnail-previous-image ()
  "Move to previous thumbnail and optionally display full-size image.
When `dired-image-thumbnail-auto-display-on-navigate' is non-nil,
the full-size image is automatically displayed."
  (interactive)
  (image-dired-backward-image)
  (when dired-image-thumbnail-auto-display-on-navigate
    (dired-image-thumbnail--display-this)))

(defun dired-image-thumbnail-delete-and-next ()
  "Delete current image file and move to next thumbnail.
This permanently deletes the file from disk and removes its thumbnail."
  (interactive)
  (let ((file-name (image-dired-original-file-name)))
    (when (and file-name
               (or dired-image-thumbnail-auto-accept
                   (y-or-n-p (format "Delete %s? " (file-name-nondirectory file-name)))))
      (delete-file file-name)
      (setq dired-image-thumbnail--current-images
            (remove file-name dired-image-thumbnail--current-images))
      (setq dired-image-thumbnail--all-images
            (remove file-name dired-image-thumbnail--all-images))
      (image-dired-delete-char)
      (when (not (eobp))
        (dired-image-thumbnail--display-this))
      (message "Deleted %s" file-name))))

(defun dired-image-thumbnail-delete-image-and-next ()
  "Delete current image displayed in the image-dired display buffer.
Gets the current file from the thumbnail buffer's text properties,
since the display buffer is not a file-visiting buffer."
  (interactive)
  (let ((current-file
         (or (buffer-file-name)
             (when-let ((thumb-buf (get-buffer image-dired-thumbnail-buffer)))
               (with-current-buffer thumb-buf
                 (image-dired-original-file-name))))))
    (when (and current-file
               (or dired-image-thumbnail-auto-accept
                   (y-or-n-p (format "Delete %s? " (file-name-nondirectory current-file)))))
      ;; Update internal lists in the thumbnail buffer
      (when-let ((thumb-buf (get-buffer image-dired-thumbnail-buffer)))
        (with-current-buffer thumb-buf
          (setq dired-image-thumbnail--current-images
                (remove current-file dired-image-thumbnail--current-images))
          (setq dired-image-thumbnail--all-images
                (remove current-file dired-image-thumbnail--all-images))
          (image-dired-forward-image)
          (dired-image-thumbnail--display-this)))
      (delete-file current-file)
      (message "Deleted %s" current-file))))

;;; Window layout management

(defun dired-image-thumbnail--apply-layout ()
  "Set up the thumbnail and image windows according to `dired-image-thumbnail-window-layout'.
Called from `dired-image-thumbnail' after buffers have been created."
  (when-let ((layout dired-image-thumbnail-window-layout)
             (thumb-buf (get-buffer image-dired-thumbnail-buffer)))
    (delete-other-windows)
    (if (eq layout 'thumb-only)
        (switch-to-buffer thumb-buf)
      (let* ((ratio dired-image-thumbnail-window-ratio)
             (horizontal (memq layout '(left-right right-left)))
             (thumb-first (memq layout '(left-right top-bottom)))
             (img-buf (get-buffer-create image-dired-display-image-buffer))
             (first-buf (if thumb-first thumb-buf img-buf))
             (second-buf (if thumb-first img-buf thumb-buf))
             (size (if horizontal
                       (round (* (frame-width) (if thumb-first ratio (- 1.0 ratio))))
                     (round (* (frame-height) (if thumb-first ratio (- 1.0 ratio)))))))
        (switch-to-buffer first-buf)
        (if horizontal
            (split-window-right size)
          (split-window-below size))
        (other-window 1)
        (switch-to-buffer second-buf)
        ;; Leave focus on the thumbnail buffer
        (select-window (get-buffer-window thumb-buf))))))

(defun dired-image-thumbnail-setup-display-buffer ()
  "Configure `display-buffer-alist' rules for thumbnail and image buffers.
Only adds rules when `dired-image-thumbnail-window-layout' is non-nil,
so that `display-buffer' respects the layout for subsequent pop-to-buffer
calls (e.g. when the image window is reused during navigation)."
  (when dired-image-thumbnail-window-layout
    (let* ((layout dired-image-thumbnail-window-layout)
           (horizontal (memq layout '(left-right right-left)))
           (thumb-first (memq layout '(left-right top-bottom)))
           (ratio dired-image-thumbnail-window-ratio)
           (thumb-dir (if thumb-first
                          (if horizontal 'left 'above)
                        (if horizontal 'right 'below)))
           (img-dir (if thumb-first
                        (if horizontal 'right 'below)
                      (if horizontal 'left 'above)))
           (thumb-size (if horizontal
                          `(window-width . ,ratio)
                        `(window-height . ,ratio)))
           (img-size (if horizontal
                        `(window-width . ,(- 1.0 ratio))
                      `(window-height . ,(- 1.0 ratio)))))
      (add-to-list 'display-buffer-alist
                   `("\\*image-dired\\*"
                     display-buffer-in-direction
                     (direction . ,thumb-dir)
                     (window . root)
                     ,thumb-size))
      (unless (eq layout 'thumb-only)
        (add-to-list 'display-buffer-alist
                     `("\\*image-dired-display-image\\*"
                       display-buffer-in-direction
                       (direction . ,img-dir)
                       (window . root)
                       ,img-size))))))

;;;###autoload
(with-eval-after-load 'image-dired
  (dired-image-thumbnail-setup-keys)
  (dired-image-thumbnail-setup-display-buffer)
  (advice-add 'image-dired-format-properties-string :around #'dired-image-thumbnail--format-properties-string)
  ;; Hook to initialize our variables when entering thumbnail mode
  (add-hook 'image-dired-thumbnail-mode-hook #'dired-image-thumbnail--initialize-buffer))

;;;###autoload
(with-eval-after-load 'image-dired
  ;; Scope C-d to the image-dired display buffer only
  (when (boundp 'image-dired-display-image-mode-map)
    (define-key image-dired-display-image-mode-map (kbd "C-d") #'dired-image-thumbnail-delete-image-and-next)))

;; Load transient menu support if available
(when (require 'dired-image-thumbnail-transient nil t)
  (dired-image-thumbnail-transient-setup-keys))

(provide 'dired-image-thumbnail)
;;; dired-image-thumbnail.el ends here
