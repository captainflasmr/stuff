# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Architecture

This is a **literate programming** repository. `README.org` is the canonical source of truth — `init.el` is **generated** from it via org-babel tangle and must never be edited directly.

The tangle target is set globally: `#+property: header-args :tangle ~/.emacs.d/Emacs-DIYer/init.el`. All `#+begin_src elisp` blocks tangle to `init.el` unless marked `:tangle no`.

### Purpose

Each section in README.org documents a DIY replacement for a popular Emacs package, implemented using only built-in Emacs features (no external packages). Sections are tracked with TODO states:

- `DONE` — replacement fully implemented and tangled into `init.el`
- `DOING` — work in progress
- `TODO` — planned replacement

### Current Implementations (DONE)

elfeed → newsticker, csv → csv-parse-buffer, ace-window → my/quick-window-jump, rainbow-mode → my/rainbow-mode, visual-fill-column → toggle-centered-buffer, magit → built-in VC, tempel → snippets, image-dired, deadgrep → ripgrep integration, kurecolor, popper, all-the-icons-dired → nerd-font overlays, diminish, emacs-everywhere, evil-mode → view-mode tweaks, spray/speedread → RSVP

## Commands

**Tangle README.org to regenerate init.el** (run from repo root):
```bash
emacs --batch -l org --eval "(org-babel-tangle-file \"README.org\")"
```

**Syntax check generated init.el:**
```bash
emacs -batch -f batch-byte-compile init.el
```

**Validate config loads without error:**
```bash
emacs -q -l ~/.emacs.d/Emacs-DIYer/init.el --eval '(message "OK")'
```

## Code Style

- Always include `; -*- lexical-binding: t; -*-` at file top (already in the first src block of README.org)
- Function naming: `my/function-name` or `my-function-name` for personal functions; predicates use `-p` suffix
- Lines ≤100 characters; 2-space indentation
- Use `condition-case` for recoverable errors, `ignore-errors` for non-critical ones
- When adding a new implementation to README.org, follow the existing section structure: `** DONE package-name` heading with prose description, then `#+begin_src elisp` ... `#+end_src`
