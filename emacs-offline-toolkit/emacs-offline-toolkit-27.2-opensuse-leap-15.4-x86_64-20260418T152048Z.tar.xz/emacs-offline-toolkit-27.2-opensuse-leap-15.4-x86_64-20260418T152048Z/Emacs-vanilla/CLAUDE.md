# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Overview

Emacs-vanilla is a standalone, package-free Emacs configuration targeting Emacs 27.2+ (also 28.2, 29.4). It uses only built-in features, making it suitable for VMs, air-gapped systems, and restricted environments. It runs on SUSE Linux Enterprise (SLES15), SwayWM/Wayland, and Windows 10.

This repo is also Layer 1 of a two-layer config system. The parent `~/.emacs.d/init.el` loads this file first via `(load-file "~/.emacs.d/Emacs-vanilla/init.el")`, then adds third-party packages. At the end of this init.el, it in turn loads `~/.emacs.d/Emacs-DIYer/init.el` (converted single-defun versions of popular packages).

## Build/Validate Commands

**Byte-compile the init file:**
```bash
emacs -batch -f batch-byte-compile init.el
```

**Load and validate configuration:**
```bash
emacs -q -l init.el --eval '(message "Config loaded successfully")'
```

**Build multiple Emacs versions for testing:**
```bash
./build-emacs-versions.sh
```

## File Structure

- `init.el` (~1986 lines) - The entire configuration in a single file
- `README.org` - Literate org-mode source (tangles to `init.el` via `:tangle` header-args)
- `CHANGELOG.org` - Release notes
- `build-emacs-versions.sh` - Script to compile Emacs 27.2/28.2/29.4/30.1 from source
- `wowee/` - Git submodule (theme: `captainflasmr/wowee`)
- `my-dictionary` - Personal ispell dictionary
- `abbrev_defs` - Abbreviation definitions
- `*.xkb` - Custom keyboard layouts (locked/sticky modifiers)

## init.el Section Organization

The file uses `;;` followed by `-> section-name` as navigable section markers. Major functional groups:

| Section | Lines | Purpose |
|---|---|---|
| `requires-core` | Top | Core requires (org, grep, bookmark, dired, ox-md) |
| `completion-core` / `modeline-completion-core` | ~13-58 | fido-vertical-mode, hippie-expand, icomplete styling |
| `keys-navigation-core` | ~61 | `M-l` jump keymap to common files/dirs |
| `keybinding-core` | ~243 | Global keybindings (windmove, tab-bar, scroll, etc.) |
| `defun-core` | ~393 | ~70+ custom `my/` utility functions |
| `window-positioning-core` | ~782 | `display-buffer-alist` rules for shells, grep, compilation |
| `org-core` / `org-agenda-core` | ~824 | Org-mode settings, TODO keywords, agenda commands |
| `dired-core` | ~893 | Dired customizations and helpers |
| `ada-core` | ~1328 | Full `ada-light-mode` major mode with eglot integration |
| `dwim` | ~1567 | Dired/image-dired shell command integration (PictureTag, etc.) |
| `publishing-core` | ~1735 | HTML/DOCX export pipeline |
| `gh-release-core` | ~1768 | GitHub release management via `gh` CLI |
| `core-configuration` | ~1978 | Loads `Emacs-DIYer/init.el` |

## Key Architectural Patterns

**Version compatibility**: Code must work across Emacs 27.2-29.4. Use `fboundp` checks before calling newer APIs (e.g., `fido-vertical-mode` falls back to `fido-mode`). Avoid tree-sitter or other 29+ only features in core paths.

**ada-light-mode**: A complete built-in Ada major mode (`ada-light-mode`, `gpr-light-mode`) with syntax highlighting, indentation, imenu, and eglot LSP integration. It's self-contained within the `ada-core` section and `provide`s itself.

**dwim media commands**: Functions in the `dwim` section shell out to external `~/bin` scripts (PictureTag, PictureCrush, VideoConvert, etc.) operating on dired-marked or image-dired files. These are conditionally loaded only when `~/bin/category-list-uniq.txt` exists.

**gh-release-core**: A `special-mode` derived mode (`my/gh-release-mode`) for managing GitHub releases. Uses `gh` CLI. Bound to `C-c G`.

**Window management**: Extensive `display-buffer-alist` rules route shells/terms to bottom (30% height), grep/compilation to leftmost (30-40% width), and help/messages to same-window.

## Keybinding Prefixes

- `M-l` - Jump keymap (files/directories)
- `M-s` - Search/edit (ediff, grep, buffer ops)
- `C-M-{h,j,k,l}` - Windmove (left, down, up, right)
- `M-{H,J,K,L}` - Window resize
- `M-[` - Shell menu
- `C-c G` - GitHub releases menu
- `C-c e` - Export/publishing menu
- `C-t t` - Picture tag/rename pipeline

## Code Style

- `; -*- lexical-binding: t; -*-` at file top
- Lines <= 100 characters, 2-space indentation
- Section headers: `;;` with `-> section-name` format
- Function naming: `my/function-name` or `my-function-name` for personal functions
- Predicates: `<name>-p` suffix
- Use `condition-case` for recoverable errors, `ignore-errors` for non-critical
- The README.org is the literate source; changes can be made in either file but keep them in sync
