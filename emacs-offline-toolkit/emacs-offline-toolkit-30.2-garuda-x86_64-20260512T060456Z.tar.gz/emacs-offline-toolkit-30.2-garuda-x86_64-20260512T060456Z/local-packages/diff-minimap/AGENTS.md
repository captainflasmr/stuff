# AGENTS.md — diff-minimap

Single-file Emacs package (`diff-minimap.el`). No build, no test runner, no CI.

## Entrypoint

- `diff-minimap-toggle` (or `C-x v m`) — opens/closes a colour-coded diff minimap side window.
- Requires `diff-hl-mode` to be active in the source buffer; otherwise a no-op.

## Validation

No automated tests exist. Manual validation only:

```bash
emacs -Q -batch -f batch-byte-compile diff-minimap.el
```

Inspect `diff-minimap.el` for unbalanced parens, free variable references, and missing `require` forms. Load in an Emacs session with `diff-hl-mode` enabled on a file with VCS changes, toggle the minimap, scroll, and verify colours update.

## Dependencies

- Emacs 27.1+, `diff-hl` (runtime), `cl-lib` (built-in).
- Loaded via `load-path` — no ELPA/MELPA `:ensure`.
- `lexical-binding: t`.

## Structure

All code lives in `diff-minimap.el` (257 lines). Customisation group `diff-minimap` with three `defcustom`s: `diff-minimap-font-scale` (0.4), `diff-minimap-width` (8), `diff-minimap-side` (right). Rendering happens in `diff-minimap--render` on `post-command-hook` (idle-scheduled, 0.02s) and `after-save-hook` (0.1s idle). Click handler uses `source-line`/`source-buf` text properties.

## Gotchas

- Uses `display-buffer-in-side-window` directly rather than `display-buffer-alist` — custom `display-buffer-alist` rules may conflict.
- `diff-minimap--last-ws` dedup skips re-render when `window-start` unchanged, but only set to `nil` on toggle and after-save.
- Buffer name ` *diff-minimap*` (leading space = hidden from buffer list).
