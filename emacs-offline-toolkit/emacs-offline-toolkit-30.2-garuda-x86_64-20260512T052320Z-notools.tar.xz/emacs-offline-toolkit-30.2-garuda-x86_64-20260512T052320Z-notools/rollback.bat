@echo off
setlocal enabledelayedexpansion

set EMACS_D=%USERPROFILE%\.emacs.d
set BACKUPS_DIR=%EMACS_D%\.backups
for /f %%I in ('powershell -Command "Get-Date -Format 'yyyyMMddTHHmmss'"') do set NOW=%%I

:: Find newest backup stamp from directory-based backups.
set LATEST=
for /f %%s in ('dir "%BACKUPS_DIR%" /b /o-d 2^>nul ^| findstr /r "^[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]T[0-9][0-9][0-9][0-9][0-9][0-9]$"') do (
  if not defined LATEST set LATEST=%%s
)

if not defined LATEST (
  echo No backups found under %BACKUPS_DIR%\
  goto :eof
)

echo Available backup stamps (newest first^):
for /f %%s in ('dir "%BACKUPS_DIR%" /b /o-d 2^>nul ^| findstr /r "^[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]T[0-9][0-9][0-9][0-9][0-9][0-9]$"') do (
  if defined LATEST (
    if "%%s"=="!LATEST!" (
      echo   %%s ^<- default
    ) else (
      echo   %%s
    )
  )
)
echo.
set /p ans="Roll back to !LATEST!? [y/N] "
if /i not "!ans!"=="y" (
  echo Aborted.
  goto :eof
)

:: Archive current state so re-rollforward is possible.
set ROLLFORWARD_DIR=%BACKUPS_DIR%\!LATEST!-rolledback
mkdir "!ROLLFORWARD_DIR!" 2>nul

:: Restore from directory backup.
set bak_dir=%BACKUPS_DIR%\!LATEST!
if exist "!bak_dir!" (
  echo ^>^> Restoring from directory backup: !LATEST!

  for %%i in (init.el early-init.el init-starter.el init-starter-coding.el elpa local-packages bin docs Emacs-vanilla Emacs-DIYer) do (
    if exist "!bak_dir!\%%i" (
      if exist "%EMACS_D%\%%i" (
        echo    archiving current %%i -^> !NOW!-rolledback\%%i
        move "%EMACS_D%\%%i" "!ROLLFORWARD_DIR!\%%i" >nul
      )
      echo    restoring %%i
      move "!bak_dir!\%%i" "%EMACS_D%\%%i" >nul
    )
  )

  :: Restore mirror extractions from the home-mirrors/ subdirectory.
  if exist "!bak_dir!\home-mirrors" (
    for /d %%d in ("!bak_dir!\home-mirrors\elpa-mirror-emacs-*") do (
      if exist "%%d" (
        set mirror_name=%%~nxd
        if exist "%USERPROFILE%\!mirror_name!" (
          if not exist "!ROLLFORWARD_DIR!\home-mirrors" mkdir "!ROLLFORWARD_DIR!\home-mirrors"
          echo    archiving current !mirror_name! -^> !NOW!-rolledback\home-mirrors\!mirror_name!
          move "%USERPROFILE%\!mirror_name!" "!ROLLFORWARD_DIR!\home-mirrors\!mirror_name!" >nul
        )
        echo    restoring !mirror_name!
        move "%%d" "%USERPROFILE%\!mirror_name!" >nul
      )
    )
  )

  rmdir "!bak_dir!" 2>nul
)

echo.
echo Rollback complete. Post-install state archived under !ROLLFORWARD_DIR!.
