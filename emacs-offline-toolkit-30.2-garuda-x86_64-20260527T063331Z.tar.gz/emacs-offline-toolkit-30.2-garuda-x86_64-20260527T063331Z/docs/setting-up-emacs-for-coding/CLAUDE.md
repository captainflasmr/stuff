# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Repository Overview

This is a documentation-only repository containing a single Org-mode guide (`README.org`) on setting up Emacs as a modern development environment using built-in and minimal-dependency packages (eglot, flymake, eldoc, corfu, dape, project.el, xref).

The guide covers two worked examples in detail: Java (Linux, JDTLS) and C#/.NET (Windows, csharp-ls/netcoredbg), with general patterns applicable to any LSP/DAP-supported language.

## Structure

- `README.org` — The entire guide, written in Org-mode markup. All content lives here.
- `LICENSE` — GPL-3.0.

There is no build system, no tests, and no source code. Changes to this repo are edits to the Org document.

## Editing Conventions

- The document uses Org-mode syntax: `#+BEGIN_SRC` blocks for code, `*` headings, `|` tables, `[[...][...]]` links.
- Elisp code blocks use `#+begin_src elisp` / `#+end_src`; shell blocks use `#+begin_src bash` or `#+begin_src shell`.
- The guide intentionally favours Emacs built-in packages over third-party alternatives (eglot over lsp-mode, flymake over flycheck, corfu over company).
- Offline/air-gapped deployment is a key concern throughout — do not add advice that assumes internet access without noting the offline alternative.
