# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

QEMU-Manager is a single-file Emacs Lisp package (`qemu-manager.el`) that manages QEMU virtual machines directly from Emacs via a tabulated list buffer. It calls external tools (`qemu-system-x86_64`, `qemu-img`, `vncviewer`, `spicy`, `ssh`, `rsync`) directly -- no wrapper script required.

## Key Dependencies

- Emacs 28.1+
- `transient` 0.4.0+
- External tools: `qemu-system-x86_64`, `qemu-img`, `ss` (port checking), `ssh`, `ssh-copy-id`, `rsync`, `vncviewer`, `spicy`, `virtiofsd` (optional, for shared folders), `wl-copy`/`wl-paste`
- Built-in Emacs libraries: `tabulated-list`, `tramp`

## Architecture

The package has five logical layers in a single file:

1. **Config & state** (`qemu-manager--list-vms`, `qemu-manager--read-conf`, `qemu-manager--write-conf`, `qemu-manager--running-p`, `qemu-manager--disk-size`, `qemu-manager--tramp-path`) -- reads/writes `vm.conf` files and PID files from `~/VM/<name>/` to discover VMs and their state.

2. **Port allocation** (`qemu-manager--port-in-use-p`, `qemu-manager--next-free-port`, `qemu-manager--next-free-vnc`) -- finds free TCP ports via `ss` for SSH, VNC, and SPICE when creating or cloning VMs.

3. **Process helpers** (`qemu-manager--run-process`, `qemu-manager--start-qemu`, `qemu-manager--display-output`) -- `qemu-manager--run-process` runs short-lived commands (qemu-img, cp, viewers) async with output in `*qemu-manager output*`. `qemu-manager--start-qemu` launches long-lived QEMU processes with PID file management and sentinel cleanup.

4. **Interactive commands** (`qemu-manager-start`, `qemu-manager-stop`, `qemu-manager-run`, `qemu-manager-vnc`, `qemu-manager-dired`, `qemu-manager-eshell`, `qemu-manager-info`, `qemu-manager-create`, etc.) -- autoloaded entry points that can be called standalone with `M-x` or from the list buffer.

5. **List buffer UI** (`qemu-manager-list-mode`, `qemu-manager-list`) -- a `tabulated-list-mode` derivative displaying all VMs in `*qemu-manager*`. Keybindings dispatch to the interactive commands using the VM name at point.

## Conventions

- Internal/private functions use the `qemu-manager--` prefix; public commands use `qemu-manager-`.
- VM config files use `KEY="value"` format parsed by regex.
- VM running state is determined by checking PID files with `signal-process`/`kill -0`.
- TRAMP paths are constructed as `/ssh:user@localhost#port:path` or `/ssh:qemu-manager-NAME:path` when SSH config exists.
- QEMU processes are started with `make-process`, detached from buffers, with sentinels that clean up PID files and refresh the VM list on exit.
- `qemu-manager-stop` uses `signal-process` with SIGTERM and polls via `run-with-timer`, escalating to SIGKILL after 10 seconds.
- `qemu-manager-create` chains async commands: `qemu-img create` -> write conf -> `qemu-manager--start-qemu` with ISO boot.
