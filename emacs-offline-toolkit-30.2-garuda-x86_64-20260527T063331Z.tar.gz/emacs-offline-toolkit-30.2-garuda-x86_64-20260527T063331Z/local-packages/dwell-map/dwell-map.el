;;; dwell-map.el --- Heatmap of where point dwells on the frame -*- lexical-binding: t; -*-
;;
;; Author: James Dyer <captainflasmr@gmail.com>
;; Version: 0.1.0
;; Package-Requires: ((emacs "27.1"))
;; Keywords: convenience, tools
;; URL: https://github.com/captainflasmr/dwell-map
;;
;; This file is not part of GNU Emacs.
;;
;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or (at
;; your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.
;;
;;; Commentary:
;;
;; dwell-map samples the position of point at a regular interval and
;; records frame-relative character coordinates into a normalized grid.
;; Over time this reveals "hot spots" — regions of the screen where the
;; cursor actually *dwells*, as opposed to merely passes through.
;;
;; Sampling is wall-clock based (default: once per second) but gated on
;; user activity: if Emacs has been idle longer than
;; `dwell-map-active-threshold' seconds, samples are skipped.  This
;; prevents an unattended Emacs from inflating a single cell over hours.
;;
;; Samples are bucketed into a `dwell-map-grid-rows' x
;; `dwell-map-grid-cols' grid so the data stays meaningful when the
;; frame is resized.
;;
;; Quick start:
;;
;;   (require 'dwell-map)
;;   (dwell-map-mode 1)          ;; start sampling (global)
;;   M-x dwell-map-show-report   ;; open the heatmap buffer
;;   M-x dwell-map-reset         ;; erase all accumulated data
;;
;; Data persists to `dwell-map-data-file' and survives restarts.
;;
;;; Code:

(require 'cl-lib)
(require 'subr-x)

(defgroup dwell-map nil
  "Heatmap of cursor dwell time across the frame."
  :group 'convenience
  :prefix "dwell-map-")

(defcustom dwell-map-sample-interval 1.0
  "Seconds of wall-clock time between position samples."
  :type 'number
  :group 'dwell-map)

(defcustom dwell-map-active-threshold 30
  "Skip samples when Emacs has been idle longer than this many seconds.
Prevents an unattended session from piling samples onto a single cell."
  :type 'number
  :group 'dwell-map)

(defcustom dwell-map-grid-rows 20
  "Number of vertical buckets in the normalized grid."
  :type 'integer
  :group 'dwell-map)

(defcustom dwell-map-grid-cols 60
  "Number of horizontal buckets in the normalized grid."
  :type 'integer
  :group 'dwell-map)

(defcustom dwell-map-data-file
  (expand-file-name "dwell-map-data.el" user-emacs-directory)
  "File where dwell-map samples are persisted."
  :type 'file
  :group 'dwell-map)

(defcustom dwell-map-save-interval 300
  "Seconds between automatic saves of accumulated data."
  :type 'number
  :group 'dwell-map)

(defcustom dwell-map-heatmap-chars " .:-=+*#%@"
  "Characters used in the ASCII heatmap, from least to most dense.
The first character represents empty cells; the last represents the
hottest cell in the current data set."
  :type 'string
  :group 'dwell-map)

(defcustom dwell-map-ignore-minibuffer t
  "If non-nil, skip samples taken while point is in the minibuffer."
  :type 'boolean
  :group 'dwell-map)

(defcustom dwell-map-use-colors t
  "If non-nil, colour heatmap characters from cool (low) to hot (high).
The underlying ASCII characters from `dwell-map-heatmap-chars' are kept
either way; this option only controls the face applied on top."
  :type 'boolean
  :group 'dwell-map)

(defface dwell-map-heat-1 '((t :foreground "#3a5fcd")) "Cold." :group 'dwell-map)
(defface dwell-map-heat-2 '((t :foreground "#4a8fd4")) "Cool." :group 'dwell-map)
(defface dwell-map-heat-3 '((t :foreground "#00ced1")) "Cool-mid." :group 'dwell-map)
(defface dwell-map-heat-4 '((t :foreground "#32cd32")) "Mid." :group 'dwell-map)
(defface dwell-map-heat-5 '((t :foreground "#adff2f")) "Warm-mid." :group 'dwell-map)
(defface dwell-map-heat-6 '((t :foreground "#ffd700")) "Warm." :group 'dwell-map)
(defface dwell-map-heat-7 '((t :foreground "#ff8c00")) "Hot." :group 'dwell-map)
(defface dwell-map-heat-8 '((t :foreground "#ff4500")) "Hotter." :group 'dwell-map)
(defface dwell-map-heat-9 '((t :foreground "#ff0000" :weight bold))
  "Peak." :group 'dwell-map)

(defvar dwell-map--heat-faces
  [dwell-map-heat-1 dwell-map-heat-2 dwell-map-heat-3
                    dwell-map-heat-4 dwell-map-heat-5 dwell-map-heat-6
                    dwell-map-heat-7 dwell-map-heat-8 dwell-map-heat-9]
  "Face vector indexed by non-empty heatmap level (0 = coldest).")

(defvar dwell-map--grid nil
  "Hash table keyed by (ROW . COL) cons cells with integer sample counts.")

(defvar dwell-map--total-samples 0
  "Total samples recorded across all sessions.")

(defvar dwell-map--session-start nil
  "Time the current sampling session started.")

(defvar dwell-map--sample-timer nil)
(defvar dwell-map--save-timer nil)

(defun dwell-map--ensure-grid ()
  "Initialise the grid hash table if not yet set."
  (unless dwell-map--grid
    (setq dwell-map--grid (make-hash-table :test 'equal))))

(defun dwell-map--user-active-p ()
  "Return non-nil if the user has been active recently enough to sample."
  (let ((idle (current-idle-time)))
    (or (null idle)
        (< (float-time idle) dwell-map-active-threshold))))

(defun dwell-map--current-cell ()
  "Return (GRID-ROW . GRID-COL) for point, or nil if it cannot be determined."
  (unless (and dwell-map-ignore-minibuffer (minibufferp))
    (when-let* ((posn (posn-at-point))
                (col-row (posn-actual-col-row posn))
                (edges (window-edges)))
      (let* ((frame-h (float (frame-height)))
             (frame-w (float (frame-width)))
             (row (+ (cdr col-row) (nth 1 edges)))
             (col (+ (car col-row) (nth 0 edges))))
        (when (and (>= row 0) (>= col 0)
                   (> frame-h 0) (> frame-w 0))
          (cons (min (1- dwell-map-grid-rows)
                     (floor (* dwell-map-grid-rows (/ row frame-h))))
                (min (1- dwell-map-grid-cols)
                     (floor (* dwell-map-grid-cols (/ col frame-w))))))))))

(defun dwell-map--sample ()
  "Record one position sample if the user is active."
  (when (dwell-map--user-active-p)
    (when-let ((cell (dwell-map--current-cell)))
      (dwell-map--ensure-grid)
      (puthash cell (1+ (gethash cell dwell-map--grid 0))
               dwell-map--grid)
      (setq dwell-map--total-samples (1+ dwell-map--total-samples)))))

(defun dwell-map--save ()
  "Persist the current grid and totals to `dwell-map-data-file'."
  (dwell-map--ensure-grid)
  (condition-case err
      (with-temp-file dwell-map-data-file
        (let ((print-length nil)
              (print-level nil)
              entries)
          (maphash (lambda (k v) (push (cons k v) entries))
                   dwell-map--grid)
          (prin1 `(:version 1
                            :grid-rows ,dwell-map-grid-rows
                            :grid-cols ,dwell-map-grid-cols
                            :total-samples ,dwell-map--total-samples
                            :entries ,entries)
                 (current-buffer))))
    (error (message "dwell-map: save failed: %s" err))))

(defun dwell-map--load ()
  "Load persisted samples from `dwell-map-data-file', if it exists."
  (dwell-map--ensure-grid)
  (when (file-readable-p dwell-map-data-file)
    (condition-case err
        (with-temp-buffer
          (insert-file-contents dwell-map-data-file)
          (goto-char (point-min))
          (let* ((data (read (current-buffer)))
                 (saved-rows (plist-get data :grid-rows))
                 (saved-cols (plist-get data :grid-cols))
                 (entries (plist-get data :entries)))
            (if (and (equal saved-rows dwell-map-grid-rows)
                     (equal saved-cols dwell-map-grid-cols))
                (progn
                  (setq dwell-map--total-samples
                        (or (plist-get data :total-samples) 0))
                  (dolist (entry entries)
                    (puthash (car entry) (cdr entry) dwell-map--grid)))
              (message "dwell-map: grid size changed (%sx%s → %sx%s); prior data ignored"
                       saved-rows saved-cols
                       dwell-map-grid-rows dwell-map-grid-cols))))
      (error (message "dwell-map: load failed: %s" err)))))

;;;###autoload
(define-minor-mode dwell-map-mode
  "Global minor mode that samples point position into a heatmap grid."
  :global t
  :lighter " Dwell"
  :group 'dwell-map
  (if dwell-map-mode
      (dwell-map--start)
    (dwell-map--stop)))

(defun dwell-map--start ()
  "Load prior data and start the sampling/save timers."
  (dwell-map--load)
  (setq dwell-map--session-start (current-time))
  (setq dwell-map--sample-timer
        (run-with-timer dwell-map-sample-interval
                        dwell-map-sample-interval
                        #'dwell-map--sample))
  (setq dwell-map--save-timer
        (run-with-timer dwell-map-save-interval
                        dwell-map-save-interval
                        #'dwell-map--save))
  (add-hook 'kill-emacs-hook #'dwell-map--save))

(defun dwell-map--stop ()
  "Cancel timers and flush data to disk."
  (when dwell-map--sample-timer
    (cancel-timer dwell-map--sample-timer)
    (setq dwell-map--sample-timer nil))
  (when dwell-map--save-timer
    (cancel-timer dwell-map--save-timer)
    (setq dwell-map--save-timer nil))
  (remove-hook 'kill-emacs-hook #'dwell-map--save)
  (dwell-map--save))

(defun dwell-map--density-index (count max-count)
  "Return the level index in `dwell-map-heatmap-chars' for COUNT vs MAX-COUNT.
Returns 0 for empty cells and 1..N-1 otherwise, where N is the number
of heatmap characters."
  (if (or (zerop count) (zerop max-count))
      0
    (let ((n (length dwell-map-heatmap-chars)))
      (min (1- n)
           (max 1
                (floor (* (1- n)
                          (/ (float count) max-count))))))))

(defun dwell-map--heat-face (idx)
  "Return the face for heatmap level IDX, or nil if colouring is disabled."
  (when (and dwell-map-use-colors (> idx 0))
    (let* ((faces dwell-map--heat-faces)
           (levels (1- (length dwell-map-heatmap-chars)))
           (slot (if (<= levels 0)
                     0
                   (min (1- (length faces))
                        (floor (* (1- (length faces))
                                  (/ (float (1- idx))
                                     (max 1 (1- levels))))))))) ; spread 1..N-1 over faces
      (aref faces slot))))

(defun dwell-map--insert-heatmap (max-count)
  "Insert an ASCII heatmap normalised against MAX-COUNT at point."
  (dotimes (r dwell-map-grid-rows)
    (dotimes (c dwell-map-grid-cols)
      (let* ((count (gethash (cons r c) dwell-map--grid 0))
             (idx (dwell-map--density-index count max-count))
             (char (aref dwell-map-heatmap-chars idx))
             (face (dwell-map--heat-face idx)))
        (insert (if face
                    (propertize (string char) 'face face)
                  (string char)))))
    (insert "\n")))

(defun dwell-map--insert-top-cells (n)
  "Insert the top N most-dwelt cells at point."
  (let (entries)
    (maphash (lambda (k v) (push (cons k v) entries))
             dwell-map--grid)
    (setq entries (cl-sort entries #'> :key #'cdr))
    (insert (format "Top %d hot spots:\n" n))
    (cl-loop for (cell . count) in entries
             for i from 1 to n
             do (insert
                 (format "  %2d. row %2d / col %2d — %d samples (%.1f%%)\n"
                         i (car cell) (cdr cell) count
                         (* 100.0 (/ (float count)
                                     (max 1 dwell-map--total-samples))))))))

(defun dwell-map--insert-quadrant-summary ()
  "Insert a breakdown of samples across the four frame quadrants."
  (let ((quadrants (make-hash-table :test 'eq))
        (total 0)
        (mid-r (/ dwell-map-grid-rows 2))
        (mid-c (/ dwell-map-grid-cols 2)))
    (maphash
     (lambda (cell count)
       (let* ((v (if (< (car cell) mid-r) 'top 'bottom))
              (h (if (< (cdr cell) mid-c) 'left 'right))
              (q (intern (format "%s-%s" v h))))
         (puthash q (+ count (gethash q quadrants 0)) quadrants)
         (setq total (+ total count))))
     dwell-map--grid)
    (insert "Quadrant distribution:\n")
    (dolist (q '(top-left top-right bottom-left bottom-right))
      (let ((c (gethash q quadrants 0)))
        (insert (format "  %-13s %6d  (%.1f%%)\n"
                        q c (* 100.0 (/ (float c) (max 1 total)))))))
    (insert "\n")))

;;;###autoload
(defun dwell-map-show-report ()
  "Show an ASCII heatmap of cursor dwell time in a dedicated buffer."
  (interactive)
  (dwell-map--ensure-grid)
  (let ((buf (get-buffer-create "*Dwell Map*"))
        (max-count 0)
        (filled-cells 0))
    (maphash (lambda (_k v)
               (setq max-count (max max-count v)
                     filled-cells (1+ filled-cells)))
             dwell-map--grid)
    (with-current-buffer buf
      (let ((inhibit-read-only t))
        (erase-buffer)
        (insert (format "Dwell Map — %d samples across %d/%d cells (peak %d)\n"
                        dwell-map--total-samples
                        filled-cells
                        (* dwell-map-grid-rows dwell-map-grid-cols)
                        max-count))
        (insert (format "Grid %dx%d  |  sample every %.1fs  |  legend "
                        dwell-map-grid-rows dwell-map-grid-cols
                        dwell-map-sample-interval))
        (insert "'")
        (dotimes (i (length dwell-map-heatmap-chars))
          (let ((face (dwell-map--heat-face i))
                (s (string (aref dwell-map-heatmap-chars i))))
            (insert (if face (propertize s 'face face) s))))
        (insert "' low→high\n\n")
        (dwell-map--insert-heatmap max-count)
        (insert "\n")
        (dwell-map--insert-quadrant-summary)
        (dwell-map--insert-top-cells 10))
      (goto-char (point-min))
      (special-mode))
    (display-buffer buf)))

;;;###autoload
(defun dwell-map-save-now ()
  "Flush the current dwell-map data to disk immediately."
  (interactive)
  (dwell-map--save)
  (message "dwell-map: data saved to %s" dwell-map-data-file))

;;;###autoload
(defun dwell-map-reset ()
  "Erase all accumulated dwell-map data, in memory and on disk."
  (interactive)
  (when (yes-or-no-p "Really erase all dwell-map data? ")
    (setq dwell-map--grid (make-hash-table :test 'equal)
          dwell-map--total-samples 0)
    (when (file-exists-p dwell-map-data-file)
      (delete-file dwell-map-data-file))
    (message "dwell-map: data cleared")))

(provide 'dwell-map)
;;; dwell-map.el ends here
