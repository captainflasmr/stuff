# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```sh
# Run the ERT test suite
emacs --batch -l emeld-tests.el

# Interactive smoke test from the repo root
emacs -Q -L . -l emeld.el --eval '(emeld-diff "dir1" "dir2")'

# Byte-compile
emacs --batch -L . -f batch-byte-compile emeld.el

# Benchmarks
test/bench.sh small [N]   # synthetic tree, default 10000 files
test/bench.sh large       # Linux kernel v7.0 vs v6.19 (requires git clone)
# bench.sh appends each run to BENCHMARKS.org by default. Env vars:
#   EMELD_BENCH_RECORD=0  print only   EMELD_BENCH_SAME=1  also run the S pass
#   EMELD_BENCH_FILE=PATH redirect the log
```

`emeld-tests.el` loads `emeld.el` with `(load-file "emeld.el")`, so tests must run from the repo root. There is no Makefile, no CI, and no package manager config.

`BENCHMARKS.org` is the timing log. `M-x emeld-benchmark-record` (with `emeld-benchmark` non-nil) and `test/bench.sh` both append dated entries stamped with machine specs and the emeld git revision (`emeld--system-info`), so runs can be compared across commits to catch regressions.

## Architecture

Single-file Emacs Lisp package (~89 KB) implementing a Meld-style side-by-side directory diff. One entrypoint: `emeld-diff` (and `emeld-diff-dwim` which guesses dirs from open Dired buffers).

### Scan pipeline

The scan is fully asynchronous to keep the UI responsive. The flow:

1. `emeld--start-diff` spawns `diff -rq` via `make-process`, passing active filter groups as `--exclude` args (built in `emeld--diff-exclude-args`).
2. The sentinel feeds raw `diff -rq` output lines to `emeld--build-tree-from-diff`, which parses lines (`emeld--parse-diff-line`) and progressively builds a node tree via `emeld--entries-to-nodes-progressive`. "Only in" directories are expanded with `directory-files-recursively`.
3. Toggling `emeld-show-same` on (after an initial `-rq` scan) runs `emeld--scan-same-async`, which merges identical files into the existing tree in chunked batches. Two methods (`emeld-same-files-method`): `list` (default) lists the left tree via `emeld-list-command` and treats as identical every left file the initial scan did not already classify as differing or left-only — reusing the initial content comparison instead of repeating it (`emeld--scan-same-list` → `emeld--process-same-files-worker`); `diff` re-runs `diff -rqs` (`emeld--scan-same-diff` → `emeld--process-same-chunk-worker`).
4. Rendering walks the `emeld-node` tree and attaches each node to its line via the `'emeld-node` text property. Standard `diff-*` faces are used so themes apply automatically.

`emeld--scan-generation` is a buffer-local counter incremented on each rescan; async callbacks check it and bail out if they belong to a stale generation. This is the cancellation mechanism — don't bypass it when adding new async work.

### Filter groups

`emeld-filter-groups` is a list of `(NAME [ACTIVE-BOOL] GLOBS...)`. If the second element is `t`/`nil` it sets the default active state; otherwise everything after NAME is a glob. The `safe-local-variable` predicate enforces this shape so projects can override via `.dir-locals.el`. Globs containing `/` match the relative path; others match the basename only (see `emeld--filtered-p`). Filters are pushed down to `diff` as `--exclude`, not applied post-hoc.

### Node model and rendering

- `emeld-node` is a cl-struct holding the whole tree; mutated in place during the scan.
- Buffer-local state (`emeld--root-node`, `emeld--left-root`, `emeld--right-root`, `emeld--marked-paths`, `emeld--saved-expanded`, etc.) is reset on each rescan.
- `emeld--saved-point-path` / `emeld--saved-point-col` preserve cursor location across rerenders.
- The view toggles (`emeld-show-same`, `emeld-show-different`, `emeld-show-added`, `emeld-show-strikethrough`, `emeld-show-tree-lines`) are `defcustom`s but treated as buffer-local in the mode.

## Conventions specific to this package

- `lexical-binding: t` everywhere. In async chains, prefer `car`/`cdr` over `pop` (gv-let-place is incompatible with closures here — there's a comment in AGENTS.md about this).
- The differences scan is `diff -rq` only; filtering goes through `diff`'s `--exclude`. The show-same merge may additionally enumerate files via `emeld-list-command` (`find` by default, `fd` configurable) — see `emeld-same-files-method`.
- Requires Emacs 27+ (uses `make-process` and the 4-arg `copy-directory`). `file-equal-p` is used for content compare on Emacs 29+; the fallback path is bounded by `emeld-max-content-size`.
- The package is namespaced `emeld-` (public) and `emeld--` (private). Faces use `emeld-*-face`.
- `emeld-benchmark` (when non-nil) collects phase timings into `emeld--benchmark-data`; `emeld--bench-report` prints them. Used by `test/bench.sh`.
