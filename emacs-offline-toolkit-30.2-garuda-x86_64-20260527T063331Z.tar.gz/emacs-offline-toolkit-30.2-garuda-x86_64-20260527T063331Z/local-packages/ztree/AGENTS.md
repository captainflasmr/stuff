# ztree — AGENTS.md

## Project
Text-mode directory tree and directory diff for Emacs.  
Author: Alexey Veretennikov.  
License: GPLv3+.  
Upstream: https://codeberg.org/fourier/ztree (moved from GitHub).

## Entry points
- `M-x ztree-dir` — browse a single directory tree in a text-mode buffer.
- `M-x ztree-diff` — side-by-side diff of two directories.

Both commands are autoloaded. The main package `ztree.el` simply requires `ztree-dir` and `ztree-diff`.

## Architecture

| File | Role |
|------|------|
| `ztree-view.el` | Generic tree-buffer framework. Renders expandable trees, handles keybindings, refresh, lines/arrows. |
| `ztree-protocol.el` | CLOS-like generic protocol (`cl-defgeneric` / `cl-defmethod`). Methods: `ztree-node-visible-p`, `ztree-node-short-name`, `ztree-node-expandable-p`, `ztree-node-equal`, `ztree-node-children` (required); `ztree-node-side`, `ztree-node-face`, `ztree-node-action`, `ztree-node-left-short-name`, `ztree-node-right-short-name` (optional). |
| `ztree-dir.el` | Implements the protocol with plain **strings** as nodes (file paths). Minor mode `ztreedir-mode`. |
| `ztree-diff.el` | Implements the protocol with `ztree-diff-node` **struct** nodes. Minor mode `ztreediff-mode`. Key bindings: `d` (simple diff), `v` (view), `C` (copy), `D` (delete), `h`/`H` (toggle visibility), `r` (partial rescan), `R`/`F5` (full rescan). |
| `ztree-diff-model.el` | The diff data model (`cl-defstruct ztree-diff-node`), file comparison logic (`diff` process), ignore/filter support. |
| `ztree-util.el` | Shared helpers: `ztree-find`, `ztree-filter`, `ztree-file-short-name`, TRAMP-aware filename helpers. |

## Dependencies
- `cl-lib` (Emacs built-in, required at compile-time via `eval-when-compile`)
- `subr-x` (for `when-let`, Emacs built-in)

## Build / Test
- No build system, no test infrastructure, no CI.
- Byte-compile any `.el` file with `M-x emacs-lisp-byte-compile` or `emacs -batch -f batch-byte-compile *.el`.
- Compiled `.elc` files are gitignored (along with `ztree-autoloads.el` and `ztree-pkg.el`).

## Conventions
- `lexical-binding: t` in all source files.
- Uses `cl-lib` namespace (`cl-defstruct`, `cl-defgeneric`, `cl-defmethod`, `cl-reduce`, `cl-incf`, `cl-delete`, `cl-remove-if`).
- Buffer-local variables prefixed `ztree-` or `ztreediff-`.
- All user-facing faces prefixed `ztreep-`.
