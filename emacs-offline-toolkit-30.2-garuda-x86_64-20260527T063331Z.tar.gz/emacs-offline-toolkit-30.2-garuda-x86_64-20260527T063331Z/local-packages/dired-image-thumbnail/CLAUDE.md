# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

`dired-image-thumbnail` is an Emacs Lisp package that extends the built-in `image-dired` with sorting, filtering, subdirectory support, wrap display, auto-display navigation, and a split-screen layout. It targets Emacs 28.1+.

## Repository Structure

- **`dired-image-thumbnail.el`** — Core package: all defcustoms, internal state variables, sorting/filtering logic, thumbnail rendering, window layout management, keybindings, and the main entry point `dired-image-thumbnail`.
- **`dired-image-thumbnail-transient.el`** — Optional transient.el menu integration (sort/filter menus bound to `S` and `\`). Depends on `transient >= 0.4.0`. Declares external variables from the core file rather than requiring it at load time.
- **`test/test.sh`** — Shell script that launches a vanilla `emacs -Q` session with the package loaded for manual interactive testing.

## Testing

There is no automated test suite. Testing is manual via vanilla Emacs:

```sh
cd test && ./test.sh
```

This opens Emacs without user config (`-Q`), loads the package, and opens a Dired buffer for interactive testing.

## Key Architecture Details

- The package advises/hooks into `image-dired` rather than replacing it — all standard `image-dired` commands and the `*image-dired*` buffer are reused.
- Thumbnail state is tracked in buffer-local variables (`dired-image-thumbnail--all-images`, `--current-images`, `--sort-by`, `--sort-order`, filter vars, `--dimension-cache`).
- Window layout is managed by manipulating `display-buffer-alist` entries when `dired-image-thumbnail-manage-window-layout` is non-nil.
- The transient file uses `defvar` declarations for core variables rather than `require`ing the core file, to keep the dependency optional.

## Elisp Conventions

- Package prefix: `dired-image-thumbnail-` for public symbols, `dired-image-thumbnail--` for internal.
- Uses `lexical-binding: t`.
- Customization group: `dired-image-thumbnail` (under `image-dired`).
- No external dependencies beyond Emacs built-ins (except optional `transient`).
