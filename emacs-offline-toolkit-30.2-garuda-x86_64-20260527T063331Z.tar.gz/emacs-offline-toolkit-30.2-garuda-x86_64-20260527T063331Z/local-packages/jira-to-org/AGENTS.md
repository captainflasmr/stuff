# Agent Guide for jira-to-org.el

## Build & Test Commands
- **Byte-compile**: `emacs -batch -f batch-byte-compile jira-to-org.el`
- **Load & test**: `emacs -Q -l jira-to-org.el --eval "(jira-to-org-parse-string \"test data\")"`
- **No formal test suite exists** - manual testing required with sample Jira data

## Code Style & Conventions

### Imports
- Use `(require 'cl-lib)` for Common Lisp extensions (prefer `cl-lib` over deprecated `cl`)
- Place all requires after Commentary section, before Code section

### Formatting
- **Lexical binding**: Always include `; -*- lexical-binding: t; -*-` in first line
- **Line length**: Aim for 80 chars; doc strings can extend to ~90
- **Indentation**: 2 spaces (standard Emacs Lisp)
- **File structure**: Commentary → Code → defgroup → defcustom → defun → provide

### Naming Conventions
- **Public functions**: `jira-to-org-function-name` (with prefix)
- **Private functions**: `jira-to-org--function-name` (double-dash prefix)
- **Predicates**: End with `-p` (e.g., `jira-to-org--valid-p`)
- **Struct constructors**: Use `cl-defstruct` (e.g., `jira-to-org-item`)

### Types & Documentation
- All `defcustom` must include `:type` and docstring
- All `defun` must have docstring describing params and return value
- Use CAPS for parameter names in docstrings (e.g., "Parse STRING...")
- Mark interactive functions with `(interactive)` form

### Data Structures
- Use `cl-defstruct` for complex data types
- Access struct fields via `structname-fieldname` (e.g., `jira-to-org-item-key`)
- Create instances with `make-structname` (e.g., `make-jira-to-org-item`)

### Error Handling
- Use `when` for single-branch conditionals, `if` for two branches
- Prefer `let*` when bindings depend on previous ones
- Use `cl-incf`/`cl-decf` instead of `setq` for increments
- Return meaningful values from functions; use `nil` for "not found"
