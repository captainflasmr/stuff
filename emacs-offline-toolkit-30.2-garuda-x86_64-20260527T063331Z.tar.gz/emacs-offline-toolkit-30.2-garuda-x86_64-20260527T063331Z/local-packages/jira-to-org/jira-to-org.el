;;; jira-to-org.el --- Parse Jira sprint data into org-mode entries -*- lexical-binding: t; -*-

;;; Commentary:
;; 
;; This package parses Jira sprint data (copied from Jira board) and converts
;; it to org-mode task entries in your roadmap format.
;;
;; Usage:
;;   1. Copy Jira data into a buffer or region
;;   2. M-x jira-to-org-parse-buffer or jira-to-org-parse-region
;;   3. Entries are inserted at point or copied to kill-ring
;;
;; The expected input format is the text copied from Jira sprint boards.

;;; Code:

(require 'cl-lib)

(defgroup jira-to-org nil
  "Convert Jira sprint data to org-mode entries."
  :group 'org
  :prefix "jira-to-org-")

(defcustom jira-to-org-default-sprint nil
  "Default sprint tag (e.g., \"s7\"). If nil, no sprint tag is added."
  :type '(choice (const :tag "None" nil)
                 (string :tag "Sprint tag")))

(defcustom jira-to-org-default-year "2025"
  "Default year to add to tags."
  :type 'string)

(defcustom jira-to-org-assignee-map
  '(("James Dyer" . "jdyer")
    ("Freddy" . "freddy")
    ("N Cropper" . "ncropper"))
  "Alist mapping full names to short tag names."
  :type '(alist :key-type string :value-type string))

(defcustom jira-to-org-priority-map
  '(("Highest" . "A")
    ("High" . "A")
    ("Medium" . "B")
    ("Low" . "C")
    ("Lowest" . "C"))
  "Alist mapping Jira priorities to org priorities."
  :type '(alist :key-type string :value-type string))

(defcustom jira-to-org-status-map
  '(("To Do" . "TODO")
    ("In Progress" . "DOING")
    ("Done" . "DONE"))
  "Alist mapping Jira statuses to org TODO keywords."
  :type '(alist :key-type string :value-type string))

(defcustom jira-to-org-heading-level 4
  "Number of asterisks for generated headings."
  :type 'integer)

(cl-defstruct jira-to-org-item
  "Structure representing a parsed Jira item."
  key           ; e.g., "MM-78"
  title         ; e.g., "Implement IG connection management APIs"
  status        ; e.g., "To Do" or "In Progress"
  assignee      ; e.g., "James Dyer"
  priority      ; e.g., "Medium"
  story-points) ; e.g., 2 or nil

(defun jira-to-org--parse-buffer-to-items (buffer-or-string)
  "Parse BUFFER-OR-STRING containing Jira data into a list of `jira-to-org-item' structs."
  (let ((text (if (bufferp buffer-or-string)
                  (with-current-buffer buffer-or-string (buffer-string))
                buffer-or-string))
        (items '())
        (current-status "To Do")
        (lines nil)
        (i 0))
    ;; Split into lines and filter empty ones
    (setq lines (seq-filter (lambda (s) (not (string-empty-p (string-trim s))))
                            (split-string text "\n")))
    (while (< i (length lines))
      (let ((line (string-trim (nth i lines))))
        (cond
         ;; Status headers
         ((member line '("To Do" "In Progress" "Done"))
          (setq current-status line)
          (cl-incf i))
         
         ;; Jira key pattern - start of a new item
         ((string-match "^\\(MM-[0-9]+\\)$" line)
          (let* ((key (match-string 1 line))
                 (title nil)
                 (assignee nil)
                 (priority nil)
                 (story-points nil))
            (cl-incf i)
            ;; Next line should be the title
            (when (< i (length lines))
              (setq title (string-trim (nth i lines)))
              (cl-incf i))
            ;; Skip "Visuals" if present
            (when (and (< i (length lines))
                       (string= (string-trim (nth i lines)) "Visuals"))
              (cl-incf i))
            ;; Parse remaining fields until next item or end
            (while (and (< i (length lines))
                        (not (string-match "^MM-[0-9]+$" (string-trim (nth i lines))))
                        (not (member (string-trim (nth i lines)) '("To Do" "In Progress" "Done"))))
              (let ((field-line (string-trim (nth i lines))))
                (cond
                 ((string-match "^Assignee: \\(.+\\)$" field-line)
                  (setq assignee (match-string 1 field-line)))
                 ((string-match "^Priority: \\(.+\\)$" field-line)
                  (setq priority (match-string 1 field-line)))
                 ((string-match "^Issue Type:" field-line)
                  ;; Skip issue type
                  )
                 ((string-match "^[0-9]+$" field-line)
                  (setq story-points (string-to-number field-line))))
                (cl-incf i)))
            ;; Create item
            (push (make-jira-to-org-item
                   :key key
                   :title title
                   :status current-status
                   :assignee assignee
                   :priority priority
                   :story-points story-points)
                  items)))
         
         ;; Skip unrecognized lines
         (t (cl-incf i)))))
    (nreverse items)))

(defun jira-to-org--assignee-to-tag (assignee)
  "Convert ASSIGNEE name to a short tag using `jira-to-org-assignee-map'."
  (or (cdr (assoc assignee jira-to-org-assignee-map))
      (when assignee
        (downcase (replace-regexp-in-string " " "" assignee)))))

(defun jira-to-org--priority-to-org (priority)
  "Convert PRIORITY to org priority letter using `jira-to-org-priority-map'."
  (or (cdr (assoc priority jira-to-org-priority-map)) "B"))

(defun jira-to-org--status-to-todo (status)
  "Convert STATUS to org TODO keyword using `jira-to-org-status-map'."
  (or (cdr (assoc status jira-to-org-status-map)) "TODO"))

(defun jira-to-org--item-to-org-heading (item &optional sprint)
  "Convert ITEM to an org-mode heading string.
SPRINT overrides `jira-to-org-default-sprint' if provided."
  (let* ((stars (make-string jira-to-org-heading-level ?*))
         (todo (jira-to-org--status-to-todo (jira-to-org-item-status item)))
         (priority (jira-to-org--priority-to-org (jira-to-org-item-priority item)))
         (key (jira-to-org-item-key item))
         (title (jira-to-org-item-title item))
         (assignee-tag (jira-to-org--assignee-to-tag (jira-to-org-item-assignee item)))
         (sprint-tag (or sprint jira-to-org-default-sprint))
         (year jira-to-org-default-year)
         (tags '()))
    ;; Build tags list
    (when sprint-tag (push sprint-tag tags))
    (when assignee-tag (push assignee-tag tags))
    (when year (push year tags))
    ;; Format: **** TODO [#B] MM-78 Title :s7:jdyer:2025:
    (format "%s %s [#%s] %s %s%s"
            stars
            todo
            priority
            key
            title
            (if tags
                (concat " :" (mapconcat #'identity (nreverse tags) ":") ":")
              ""))))

(defun jira-to-org-parse-string (string &optional sprint)
  "Parse STRING containing Jira data and return org-mode headings.
SPRINT overrides the default sprint tag."
  (let ((items (jira-to-org--parse-buffer-to-items string)))
    (mapconcat (lambda (item)
                 (jira-to-org--item-to-org-heading item sprint))
               items
               "\n")))

(defun jira-to-org-parse-region (beg end &optional sprint)
  "Parse Jira data in region from BEG to END and insert org headings.
With prefix arg, prompts for SPRINT tag."
  (interactive
   (list (region-beginning)
         (region-end)
         (when current-prefix-arg
           (read-string "Sprint tag (e.g., s7): "))))
  (let* ((text (buffer-substring-no-properties beg end))
         (result (jira-to-org-parse-string text sprint)))
    (kill-new result)
    (message "Parsed %d items, copied to kill ring"
             (length (jira-to-org--parse-buffer-to-items text)))
    result))

(defun jira-to-org-parse-buffer (&optional sprint)
  "Parse entire buffer as Jira data and insert org headings.
With prefix arg, prompts for SPRINT tag."
  (interactive
   (list (when current-prefix-arg
           (read-string "Sprint tag (e.g., s7): "))))
  (jira-to-org-parse-region (point-min) (point-max) sprint))

(defun jira-to-org-parse-and-insert (&optional sprint)
  "Parse Jira data from clipboard and insert at point.
With prefix arg, prompts for SPRINT tag."
  (interactive
   (list (when current-prefix-arg
           (read-string "Sprint tag (e.g., s7): "))))
  (let* ((text (current-kill 0))
         (result (jira-to-org-parse-string text sprint)))
    (insert result)
    (message "Inserted %d items"
             (length (jira-to-org--parse-buffer-to-items text)))))

;;; Functions for updating existing org entries

(defun jira-to-org--find-org-entry (key)
  "Find org entry with Jira KEY in current buffer.
Returns marker to the heading or nil if not found."
  (save-excursion
    (goto-char (point-min))
    (when (re-search-forward (format "^\\*+ .* %s " (regexp-quote key)) nil t)
      (point-marker))))

(defun jira-to-org--update-entry-status (key new-status)
  "Update the TODO status of entry with KEY to NEW-STATUS."
  (let ((marker (jira-to-org--find-org-entry key)))
    (when marker
      (goto-char marker)
      (beginning-of-line)
      (when (looking-at "^\\(\\*+\\) \\([A-Z]+\\) ")
        (replace-match (format "\\1 %s " new-status))
        t))))

(defun jira-to-org-update-from-jira (jira-text)
  "Update existing org entries based on JIRA-TEXT.
Updates status of existing entries, reports new items that need adding."
  (interactive "sJira data (or paste and use region): ")
  (let ((items (jira-to-org--parse-buffer-to-items jira-text))
        (updated 0)
        (new-items '()))
    (dolist (item items)
      (let ((key (jira-to-org-item-key item))
            (status (jira-to-org--status-to-todo (jira-to-org-item-status item))))
        (if (jira-to-org--update-entry-status key status)
            (cl-incf updated)
          (push item new-items))))
    (message "Updated %d entries. %d new items not in buffer."
             updated (length new-items))
    (when new-items
      (kill-new (mapconcat #'jira-to-org--item-to-org-heading (nreverse new-items) "\n"))
      (message "New items copied to kill ring"))))

(provide 'jira-to-org)
;;; jira-to-org.el ends here
