/***********************************************************************
  Copyright (C) 2023 Pitch Technologies AB

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 **********************************************************************/

#include "services-common/RTIcompat.h"

#if (RTI_HLA_VERSION >= 2025)
#include <RTI/time/LogicalTime.h>
#else
#include <RTI/LogicalTime.h>
#endif

#include <ostream>

namespace RTI_NAMESPACE
{
#if (RTI_HLA_VERSION < 2025)
   LogicalTime::~LogicalTime() RTI_NOEXCEPT = default;
#endif

   std::wostream RTI_EXPORT & operator << (
         std::wostream & stream,
         LogicalTime const & time)
   {
      stream << time.toString();
      return stream;
   }
} // RTI_NAMESPACE
