/***********************************************************************
  Copyright (C) 2023 Pitch Technologies AB

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 **********************************************************************/

#pragma once

#include <fedpro/Transport.h>

#include <memory>
#include <functional>

class SocketSupplierTransport : public FedPro::Transport {
public:

   using SocketSupplier = std::function<std::shared_ptr<FedPro::Socket>()>;

   /**
    * Create a Transport from a SocketSupplier function.
    * @param socketSupplier Supplier of connected socket.
    */
   explicit SocketSupplierTransport(SocketSupplier socketSupplier);

   /**
    * Create a Transport from an already-connected FedPro::Socket.
    * @param socket Already-connected FedPro::Socket to return upon connect().
    */
   explicit SocketSupplierTransport(std::shared_ptr<FedPro::Socket> socket);

   SocketSupplierTransport(const SocketSupplierTransport & transport) noexcept;

   ~SocketSupplierTransport() override;

   std::shared_ptr<FedPro::Socket> connect() override;

private:

   SocketSupplier _socketSupplier;
};
