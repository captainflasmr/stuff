#pragma once
/***********************************************************************
   The IEEE hereby grants a general, royalty-free license to copy, distribute,
   display and make derivative works from this material, for all purposes,
   provided that any use of the material contains the following
   attribution: "Reprinted with permission from IEEE 1516.1(TM)-2025".
   Should you require additional information, contact the Manager, Standards
   Intellectual Property, IEEE Standards Association (stds-ipr@ieee.org).
***********************************************************************/

#include <RTI/SpecificConfig.h>

namespace rti1516_2025
{
   class RTI_EXPORT RangeBounds
   {
   public:
      RangeBounds ();

      RangeBounds (
         unsigned long lowerBound,
         unsigned long upperBound);

      ~RangeBounds ()
         noexcept;

      RangeBounds (
         RangeBounds const & rhs);

      RangeBounds & operator= (
         RangeBounds const & rhs);

      unsigned long getLowerBound () const;

      unsigned long getUpperBound () const;

      void setLowerBound (
         unsigned long lowerBound);

      void setUpperBound (
         unsigned long upperBound);

   private:
      unsigned long _lowerBound;
      unsigned long _upperBound;
   };
}


