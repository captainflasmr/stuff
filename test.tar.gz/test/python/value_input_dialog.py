import tkinter as tk
from tkinter import simpledialog

class ValueInputDialog:
    def __init__(self, root):
        self.root = root
        self.initialize_ui()

    def initialize_ui(self):
        self.root.withdraw()  # Hide the main window
        self.prompt_value()

    def validate_value(self, value):
        try:
            val = int(value)
            if 1 <= val <= 10:
                return True
        except ValueError:
            pass
        return False

    def prompt_value(self):
        while True:
            value_str = simpledialog.askstring("Input", "Please input a value between 1 and 10:",
                                               parent=self.root)
            if value_str is None:
                print("No value entered. Exiting.")
                break

            if self.validate_value(value_str):
                print(f"Valid input received: {value_str}")
                break
            else:
                tk.messagebox.showerror("Invalid Input", "Please enter a value between 1 and 10.")

if __name__ == "__main__":
    root = tk.Tk()
    app = ValueInputDialog(root)
    root.mainloop()
