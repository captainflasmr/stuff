#!/bin/bash

# rename directories to lowercase

# for dir in 'find * -depth -type d';
# do
#   # Translate Caps to small letters
#   lcdir=$(echo $dir | tr '[A-Z]' '[a-z]')

#   # Check if the directory is already lowercase
#   if [ $dir != $lcdir ]; then
#     mv $dir/* $lcdir
#   fi
# done

# rename files to lowercase

#for file in `find SCCS -name p.* -exec basename {} \;`;
#do
#    echo $file
#    file=${file#p.}
#    echo $file
#done

mypos=5

#let "answer = $mypos * 10"
answer=$(($mypos * 10))

printf "mypos : $mypos : $answer\n"
