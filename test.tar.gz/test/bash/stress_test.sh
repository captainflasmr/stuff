#!/bin/bash

function infinite_loop {
    while [ 1 ] ; do
	# Force some computation even if it is useless to actually work the CPU
	echo $((13**99)) 1>/dev/null 2>&1
    done
}

abort() {
   # on exit or ^C tidy up
    printf "!!!!! : Abort called !!\n"

# Parent kills its children
    for pid in "${PIDS[@]}"
    do
	printf "Killed $pid\n"
	kill $pid
    done

   exit
}

# Either use environment variables for DURATION, or define them here
NUM_CPU=$(grep -c ^processor /proc/cpuinfo 2>/dev/null || sysctl -n hw.ncpu)
printf "Number of CPUs to stress : $NUM_CPU\n"
PIDS=()
for i in `seq ${NUM_CPU}`; do
    # Put an infinite loop on each CPU
    infinite_loop &
    PIDS+=("$!")
done

trap abort 2 15

# Wait DURATION seconds then stop the loops and quit
sleep 100

# Parent kills its children
for pid in "${PIDS[@]}"
do
    kill $pid
done
