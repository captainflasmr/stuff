#!/bin/bash

count=0

while [ 1 ] ; do

    sleep 1

    count=$((count+1))
    
    while read THELINE
    do
#	printf "$THELINE\n"

	if [[ ! ${THELINE} =~ ^#.* ]]; then
	    printf "$THELINE\n"
	fi
    done < ./ais_messages
done
