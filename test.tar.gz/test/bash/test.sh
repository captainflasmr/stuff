#!/bin/bash

FULL_DEPLOY_LIST="config scripts applications data thirdPartyProducts userData"
DEPLOY_LIST="config"

for DEPLOY in $DEPLOY_LIST; do
    if [[ $DEPLOY =~ $FULL_DEPLOY_LIST ]]; then
	printf "\nAaaaaaah!!\n"
    fi
done
