#!/bin/bash

#TEST="$TRAINER_ROOT"legacy
##TEST=$TRAINER_ROOT
#TEST=legacy

#printf "test : %s\n" $TEST

# mapping is an associative array
#declare -A mapping

#mapping[vehicle]=vrn
#mapping[radar]=re
#mapping[sonar]=AS

#map_vehicle="vrn"
#map_radar="re"
#map_sonar="AS"

#printf ${mapping[vehicle]}
#printf ${mapping[radar]}
#printf ${mapping[sonar]}

#for db_name in vehicle radar sonar; do
#  printf "$mapping[$db_name]\n"
#    tmp=map_$db_name
#  printf ${!tmp}
#  printf ${!"map_$db_name"}
#done

test="first second"

read -a input_array <<< $test

count=0
printf "input_array : ${input_array[$count]}\n"
count=$((count+1))
printf "input_array : ${input_array[$count]}\n"

#GENERATED_SONAR_MENU_FILE="./text2.txt"
#MENU_FILE="./text.txt"

#sed -i '/#Generated Scenario Menu/ r ${GENERATED_SONAR_MENU_FILE}' ${MENU_FILE}
#sed '/#Generated Scenario Menu/ r '${GENERATED_SONAR_MENU_FILE}'' ${MENU_FILE}

#sonar_machine=sonar-01

#if [[ ($1 != "" && $sonar_machine == $1) || ($1 == "") ]]; then
#  printf "Processing Sonar!!\n"
#fi

#display_str="2046 standard"

#sed -i "s/james/$display_str/" text.txt

#printf "=----------------------------------------"

#LIST=$(find . -name 'bb_ids.ads' -exec basename '{}' \;)

#if [[ $(find . -name 'bb_ids.ad' -exec basename '{}' \;) != "" ]]; then
#  printf "#### Have found stuff!!!!\n"
#fi

#wsd_basedir=${TRAINER_ROOT}thirdPartyProducts/

#length_wsd=${#wsd_basedir}
#printf "#### length : $length_wsd\n"

#printf "\n"
#for ((i=1; i<${#wsd_basedir}; i++)) do printf "="; done;
#printf "\n"

#find thirdPartyProducts -maxdepth 1 -name '*' -type d
#find thirdPartyProducts -maxdepth 1 -name '*' -type d -exec basename '{}' \;
#find thirdPartyProducts -maxdepth 1 -type d -name 'wsdb_iss*' -exec basename '{}' \;
#find thirdPartyProducts -maxdepth 1 -type d -name 'wsdb_iss[[:digit:]][[:digit:]]' -exec basename '{}' \;

# wsd_format=${wsd_basedir//\//-}

# printf "#### ${wsd_format}\n"

# PS3="Your choice: "

# WSD_ISS_DIR=$(find $wsd_basedir -maxdepth 1 -type d -name 'wsdb_iss[[:digit:]][[:digit:]]' -exec basename '{}' \; | sed 's/wsdb_//g')

# select ISS_ID in $WSD_ISS_DIR quit;
# do
#   case $ISS_ID in
#     "quit")
#       printf "\nExited.\n"
#       break
#       ;;
#     *)
#       if [ "$ISS_ID" != "" ]; then

#         if [ -d "${wsd_basedir}wsdb_${ISS_ID}" ]; then

# 	    printf "Have found ${ISS_ID}!!!\n"
#           break
#         else
#           printf "\nTrainer directory NOT FOUND re-enter command!!\n"
#         fi
#       else
#         printf "\nPlease re-enter command!!\n"
#       fi
#       ;;
#   esac
# done

#reverse_sourcedir="WSD Test Dir"
#reverse_sourcedir=${reverse_sourcedir// /'\ '};
#echo $reverse_sourcedir
#cd "$reverse_sourcedir"
#echo ${reverse_sourcedir// /_};
#echo $reverse_sourcedir

#all_the_data="james dyer will sort this out"

#for char in $all_the_data; do

#    out_all_the_data+='printf "$char\n"'
#done

#out_all_the_data+="james"`\n`
#out_all_the_data+="dyer"`\n`

#echo ${out_all_the_data} | sort -r
