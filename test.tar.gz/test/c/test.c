#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (int argc, char * argv[])
{
  FILE *fr;
  char *token;
  char line[80];
  char *saveptr;

  char trainer_name [160];
  char trainer_status_fn [160];
  char trainer_mode [20];

  sprintf (trainer_name, "%s", getenv("TRAINER_NAME"));
  sprintf (trainer_status_fn, "%suserdata/trainer_mode.status",
	   getenv("TRAINER_ROOT"));

  fr = fopen (trainer_status_fn, "r");

  if (fr != NULL)
    {
      fgets(line, 80, fr);

      // get the trainer mode
      token = strtok_r(line, ":", &saveptr);
      strcpy (trainer_mode, token);

      fclose(fr);
    }
  else
    {
      // If the file cannot be found or cannot be read then set to default
      fprintf (stderr, "\n!!!! WARNING !!!! - trainer_mode.status file NOT FOUND, setting to DEFAULT standard !!!!\n");
      strcpy (trainer_mode, "standard");
    }

  fprintf (stderr, "TRAINER_MODE : ##%s##\n", trainer_mode);
  fprintf (stderr, "TRAINER_NAME : ##%s##\n", trainer_name);
  fprintf (stderr, "TRAINER_STAT : ##%s##\n", trainer_status_fn);

  if (strcmp (trainer_name,"as1082") == 0
      && (strcmp (trainer_mode,"split") == 0 || strcmp (trainer_mode,"shared") == 0)) {

    fprintf(stderr, "\nDAT - DISABLED STIMULATED 2076 CUTS\n");
  }
  else {
    fprintf(stderr,"\nBOOO-URNS!\n");
  }
}
