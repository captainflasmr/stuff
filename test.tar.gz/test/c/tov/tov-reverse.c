#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LEAP_SECOND_OFFSET -25
#define ROLLOVER_CONSTANT 16777216
#define SECONDS_PER_DAY 86400
#define SECONDS_PER_HOUR 3600
#define SECONDS_PER_MINUTE 60
#define DAYS_PER_YEAR 365.25
#define INITIALISATION_CONSTANT 14227303
#define THREE_BYTE_LIMIT 8388608

//int ftt=1;

// JD : double check May
int month_lookup[12] = {9661184, 12339584, 0, 2678400, 5270400, 7948800, 10540800, 13219200, 15897600, 1712384, 4390784, 6982784};

int year;
int month;
int day;
int hour;
int minute;
int second;

int tov;
int init_constant = 0;

int reverse_calculate_tov (int the_tov)
{
  unsigned int osdi_year;
  unsigned int year_contr, month_contr, day_contr, hour_contr, minute_contr;
  unsigned int tov_uns;

  tov_uns = the_tov;

  tov_uns = tov_uns + INITIALISATION_CONSTANT - LEAP_SECOND_OFFSET;

  // OSDI year first
  if (month > 2) {
    osdi_year = year;
  }
  else {
    osdi_year = year - 1;
  }

  // now the contributions
  year_contr = ((int) (osdi_year * DAYS_PER_YEAR)) % ROLLOVER_CONSTANT;
  year_contr = (year_contr * SECONDS_PER_DAY) % ROLLOVER_CONSTANT;
  month_contr = (month_lookup[month-1]) % ROLLOVER_CONSTANT;
  day_contr = day * SECONDS_PER_DAY;
  hour_contr = hour * SECONDS_PER_HOUR;
  minute_contr = minute * SECONDS_PER_MINUTE;

  the_tov = year_contr + month_contr + day_contr + hour_contr + minute_contr + second + LEAP_SECOND_OFFSET - INITIALISATION_CONSTANT;

  // now fit into 3 bytes
  //  if (the_tov > 8388608 && ftt == 0) {
  if (the_tov > THREE_BYTE_LIMIT) {
    //    printf ("\n@@@@@@@@@@@@@@@@@@@@ ROLLOVER!!!!\n");
    the_tov = -(ROLLOVER_CONSTANT - the_tov);
  }

  printf ("%d\n", the_tov);      
  //  printf ("\n%d : %d : %d : %d : %d : %d : TOV : %d\n", day, month, year, hour, minute, second, the_tov);      
  //printf ("yc : %d : mc : %d : dc : %d : hc : %d : mc : %d : s : %d : ic : %d\n",
  // 	  year_contr, month_contr, day_contr, hour_contr, minute_contr, second, init_constant);

  return the_tov;
}

int main (int argc, char * argv[])
{
  char data_fn [160];
  char line[80];
  char *token;
  FILE *fr;

  // first calculate the initialisation constant
  // which is the rolling count based on :
  // 0 hrs 0 min 0 secs 1 Jan 1990
  //year   = 1990;
  //month  = 1;
  //day    = 1;
  //hour   = 0;
  //minute = 0;
  //second = 0;

  //  printf ("\n@@@@@@@@@@@@@@ %d\n", sizeof(tov));

  //  init_constant = calculate_tov (year, month, day, hour, minute, second);

  //ftt=0;

  // lets read values from a test file
  // to see if my algorithm actuall works!
  sprintf (data_fn, "./tov_data_reverse");

  // initialise values
  if (fr = fopen (data_fn, "r")) {

    while (fgets(line, 80, fr)) {

      token = strtok(line, ":");
      the_tov = atoi (token);

      tov = reverse_calculate_tov (the_tov);
    }

    fclose (fr);
  }
}

