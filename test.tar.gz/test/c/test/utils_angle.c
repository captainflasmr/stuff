/*-----------------------------------------------------------------------------
Project:             Generic
Item:                10         Weapons
Component:           10.5       Spearfish
Unit:                10.5.1     Model
                     10.5.1.10  utilities

Filename:            %M%
Classification:      SECRET

Originator:          J. Dyer
Version:             %I%
Date:                %E%
Time:                %U%

Language:            C
Compiler:            Gnu GCC version 2.7.2
Host OS:             Solaris 2
Target Processor:    SPARC
Target OS:           Solaris 2
-------------------------------------------------------------------------------
Description:    These routines are for use on angles supplied in radians.
                angle_interval : returns the angular difference between
                the two supplied bearing angles.
                add_angle   : returns the resultant angle of the two
                supplied angles.
                subtract_angle : returns the angle given by the first
                angle minus the second angle.
-------------------------------------------------------------------------------
Amendment record:
-------------------------------------------------------------------------------
(c) 2002 AMS
-----------------------------------------------------------------------------*/

#include <math.h>
#include "d7macs.h"

/******************************************************************************

   angle_interval : works out the angular difference between two bearing
          angles.

******************************************************************************/
double angle_interval (double angle1, double angle2)
{
   double diff = fabs(angle1 - angle2);
   if (diff > DM_PI)
   {
      diff = (2.0 * DM_PI) - diff;
   }
   return (fabs(diff));
}

/******************************************************************************

   add_angle : works out the resultant angle of two angles.

*****************************************************************************/
double add_angle (double angle1, double angle2)
{
   double local_add = angle1 + angle2;
   if (local_add>DM_PI)
   {
      local_add -= 2.0 * DM_PI;
   }
   else if (local_add<-DM_PI)
   {
      local_add = (2.0 * DM_PI) + local_add;
   }
   return local_add;
}

/******************************************************************************

   subtract_angle : works out the angle given by the
          first angle minus the second angle.

******************************************************************************/
double subtract_angle (double angle1, double angle2)
{
   double sub = angle1 - angle2;
   if (sub>DM_PI)
   {
      sub -= 2.0 * DM_PI;
   }
   else if (sub<-DM_PI)
   {
      sub = (2.0 * DM_PI) + sub;
   }
   return (sub);
}

/******************************************************************************

	angle_360 : converts a -180 - 180 angle to 0-360 range

******************************************************************************/
double angle_360 (double angle1)
{
	if (angle1 < 0.0)
	{
		angle1 += 360.0;
	}

	return (angle1);
}
