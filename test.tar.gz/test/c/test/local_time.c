#include <time.h>
#include <stdio.h>
#include "local_time.h"

int main(void)
{
int arg_sign;
 float a_float;
 unsigned short a_short;
 unsigned int an_usint;
 unsigned long an_uslong;
 unsigned long long an_uslonglong;

    printf ("int         = %d\n", sizeof(arg_sign));
    printf ("flt         = %d\n", sizeof(a_float));
    printf ("u short     = %d\n", sizeof(a_short));
    printf ("u int       = %d\n", sizeof(an_usint));
    printf ("u long      = %d\n", sizeof(an_uslong));
    printf ("u long long = %d\n", sizeof(an_uslonglong));

    return 1;
}

