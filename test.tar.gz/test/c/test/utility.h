/* ------------------------------------------------------------------------
 *  Project:            GENERIC
 *  Item:               ????
 *  Component:          ????
 *  Filename:           %M%
 *  Classification:     RESTRICTED
 *
 *  Originator:         J. Dyer
 *  Version:            %I%
 *  Date:               %E%
 *  Time:               %U%
 *
 *  Language:           C
 *  Compiler:           Gnu C
 *  Host OS:            Solaris
 *  Target processor:   SPARC
 *  Target OS:          Solaris
 * ------------------------------------------------------------------------
 *  Description:
 *
 *  provides utilities.
 *
 * ------------------------------------------------------------------------
 *  (c) Copyright 2002 AMS
 * ------------------------------------------------------------------------
 */


#ifndef UTILITY_H
#    define UTILITY_H
#    include <stdio.h>

/*  #define KTOMS 0.51447 */
/*  #define CYTOM 0.9144 */
/*  #define CFTOM 0.3048 */

/*  	typedef struct */
/*  	{ */
/*  	   unsigned int acomm; */
/*  	   unsigned int bcomm; */
/*  	} COMINT; */

/*  	typedef struct */
/*  	{ */
/*  	   float time; */
/*  	   int   command; */
/*  	   float value[3]; */
/*  	} COMFIX; */

/*  	typedef union */
/*  	{ */
/*  	   COMINT vali; */
/*  	   COMFIX valf; */
/*  	} COMVALUE; */

/*  	typedef struct node */
/*  	{ */
/*  	   COMVALUE     value; */
/*  	   struct node* next; */
/*  	   struct node* prev; */
/*  	} NODE; */

/*  	typedef struct */
/*  	{ */
/*  	   int   length; */
/*  	   NODE* start; */
/*  	   NODE* end; */
/*  	} LIST; */

//	int in_rectangle(DISPLAY_COORDINATES,
//					 DISPLAY_COORDINATES,
//					 int,int);

//	float maxf(float, float);
//	float minf(float, float);
//	int   maxi(int, int);
//	int   mini(int, int);
//	int   nint(float);
//	float slant_range(WORLD_COORDINATES*, WORLD_COORDINATES*);
	char* read_line(FILE*);
	int read_line2(char *the_string, FILE* from_file);
//	char* translate_state(int);

	/* linked list operations */
//	void     make_a_list(LIST*, COMVALUE*);
//	void     add_to_end(LIST*, COMVALUE*);
//	COMVALUE remove_from_start(LIST**, int);
//	void     make_empty(LIST*);
//	int      is_empty(LIST*);

//	int   tgtno(void);
//	void  set_tgtno(int);

//	void right_justify(char*, int);

//	float normal(float);

//	float interp(float, float, float, float, float);

#endif

