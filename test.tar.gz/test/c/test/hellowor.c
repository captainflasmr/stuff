/* cs214/week1/helloworld.c */

#include <string.h>
#include <time.h>
#include <stdlib.h>


main()
{
   int i;
   float curr_time = 0.0;
   ldiv_t curr_div;
   char *format_str = "helloe";
   char *format_sec;
   char *format_min;

   struct tm time_num;

/*   for(i=0; i<=20; i++) { */
     curr_time = 201.4;

     curr_div = ldiv((long)curr_time, (long)60.0);

     time_num.tm_sec = (int)curr_div.rem;
     time_num.tm_min = (int)curr_div.quot;

     strftime(format_sec, 10, "%S", &time_num);
     strftime(format_min, 10, "%M", &time_num);

     sprintf(format_str, "%s:%s.%d,  ", format_min, format_sec, ((int)(curr_time*10) - ((int)curr_time)*10));

     printf("Format = %s\n", format_str);
/*   } */
        
}

