/* ------------------------------------------------------------------------
 *  Project:            GENERIC
 *  Item:               ????
 *  Component:          ????
 *  Filename:           %M%
 *  Classification:     RESTRICTED
 *
 *  Originator:         J. Dyer
 *  Version:            %I%
 *  Date:               %E%
 *  Time:               %U%
 *
 *  Language:           C
 *  Compiler:           Gnu C
 *  Host OS:            Solaris
 *  Target processor:   SPARC
 *  Target OS:          Solaris
 * ------------------------------------------------------------------------
 *  Description:
 *
 *  provides utilities.
 *
 * ------------------------------------------------------------------------
 *  (c) Copyright 2002 AMS
 * ------------------------------------------------------------------------
 */

#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "utility.h"

#ifdef DMALLOC
#include "../dmalloc/dmalloc-4.8.2/dmalloc.h"
#endif

//static int tn;

/* public subroutines */
/*  int in_rectangle(DISPLAY_COORDINATES cp, */
/*  				 DISPLAY_COORDINATES recxy, int ht, int wid) */
/*  { */
/*  	if (cp.x >= recxy.x && */
/*  		cp.x <= recxy.x + wid && */
/*  		cp.y >= recxy.y-PIXELS_PER_CHARACTER && */
/*  		cp.y <= recxy.y + ht-PIXELS_PER_CHARACTER) {return (1);} */
/*  	else {return (0);} */
/*  } */

/*  float maxf(float arg1, float arg2){return ((arg1 < arg2) ? arg2 : arg1);} */
/*  float minf(float arg1, float arg2){return ((arg1 > arg2) ? arg2 : arg1);} */

/*  int maxi(int arg1, int arg2){return ((arg1 < arg2) ? arg2 : arg1);} */
/*  int mini(int arg1, int arg2){return ((arg1 > arg2) ? arg2 : arg1);} */

/*  int nint(float arg){return ((arg > ((int)arg+0.5)) ? arg + 1 : arg);} */

/*  float slant_range(WORLD_COORDINATES* arg1, WORLD_COORDINATES* arg2) */
/*  { */
/*  	float result; */
/*  	result = sqrt(pow((arg1->x - arg2->x), 2.0) + */
/*  				  pow((arg1->y - arg2->y), 2.0) + */
/*  				  pow((arg1->z - arg2->z), 2.0)); */
/*  	return (result); */
/*  } */

char* read_line(FILE* from_file)
{
	char* temp = "                                        ";
	char c;
	char null = '\0';
	int i= 0;

//	temp = (char *) malloc(40);

//	if (temp == NULL)
//	    printf ("No Memory\n");

	/* Get first character and check for duff new line. First skip tabs*/
	while ((c = fgetc(from_file)) == '\t');

	if (c != '\n') /* not eoln so copy to temp */
	  if (c != ' ' && c != '\t') temp[i++] = c;

	while ((c = fgetc(from_file)) != '\n')
	{
	    if (c != ' ' && c != '\t') {
		temp[i++] = c;
	    }
	    printf("%c\n",c);
	}

	temp[i] = null;

	return (temp);

//	free(temp);
}

int read_line2(char *the_string, FILE* from_file)
{
//	char temp[40];
	char c;
	char null = '\0';
	int i= 0;

//	temp = (char *) malloc(40);

//	if (temp == NULL)
//	    printf("No Memory\n");

	/* skip the opening blanks */
	while ((c = fgetc(from_file)) == ' ' || c == '\t');

	the_string[i++] = c;

	while ((c = fgetc(from_file)) != '\n') {
	    the_string[i++] = c;
	    printf("%c\n",c);
	}
	the_string[i] = null;
	return i;
//	free(temp);
}

/*
float read_float(FILE* from_file)
{
	float number;


	return number;
}
float read_integer(FILE* from_file)
{
	float number;


	return number;
}

*/

/*  char* translate_state(int state) */
/*  { */
/*  	switch (state) */
/*  	{ */
/*  		case DM_DEAD: */
/*  			return "DEAD"; */
/*  		case DM_FUEL: */
/*  			return "FUEL"; */
/*  		case DM_HIT: */
/*  			return " HIT"; */
/*  		case DM_OFF: */
/*  			return " OFF"; */
/*  		case DM_ON: */
/*  			return "  ON"; */
/*  		case DM_LIVE: */
/*  			return "LIVE"; */
/*  		case DM_DIS: */
/*  			return " DIS"; */
/*  		case DM_SAA: */
/*  			return " SAA"; */
/*  		case DM_CGI: */
/*  			return "  CI"; */
/*  		case DM_CGP: */
/*  			return " CSP"; */
/*  		case DM_CGA: */
/*  			return " CSA"; */
/*  		case DM_MCG: */
/*  			return " MCG"; */
/*  		case DM_PC: */
/*  			return "  PC"; */
/*  		case DM_PS: */
/*  			return "  PS"; */
/*  		case DM_AS1: */
/*  			return " AS1"; */
/*  		case DM_AS2: */
/*  			return " AS2"; */
/*  		case DM_AS3: */
/*  			return " AS3"; */
/*  		case DM_AS4: */
/*  			return " AS4"; */
/*  		case DM_AS5: */
/*  			return " AS5"; */
/*  		case DM_AS6: */
/*  			return " AS6"; */
/*  		case DM_AS7: */
/*  			return " AS7"; */
/*  		case DM_AC: */
/*  			return "  AC"; */
/*  		case DM_AH: */
/*  			return "  AH"; */
/*  		case DM_TI: */
/*  			return "  TI"; */
/*  		case DM_AF: */
/*  			return "  AF"; */
/*  		case DM_RATK: */
/*  			return "RATK"; */
/*  		case DM_JC: */
/*  			return "  JC"; */
/*  		case DM_UJA: */
/*  			return " UJA"; */
/*  		case DM_MJA: */
/*  			return " MJA"; */
/*  		case DM_UJO: */
/*  			return " UJO"; */
/*  		case DM_SJA: */
/*  			return " SJA"; */
/*  		case DM_SJO: */
/*  			return " SJO"; */
/*  		case DM_LCP1: */
/*  			return "LCP1"; */
/*  		case DM_LCP2: */
/*  			return "LCP2"; */
/*  		case DM_SHM: */
/*  			return " SHM"; */
/*  	} */
/*  	return         " ERR"; */
/*  } */

/* linked list operations */

//void dispose(NODE* start_node)
//{   /* delete from start_node to the end of the list */
/*  	NODE* N1; */
/*  	NODE* N2; */

/*  	N1 = start_node; */
/*  	start_node = NULL; */

/*  	while (N1 != NULL) */
/*  	{ */
/*  		N2 = (*N1).next; */
/*  		free(N1); */
/*  		N1 = N2; */
/*  	} */
/*  } */


//void make_a_list(LIST* the_list, COMVALUE* from_value)
//{   /* start a new list from a single value */
//	NODE newnode;

	/*if (the_list == NULL)the_list = malloc(sizeof(LIST));   */

//	(*the_list).length = 1;
//	(*the_list).start  = (node*) malloc(sizeof(NODE));
//	(*the_list).start  = (NODE*) malloc(sizeof(NODE));

//	newnode.value = *from_value;
//	newnode.next  = NULL;
//	newnode.prev  = NULL;

//	*((*the_list).start) = newnode;
//	(*the_list).end   = (*the_list).start;
//	printf("make_a_list empty\n");
//}


//void add_to_end(LIST* the_list, COMVALUE* the_value)
//{   /* add a new value to the end of the list */

//	NODE* newnode;

	/* set up the new node */
//	newnode = (node*) malloc(sizeof(NODE));
//	newnode = (NODE*) malloc(sizeof(NODE));
//	(*newnode).value = *the_value;
//	(*newnode).next  = NULL;
//	(*newnode).prev  = (*the_list).end;

	/* first set the new node as the next node for the end node ...*/
//	if ((*the_list).end != NULL) (*(*the_list).end).next = newnode;

	/* ... now replace the new node as the end node ...*/
//	(*the_list).end  = newnode;

	/* ... and finally increment the length */
//	if ((*the_list).length == NULL)
//	{
//		(*the_list).start  = (*the_list).end;
//		(*the_list).length = 1;
//	}
//	else (*the_list).length++;
//	printf("add_to_end empty\n");
//}


//COMVALUE remove_from_start(LIST** the_list, int tag)
//{  /* take a value from the start of the list */
/*     COMVALUE temp; */
/*     NODE*    the_node; */

/*     if (!tag) */
/*     {  temp.vali.acomm = 0; */
/*  	  temp.vali.bcomm = 0; */
/*     } */
/*     else */
/*     {  temp.valf.time     = 0.0; */
/*  	  temp.valf.command  = 0; */
/*  	  temp.valf.value[0] = 0.0; */
/*  	  temp.valf.value[1] = 0.0; */
/*  	  temp.valf.value[2] = 0.0; */
/*     } */

/*     if ((**the_list).length == NULL) */
/*     { */
/*  	  return temp; */
/*     } */
/*     else */
/*     { */
/*  	  the_node = (**the_list).start; */

/*  	  if ((**the_list).length == 1) */
/*  	  { */
		  /* This is a bit odd - the list is destroyed if it is empty.
			 This makes the is_empty routine redundant and the test
			 is just made on = or != NULL */
/*  		  free(*the_list); */
/*  		  *the_list = NULL; */
/*  	  } */
/*  	  else */
/*  	  { */
/*  		  (**the_list).length--; */
/*  		  (**the_list).start = (*the_node).next; */
/*  		  (*(**the_list).start).prev = NULL; */
/*  	  } */

/*  	  temp = (*the_node).value; */
/*  	  free(the_node); */
/*     } */
/*     return temp; */
/*  } */

//void make_empty(LIST* the_list)
//{   /* empty the list */
/*  	dispose((*the_list).start); */
/*  	(*the_list).length = 0; */
/*  } */

/*  int is_empty(LIST* the_list) */
/*  { */
/*  	if ((*the_list).length > 0)return 0; */
/*  	else return 1; */
/*  } */

/*  int tgtno(void){return tn;} */


/*  void set_tgtno(int tgt){tn = tgt;} */


/*  void right_justify(char* the_string, int finlen) */
/*  { */
/*  	char* s; */
/*  	int i; */

/*  	s = (char*) malloc(finlen); */

/*  	if (s == NULL) */
/*  	    printf("No memory"); */

/*  	i = 0; */
/*  	while (i < finlen) s[i++] = ' '; */

/*  	strcpy(s + finlen - strlen(the_string) - 1, the_string); */

/*  	strcpy(the_string, s); */

/*  	free(s); */
/*  } */


/*  float normal( float s_dev ) */
/*  { */
/*  	float u1; */
/*  	static float u2; */
/*  	float ss; */
/*  	static float tt; */
/*  	float sample; */
/*  	static int pair = 0; */

/*  	do */
/*  	{ */
/*  		if ( pair == 0 ) */
/*  		{ */
/*  			do */
/*  			{ */
/*  				u1 = 2.0 * (float)(rand()%1000)/(float)1000.0 -1.0; */
/*  				u2 = 2.0 * (float)(rand()%1000)/(float)1000.0 -1.0; */
/*  				ss = ( u1*u1 ) + ( u2*u2 ); */
/*  			} while ( ss > 1.0 ); */
/*  			tt = sqrt( -2.0 * log(ss)/ss ); */
/*  			sample = u1 * tt * s_dev; */
/*  			pair = 1; */
/*  		} */
/*  		else */
/*  		{ */
/*  			sample = u2 * tt * s_dev; */
/*  			pair = 0; */
/*  		} */
/*  	} while ( fabs(sample) > 3.0 * s_dev ); */
/*  	return (sample); */
/*  } */


/*  float interp(float x1, float x2, float y1, float y2, float x) */
/*  { */
/*     float y, dx; */

/*     dx = x2 - x1; */

/*     if (fabs(dx) < 1.0E-5) return y1; */
/*     else */
/*     {  y = y1 + ((y2 - y1) * (x - x1) / dx); */
/*  	  return y; */
/*     } */
/*  } */
