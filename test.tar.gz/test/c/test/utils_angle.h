/*-----------------------------------------------------------------------------
Project:             Generic
Item:                10         Weapons
Component:           10.5       Spearfish
Unit:                10.5.1     Model
                     10.5.1.10  utilities

Filename:            %M%
Classification:      SECRET

Originator:          J. Dyer
Version:             %I%
Date:                %E%
Time:                %U%

Language:            C
Compiler:            Gnu GCC version 2.7.2
Host OS:             Solaris 2
Target Processor:    SPARC
Target OS:           Solaris 2
-------------------------------------------------------------------------------
Description:    These routines are for use on angles supplied in radians.
                angle_interval : returns the angular difference between
                the two supplied bearing angles.
                add_angle   : returns the resultant angle of the two
                supplied angles.
                subtract_angle : returns the angle given by the first
                angle minus the second angle.
-------------------------------------------------------------------------------
Amendment record:
-------------------------------------------------------------------------------
(c) 2002 AMS
-----------------------------------------------------------------------------*/



//#ifndef DM_DEFINED
//#define DM_DEFINED
//#include "../sfish/wpns_sfish_data_macros.h"

double angle_interval (double angle1, double angle2);

double add_angle (double angle1, double angle2);

double subtract_angle (double angle1, double angle2);

double angle_360(double angle1);

//#endif

