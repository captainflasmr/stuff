/* cs214/week1/helloworld.c */

#include <string.h>
#include <time.h>
#include <stdlib.h>


main()
{
   int min_int, sec_int, ms_int;
   float total_flt; 

   int i;
   float curr_time = 0.0;
   ldiv_t curr_div;
   char *format_str = "helloe";
   char *format_sec;
   char *format_min;

   struct tm time_num;


/*   for(i=0; i<=20; i++) { */
     curr_time = 201.2;

     curr_div = ldiv((long)curr_time, (long)60.0);

     time_num.tm_sec = (int)curr_div.rem;
     time_num.tm_min = (int)curr_div.quot;

     strftime(format_sec, 10, "%S", &time_num);
     strftime(format_min, 10, "%M", &time_num);

     sprintf(format_str, "%s:%s.%d  ", format_min, format_sec,
           ((int)(curr_time*10) - ((int)curr_time)*10));

     printf("Format = %s, ms1 = %d, ms2 = %d, ct = %d\n", format_str,
     (int)(curr_time*10), ((int)curr_time)*10, (int)(curr_time*10));
/*   } */

     /* Convert back into seconds */
     /* Convert minutes */
     min_int = (format_str[0] - '0')*10 + (format_str[1] - '0');
     /* Convert seconds */
     sec_int =  (format_str[3] - '0')*10 + (format_str[4] - '0');
     /* Convert milliseconds */
     ms_int = (format_str[6] - '0');

     total_flt = (min_int * 60) + (sec_int) + ((float)ms_int / 10);

     printf("%d:%d.%d\n", min_int, sec_int, ms_int);
     printf("Total float = %3.1f\n", total_flt);
}

