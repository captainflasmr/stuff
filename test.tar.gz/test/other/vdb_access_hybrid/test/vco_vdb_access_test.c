//  %M% %I% %E% %U%
//  Originator : J. Dyer
//
//  Quick test of Ada Vehicle Classification Overlay (VCO) Vehicle Database Access
//

#include <stdio.h>
#include <string.h>

#include "../vco_vdb_access.h"

//
// Specifing any command line parameter triggers a pass of the whole DB.
//

int main (int argc, char **argv) {

  printf ("\nvco_vdb_access_test: C start...\n");

  Vco_Vdb_Access_Data_P myInfo_P;
  Vco_Vdb_Access_Data_T myInfo_T;

  printf ("\nvco_vdb_access_test: Ada starting...\n");
  adainit();
  printf ("\nvco_vdb_access_test: Ada started\n");

  // Fails
  printf ("\nvco_vdb_access_test: Expect Fail...\n");
  myInfo_P = Vco_Vdb_Access_Get_Data_P (1);
  memcpy (&myInfo_T, myInfo_P, sizeof (Vco_Vdb_Access_Data_T));
  printf ("vco_vdb_access_test: Fail Length=%f\n", myInfo_T.C200_Length);
  printf ("vco_vdb_access_test: Fail Height=%f\n", myInfo_T.C203_Height);
  printf ("vco_vdb_access_test: Fail Width=%f\n", myInfo_T.C215_Width);

  //
  // Now Initialise
  //
  Vco_Vdb_Access_Initialise ();

  printf ("\nvco_vdb_access_test: Expect Success Pointer Method...\n"); 
  // This requests the first Submarine data at the moment, will eventually
  // pass in a C enumeration
  myInfo_P = Vco_Vdb_Access_Get_Data_P (4);
  memcpy (&myInfo_T, myInfo_P, sizeof (Vco_Vdb_Access_Data_T));
  printf ("vco_vdb_access_test: Subtest Length=%f\n", myInfo_T.C200_Length);
  printf ("vco_vdb_access_test: Subtest Height=%f\n", myInfo_T.C203_Height);
  printf ("vco_vdb_access_test: Subtest Width=%f\n", myInfo_T.C215_Width);

  printf ("\nvco_vdb_access_test: Expect Success - Structure Method...\n");
  myInfo_T = Vco_Vdb_Access_Get_Data_T (4);
  printf ("vco_vdb_access_test: Echo II Length=%f\n", myInfo_T.C200_Length);
  printf ("vco_vdb_access_test: Echo II Height=%f\n", myInfo_T.C203_Height);
  printf ("vco_vdb_access_test: Echo II Width=%f\n", myInfo_T.C215_Width);

  adafinal();
  printf ("\nvco_vdb_access_test: Ada ended.\n");

  return 0;
}
