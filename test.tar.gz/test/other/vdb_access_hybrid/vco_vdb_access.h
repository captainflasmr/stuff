/*
---------------------------------------------------------------------------
--  Project:            ASTUTE
--  Item:
--  Component:
--  Unit:
--  Classification:     RESTRICTED
--
--  Subversion:         $Id: radar_vdb_access.h 11 2006-08-21 13:31:12Z rconnell $
--  Originator:         R W Norris
--
--  Language:           C
--  Compiler:           GCC
--  Host OS:            GNU/Linux
--  Target processor:   x86
--  Target OS:          GNU/Linux
---------------------------------------------------------------------------
--  Description:
--
--    Simple Interface for Radar Subsystem to access Vehicle Database
--    All names start with the name of the package 'Radar_Vdb_Access' to hopefully
--    prevent any C name clashes.
--
--    Also see equivalent radar_vdb_access.ads for the Ada equivalents
--    (Imperative these two files are consistent)
--
---------------------------------------------------------------------------
--  (c) Copyright 2006 BAE Systems
---------------------------------------------------------------------------
*/

#ifndef VCO_VDB_ACCESS_H
#define VCO_VDB_ACCESS_H

#ifdef __cplusplus
extern "C"
  {
#endif

    /** @brief   Data structure that contains all information that the radar subsystem requires from the vehicle database for any single vehicle
     *           All units are metres
     */
    typedef struct {
      float C200_Length;
      float C203_Height;
      float C215_Width;
    } Vco_Vdb_Access_Data_T;
    
    /** @brief   Pointer to data structure
     */
    typedef Vco_Vdb_Access_Data_T* Vco_Vdb_Access_Data_P;
    
    /** @brief   Ada Runtime Start
     *           Must be called before calling any Ada routine
     *
     *  @param   void
     *  @return  void
     */
    extern void adainit ( void );

    /** @brief   Ada Runtime Finish
     *           Should be called when program no longer requires the Ada Runtime (and hence any Ada routine)
     *           Normally called when program exits for clean shutdown
     *
     *  @param   void
     *  @return  void
     */
    extern void adafinal ( void );
        
    /** @brief   Vehicle Database Initialise
     *           Initialise must be called first (before calling any 'get_data' methods)
     *
     *  @param   void
     *  @return  void
     */
    extern void Vco_Vdb_Access_Initialise ( void );

    /** @brief  Call this to get back vco info about a vehicle
     *          Direct structure method 
     *          Sometimes there are problems passing structures between Ada & C, so pointer method is more reliable.
     *          They both appear to work
     * 
     *  @param  PassiveParameterIndex       HLA RPRFOM-NS-X6+: BaseEntity.PassiveParameterIndex.
     *                                      This routine maps PassiveParameterIndex into the Database for the given vehicle including permanent / temporary
     *  @return Vco_Vdb_Access_Data_T     Data structure
     *                                      If all values are 0.0 then probably no db entry exists for the PassiveParameterIndex
     *                                      (or possibly access to db timed out (unlikely) - If problem will put some error codes into data structure
     */
    extern Vco_Vdb_Access_Data_T Vco_Vdb_Access_Get_Data_T ( int );
    
    /** @brief  Call this to get back vco info about a vehicle
     *          Pointer method	
     *          Sometimes there are problems passing structures between Ada & C, so pointer method is more reliable.
     *          They both appear to work
     * 
     *  @param  PassiveParameterIndex       HLA RPRFOM-NS-X6+: BaseEntity.PassiveParameterIndex.
     *                                      This routine maps PassiveParameterIndex into the Database for the given vehicle including permanent / temporary
     *  @return Vco_Vdb_Access_Data_P     Pointer to data structure
     *                                      Normally best practise immediately copy the contents of the pointer into local store
     *                                      If all values are 0.0 then probably no db entry exists for the PassiveParameterIndex
     *                                      (or possibly access to db timed out (unlikely) - If problem will put some error codes into data structure
     */
    extern Vco_Vdb_Access_Data_P Vco_Vdb_Access_Get_Data_P ( int );

#ifdef __cplusplus
} // end extern
#endif

#endif // VCO_VDB_ACCESS_H
