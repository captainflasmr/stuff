#ifdef __STDC__
#define PARAMS(paramlist) paramlist
#else
#define PARAMS(paramlist) ()
#endif

extern void __gnat_set_globals 
 PARAMS ((int, int, int, int, int, int, const char *,
          const char *, int, int, int, int));
extern void adafinal PARAMS ((void));
extern void adainit PARAMS ((void));
extern void system__standard_library__adafinal PARAMS ((void));
extern int main PARAMS ((int, char **, char **));
extern void exit PARAMS ((int));
extern void __gnat_break_start PARAMS ((void));
extern int _ada_vco_vdb_access PARAMS ((void));
extern void __gnat_initialize PARAMS ((void));
extern void __gnat_finalize PARAMS ((void));
extern void __gnat_install_handler PARAMS ((void));

extern void ada__exceptions___elabs PARAMS ((void));
extern void system__exceptions___elabs PARAMS ((void));
extern void system__soft_links___elabb PARAMS ((void));
extern void system__secondary_stack___elabb PARAMS ((void));
extern void system__exception_table___elabb PARAMS ((void));
extern void ada__calendar___elabs PARAMS ((void));
extern void ada__io_exceptions___elabs PARAMS ((void));
extern void ada__numerics___elabs PARAMS ((void));
extern void ada__strings___elabs PARAMS ((void));
extern void ada__tags___elabs PARAMS ((void));
extern void ada__tags___elabb PARAMS ((void));
extern void ada__streams___elabs PARAMS ((void));
extern void interfaces__c___elabs PARAMS ((void));
extern void interfaces__c__strings___elabs PARAMS ((void));
extern void system__finalization_root___elabs PARAMS ((void));
extern void ada__exceptions___elabb PARAMS ((void));
extern void ada__calendar__delays___elabb PARAMS ((void));
extern void ada__strings__maps___elabs PARAMS ((void));
extern void ada__strings__maps__constants___elabs PARAMS ((void));
extern void system__finalization_implementation___elabs PARAMS ((void));
extern void system__finalization_implementation___elabb PARAMS ((void));
extern void ada__finalization___elabs PARAMS ((void));
extern void ada__finalization__list_controller___elabs PARAMS ((void));
extern void ada__strings__unbounded___elabs PARAMS ((void));
extern void system__file_control_block___elabs PARAMS ((void));
extern void system__direct_io___elabs PARAMS ((void));
extern void system__file_io___elabb PARAMS ((void));
extern void ada__text_io___elabs PARAMS ((void));
extern void ada__text_io___elabb PARAMS ((void));
extern void csl_level_exceptions___elabs PARAMS ((void));
extern void csl_angle___elabs PARAMS ((void));
extern void csl_decibel___elabb PARAMS ((void));
extern void csl_angle___elabb PARAMS ((void));
extern void csl_length___elabs PARAMS ((void));
extern void csl_angle_rate___elabs PARAMS ((void));
extern void csl_levels___elabs PARAMS ((void));
extern void csl_levels___elabb PARAMS ((void));
extern void csl_tonals___elabs PARAMS ((void));
extern void csl_tonals___elabb PARAMS ((void));
extern void csl_image_utilities___elabs PARAMS ((void));
extern void csl_config___elabb PARAMS ((void));
extern void sm_model_radar_general_types___elabs PARAMS ((void));
extern void sm_model_radar_kind___elabs PARAMS ((void));
extern void sm_model_sonar_general_types___elabs PARAMS ((void));
extern void sm_model_sonar_kind___elabs PARAMS ((void));
extern void sm_model_vehicle_bb_flow_types___elabs PARAMS ((void));
extern void sm_model_vehicle_bb_machinery_types___elabs PARAMS ((void));
extern void sm_model_vehicle_bb_propeller_modulation_types___elabs PARAMS ((void));
extern void sm_model_vehicle_bb_propeller_types___elabs PARAMS ((void));
extern void sm_model_vehicle_enhanced_aural_types___elabs PARAMS ((void));
extern void sm_model_vehicle_general_types___elabs PARAMS ((void));
extern void sm_model_vehicle_general___elabs PARAMS ((void));
extern void sm_model_vehicle_kind___elabs PARAMS ((void));
extern void sm_model_vehicle_associated_fit_types___elabs PARAMS ((void));
extern void sm_model_vehicle_nb_aux_int_types___elabs PARAMS ((void));
extern void sm_model_vehicle_nb_bld_types___elabs PARAMS ((void));
extern void sm_model_vehicle_nb_common_types___elabs PARAMS ((void));
extern void sm_model_vehicle_bb_aural_types___elabs PARAMS ((void));
extern void sm_model_vehicle_nb_fir_types___elabs PARAMS ((void));
extern void sm_model_vehicle_nb_mod_types___elabs PARAMS ((void));
extern void sm_model_vehicle_nb_spd_bld_types___elabs PARAMS ((void));
extern void sm_model_vehicle_nb_spd_types___elabs PARAMS ((void));
extern void sm_model_vehicle_physical_types___elabs PARAMS ((void));
extern void sm_model_vehicle_project_specific_types___elabs PARAMS ((void));
extern void sm_model_vehicle_propulsion_mode_types___elabs PARAMS ((void));
extern void sm_model_vehicle_associated_fit___elabs PARAMS ((void));
extern void sm_model_vehicle_bb_aural___elabs PARAMS ((void));
extern void sm_model_vehicle_bb_flow___elabs PARAMS ((void));
extern void sm_model_vehicle_bb_machinery___elabs PARAMS ((void));
extern void sm_model_vehicle_bb_propeller___elabs PARAMS ((void));
extern void sm_model_vehicle_bb_propeller_modulation___elabs PARAMS ((void));
extern void sm_model_vehicle_bb___elabs PARAMS ((void));
extern void sm_model_vehicle_enhanced_aural___elabs PARAMS ((void));
extern void sm_model_vehicle_nb_aux_int___elabs PARAMS ((void));
extern void sm_model_vehicle_nb_common___elabs PARAMS ((void));
extern void sm_model_vehicle_nb_fir___elabs PARAMS ((void));
extern void sm_model_vehicle_nb_bld___elabs PARAMS ((void));
extern void sm_model_vehicle_nb_spd___elabs PARAMS ((void));
extern void sm_model_vehicle_nb___elabs PARAMS ((void));
extern void sm_model_vehicle_physical___elabs PARAMS ((void));
extern void sm_model_vehicle_propulsion_mode___elabs PARAMS ((void));
extern void sm_model_vehicle_speed_types___elabs PARAMS ((void));
extern void sm_model_vehicle_speed___elabs PARAMS ((void));
extern void sm_model_vehicle_turning_diving_types___elabs PARAMS ((void));
extern void sm_model_vehicle_turning_diving___elabs PARAMS ((void));
extern void sm_model_vehicle_wb_types___elabs PARAMS ((void));
extern void sm_model_vehicle_wb___elabs PARAMS ((void));
extern void sm_model_vehicle___elabs PARAMS ((void));
extern void sm_model_vehicle___elabb PARAMS ((void));
extern void sm_model_vehicle_database___elabs PARAMS ((void));
extern void sm_model_vehicle_database___elabb PARAMS ((void));

extern int  __gnat_handler_installed;

void adafinal () {
   system__standard_library__adafinal ();
}

void adainit ()
{
   extern char gnat__strings_E;
   extern char ada__exceptions_E;
   extern char system__exceptions_E;
   extern char system__secondary_stack_E;
   extern char system__soft_links_E;
   extern char system__exception_table_E;
   extern char ada__calendar_E;
   extern char ada__calendar__delays_E;
   extern char ada__io_exceptions_E;
   extern char ada__numerics_E;
   extern char ada__strings_E;
   extern char ada__tags_E;
   extern char ada__streams_E;
   extern char interfaces__c_E;
   extern char interfaces__c__strings_E;
   extern char system__finalization_root_E;
   extern char ada__strings__maps_E;
   extern char ada__strings__maps__constants_E;
   extern char system__finalization_implementation_E;
   extern char ada__finalization_E;
   extern char ada__finalization__list_controller_E;
   extern char ada__strings__unbounded_E;
   extern char system__file_control_block_E;
   extern char system__direct_io_E;
   extern char system__file_io_E;
   extern char ada__text_io_E;
   extern char csl_host_E;
   extern char csl_level_exceptions_E;
   extern char csl_system_numbers_E;
   extern char csl_angle_E;
   extern char csl_decibel_E;
   extern char csl_fast_maths_E;
   extern char csl_length_E;
   extern char csl_powers_E;
   extern char csl_statistical_E;
   extern char csl_system_utils_E;
   extern char csl_time_E;
   extern char csl_angle_rate_E;
   extern char csl_database_E;
   extern char csl_frequency_E;
   extern char csl_real_time_E;
   extern char csl_velocity_E;
   extern char csl_volts_E;
   extern char csl_levels_E;
   extern char csl_paths_E;
   extern char csl_tonals_E;
   extern char csl_image_utilities_E;
   extern char csl_config_E;
   extern char sm_model_radar_general_types_E;
   extern char sm_model_radar_kind_E;
   extern char sm_model_sonar_general_types_E;
   extern char sm_model_sonar_kind_E;
   extern char sm_model_vehicle_bb_flow_types_E;
   extern char sm_model_vehicle_bb_machinery_types_E;
   extern char sm_model_vehicle_bb_propeller_modulation_types_E;
   extern char sm_model_vehicle_bb_propeller_types_E;
   extern char sm_model_vehicle_enhanced_aural_types_E;
   extern char sm_model_vehicle_general_types_E;
   extern char sm_model_vehicle_general_E;
   extern char sm_model_vehicle_kind_E;
   extern char sm_model_vehicle_associated_fit_types_E;
   extern char sm_model_vehicle_nb_aux_int_types_E;
   extern char sm_model_vehicle_nb_bld_types_E;
   extern char sm_model_vehicle_nb_common_types_E;
   extern char sm_model_vehicle_bb_aural_types_E;
   extern char sm_model_vehicle_nb_fir_types_E;
   extern char sm_model_vehicle_nb_mod_types_E;
   extern char sm_model_vehicle_nb_spd_bld_types_E;
   extern char sm_model_vehicle_nb_spd_types_E;
   extern char sm_model_vehicle_physical_types_E;
   extern char sm_model_vehicle_project_specific_types_E;
   extern char sm_model_vehicle_propulsion_mode_types_E;
   extern char sm_model_vehicle_associated_fit_E;
   extern char sm_model_vehicle_bb_aural_E;
   extern char sm_model_vehicle_bb_flow_E;
   extern char sm_model_vehicle_bb_machinery_E;
   extern char sm_model_vehicle_bb_propeller_E;
   extern char sm_model_vehicle_bb_propeller_modulation_E;
   extern char sm_model_vehicle_bb_E;
   extern char sm_model_vehicle_enhanced_aural_E;
   extern char sm_model_vehicle_nb_aux_int_E;
   extern char sm_model_vehicle_nb_common_E;
   extern char sm_model_vehicle_nb_fir_E;
   extern char sm_model_vehicle_nb_bld_E;
   extern char sm_model_vehicle_nb_spd_E;
   extern char sm_model_vehicle_nb_E;
   extern char sm_model_vehicle_physical_E;
   extern char sm_model_vehicle_propulsion_mode_E;
   extern char sm_model_vehicle_speed_types_E;
   extern char sm_model_vehicle_speed_E;
   extern char sm_model_vehicle_turning_diving_types_E;
   extern char sm_model_vehicle_turning_diving_E;
   extern char sm_model_vehicle_wb_types_E;
   extern char sm_model_vehicle_wb_E;
   extern char sm_model_vehicle_E;
   extern char sm_model_vehicle_database_E;
   extern char sm_model_vehicle_database_E;
   extern char vco_vdb_access_E;

   const char *restrictions = "nnvvnnvvvnnvnnvvvvvvnvvvnvnnvnvnvnvvnnnnnnvvvvnnnvvnv";
   const char *interrupt_states = "";

   __gnat_set_globals (
      -1,               /* Main_Priority              */
      -1,               /* Time_Slice_Value           */
      '8',              /* WC_Encoding                */
      ' ',              /* Locking_Policy             */
      ' ',              /* Queuing_Policy             */
      ' ',              /* Tasking_Dispatching_Policy */
      restrictions,     /* Restrictions               */
      interrupt_states, /* Interrupt_States           */
      0,                /* Num_Interrupt_States       */
      0,                /* Unreserve_All_Interrupts   */
      0,                /* Exception_Tracebacks       */
      0);               /* Zero_Cost_Exceptions       */

   if (__gnat_handler_installed == 0)
     {
        __gnat_install_handler ();
     }

   gnat__strings_E = 1;
   if (ada__exceptions_E == 0) {
      ada__exceptions___elabs ();
   }
   if (system__exceptions_E == 0) {
      system__exceptions___elabs ();
      system__exceptions_E++;
   }
   if (system__soft_links_E == 0) {
      system__soft_links___elabb ();
      system__soft_links_E++;
   }
   if (system__secondary_stack_E == 0) {
      system__secondary_stack___elabb ();
      system__secondary_stack_E++;
   }
   if (system__exception_table_E == 0) {
      system__exception_table___elabb ();
      system__exception_table_E++;
   }
   if (ada__calendar_E == 0) {
      ada__calendar___elabs ();
   }
   ada__calendar_E = 1;
   if (ada__io_exceptions_E == 0) {
      ada__io_exceptions___elabs ();
      ada__io_exceptions_E++;
   }
   if (ada__numerics_E == 0) {
      ada__numerics___elabs ();
      ada__numerics_E++;
   }
   if (ada__strings_E == 0) {
      ada__strings___elabs ();
      ada__strings_E++;
   }
   if (ada__tags_E == 0) {
      ada__tags___elabs ();
   }
   if (ada__tags_E == 0) {
      ada__tags___elabb ();
      ada__tags_E++;
   }
   if (ada__streams_E == 0) {
      ada__streams___elabs ();
      ada__streams_E++;
   }
   if (interfaces__c_E == 0) {
      interfaces__c___elabs ();
   }
   interfaces__c_E = 1;
   if (interfaces__c__strings_E == 0) {
      interfaces__c__strings___elabs ();
   }
   interfaces__c__strings_E = 1;
   if (system__finalization_root_E == 0) {
      system__finalization_root___elabs ();
   }
   system__finalization_root_E = 1;
   if (ada__exceptions_E == 0) {
      ada__exceptions___elabb ();
      ada__exceptions_E++;
   }
   if (ada__calendar__delays_E == 0) {
      ada__calendar__delays___elabb ();
      ada__calendar__delays_E++;
   }
   if (ada__strings__maps_E == 0) {
      ada__strings__maps___elabs ();
   }
   ada__strings__maps_E = 1;
   if (ada__strings__maps__constants_E == 0) {
      ada__strings__maps__constants___elabs ();
      ada__strings__maps__constants_E++;
   }
   if (system__finalization_implementation_E == 0) {
      system__finalization_implementation___elabs ();
   }
   if (system__finalization_implementation_E == 0) {
      system__finalization_implementation___elabb ();
      system__finalization_implementation_E++;
   }
   if (ada__finalization_E == 0) {
      ada__finalization___elabs ();
   }
   ada__finalization_E = 1;
   if (ada__finalization__list_controller_E == 0) {
      ada__finalization__list_controller___elabs ();
   }
   ada__finalization__list_controller_E = 1;
   if (ada__strings__unbounded_E == 0) {
      ada__strings__unbounded___elabs ();
   }
   ada__strings__unbounded_E = 1;
   if (system__file_control_block_E == 0) {
      system__file_control_block___elabs ();
      system__file_control_block_E++;
   }
   if (system__direct_io_E == 0) {
      system__direct_io___elabs ();
   }
   if (system__file_io_E == 0) {
      system__file_io___elabb ();
      system__file_io_E++;
   }
   system__direct_io_E = 1;
   if (ada__text_io_E == 0) {
      ada__text_io___elabs ();
   }
   if (ada__text_io_E == 0) {
      ada__text_io___elabb ();
      ada__text_io_E++;
   }
   csl_host_E = 1;
   if (csl_level_exceptions_E == 0) {
      csl_level_exceptions___elabs ();
      csl_level_exceptions_E++;
   }
   csl_system_numbers_E = 1;
   if (csl_angle_E == 0) {
      csl_angle___elabs ();
   }
   csl_fast_maths_E = 1;
   if (csl_decibel_E == 0) {
      csl_decibel___elabb ();
      csl_decibel_E++;
   }
   if (csl_angle_E == 0) {
      csl_angle___elabb ();
      csl_angle_E++;
   }
   if (csl_length_E == 0) {
      csl_length___elabs ();
   }
   csl_length_E = 1;
   csl_powers_E = 1;
   csl_statistical_E = 1;
   csl_system_utils_E = 1;
   csl_time_E = 1;
   if (csl_angle_rate_E == 0) {
      csl_angle_rate___elabs ();
   }
   csl_angle_rate_E = 1;
   csl_frequency_E = 1;
   csl_real_time_E = 1;
   csl_database_E = 1;
   csl_velocity_E = 1;
   csl_volts_E = 1;
   if (csl_levels_E == 0) {
      csl_levels___elabs ();
   }
   if (csl_levels_E == 0) {
      csl_levels___elabb ();
      csl_levels_E++;
   }
   csl_paths_E = 1;
   if (csl_tonals_E == 0) {
      csl_tonals___elabs ();
   }
   if (csl_tonals_E == 0) {
      csl_tonals___elabb ();
      csl_tonals_E++;
   }
   if (csl_image_utilities_E == 0) {
      csl_image_utilities___elabs ();
   }
   csl_image_utilities_E = 1;
   if (csl_config_E == 0) {
      csl_config___elabb ();
      csl_config_E++;
   }
   if (sm_model_radar_general_types_E == 0) {
      sm_model_radar_general_types___elabs ();
   }
   sm_model_radar_general_types_E = 1;
   if (sm_model_radar_kind_E == 0) {
      sm_model_radar_kind___elabs ();
   }
   sm_model_radar_kind_E = 1;
   if (sm_model_sonar_general_types_E == 0) {
      sm_model_sonar_general_types___elabs ();
   }
   sm_model_sonar_general_types_E = 1;
   if (sm_model_sonar_kind_E == 0) {
      sm_model_sonar_kind___elabs ();
   }
   sm_model_sonar_kind_E = 1;
   if (sm_model_vehicle_bb_flow_types_E == 0) {
      sm_model_vehicle_bb_flow_types___elabs ();
      sm_model_vehicle_bb_flow_types_E++;
   }
   if (sm_model_vehicle_bb_machinery_types_E == 0) {
      sm_model_vehicle_bb_machinery_types___elabs ();
      sm_model_vehicle_bb_machinery_types_E++;
   }
   if (sm_model_vehicle_bb_propeller_modulation_types_E == 0) {
      sm_model_vehicle_bb_propeller_modulation_types___elabs ();
      sm_model_vehicle_bb_propeller_modulation_types_E++;
   }
   if (sm_model_vehicle_bb_propeller_types_E == 0) {
      sm_model_vehicle_bb_propeller_types___elabs ();
      sm_model_vehicle_bb_propeller_types_E++;
   }
   if (sm_model_vehicle_enhanced_aural_types_E == 0) {
      sm_model_vehicle_enhanced_aural_types___elabs ();
   }
   sm_model_vehicle_enhanced_aural_types_E = 1;
   if (sm_model_vehicle_general_types_E == 0) {
      sm_model_vehicle_general_types___elabs ();
   }
   sm_model_vehicle_general_types_E = 1;
   if (sm_model_vehicle_general_E == 0) {
      sm_model_vehicle_general___elabs ();
      sm_model_vehicle_general_E++;
   }
   if (sm_model_vehicle_kind_E == 0) {
      sm_model_vehicle_kind___elabs ();
   }
   sm_model_vehicle_kind_E = 1;
   if (sm_model_vehicle_associated_fit_types_E == 0) {
      sm_model_vehicle_associated_fit_types___elabs ();
   }
   sm_model_vehicle_associated_fit_types_E = 1;
   if (sm_model_vehicle_nb_aux_int_types_E == 0) {
      sm_model_vehicle_nb_aux_int_types___elabs ();
   }
   sm_model_vehicle_nb_aux_int_types_E = 1;
   if (sm_model_vehicle_nb_bld_types_E == 0) {
      sm_model_vehicle_nb_bld_types___elabs ();
      sm_model_vehicle_nb_bld_types_E++;
   }
   if (sm_model_vehicle_nb_common_types_E == 0) {
      sm_model_vehicle_nb_common_types___elabs ();
   }
   sm_model_vehicle_nb_common_types_E = 1;
   if (sm_model_vehicle_bb_aural_types_E == 0) {
      sm_model_vehicle_bb_aural_types___elabs ();
   }
   sm_model_vehicle_bb_aural_types_E = 1;
   if (sm_model_vehicle_nb_fir_types_E == 0) {
      sm_model_vehicle_nb_fir_types___elabs ();
      sm_model_vehicle_nb_fir_types_E++;
   }
   if (sm_model_vehicle_nb_mod_types_E == 0) {
      sm_model_vehicle_nb_mod_types___elabs ();
      sm_model_vehicle_nb_mod_types_E++;
   }
   if (sm_model_vehicle_nb_spd_bld_types_E == 0) {
      sm_model_vehicle_nb_spd_bld_types___elabs ();
      sm_model_vehicle_nb_spd_bld_types_E++;
   }
   if (sm_model_vehicle_nb_spd_types_E == 0) {
      sm_model_vehicle_nb_spd_types___elabs ();
      sm_model_vehicle_nb_spd_types_E++;
   }
   if (sm_model_vehicle_physical_types_E == 0) {
      sm_model_vehicle_physical_types___elabs ();
      sm_model_vehicle_physical_types_E++;
   }
   if (sm_model_vehicle_project_specific_types_E == 0) {
      sm_model_vehicle_project_specific_types___elabs ();
      sm_model_vehicle_project_specific_types_E++;
   }
   if (sm_model_vehicle_propulsion_mode_types_E == 0) {
      sm_model_vehicle_propulsion_mode_types___elabs ();
   }
   sm_model_vehicle_propulsion_mode_types_E = 1;
   if (sm_model_vehicle_associated_fit_E == 0) {
      sm_model_vehicle_associated_fit___elabs ();
      sm_model_vehicle_associated_fit_E++;
   }
   if (sm_model_vehicle_bb_aural_E == 0) {
      sm_model_vehicle_bb_aural___elabs ();
      sm_model_vehicle_bb_aural_E++;
   }
   if (sm_model_vehicle_bb_flow_E == 0) {
      sm_model_vehicle_bb_flow___elabs ();
      sm_model_vehicle_bb_flow_E++;
   }
   if (sm_model_vehicle_bb_machinery_E == 0) {
      sm_model_vehicle_bb_machinery___elabs ();
      sm_model_vehicle_bb_machinery_E++;
   }
   if (sm_model_vehicle_bb_propeller_E == 0) {
      sm_model_vehicle_bb_propeller___elabs ();
      sm_model_vehicle_bb_propeller_E++;
   }
   if (sm_model_vehicle_bb_propeller_modulation_E == 0) {
      sm_model_vehicle_bb_propeller_modulation___elabs ();
      sm_model_vehicle_bb_propeller_modulation_E++;
   }
   if (sm_model_vehicle_bb_E == 0) {
      sm_model_vehicle_bb___elabs ();
      sm_model_vehicle_bb_E++;
   }
   if (sm_model_vehicle_enhanced_aural_E == 0) {
      sm_model_vehicle_enhanced_aural___elabs ();
      sm_model_vehicle_enhanced_aural_E++;
   }
   if (sm_model_vehicle_nb_aux_int_E == 0) {
      sm_model_vehicle_nb_aux_int___elabs ();
      sm_model_vehicle_nb_aux_int_E++;
   }
   if (sm_model_vehicle_nb_common_E == 0) {
      sm_model_vehicle_nb_common___elabs ();
      sm_model_vehicle_nb_common_E++;
   }
   if (sm_model_vehicle_nb_fir_E == 0) {
      sm_model_vehicle_nb_fir___elabs ();
      sm_model_vehicle_nb_fir_E++;
   }
   if (sm_model_vehicle_nb_bld_E == 0) {
      sm_model_vehicle_nb_bld___elabs ();
      sm_model_vehicle_nb_bld_E++;
   }
   if (sm_model_vehicle_nb_spd_E == 0) {
      sm_model_vehicle_nb_spd___elabs ();
      sm_model_vehicle_nb_spd_E++;
   }
   if (sm_model_vehicle_nb_E == 0) {
      sm_model_vehicle_nb___elabs ();
      sm_model_vehicle_nb_E++;
   }
   if (sm_model_vehicle_physical_E == 0) {
      sm_model_vehicle_physical___elabs ();
      sm_model_vehicle_physical_E++;
   }
   if (sm_model_vehicle_propulsion_mode_E == 0) {
      sm_model_vehicle_propulsion_mode___elabs ();
      sm_model_vehicle_propulsion_mode_E++;
   }
   if (sm_model_vehicle_speed_types_E == 0) {
      sm_model_vehicle_speed_types___elabs ();
   }
   sm_model_vehicle_speed_types_E = 1;
   if (sm_model_vehicle_speed_E == 0) {
      sm_model_vehicle_speed___elabs ();
      sm_model_vehicle_speed_E++;
   }
   if (sm_model_vehicle_turning_diving_types_E == 0) {
      sm_model_vehicle_turning_diving_types___elabs ();
   }
   sm_model_vehicle_turning_diving_types_E = 1;
   if (sm_model_vehicle_turning_diving_E == 0) {
      sm_model_vehicle_turning_diving___elabs ();
      sm_model_vehicle_turning_diving_E++;
   }
   if (sm_model_vehicle_wb_types_E == 0) {
      sm_model_vehicle_wb_types___elabs ();
   }
   sm_model_vehicle_wb_types_E = 1;
   if (sm_model_vehicle_wb_E == 0) {
      sm_model_vehicle_wb___elabs ();
      sm_model_vehicle_wb_E++;
   }
   if (sm_model_vehicle_E == 0) {
      sm_model_vehicle___elabs ();
   }
   if (sm_model_vehicle_E == 0) {
      sm_model_vehicle___elabb ();
      sm_model_vehicle_E++;
   }
   if (sm_model_vehicle_database_E == 0) {
      sm_model_vehicle_database___elabs ();
   }
   if (sm_model_vehicle_database_E == 0) {
      sm_model_vehicle_database___elabb ();
      sm_model_vehicle_database_E++;
   }
   vco_vdb_access_E = 1;
}
unsigned vco_vdb_accessB = 0x955b69e7;
unsigned vco_vdb_accessS = 0xd3fdc5ea;
unsigned system__standard_libraryB = 0xf0f638a3;
unsigned system__standard_libraryS = 0xfcd73e35;
unsigned adaS = 0xa0108083;
unsigned ada__exceptionsB = 0x6c073a52;
unsigned ada__exceptionsS = 0xe45f2410;
unsigned systemS = 0xc9d22edf;
unsigned system__exception_tableB = 0xa02d11f2;
unsigned system__exception_tableS = 0x4848f450;
unsigned system__htableB = 0x486f31be;
unsigned system__htableS = 0x32d06788;
unsigned system__soft_linksB = 0xb2f62c12;
unsigned system__soft_linksS = 0xd6d2e3d3;
unsigned system__machine_state_operationsB = 0xa7e20c82;
unsigned system__machine_state_operationsS = 0x5c6474b9;
unsigned system__exceptionsS = 0xe9d93e0d;
unsigned system__storage_elementsB = 0x0b833d88;
unsigned system__storage_elementsS = 0xa00b7e6a;
unsigned system__parametersB = 0x1049bcb8;
unsigned system__parametersS = 0xc4134ff4;
unsigned system__secondary_stackB = 0xdbf16d8b;
unsigned system__secondary_stackS = 0x48356ba5;
unsigned system__stack_checkingB = 0xefcdd5d0;
unsigned system__stack_checkingS = 0xc13e8d5e;
unsigned system__tracebackB = 0x4d4e8ee2;
unsigned system__tracebackS = 0xff9f1b40;
unsigned ada__text_ioB = 0x8c278060;
unsigned ada__text_ioS = 0x4d34fc10;
unsigned ada__streamsS = 0x7bf62c37;
unsigned ada__tagsB = 0x2b0f8db3;
unsigned ada__tagsS = 0xf5266995;
unsigned interfacesS = 0xb44484df;
unsigned interfaces__c_streamsB = 0x83609014;
unsigned interfaces__c_streamsS = 0xf5cc25b4;
unsigned system__file_ioB = 0x1f955b97;
unsigned system__file_ioS = 0x6ab8a35f;
unsigned ada__finalizationB = 0xdec8b4cc;
unsigned ada__finalizationS = 0x0af0a97f;
unsigned system__finalization_rootB = 0x2707dc21;
unsigned system__finalization_rootS = 0x6c6a8510;
unsigned system__finalization_implementationB = 0x334bd049;
unsigned system__finalization_implementationS = 0x58e982ba;
unsigned system__string_ops_concat_3B = 0x9d5e2b8a;
unsigned system__string_ops_concat_3S = 0x328e17bb;
unsigned system__string_opsB = 0x474b0583;
unsigned system__string_opsS = 0x26e70524;
unsigned system__stream_attributesB = 0x71d6691b;
unsigned system__stream_attributesS = 0x71f0b14c;
unsigned ada__io_exceptionsS = 0x753e9209;
unsigned system__unsigned_typesS = 0xfc1bbca6;
unsigned system__file_control_blockS = 0x4a3c232f;
unsigned ada__finalization__list_controllerB = 0xffad3e68;
unsigned ada__finalization__list_controllerS = 0x29e5afbc;
unsigned csl_lengthB = 0x3616b5ec;
unsigned csl_lengthS = 0x69b8d682;
unsigned ada__text_io__float_auxB = 0x502c314b;
unsigned ada__text_io__float_auxS = 0x84f33c46;
unsigned ada__text_io__generic_auxB = 0x829761c5;
unsigned ada__text_io__generic_auxS = 0x3c483919;
unsigned system__img_realB = 0xedab3d38;
unsigned system__img_realS = 0x0e46bdc4;
unsigned system__fat_llfS = 0x740dac62;
unsigned system__img_lluB = 0xc2b18a40;
unsigned system__img_lluS = 0x345173b0;
unsigned system__img_unsB = 0x573f6ca0;
unsigned system__img_unsS = 0x1928df3c;
unsigned system__powten_tableS = 0x4d6c1686;
unsigned system__val_realB = 0xe5d7f7d8;
unsigned system__val_realS = 0x49ef789d;
unsigned system__exn_llfS = 0xd9cdfb35;
unsigned system__exn_genB = 0x15aa9939;
unsigned system__exn_genS = 0x4af48a6a;
unsigned system__val_utilB = 0x682fa91a;
unsigned system__val_utilS = 0x391e647f;
unsigned system__case_utilB = 0x87d63e0c;
unsigned system__case_utilS = 0xc77407e3;
unsigned csl_angleB = 0xcf075b4d;
unsigned csl_angleS = 0x156d00ae;
unsigned csl_fast_mathsB = 0x32a8c1dc;
unsigned csl_fast_mathsS = 0xd8369f1c;
unsigned ada__numericsS = 0x846587b0;
unsigned ada__numerics__auxS = 0x200205e5;
unsigned csl_system_numbersB = 0x4c1d1732;
unsigned csl_system_numbersS = 0x60948f4d;
unsigned system__exp_intS = 0x4bb7ff3f;
unsigned system__exp_genB = 0xd0b395de;
unsigned system__exp_genS = 0xec170494;
unsigned system__exp_sfltS = 0x7d673064;
unsigned system__exn_sfltS = 0x12fbe80c;
unsigned system__exp_llfS = 0x3bf9958e;
unsigned system__fat_sfltS = 0x2a021bcc;
unsigned text_ioS = 0x1528e471;
unsigned sm_model_vehicleB = 0x4b0b358d;
unsigned sm_model_vehicleS = 0x12de18ba;
unsigned csl_configB = 0xe1f9f02f;
unsigned csl_configS = 0x366b309f;
unsigned ada__charactersS = 0x060f352a;
unsigned ada__characters__handlingB = 0xf6447ab9;
unsigned ada__characters__handlingS = 0x46d230ec;
unsigned ada__characters__latin_1S = 0xa0be30a8;
unsigned ada__stringsS = 0xc4504387;
unsigned ada__strings__mapsB = 0x7f70d6fb;
unsigned ada__strings__mapsS = 0x841ddc3f;
unsigned system__bit_opsB = 0x676142d1;
unsigned system__bit_opsS = 0x0c033dfd;
unsigned system__pure_exceptionsS = 0x6bea159d;
unsigned ada__strings__maps__constantsS = 0x6b21310c;
unsigned ada__command_lineB = 0xbf55ad5e;
unsigned ada__command_lineS = 0xd8088025;
unsigned ada__strings__unboundedB = 0xcc5a967d;
unsigned ada__strings__unboundedS = 0x39162d55;
unsigned ada__strings__fixedB = 0x95f1ae19;
unsigned ada__strings__fixedS = 0xa09484f4;
unsigned ada__strings__searchB = 0x6b03b68b;
unsigned ada__strings__searchS = 0xebae4dd3;
unsigned system__compare_array_unsigned_8B = 0xb3a2acc9;
unsigned system__compare_array_unsigned_8S = 0x67590716;
unsigned ada__text_io__enumeration_auxB = 0x2b030732;
unsigned ada__text_io__enumeration_auxS = 0x9e0d0a87;
unsigned calendarS = 0x6050a177;
unsigned ada__calendarB = 0xb5ef5a33;
unsigned ada__calendarS = 0x2311df51;
unsigned system__arith_64B = 0x83330338;
unsigned system__arith_64S = 0xc3f2c13c;
unsigned system__os_primitivesB = 0x13b53d43;
unsigned system__os_primitivesS = 0xdec91647;
unsigned csl_system_utilsB = 0x5af025e1;
unsigned csl_system_utilsS = 0x613fa9ad;
unsigned system__string_ops_concat_5B = 0xec185bba;
unsigned system__string_ops_concat_5S = 0x9ee2b23c;
unsigned system__string_ops_concat_4B = 0xcfb745b6;
unsigned system__string_ops_concat_4S = 0xf5160279;
unsigned interfaces__cB = 0x21635c57;
unsigned interfaces__cS = 0x308c7ef4;
unsigned interfaces__c__stringsB = 0x6cecd508;
unsigned interfaces__c__stringsS = 0x1b490ea4;
unsigned integer_ioB = 0x3d2075ba;
unsigned integer_ioS = 0x16771cbd;
unsigned ada__text_io__integer_auxB = 0xf4128bc8;
unsigned ada__text_io__integer_auxS = 0x881024e6;
unsigned system__img_biuB = 0x0aa887df;
unsigned system__img_biuS = 0xa30b4c74;
unsigned system__img_intB = 0x70f6a786;
unsigned system__img_intS = 0x3868aabc;
unsigned system__img_llbB = 0x957391f7;
unsigned system__img_llbS = 0x389e7e31;
unsigned system__img_lliB = 0xf02ff885;
unsigned system__img_lliS = 0x9074f7ce;
unsigned system__img_llwB = 0x196d4619;
unsigned system__img_llwS = 0x5a747733;
unsigned system__img_wiuB = 0x1bf5bdbe;
unsigned system__img_wiuS = 0x2686aace;
unsigned system__val_intB = 0x6fbab107;
unsigned system__val_intS = 0x1eb77268;
unsigned system__val_unsB = 0xae8bdc17;
unsigned system__val_unsS = 0xe197e31d;
unsigned system__val_lliB = 0x78405b67;
unsigned system__val_lliS = 0xd808ed08;
unsigned system__val_lluB = 0x138d427c;
unsigned system__val_lluS = 0xf52d5249;
unsigned system__img_boolB = 0x31cde6a7;
unsigned system__img_boolS = 0xd54d5fcd;
unsigned system__img_enumB = 0x726bb6bb;
unsigned system__img_enumS = 0xe9b13311;
unsigned system__val_enumB = 0xe9918401;
unsigned system__val_enumS = 0x4eb66a4b;
unsigned csl_hostB = 0x4bc86320;
unsigned csl_hostS = 0xd5a3d141;
unsigned sm_model_vehicle_associated_fitS = 0x93b8a965;
unsigned sm_model_vehicle_associated_fit_typesB = 0xea9057e1;
unsigned sm_model_vehicle_associated_fit_typesS = 0x6a94914c;
unsigned csl_image_utilitiesB = 0x213b847a;
unsigned csl_image_utilitiesS = 0x39d36611;
unsigned current_exceptionS = 0x61b8ef33;
unsigned csl_angle_rateB = 0x54e195c1;
unsigned csl_angle_rateS = 0xfdab6d52;
unsigned csl_timeB = 0x68808e64;
unsigned csl_timeS = 0x1d23954e;
unsigned csl_frequencyB = 0x9bcadf13;
unsigned csl_frequencyS = 0xa1c9a278;
unsigned csl_levelsB = 0x871dd33f;
unsigned csl_levelsS = 0xea4ffb79;
unsigned csl_decibelB = 0x599896aa;
unsigned csl_decibelS = 0x18c7a382;
unsigned csl_level_exceptionsS = 0xed1cbc37;
unsigned csl_powersB = 0xd90e8414;
unsigned csl_powersS = 0x620d7e3c;
unsigned csl_voltsB = 0x4136d359;
unsigned csl_voltsS = 0xc54facfd;
unsigned csl_tonalsB = 0xce5c7064;
unsigned csl_tonalsS = 0xf0dc9e10;
unsigned csl_pathsB = 0x47773ca5;
unsigned csl_pathsS = 0xac1b7c10;
unsigned csl_velocityB = 0x3989a2b2;
unsigned csl_velocityS = 0xe41306e4;
unsigned sm_model_radar_kindB = 0xcb9a82e5;
unsigned sm_model_radar_kindS = 0x781b42a9;
unsigned sm_model_radar_general_typesB = 0xe68ab037;
unsigned sm_model_radar_general_typesS = 0xdcb4c092;
unsigned sm_model_sonar_kindB = 0x1ee01266;
unsigned sm_model_sonar_kindS = 0x4b7749d0;
unsigned sm_model_sonar_general_typesB = 0x0cc5ab44;
unsigned sm_model_sonar_general_typesS = 0xd661c701;
unsigned sm_model_vehicle_kindB = 0xbb062277;
unsigned sm_model_vehicle_kindS = 0xc832324c;
unsigned sm_model_vehicle_general_typesB = 0x22af5a6e;
unsigned sm_model_vehicle_general_typesS = 0x8144fe88;
unsigned sm_model_vehicle_propulsion_mode_typesB = 0xd1dda385;
unsigned sm_model_vehicle_propulsion_mode_typesS = 0x3348061e;
unsigned sm_model_vehicle_bbS = 0x381c2528;
unsigned sm_model_vehicle_bb_auralS = 0xd33110dc;
unsigned sm_model_vehicle_bb_aural_typesB = 0x08064f5e;
unsigned sm_model_vehicle_bb_aural_typesS = 0xc2846832;
unsigned sm_model_vehicle_nb_common_typesB = 0x95d4dca1;
unsigned sm_model_vehicle_nb_common_typesS = 0xc87e1900;
unsigned csl_statisticalB = 0x9b4e83a8;
unsigned csl_statisticalS = 0x0d60a20e;
unsigned sm_model_vehicle_bb_flowS = 0x4b732a85;
unsigned sm_model_vehicle_bb_flow_typesS = 0xa2364d94;
unsigned sm_model_vehicle_bb_machineryS = 0x4829579f;
unsigned sm_model_vehicle_bb_machinery_typesS = 0x6553588a;
unsigned sm_model_vehicle_bb_propellerS = 0x5664b3d9;
unsigned sm_model_vehicle_bb_propeller_typesS = 0x75d18847;
unsigned sm_model_vehicle_bb_propeller_modulationS = 0xdc7fc1ae;
unsigned sm_model_vehicle_bb_propeller_modulation_typesS = 0x5f26d70b;
unsigned sm_model_vehicle_enhanced_auralS = 0xeacd08e9;
unsigned sm_model_vehicle_enhanced_aural_typesB = 0xdd8fcc69;
unsigned sm_model_vehicle_enhanced_aural_typesS = 0x05aeb8f4;
unsigned sm_model_vehicle_generalS = 0x5ff54ac3;
unsigned sm_model_vehicle_nbS = 0xf9c6e625;
unsigned sm_model_vehicle_nb_aux_intS = 0x95bf138f;
unsigned sm_model_vehicle_nb_aux_int_typesB = 0x59dd5966;
unsigned sm_model_vehicle_nb_aux_int_typesS = 0xf3a1bdeb;
unsigned sm_model_vehicle_nb_bldS = 0x4821214f;
unsigned sm_model_vehicle_nb_bld_typesS = 0x9e4fd250;
unsigned sm_model_vehicle_nb_spd_bldS = 0x070c9175;
unsigned sm_model_vehicle_nb_spd_bld_typesS = 0x84f7ff8f;
unsigned sm_model_vehicle_nb_commonS = 0xb45039e1;
unsigned sm_model_vehicle_nb_firS = 0x07bb1df5;
unsigned sm_model_vehicle_nb_fir_typesS = 0xc7f0cb52;
unsigned sm_model_vehicle_nb_modS = 0x8bdbcaae;
unsigned sm_model_vehicle_nb_mod_typesS = 0xca7fa039;
unsigned sm_model_vehicle_nb_spdS = 0xfb921665;
unsigned sm_model_vehicle_nb_spd_typesS = 0x124d1514;
unsigned sm_model_vehicle_physicalS = 0x195c58d7;
unsigned sm_model_vehicle_physical_typesS = 0x63ff97d9;
unsigned sm_model_vehicle_project_specificS = 0x11060033;
unsigned sm_model_vehicle_project_specific_typesS = 0xcf1d69f2;
unsigned sm_model_vehicle_propulsion_modeS = 0x2a22460a;
unsigned sm_model_vehicle_speedS = 0x1c0292c1;
unsigned sm_model_vehicle_speed_typesB = 0xe07c724f;
unsigned sm_model_vehicle_speed_typesS = 0xb332175c;
unsigned sm_model_vehicle_turning_divingS = 0xe85cea52;
unsigned sm_model_vehicle_turning_diving_typesB = 0xbb096d36;
unsigned sm_model_vehicle_turning_diving_typesS = 0xae796dda;
unsigned sm_model_vehicle_wbS = 0x3f21691d;
unsigned sm_model_vehicle_wb_typesB = 0x522a8d15;
unsigned sm_model_vehicle_wb_typesS = 0x0e56a360;
unsigned sm_model_vehicle_databaseB = 0x2014b2db;
unsigned sm_model_vehicle_databaseS = 0x1e176630;
unsigned ada__calendar__delaysB = 0x48c42869;
unsigned ada__calendar__delaysS = 0x56f69050;
unsigned system__tracesB = 0xd5c08480;
unsigned system__tracesS = 0x0d80c564;
unsigned csl_databaseB = 0xd80766d6;
unsigned csl_databaseS = 0xafba2cfa;
unsigned csl_real_timeB = 0x6c72719d;
unsigned csl_real_timeS = 0xba0d541e;
unsigned gnatS = 0x6380ea48;
unsigned gnat__os_libB = 0xe8b2cb33;
unsigned gnat__os_libS = 0x6515dd1c;
unsigned gnat__stringsB = 0x1d1cd3a0;
unsigned gnat__stringsS = 0x635d1177;
unsigned system__direct_ioB = 0x8eb79fd0;
unsigned system__direct_ioS = 0xc0ef7754;
unsigned sm_model_vehicle_general_c100_valuesS = 0x7cc01434;
unsigned system__memoryB = 0x61bdd763;
unsigned system__memoryS = 0xc420f86f;

/* BEGIN ELABORATION ORDER
ada (spec)
ada.characters (spec)
ada.characters.handling (spec)
ada.characters.latin_1 (spec)
ada.command_line (spec)
gnat (spec)
gnat.strings (spec)
gnat.strings (body)
interfaces (spec)
system (spec)
system.arith_64 (spec)
system.bit_ops (spec)
system.case_util (spec)
system.case_util (body)
system.compare_array_unsigned_8 (spec)
system.compare_array_unsigned_8 (body)
system.exn_gen (spec)
system.exn_gen (body)
system.exp_gen (spec)
system.exp_gen (body)
system.exp_int (spec)
system.htable (spec)
system.htable (body)
system.img_bool (spec)
system.img_enum (spec)
system.img_int (spec)
system.img_lli (spec)
system.img_real (spec)
system.os_primitives (spec)
system.os_primitives (body)
system.parameters (spec)
system.parameters (body)
interfaces.c_streams (spec)
interfaces.c_streams (body)
system.powten_table (spec)
system.pure_exceptions (spec)
system.arith_64 (body)
system.standard_library (spec)
ada.exceptions (spec)
system.exceptions (spec)
system.storage_elements (spec)
system.storage_elements (body)
system.machine_state_operations (spec)
system.machine_state_operations (body)
system.secondary_stack (spec)
system.img_lli (body)
system.img_int (body)
system.img_enum (body)
system.img_bool (body)
ada.command_line (body)
system.stack_checking (spec)
system.soft_links (spec)
system.soft_links (body)
system.stack_checking (body)
system.secondary_stack (body)
system.exception_table (spec)
system.exception_table (body)
ada.calendar (spec)
ada.calendar (body)
ada.calendar.delays (spec)
ada.io_exceptions (spec)
ada.numerics (spec)
ada.numerics.aux (spec)
ada.strings (spec)
ada.tags (spec)
ada.tags (body)
ada.streams (spec)
calendar (spec)
gnat.os_lib (spec)
gnat.os_lib (body)
interfaces.c (spec)
interfaces.c (body)
interfaces.c.strings (spec)
interfaces.c.strings (body)
system.exn_llf (spec)
system.exn_sflt (spec)
system.exp_llf (spec)
system.exp_sflt (spec)
system.finalization_root (spec)
system.finalization_root (body)
system.memory (spec)
system.memory (body)
system.standard_library (body)
system.string_ops (spec)
system.string_ops (body)
system.string_ops_concat_3 (spec)
system.string_ops_concat_3 (body)
system.string_ops_concat_4 (spec)
system.string_ops_concat_4 (body)
system.string_ops_concat_5 (spec)
system.string_ops_concat_5 (body)
system.traceback (spec)
system.traceback (body)
ada.exceptions (body)
system.traces (spec)
system.traces (body)
ada.calendar.delays (body)
system.unsigned_types (spec)
system.bit_ops (body)
ada.strings.maps (spec)
ada.strings.maps (body)
ada.strings.fixed (spec)
ada.strings.maps.constants (spec)
ada.characters.handling (body)
ada.strings.search (spec)
ada.strings.search (body)
ada.strings.fixed (body)
system.fat_llf (spec)
system.fat_sflt (spec)
system.img_biu (spec)
system.img_biu (body)
system.img_llb (spec)
system.img_llb (body)
system.img_llu (spec)
system.img_llu (body)
system.img_llw (spec)
system.img_llw (body)
system.img_uns (spec)
system.img_uns (body)
system.img_real (body)
system.img_wiu (spec)
system.img_wiu (body)
system.stream_attributes (spec)
system.stream_attributes (body)
system.finalization_implementation (spec)
system.finalization_implementation (body)
ada.finalization (spec)
ada.finalization (body)
ada.finalization.list_controller (spec)
ada.finalization.list_controller (body)
ada.strings.unbounded (spec)
ada.strings.unbounded (body)
system.file_control_block (spec)
system.direct_io (spec)
system.file_io (spec)
system.file_io (body)
system.direct_io (body)
ada.text_io (spec)
ada.text_io (body)
ada.text_io.enumeration_aux (spec)
ada.text_io.float_aux (spec)
ada.text_io.generic_aux (spec)
ada.text_io.generic_aux (body)
ada.text_io.enumeration_aux (body)
ada.text_io.integer_aux (spec)
system.val_enum (spec)
system.val_int (spec)
system.val_lli (spec)
ada.text_io.integer_aux (body)
system.val_llu (spec)
system.val_real (spec)
ada.text_io.float_aux (body)
system.val_uns (spec)
system.val_util (spec)
system.val_util (body)
system.val_uns (body)
system.val_real (body)
system.val_llu (body)
system.val_lli (body)
system.val_int (body)
system.val_enum (body)
text_io (spec)
csl_host (spec)
csl_host (body)
csl_level_exceptions (spec)
csl_system_numbers (spec)
csl_system_numbers (body)
csl_angle (spec)
csl_decibel (spec)
csl_fast_maths (spec)
csl_fast_maths (body)
csl_decibel (body)
csl_angle (body)
csl_length (spec)
csl_length (body)
csl_powers (spec)
csl_powers (body)
csl_statistical (spec)
csl_statistical (body)
csl_system_utils (spec)
csl_system_utils (body)
csl_time (spec)
csl_time (body)
csl_angle_rate (spec)
csl_angle_rate (body)
csl_database (spec)
csl_frequency (spec)
csl_frequency (body)
csl_real_time (spec)
csl_real_time (body)
csl_database (body)
csl_velocity (spec)
csl_velocity (body)
csl_volts (spec)
csl_volts (body)
csl_levels (spec)
csl_levels (body)
csl_paths (spec)
csl_paths (body)
csl_tonals (spec)
csl_tonals (body)
csl_image_utilities (spec)
current_exception (spec)
csl_image_utilities (body)
integer_io (spec)
integer_io (body)
csl_config (spec)
csl_config (body)
sm_model_radar_general_types (spec)
sm_model_radar_general_types (body)
sm_model_radar_kind (spec)
sm_model_radar_kind (body)
sm_model_sonar_general_types (spec)
sm_model_sonar_general_types (body)
sm_model_sonar_kind (spec)
sm_model_sonar_kind (body)
sm_model_vehicle_bb_flow_types (spec)
sm_model_vehicle_bb_machinery_types (spec)
sm_model_vehicle_bb_propeller_modulation_types (spec)
sm_model_vehicle_bb_propeller_types (spec)
sm_model_vehicle_enhanced_aural_types (spec)
sm_model_vehicle_enhanced_aural_types (body)
sm_model_vehicle_general_types (spec)
sm_model_vehicle_general_types (body)
sm_model_vehicle_general (spec)
sm_model_vehicle_general_c100_values (spec)
sm_model_vehicle_kind (spec)
sm_model_vehicle_kind (body)
sm_model_vehicle_associated_fit_types (spec)
sm_model_vehicle_associated_fit_types (body)
sm_model_vehicle_nb_aux_int_types (spec)
sm_model_vehicle_nb_aux_int_types (body)
sm_model_vehicle_nb_bld_types (spec)
sm_model_vehicle_nb_common_types (spec)
sm_model_vehicle_nb_common_types (body)
sm_model_vehicle_bb_aural_types (spec)
sm_model_vehicle_bb_aural_types (body)
sm_model_vehicle_nb_fir_types (spec)
sm_model_vehicle_nb_mod_types (spec)
sm_model_vehicle_nb_spd_bld_types (spec)
sm_model_vehicle_nb_spd_types (spec)
sm_model_vehicle_physical_types (spec)
sm_model_vehicle_project_specific_types (spec)
sm_model_vehicle_project_specific (spec)
sm_model_vehicle_propulsion_mode_types (spec)
sm_model_vehicle_propulsion_mode_types (body)
sm_model_vehicle_associated_fit (spec)
sm_model_vehicle_bb_aural (spec)
sm_model_vehicle_bb_flow (spec)
sm_model_vehicle_bb_machinery (spec)
sm_model_vehicle_bb_propeller (spec)
sm_model_vehicle_bb_propeller_modulation (spec)
sm_model_vehicle_bb (spec)
sm_model_vehicle_enhanced_aural (spec)
sm_model_vehicle_nb_aux_int (spec)
sm_model_vehicle_nb_common (spec)
sm_model_vehicle_nb_fir (spec)
sm_model_vehicle_nb_mod (spec)
sm_model_vehicle_nb_spd_bld (spec)
sm_model_vehicle_nb_bld (spec)
sm_model_vehicle_nb_spd (spec)
sm_model_vehicle_nb (spec)
sm_model_vehicle_physical (spec)
sm_model_vehicle_propulsion_mode (spec)
sm_model_vehicle_speed_types (spec)
sm_model_vehicle_speed_types (body)
sm_model_vehicle_speed (spec)
sm_model_vehicle_turning_diving_types (spec)
sm_model_vehicle_turning_diving_types (body)
sm_model_vehicle_turning_diving (spec)
sm_model_vehicle_wb_types (spec)
sm_model_vehicle_wb_types (body)
sm_model_vehicle_wb (spec)
sm_model_vehicle (spec)
sm_model_vehicle (body)
sm_model_vehicle_database (spec)
sm_model_vehicle_database (body)
vco_vdb_access (spec)
vco_vdb_access (body)
   END ELABORATION ORDER */

/*  BEGIN Object file/option list
/talisman/factory/dev/generic/csl/csl_host.o
/talisman/factory/dev/generic/csl/csl_level_exceptions.o
/talisman/factory/dev/generic/csl/csl_system_numbers.o
/talisman/factory/dev/generic/csl/csl_fast_maths.o
/talisman/factory/dev/generic/csl/csl_decibel.o
/talisman/factory/dev/generic/csl/csl_angle.o
/talisman/factory/dev/generic/csl/csl_length.o
/talisman/factory/dev/generic/csl/csl_powers.o
/talisman/factory/dev/generic/csl/csl_statistical.o
/talisman/factory/dev/generic/csl/csl_system_utils.o
/talisman/factory/dev/generic/csl/csl_time.o
/talisman/factory/dev/generic/csl/csl_angle_rate.o
/talisman/factory/dev/generic/csl/csl_frequency.o
/talisman/factory/dev/generic/csl/csl_real_time.o
/talisman/factory/dev/generic/csl/csl_database.o
/talisman/factory/dev/generic/csl/csl_velocity.o
/talisman/factory/dev/generic/csl/csl_volts.o
/talisman/factory/dev/generic/csl/csl_levels.o
/talisman/factory/dev/generic/csl/csl_paths.o
/talisman/factory/dev/generic/csl/csl_tonals.o
/talisman/factory/dev/generic/missing/current_exception.o
/talisman/factory/dev/generic/csl/csl_image_utilities.o
/talisman/factory/dev/generic/missing/integer_io.o
/talisman/factory/dev/generic/csl/csl_config.o
/talisman/factory/dev/generic/sm/models/radar/sm_model_radar_general_types.o
/talisman/factory/dev/generic/sm/models/radar/sm_model_radar_kind.o
/talisman/factory/dev/generic/sm/models/sonar/sm_model_sonar_general_types.o
/talisman/factory/dev/generic/sm/models/sonar/sm_model_sonar_kind.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_bb_flow_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_bb_machinery_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_bb_propeller_modulation_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_bb_propeller_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_enhanced_aural_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_general_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_general.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_general_c100_values.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_kind.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_associated_fit_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_nb_aux_int_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_nb_bld_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_nb_common_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_bb_aural_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_nb_fir_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_nb_mod_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_nb_spd_bld_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_nb_spd_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_physical_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_project_specific_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_project_specific.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_propulsion_mode_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_associated_fit.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_bb_aural.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_bb_flow.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_bb_machinery.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_bb_propeller.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_bb_propeller_modulation.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_bb.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_enhanced_aural.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_nb_aux_int.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_nb_common.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_nb_fir.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_nb_mod.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_nb_spd_bld.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_nb_bld.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_nb_spd.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_nb.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_physical.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_propulsion_mode.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_speed_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_speed.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_turning_diving_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_turning_diving.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_wb_types.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_wb.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle.o
/talisman/factory/dev/generic/sm/models/vehicle/sm_model_vehicle_database.o
./vco_vdb_access.o
-L./
-L/talisman/factory/dev/generic/csl/
-L/talisman/factory/dev/generic/missing/
-L/talisman/factory/dev/generic/sm/models/radar/
-L/talisman/factory/dev/generic/sm/models/sonar/
-L/talisman/factory/dev/generic/sm/models/vehicle/
-L/opt/ngnu/lib/gcc-lib/sparc-sun-solaris2.8/2.8.1/adalib/
-static
-lgnat
-lm
    END Object file/option list */
