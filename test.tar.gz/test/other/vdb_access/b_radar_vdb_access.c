extern void __gnat_set_globals
  (int, int, char, char, char, char,
   const char *, const char *,
   int, int, int, int);
extern void adafinal (void);
extern void adainit (void);
extern void system__standard_library__adafinal (void);
extern int main (int, char **, char **);
extern void exit (int);
extern void __gnat_break_start (void);
extern int _ada_radar_vdb_access (void);
extern void __gnat_initialize (void);
extern void __gnat_finalize (void);
extern void __gnat_install_handler (void);

extern void ada__exceptions___elabs (void);
extern void system__exceptions___elabs (void);
extern void system__soft_links___elabb (void);
extern void system__secondary_stack___elabb (void);
extern void system__exception_table___elabb (void);
extern void ada__calendar___elabs (void);
extern void ada__io_exceptions___elabs (void);
extern void ada__numerics___elabs (void);
extern void ada__strings___elabs (void);
extern void ada__tags___elabs (void);
extern void ada__tags___elabb (void);
extern void ada__streams___elabs (void);
extern void gnat__lock_files___elabs (void);
extern void interfaces__c___elabs (void);
extern void interfaces__c__strings___elabs (void);
extern void system__finalization_root___elabs (void);
extern void ada__calendar__delays___elabb (void);
extern void ada__exceptions___elabb (void);
extern void ada__strings__maps___elabs (void);
extern void ada__strings__maps__constants___elabs (void);
extern void system__finalization_implementation___elabs (void);
extern void system__finalization_implementation___elabb (void);
extern void ada__finalization___elabs (void);
extern void ada__finalization__list_controller___elabs (void);
extern void ada__strings__unbounded___elabs (void);
extern void gnat__sockets___elabs (void);
extern void gnat__sockets__thin___elabs (void);
extern void gnat__sockets__thin___elabb (void);
extern void system__file_control_block___elabs (void);
extern void system__direct_io___elabs (void);
extern void system__file_io___elabb (void);
extern void ada__text_io___elabs (void);
extern void ada__text_io___elabb (void);
extern void gnat__sockets___elabb (void);
extern void csl_host___elabb (void);
extern void csl_level_exceptions___elabs (void);
extern void csl_angle___elabs (void);
extern void csl_decibel___elabb (void);
extern void csl_angle___elabb (void);
extern void csl_length___elabs (void);
extern void csl_angle_rate___elabs (void);
extern void csl_levels___elabs (void);
extern void csl_levels___elabb (void);
extern void csl_tonals___elabs (void);
extern void csl_tonals___elabb (void);
extern void csl_image_utilities___elabs (void);
extern void sm_model_radar_general_types___elabs (void);
extern void sm_model_radar_kind___elabs (void);
extern void sm_model_sonar_general_types___elabs (void);
extern void sm_model_sonar_kind___elabs (void);
extern void sm_model_vehicle_bb_flow_types___elabs (void);
extern void sm_model_vehicle_bb_machinery_types___elabs (void);
extern void sm_model_vehicle_bb_propeller_modulation_types___elabs (void);
extern void sm_model_vehicle_bb_propeller_types___elabs (void);
extern void sm_model_vehicle_enhanced_aural_types___elabs (void);
extern void sm_model_vehicle_general_types___elabs (void);
extern void sm_model_vehicle_general___elabs (void);
extern void sm_model_vehicle_kind___elabs (void);
extern void sm_model_vehicle_associated_fit_types___elabs (void);
extern void sm_model_vehicle_nb_aux_int_types___elabs (void);
extern void sm_model_vehicle_nb_bld_types___elabs (void);
extern void sm_model_vehicle_nb_common_types___elabs (void);
extern void sm_model_vehicle_bb_aural_types___elabs (void);
extern void sm_model_vehicle_nb_fir_types___elabs (void);
extern void sm_model_vehicle_nb_mod_types___elabs (void);
extern void sm_model_vehicle_nb_spd_bld_types___elabs (void);
extern void sm_model_vehicle_nb_spd_types___elabs (void);
extern void sm_model_vehicle_physical_types___elabs (void);
extern void sm_model_vehicle_project_specific_types___elabs (void);
extern void sm_model_vehicle_propulsion_mode_types___elabs (void);
extern void sm_model_vehicle_associated_fit___elabs (void);
extern void sm_model_vehicle_bb_aural___elabs (void);
extern void sm_model_vehicle_bb_flow___elabs (void);
extern void sm_model_vehicle_bb_machinery___elabs (void);
extern void sm_model_vehicle_bb_propeller___elabs (void);
extern void sm_model_vehicle_bb_propeller_modulation___elabs (void);
extern void sm_model_vehicle_bb___elabs (void);
extern void sm_model_vehicle_enhanced_aural___elabs (void);
extern void sm_model_vehicle_nb_aux_int___elabs (void);
extern void sm_model_vehicle_nb_common___elabs (void);
extern void sm_model_vehicle_nb_fir___elabs (void);
extern void sm_model_vehicle_nb_bld___elabs (void);
extern void sm_model_vehicle_nb_spd___elabs (void);
extern void sm_model_vehicle_nb___elabs (void);
extern void sm_model_vehicle_physical___elabs (void);
extern void sm_model_vehicle_propulsion_mode___elabs (void);
extern void sm_model_vehicle_speed_types___elabs (void);
extern void sm_model_vehicle_speed___elabs (void);
extern void sm_model_vehicle_turning_diving_types___elabs (void);
extern void sm_model_vehicle_turning_diving___elabs (void);
extern void sm_model_vehicle_wb_types___elabs (void);
extern void sm_model_vehicle_wb___elabs (void);
extern void sm_model_vehicle___elabs (void);
extern void csl_config___elabb (void);
extern void sm_model_vehicle___elabb (void);
extern void sm_model_vehicle_database___elabs (void);
extern void sm_model_vehicle_database___elabb (void);

extern int  __gnat_handler_installed;

void adafinal () {
   system__standard_library__adafinal ();
}

void adainit (void)
{
   extern char gnat__strings_E;
   extern char system__secondary_stack_E;
   extern char ada__exceptions_E;
   extern char system__exceptions_E;
   extern char system__soft_links_E;
   extern char system__exception_table_E;
   extern char ada__calendar_E;
   extern char ada__calendar__delays_E;
   extern char ada__io_exceptions_E;
   extern char ada__numerics_E;
   extern char ada__strings_E;
   extern char ada__tags_E;
   extern char ada__streams_E;
   extern char gnat__lock_files_E;
   extern char interfaces__c_E;
   extern char interfaces__c__strings_E;
   extern char system__finalization_root_E;
   extern char ada__strings__maps_E;
   extern char ada__strings__maps__constants_E;
   extern char system__finalization_implementation_E;
   extern char ada__finalization_E;
   extern char ada__finalization__list_controller_E;
   extern char ada__strings__unbounded_E;
   extern char gnat__sockets_E;
   extern char gnat__sockets__thin_E;
   extern char system__file_control_block_E;
   extern char system__direct_io_E;
   extern char system__file_io_E;
   extern char ada__text_io_E;
   extern char csl_host_E;
   extern char csl_level_exceptions_E;
   extern char csl_system_numbers_E;
   extern char csl_angle_E;
   extern char csl_decibel_E;
   extern char csl_fast_maths_E;
   extern char csl_length_E;
   extern char csl_powers_E;
   extern char csl_statistical_E;
   extern char csl_system_utils_E;
   extern char csl_time_E;
   extern char csl_angle_rate_E;
   extern char csl_database_E;
   extern char csl_frequency_E;
   extern char csl_real_time_E;
   extern char csl_velocity_E;
   extern char csl_volts_E;
   extern char csl_levels_E;
   extern char csl_paths_E;
   extern char csl_tonals_E;
   extern char csl_image_utilities_E;
   extern char radar_vdb_access_E;
   extern char sm_model_radar_general_types_E;
   extern char sm_model_radar_kind_E;
   extern char sm_model_sonar_general_types_E;
   extern char sm_model_sonar_kind_E;
   extern char sm_model_vehicle_bb_flow_types_E;
   extern char sm_model_vehicle_bb_machinery_types_E;
   extern char sm_model_vehicle_bb_propeller_modulation_types_E;
   extern char sm_model_vehicle_bb_propeller_types_E;
   extern char sm_model_vehicle_enhanced_aural_types_E;
   extern char sm_model_vehicle_general_types_E;
   extern char sm_model_vehicle_general_E;
   extern char sm_model_vehicle_kind_E;
   extern char sm_model_vehicle_associated_fit_types_E;
   extern char sm_model_vehicle_nb_aux_int_types_E;
   extern char sm_model_vehicle_nb_bld_types_E;
   extern char sm_model_vehicle_nb_common_types_E;
   extern char sm_model_vehicle_bb_aural_types_E;
   extern char sm_model_vehicle_nb_fir_types_E;
   extern char sm_model_vehicle_nb_mod_types_E;
   extern char sm_model_vehicle_nb_spd_bld_types_E;
   extern char sm_model_vehicle_nb_spd_types_E;
   extern char sm_model_vehicle_physical_types_E;
   extern char sm_model_vehicle_project_specific_types_E;
   extern char sm_model_vehicle_propulsion_mode_types_E;
   extern char sm_model_vehicle_associated_fit_E;
   extern char sm_model_vehicle_bb_aural_E;
   extern char sm_model_vehicle_bb_flow_E;
   extern char sm_model_vehicle_bb_machinery_E;
   extern char sm_model_vehicle_bb_propeller_E;
   extern char sm_model_vehicle_bb_propeller_modulation_E;
   extern char sm_model_vehicle_bb_E;
   extern char sm_model_vehicle_enhanced_aural_E;
   extern char sm_model_vehicle_nb_aux_int_E;
   extern char sm_model_vehicle_nb_common_E;
   extern char sm_model_vehicle_nb_fir_E;
   extern char sm_model_vehicle_nb_bld_E;
   extern char sm_model_vehicle_nb_spd_E;
   extern char sm_model_vehicle_nb_E;
   extern char sm_model_vehicle_physical_E;
   extern char sm_model_vehicle_propulsion_mode_E;
   extern char sm_model_vehicle_speed_types_E;
   extern char sm_model_vehicle_speed_E;
   extern char sm_model_vehicle_turning_diving_types_E;
   extern char sm_model_vehicle_turning_diving_E;
   extern char sm_model_vehicle_wb_types_E;
   extern char sm_model_vehicle_wb_E;
   extern char sm_model_vehicle_E;
   extern char csl_ids_E;
   extern char csl_config_E;
   extern char sm_model_vehicle_database_E;
   extern char sm_model_vehicle_database_E;

   const char *restrictions = "nnvvnvvvvnnvnnvnvvvvvvnvvnvnvnnvnvnvnvvnnnnnnvvvvnnnvvnv";
   const char *interrupt_states = "";

   __gnat_set_globals (
      -1,               /* Main_Priority              */
      -1,               /* Time_Slice_Value           */
      '8',              /* WC_Encoding                */
      ' ',              /* Locking_Policy             */
      ' ',              /* Queuing_Policy             */
      ' ',              /* Tasking_Dispatching_Policy */
      restrictions,     /* Restrictions               */
      interrupt_states, /* Interrupt_States           */
      0,                /* Num_Interrupt_States       */
      0,                /* Unreserve_All_Interrupts   */
      0,                /* Exception_Tracebacks       */
      1);               /* Zero_Cost_Exceptions       */

   if (__gnat_handler_installed == 0)
     {
        __gnat_install_handler ();
     }

   gnat__strings_E = 1;
   if (ada__exceptions_E == 0) {
      ada__exceptions___elabs ();
   }
   if (system__exceptions_E == 0) {
      system__exceptions___elabs ();
      system__exceptions_E++;
   }
   if (system__soft_links_E == 0) {
      system__soft_links___elabb ();
      system__soft_links_E++;
   }
   if (system__secondary_stack_E == 0) {
      system__secondary_stack___elabb ();
      system__secondary_stack_E++;
   }
   if (system__exception_table_E == 0) {
      system__exception_table___elabb ();
      system__exception_table_E++;
   }
   if (ada__calendar_E == 0) {
      ada__calendar___elabs ();
   }
   ada__calendar_E = 1;
   if (ada__io_exceptions_E == 0) {
      ada__io_exceptions___elabs ();
      ada__io_exceptions_E++;
   }
   if (ada__numerics_E == 0) {
      ada__numerics___elabs ();
      ada__numerics_E++;
   }
   if (ada__strings_E == 0) {
      ada__strings___elabs ();
      ada__strings_E++;
   }
   if (ada__tags_E == 0) {
      ada__tags___elabs ();
   }
   if (ada__tags_E == 0) {
      ada__tags___elabb ();
      ada__tags_E++;
   }
   if (ada__streams_E == 0) {
      ada__streams___elabs ();
      ada__streams_E++;
   }
   if (gnat__lock_files_E == 0) {
      gnat__lock_files___elabs ();
   }
   gnat__lock_files_E = 1;
   if (interfaces__c_E == 0) {
      interfaces__c___elabs ();
   }
   interfaces__c_E = 1;
   if (interfaces__c__strings_E == 0) {
      interfaces__c__strings___elabs ();
   }
   interfaces__c__strings_E = 1;
   if (system__finalization_root_E == 0) {
      system__finalization_root___elabs ();
   }
   system__finalization_root_E = 1;
   if (ada__calendar__delays_E == 0) {
      ada__calendar__delays___elabb ();
      ada__calendar__delays_E++;
   }
   if (ada__exceptions_E == 0) {
      ada__exceptions___elabb ();
      ada__exceptions_E++;
   }
   if (ada__strings__maps_E == 0) {
      ada__strings__maps___elabs ();
   }
   ada__strings__maps_E = 1;
   if (ada__strings__maps__constants_E == 0) {
      ada__strings__maps__constants___elabs ();
      ada__strings__maps__constants_E++;
   }
   if (system__finalization_implementation_E == 0) {
      system__finalization_implementation___elabs ();
   }
   if (system__finalization_implementation_E == 0) {
      system__finalization_implementation___elabb ();
      system__finalization_implementation_E++;
   }
   if (ada__finalization_E == 0) {
      ada__finalization___elabs ();
   }
   ada__finalization_E = 1;
   if (ada__finalization__list_controller_E == 0) {
      ada__finalization__list_controller___elabs ();
   }
   ada__finalization__list_controller_E = 1;
   if (ada__strings__unbounded_E == 0) {
      ada__strings__unbounded___elabs ();
   }
   ada__strings__unbounded_E = 1;
   if (gnat__sockets_E == 0) {
      gnat__sockets___elabs ();
   }
   if (gnat__sockets__thin_E == 0) {
      gnat__sockets__thin___elabs ();
   }
   if (gnat__sockets__thin_E == 0) {
      gnat__sockets__thin___elabb ();
      gnat__sockets__thin_E++;
   }
   if (system__file_control_block_E == 0) {
      system__file_control_block___elabs ();
      system__file_control_block_E++;
   }
   if (system__direct_io_E == 0) {
      system__direct_io___elabs ();
   }
   if (system__file_io_E == 0) {
      system__file_io___elabb ();
      system__file_io_E++;
   }
   system__direct_io_E = 1;
   if (ada__text_io_E == 0) {
      ada__text_io___elabs ();
   }
   if (ada__text_io_E == 0) {
      ada__text_io___elabb ();
      ada__text_io_E++;
   }
   if (gnat__sockets_E == 0) {
      gnat__sockets___elabb ();
      gnat__sockets_E++;
   }
   if (csl_host_E == 0) {
      csl_host___elabb ();
      csl_host_E++;
   }
   if (csl_level_exceptions_E == 0) {
      csl_level_exceptions___elabs ();
      csl_level_exceptions_E++;
   }
   csl_system_numbers_E = 1;
   if (csl_angle_E == 0) {
      csl_angle___elabs ();
   }
   csl_fast_maths_E = 1;
   if (csl_decibel_E == 0) {
      csl_decibel___elabb ();
      csl_decibel_E++;
   }
   if (csl_angle_E == 0) {
      csl_angle___elabb ();
      csl_angle_E++;
   }
   if (csl_length_E == 0) {
      csl_length___elabs ();
   }
   csl_length_E = 1;
   csl_powers_E = 1;
   csl_statistical_E = 1;
   csl_system_utils_E = 1;
   csl_time_E = 1;
   if (csl_angle_rate_E == 0) {
      csl_angle_rate___elabs ();
   }
   csl_angle_rate_E = 1;
   csl_frequency_E = 1;
   csl_real_time_E = 1;
   csl_database_E = 1;
   csl_velocity_E = 1;
   csl_volts_E = 1;
   if (csl_levels_E == 0) {
      csl_levels___elabs ();
   }
   if (csl_levels_E == 0) {
      csl_levels___elabb ();
      csl_levels_E++;
   }
   csl_paths_E = 1;
   if (csl_tonals_E == 0) {
      csl_tonals___elabs ();
   }
   if (csl_tonals_E == 0) {
      csl_tonals___elabb ();
      csl_tonals_E++;
   }
   if (csl_image_utilities_E == 0) {
      csl_image_utilities___elabs ();
   }
   csl_image_utilities_E = 1;
   if (sm_model_radar_general_types_E == 0) {
      sm_model_radar_general_types___elabs ();
   }
   sm_model_radar_general_types_E = 1;
   if (sm_model_radar_kind_E == 0) {
      sm_model_radar_kind___elabs ();
   }
   sm_model_radar_kind_E = 1;
   if (sm_model_sonar_general_types_E == 0) {
      sm_model_sonar_general_types___elabs ();
   }
   sm_model_sonar_general_types_E = 1;
   if (sm_model_sonar_kind_E == 0) {
      sm_model_sonar_kind___elabs ();
   }
   sm_model_sonar_kind_E = 1;
   if (sm_model_vehicle_bb_flow_types_E == 0) {
      sm_model_vehicle_bb_flow_types___elabs ();
      sm_model_vehicle_bb_flow_types_E++;
   }
   if (sm_model_vehicle_bb_machinery_types_E == 0) {
      sm_model_vehicle_bb_machinery_types___elabs ();
      sm_model_vehicle_bb_machinery_types_E++;
   }
   if (sm_model_vehicle_bb_propeller_modulation_types_E == 0) {
      sm_model_vehicle_bb_propeller_modulation_types___elabs ();
      sm_model_vehicle_bb_propeller_modulation_types_E++;
   }
   if (sm_model_vehicle_bb_propeller_types_E == 0) {
      sm_model_vehicle_bb_propeller_types___elabs ();
      sm_model_vehicle_bb_propeller_types_E++;
   }
   if (sm_model_vehicle_enhanced_aural_types_E == 0) {
      sm_model_vehicle_enhanced_aural_types___elabs ();
   }
   sm_model_vehicle_enhanced_aural_types_E = 1;
   if (sm_model_vehicle_general_types_E == 0) {
      sm_model_vehicle_general_types___elabs ();
   }
   sm_model_vehicle_general_types_E = 1;
   if (sm_model_vehicle_general_E == 0) {
      sm_model_vehicle_general___elabs ();
      sm_model_vehicle_general_E++;
   }
   if (sm_model_vehicle_kind_E == 0) {
      sm_model_vehicle_kind___elabs ();
   }
   sm_model_vehicle_kind_E = 1;
   if (sm_model_vehicle_associated_fit_types_E == 0) {
      sm_model_vehicle_associated_fit_types___elabs ();
   }
   sm_model_vehicle_associated_fit_types_E = 1;
   if (sm_model_vehicle_nb_aux_int_types_E == 0) {
      sm_model_vehicle_nb_aux_int_types___elabs ();
   }
   sm_model_vehicle_nb_aux_int_types_E = 1;
   if (sm_model_vehicle_nb_bld_types_E == 0) {
      sm_model_vehicle_nb_bld_types___elabs ();
      sm_model_vehicle_nb_bld_types_E++;
   }
   if (sm_model_vehicle_nb_common_types_E == 0) {
      sm_model_vehicle_nb_common_types___elabs ();
   }
   sm_model_vehicle_nb_common_types_E = 1;
   if (sm_model_vehicle_bb_aural_types_E == 0) {
      sm_model_vehicle_bb_aural_types___elabs ();
   }
   sm_model_vehicle_bb_aural_types_E = 1;
   if (sm_model_vehicle_nb_fir_types_E == 0) {
      sm_model_vehicle_nb_fir_types___elabs ();
      sm_model_vehicle_nb_fir_types_E++;
   }
   if (sm_model_vehicle_nb_mod_types_E == 0) {
      sm_model_vehicle_nb_mod_types___elabs ();
      sm_model_vehicle_nb_mod_types_E++;
   }
   if (sm_model_vehicle_nb_spd_bld_types_E == 0) {
      sm_model_vehicle_nb_spd_bld_types___elabs ();
      sm_model_vehicle_nb_spd_bld_types_E++;
   }
   if (sm_model_vehicle_nb_spd_types_E == 0) {
      sm_model_vehicle_nb_spd_types___elabs ();
      sm_model_vehicle_nb_spd_types_E++;
   }
   if (sm_model_vehicle_physical_types_E == 0) {
      sm_model_vehicle_physical_types___elabs ();
      sm_model_vehicle_physical_types_E++;
   }
   if (sm_model_vehicle_project_specific_types_E == 0) {
      sm_model_vehicle_project_specific_types___elabs ();
      sm_model_vehicle_project_specific_types_E++;
   }
   if (sm_model_vehicle_propulsion_mode_types_E == 0) {
      sm_model_vehicle_propulsion_mode_types___elabs ();
   }
   sm_model_vehicle_propulsion_mode_types_E = 1;
   if (sm_model_vehicle_associated_fit_E == 0) {
      sm_model_vehicle_associated_fit___elabs ();
      sm_model_vehicle_associated_fit_E++;
   }
   if (sm_model_vehicle_bb_aural_E == 0) {
      sm_model_vehicle_bb_aural___elabs ();
      sm_model_vehicle_bb_aural_E++;
   }
   if (sm_model_vehicle_bb_flow_E == 0) {
      sm_model_vehicle_bb_flow___elabs ();
      sm_model_vehicle_bb_flow_E++;
   }
   if (sm_model_vehicle_bb_machinery_E == 0) {
      sm_model_vehicle_bb_machinery___elabs ();
      sm_model_vehicle_bb_machinery_E++;
   }
   if (sm_model_vehicle_bb_propeller_E == 0) {
      sm_model_vehicle_bb_propeller___elabs ();
      sm_model_vehicle_bb_propeller_E++;
   }
   if (sm_model_vehicle_bb_propeller_modulation_E == 0) {
      sm_model_vehicle_bb_propeller_modulation___elabs ();
      sm_model_vehicle_bb_propeller_modulation_E++;
   }
   if (sm_model_vehicle_bb_E == 0) {
      sm_model_vehicle_bb___elabs ();
      sm_model_vehicle_bb_E++;
   }
   if (sm_model_vehicle_enhanced_aural_E == 0) {
      sm_model_vehicle_enhanced_aural___elabs ();
      sm_model_vehicle_enhanced_aural_E++;
   }
   if (sm_model_vehicle_nb_aux_int_E == 0) {
      sm_model_vehicle_nb_aux_int___elabs ();
      sm_model_vehicle_nb_aux_int_E++;
   }
   if (sm_model_vehicle_nb_common_E == 0) {
      sm_model_vehicle_nb_common___elabs ();
      sm_model_vehicle_nb_common_E++;
   }
   if (sm_model_vehicle_nb_fir_E == 0) {
      sm_model_vehicle_nb_fir___elabs ();
      sm_model_vehicle_nb_fir_E++;
   }
   if (sm_model_vehicle_nb_bld_E == 0) {
      sm_model_vehicle_nb_bld___elabs ();
      sm_model_vehicle_nb_bld_E++;
   }
   if (sm_model_vehicle_nb_spd_E == 0) {
      sm_model_vehicle_nb_spd___elabs ();
      sm_model_vehicle_nb_spd_E++;
   }
   if (sm_model_vehicle_nb_E == 0) {
      sm_model_vehicle_nb___elabs ();
      sm_model_vehicle_nb_E++;
   }
   if (sm_model_vehicle_physical_E == 0) {
      sm_model_vehicle_physical___elabs ();
      sm_model_vehicle_physical_E++;
   }
   if (sm_model_vehicle_propulsion_mode_E == 0) {
      sm_model_vehicle_propulsion_mode___elabs ();
      sm_model_vehicle_propulsion_mode_E++;
   }
   if (sm_model_vehicle_speed_types_E == 0) {
      sm_model_vehicle_speed_types___elabs ();
   }
   sm_model_vehicle_speed_types_E = 1;
   if (sm_model_vehicle_speed_E == 0) {
      sm_model_vehicle_speed___elabs ();
      sm_model_vehicle_speed_E++;
   }
   if (sm_model_vehicle_turning_diving_types_E == 0) {
      sm_model_vehicle_turning_diving_types___elabs ();
   }
   sm_model_vehicle_turning_diving_types_E = 1;
   if (sm_model_vehicle_turning_diving_E == 0) {
      sm_model_vehicle_turning_diving___elabs ();
      sm_model_vehicle_turning_diving_E++;
   }
   if (sm_model_vehicle_wb_types_E == 0) {
      sm_model_vehicle_wb_types___elabs ();
   }
   sm_model_vehicle_wb_types_E = 1;
   if (sm_model_vehicle_wb_E == 0) {
      sm_model_vehicle_wb___elabs ();
      sm_model_vehicle_wb_E++;
   }
   if (sm_model_vehicle_E == 0) {
      sm_model_vehicle___elabs ();
   }
   csl_ids_E = 1;
   if (csl_config_E == 0) {
      csl_config___elabb ();
      csl_config_E++;
   }
   if (sm_model_vehicle_E == 0) {
      sm_model_vehicle___elabb ();
      sm_model_vehicle_E++;
   }
   if (sm_model_vehicle_database_E == 0) {
      sm_model_vehicle_database___elabs ();
   }
   if (sm_model_vehicle_database_E == 0) {
      sm_model_vehicle_database___elabb ();
      sm_model_vehicle_database_E++;
   }
   radar_vdb_access_E = 1;
}
unsigned radar_vdb_accessB = 0xda692556;
unsigned radar_vdb_accessS = 0xb6fdb491;
unsigned system__standard_libraryB = 0x9d9c3691;
unsigned system__standard_libraryS = 0xfcd73e35;
unsigned adaS = 0xa0108083;
unsigned ada__exceptionsB = 0x400efd0b;
unsigned ada__exceptionsS = 0xa9c7ad17;
unsigned ada__exceptions__last_chance_handlerB = 0x0fccca55;
unsigned ada__exceptions__last_chance_handlerS = 0x0eaa7c0d;
unsigned system__secondary_stackB = 0xf5fe57c5;
unsigned system__secondary_stackS = 0xb55bea4e;
unsigned systemS = 0xa711752f;
unsigned system__parametersB = 0x4fed447a;
unsigned system__parametersS = 0x23689ac9;
unsigned system__soft_linksB = 0xab74c53c;
unsigned system__soft_linksS = 0x735063ac;
unsigned system__machine_state_operationsB = 0x060e703d;
unsigned system__machine_state_operationsS = 0x313092b1;
unsigned system__machine_codeS = 0x569917bc;
unsigned system__memoryB = 0x8dc75365;
unsigned system__memoryS = 0xaae3a39f;
unsigned system__crtlS = 0x87ce609a;
unsigned system__storage_elementsB = 0x08148070;
unsigned system__storage_elementsS = 0xcd5f9862;
unsigned system__exceptionsS = 0x2298e582;
unsigned system__stack_checkingB = 0xaad35c05;
unsigned system__stack_checkingS = 0xac6a6b56;
unsigned interfacesS = 0x6e859da6;
unsigned system__exception_tableB = 0xcf943c5d;
unsigned system__exception_tableS = 0x268bafa0;
unsigned system__htableB = 0x1c775a3d;
unsigned system__htableS = 0x080b57fb;
unsigned system__tracebackB = 0xe67db754;
unsigned system__tracebackS = 0x5ec0b96c;
unsigned system__unsigned_typesS = 0xaa386b6b;
unsigned system__traceback_entriesB = 0x1a18fd0f;
unsigned system__traceback_entriesS = 0x4f0b7c57;
unsigned ada__text_ioB = 0x0d0ab408;
unsigned ada__text_ioS = 0x23f7a7e0;
unsigned ada__streamsS = 0x7bf62c37;
unsigned ada__tagsB = 0xce67505f;
unsigned ada__tagsS = 0xe243e27d;
unsigned interfaces__c_streamsB = 0xa3942187;
unsigned interfaces__c_streamsS = 0xbcb38f2c;
unsigned system__file_ioB = 0x1efe2fa9;
unsigned system__file_ioS = 0x3ea2d036;
unsigned ada__finalizationB = 0xdec8b4cc;
unsigned ada__finalizationS = 0x0af0a97f;
unsigned system__finalization_rootB = 0x2707dc21;
unsigned system__finalization_rootS = 0x02a9dee0;
unsigned system__finalization_implementationB = 0x81acdbde;
unsigned system__finalization_implementationS = 0x362ad94a;
unsigned system__string_ops_concat_3B = 0x9d5e2b8a;
unsigned system__string_ops_concat_3S = 0x5c4d4c4b;
unsigned system__string_opsB = 0x474b0583;
unsigned system__string_opsS = 0x48245ed4;
unsigned system__stream_attributesB = 0x2f0e9cd7;
unsigned system__stream_attributesS = 0x17c8c8bd;
unsigned ada__io_exceptionsS = 0x753e9209;
unsigned system__file_control_blockS = 0x1e265046;
unsigned ada__finalization__list_controllerB = 0xffad3e68;
unsigned ada__finalization__list_controllerS = 0x29e5afbc;
unsigned csl_lengthB = 0x3616b5ec;
unsigned csl_lengthS = 0x69b8d682;
unsigned ada__text_io__float_auxB = 0xc74fb7ce;
unsigned ada__text_io__float_auxS = 0x84f33c46;
unsigned ada__text_io__generic_auxB = 0xb84e495c;
unsigned ada__text_io__generic_auxS = 0x3c483919;
unsigned system__img_realB = 0xd54bb105;
unsigned system__img_realS = 0x6085e634;
unsigned system__fat_llfS = 0x17d7a7c8;
unsigned system__img_lluB = 0xfa51067d;
unsigned system__img_lluS = 0x6272a47d;
unsigned system__img_unsB = 0x6fdfe09d;
unsigned system__img_unsS = 0x4f0b08f1;
unsigned system__powten_tableS = 0x23af4d76;
unsigned system__val_realB = 0xc7726af2;
unsigned system__val_realS = 0x272c236d;
unsigned system__exn_llfB = 0x17d993aa;
unsigned system__exn_llfS = 0x3ada11e8;
unsigned system__val_utilB = 0x682fa91a;
unsigned system__val_utilS = 0x57dd3f8f;
unsigned system__case_utilB = 0x87d63e0c;
unsigned system__case_utilS = 0xa9b75c13;
unsigned csl_angleB = 0x274014ff;
unsigned csl_angleS = 0x156d00ae;
unsigned csl_fast_mathsB = 0x32a8c1dc;
unsigned csl_fast_mathsS = 0xd8369f1c;
unsigned ada__numericsS = 0x846587b0;
unsigned ada__numerics__auxB = 0xe279379d;
unsigned ada__numerics__auxS = 0x81e912f6;
unsigned csl_system_numbersB = 0x4c1d1732;
unsigned csl_system_numbersS = 0x60948f4d;
unsigned system__exp_intB = 0x564e5b8e;
unsigned system__exp_intS = 0x9407b37a;
unsigned system__fat_sfltS = 0x937e8390;
unsigned text_ioS = 0x1528e471;
unsigned sm_model_vehicleB = 0x0226f4fb;
unsigned sm_model_vehicleS = 0x12de18ba;
unsigned csl_configB = 0xd6846472;
unsigned csl_configS = 0xe72ffe56;
unsigned ada__charactersS = 0x060f352a;
unsigned ada__characters__handlingB = 0xf6447ab9;
unsigned ada__characters__handlingS = 0x46d230ec;
unsigned ada__characters__latin_1S = 0xa0be30a8;
unsigned ada__stringsS = 0xc4504387;
unsigned ada__strings__mapsB = 0x7f70d6fb;
unsigned ada__strings__mapsS = 0x841ddc3f;
unsigned system__bit_opsB = 0x3142951c;
unsigned system__bit_opsS = 0x0c033dfd;
unsigned system__pure_exceptionsS = 0x05294e6d;
unsigned ada__strings__maps__constantsS = 0x6b21310c;
unsigned ada__command_lineB = 0x732c5bd7;
unsigned ada__command_lineS = 0xd8088025;
unsigned ada__strings__unboundedB = 0xcc5a967d;
unsigned ada__strings__unboundedS = 0x39162d55;
unsigned ada__strings__fixedB = 0x95f1ae19;
unsigned ada__strings__fixedS = 0xa09484f4;
unsigned ada__strings__searchB = 0x6b03b68b;
unsigned ada__strings__searchS = 0xebae4dd3;
unsigned system__compare_array_unsigned_8B = 0xb3a2acc9;
unsigned system__compare_array_unsigned_8S = 0x099a5ce6;
unsigned calendarS = 0x6050a177;
unsigned ada__calendarB = 0xfdf6f7bf;
unsigned ada__calendarS = 0x2311df51;
unsigned system__arith_64B = 0x59f21a41;
unsigned system__arith_64S = 0x77f083b5;
unsigned system__os_primitivesB = 0xbcbf130b;
unsigned system__os_primitivesS = 0xf813e03b;
unsigned csl_system_utilsB = 0x970edd5b;
unsigned csl_system_utilsS = 0x28501a9e;
unsigned interfaces__cB = 0x21635c57;
unsigned interfaces__cS = 0x63f5e940;
unsigned interfaces__c__stringsB = 0x01b83300;
unsigned interfaces__c__stringsS = 0x1b490ea4;
unsigned integer_ioB = 0x3d2075ba;
unsigned integer_ioS = 0x16771cbd;
unsigned ada__text_io__integer_auxB = 0xefa37476;
unsigned ada__text_io__integer_auxS = 0x881024e6;
unsigned system__img_biuB = 0x32480be2;
unsigned system__img_biuS = 0xf5289bb9;
unsigned system__img_intB = 0x70f6a786;
unsigned system__img_intS = 0x56abf14c;
unsigned system__img_llbB = 0xad931dca;
unsigned system__img_llbS = 0x6ebda9fc;
unsigned system__img_lliB = 0xf02ff885;
unsigned system__img_lliS = 0xfeb7ac3e;
unsigned system__img_llwB = 0x218dca24;
unsigned system__img_llwS = 0x0c57a0fe;
unsigned system__img_wiuB = 0x23153183;
unsigned system__img_wiuS = 0x70a57d03;
unsigned system__val_intB = 0x575a3d3a;
unsigned system__val_intS = 0x70742998;
unsigned system__val_unsB = 0x966b502a;
unsigned system__val_unsS = 0xb7b434d0;
unsigned system__val_lliB = 0x40a0d75a;
unsigned system__val_lliS = 0xb6cbb6f8;
unsigned system__val_lluB = 0x2b6dce41;
unsigned system__val_lluS = 0xa30e8584;
unsigned system__img_enumB = 0x726bb6bb;
unsigned system__img_enumS = 0x877268e1;
unsigned system__string_ops_concat_4B = 0xcfb745b6;
unsigned system__string_ops_concat_4S = 0x9bd55989;
unsigned system__string_ops_concat_5B = 0xec185bba;
unsigned system__string_ops_concat_5S = 0xf021e9cc;
unsigned csl_hostB = 0xa0a10341;
unsigned csl_hostS = 0x8fa5b692;
unsigned gnatS = 0x6380ea48;
unsigned gnat__socketsB = 0x796785d9;
unsigned gnat__socketsS = 0x797cd068;
unsigned gnat__os_libB = 0xe9ed374c;
unsigned gnat__os_libS = 0xd3935af5;
unsigned gnat__stringsB = 0x1d1cd3a0;
unsigned gnat__stringsS = 0x635d1177;
unsigned gnat__sockets__constantsS = 0x9c130fb9;
unsigned gnat__sockets__linker_optionsS = 0x574a1ec7;
unsigned gnat__sockets__thinB = 0x33d22b1c;
unsigned gnat__sockets__thinS = 0xbb5dadcc;
unsigned ada__calendar__delaysB = 0x89650b28;
unsigned ada__calendar__delaysS = 0x56f69050;
unsigned system__tracesB = 0xd5c08480;
unsigned system__tracesS = 0x63439e94;
unsigned gnat__task_lockB = 0xc3022143;
unsigned gnat__task_lockS = 0x01a0b0da;
unsigned csl_idsB = 0x7925aa48;
unsigned csl_idsS = 0x7faa5dfd;
unsigned unsigned_typesS = 0x2bf79376;
unsigned sm_model_vehicle_associated_fitS = 0x2e5924d5;
unsigned sm_model_vehicle_associated_fit_typesB = 0xf55ab554;
unsigned sm_model_vehicle_associated_fit_typesS = 0x755e73f9;
unsigned csl_image_utilitiesB = 0xfc1fcefd;
unsigned csl_image_utilitiesS = 0x265e7aa3;
unsigned current_exceptionS = 0x61b8ef33;
unsigned system__fat_fltS = 0x6f97a5d6;
unsigned csl_angle_rateB = 0x577d5678;
unsigned csl_angle_rateS = 0xe22671e0;
unsigned csl_timeB = 0xcaabe161;
unsigned csl_timeS = 0xe57fb1a2;
unsigned csl_frequencyB = 0x266caca4;
unsigned csl_frequencyS = 0x1c6fd1cf;
unsigned csl_levelsB = 0x871dd33f;
unsigned csl_levelsS = 0xea4ffb79;
unsigned csl_decibelB = 0x599896aa;
unsigned csl_decibelS = 0x18c7a382;
unsigned csl_level_exceptionsS = 0xed1cbc37;
unsigned csl_powersB = 0xd90e8414;
unsigned csl_powersS = 0x620d7e3c;
unsigned csl_voltsB = 0x4136d359;
unsigned csl_voltsS = 0xc54facfd;
unsigned csl_tonalsB = 0xce5c7064;
unsigned csl_tonalsS = 0xf0dc9e10;
unsigned csl_pathsB = 0x47773ca5;
unsigned csl_pathsS = 0xac1b7c10;
unsigned csl_velocityB = 0x3989a2b2;
unsigned csl_velocityS = 0x463869e1;
unsigned sm_model_radar_kindB = 0xcb9a82e5;
unsigned sm_model_radar_kindS = 0x781b42a9;
unsigned sm_model_radar_general_typesB = 0xe68ab037;
unsigned sm_model_radar_general_typesS = 0xdcb4c092;
unsigned sm_model_sonar_kindB = 0x1ee01266;
unsigned sm_model_sonar_kindS = 0x4b7749d0;
unsigned sm_model_sonar_general_typesB = 0x0cc5ab44;
unsigned sm_model_sonar_general_typesS = 0xd661c701;
unsigned sm_model_vehicle_kindB = 0xdf18d645;
unsigned sm_model_vehicle_kindS = 0xac2cc67e;
unsigned sm_model_vehicle_general_typesB = 0x46b1ae5c;
unsigned sm_model_vehicle_general_typesS = 0xe55a0aba;
unsigned sm_model_vehicle_propulsion_mode_typesB = 0xd1dda385;
unsigned sm_model_vehicle_propulsion_mode_typesS = 0x9163691b;
unsigned sm_model_vehicle_bbS = 0x381c2528;
unsigned sm_model_vehicle_bb_auralS = 0xd33110dc;
unsigned sm_model_vehicle_bb_aural_typesB = 0xaa2d205b;
unsigned sm_model_vehicle_bb_aural_typesS = 0x60af0737;
unsigned sm_model_vehicle_nb_common_typesB = 0x37ffb3a4;
unsigned sm_model_vehicle_nb_common_typesS = 0x6a557605;
unsigned csl_statisticalB = 0x9b4e83a8;
unsigned csl_statisticalS = 0x0d60a20e;
unsigned sm_model_vehicle_bb_flowS = 0x4b732a85;
unsigned sm_model_vehicle_bb_flow_typesS = 0xa2364d94;
unsigned sm_model_vehicle_bb_machineryS = 0x4829579f;
unsigned sm_model_vehicle_bb_machinery_typesS = 0x6553588a;
unsigned sm_model_vehicle_bb_propellerS = 0x5664b3d9;
unsigned sm_model_vehicle_bb_propeller_typesS = 0x75d18847;
unsigned sm_model_vehicle_bb_propeller_modulationS = 0xdc7fc1ae;
unsigned sm_model_vehicle_bb_propeller_modulation_typesS = 0x5f26d70b;
unsigned sm_model_vehicle_enhanced_auralS = 0xeacd08e9;
unsigned sm_model_vehicle_enhanced_aural_typesB = 0x7fa4a36c;
unsigned sm_model_vehicle_enhanced_aural_typesS = 0x05aeb8f4;
unsigned sm_model_vehicle_generalS = 0x3bebbef1;
unsigned sm_model_vehicle_nbS = 0xf9c6e625;
unsigned sm_model_vehicle_nb_aux_intS = 0x95bf138f;
unsigned sm_model_vehicle_nb_aux_int_typesB = 0xfbf63663;
unsigned sm_model_vehicle_nb_aux_int_typesS = 0x518ad2ee;
unsigned sm_model_vehicle_nb_bldS = 0x4821214f;
unsigned sm_model_vehicle_nb_bld_typesS = 0x9e4fd250;
unsigned sm_model_vehicle_nb_spd_bldS = 0x070c9175;
unsigned sm_model_vehicle_nb_spd_bld_typesS = 0x84f7ff8f;
unsigned sm_model_vehicle_nb_commonS = 0xb45039e1;
unsigned sm_model_vehicle_nb_firS = 0xd34f4f25;
unsigned sm_model_vehicle_nb_fir_typesS = 0x13049982;
unsigned sm_model_vehicle_nb_modS = 0x8bdbcaae;
unsigned sm_model_vehicle_nb_mod_typesS = 0xca7fa039;
unsigned sm_model_vehicle_nb_spdS = 0xfb921665;
unsigned sm_model_vehicle_nb_spd_typesS = 0x124d1514;
unsigned sm_model_vehicle_physicalS = 0x195c58d7;
unsigned sm_model_vehicle_physical_typesS = 0x63ff97d9;
unsigned sm_model_vehicle_project_specificS = 0x11060033;
unsigned sm_model_vehicle_project_specific_typesS = 0xcf1d69f2;
unsigned sm_model_vehicle_propulsion_modeS = 0x2a22460a;
unsigned sm_model_vehicle_speedS = 0x1c0292c1;
unsigned sm_model_vehicle_speed_typesB = 0xfff16efd;
unsigned sm_model_vehicle_speed_typesS = 0xacbf0bee;
unsigned sm_model_vehicle_turning_divingS = 0xe85cea52;
unsigned sm_model_vehicle_turning_diving_typesB = 0x19220233;
unsigned sm_model_vehicle_turning_diving_typesS = 0xb1f47168;
unsigned sm_model_vehicle_wbS = 0x3f21691d;
unsigned sm_model_vehicle_wb_typesB = 0xf001e210;
unsigned sm_model_vehicle_wb_typesS = 0xac7dcc65;
unsigned sm_model_vehicle_databaseB = 0x2014b2db;
unsigned sm_model_vehicle_databaseS = 0x2dbbe1f6;
unsigned csl_databaseB = 0x128cc9fc;
unsigned csl_databaseS = 0x3e3dc439;
unsigned csl_real_timeB = 0x1d461fea;
unsigned csl_real_timeS = 0xcb393a69;
unsigned gnat__lock_filesB = 0x8e801d65;
unsigned gnat__lock_filesS = 0x572a55dd;
unsigned system__direct_ioB = 0x98e223f8;
unsigned system__direct_ioS = 0x9762b9c5;

/* BEGIN ELABORATION ORDER
ada (spec)
ada.characters (spec)
ada.characters.handling (spec)
ada.characters.latin_1 (spec)
ada.command_line (spec)
gnat (spec)
gnat.strings (spec)
gnat.strings (body)
interfaces (spec)
system (spec)
system.arith_64 (spec)
system.bit_ops (spec)
system.case_util (spec)
system.case_util (body)
system.compare_array_unsigned_8 (spec)
system.compare_array_unsigned_8 (body)
system.exn_llf (spec)
system.exn_llf (body)
system.exp_int (spec)
system.exp_int (body)
system.htable (spec)
system.htable (body)
system.img_enum (spec)
system.img_int (spec)
system.img_lli (spec)
system.img_real (spec)
system.machine_code (spec)
system.os_primitives (spec)
system.os_primitives (body)
system.parameters (spec)
system.parameters (body)
system.crtl (spec)
interfaces.c_streams (spec)
interfaces.c_streams (body)
system.powten_table (spec)
system.pure_exceptions (spec)
system.arith_64 (body)
system.standard_library (spec)
system.storage_elements (spec)
system.storage_elements (body)
system.secondary_stack (spec)
system.img_lli (body)
system.img_int (body)
system.img_enum (body)
ada.command_line (body)
system.stack_checking (spec)
system.string_ops (spec)
system.string_ops (body)
system.string_ops_concat_3 (spec)
system.string_ops_concat_3 (body)
system.string_ops_concat_4 (spec)
system.string_ops_concat_4 (body)
system.string_ops_concat_5 (spec)
system.string_ops_concat_5 (body)
system.traceback (spec)
system.traceback (body)
system.traceback_entries (spec)
system.traceback_entries (body)
ada.exceptions (spec)
ada.exceptions.last_chance_handler (spec)
ada.exceptions.last_chance_handler (body)
system.exceptions (spec)
system.machine_state_operations (spec)
system.soft_links (spec)
system.soft_links (body)
system.stack_checking (body)
system.secondary_stack (body)
gnat.task_lock (spec)
gnat.task_lock (body)
system.exception_table (spec)
system.exception_table (body)
ada.calendar (spec)
ada.calendar (body)
ada.calendar.delays (spec)
ada.io_exceptions (spec)
ada.numerics (spec)
ada.numerics.aux (spec)
ada.strings (spec)
ada.tags (spec)
ada.tags (body)
ada.streams (spec)
calendar (spec)
gnat.lock_files (spec)
gnat.lock_files (body)
gnat.os_lib (spec)
gnat.os_lib (body)
interfaces.c (spec)
interfaces.c (body)
interfaces.c.strings (spec)
interfaces.c.strings (body)
system.finalization_root (spec)
system.finalization_root (body)
system.memory (spec)
system.memory (body)
system.machine_state_operations (body)
system.standard_library (body)
system.traces (spec)
system.traces (body)
ada.calendar.delays (body)
system.unsigned_types (spec)
ada.exceptions (body)
system.bit_ops (body)
ada.strings.maps (spec)
ada.strings.maps (body)
ada.strings.fixed (spec)
ada.strings.maps.constants (spec)
ada.characters.handling (body)
ada.strings.search (spec)
ada.strings.search (body)
ada.strings.fixed (body)
system.fat_flt (spec)
system.fat_llf (spec)
ada.numerics.aux (body)
system.fat_sflt (spec)
system.img_biu (spec)
system.img_biu (body)
system.img_llb (spec)
system.img_llb (body)
system.img_llu (spec)
system.img_llu (body)
system.img_llw (spec)
system.img_llw (body)
system.img_uns (spec)
system.img_uns (body)
system.img_real (body)
system.img_wiu (spec)
system.img_wiu (body)
system.stream_attributes (spec)
system.stream_attributes (body)
system.finalization_implementation (spec)
system.finalization_implementation (body)
ada.finalization (spec)
ada.finalization (body)
ada.finalization.list_controller (spec)
ada.finalization.list_controller (body)
ada.strings.unbounded (spec)
ada.strings.unbounded (body)
gnat.sockets (spec)
gnat.sockets.constants (spec)
gnat.sockets.linker_options (spec)
gnat.sockets.thin (spec)
gnat.sockets.thin (body)
system.file_control_block (spec)
system.direct_io (spec)
system.file_io (spec)
system.file_io (body)
system.direct_io (body)
ada.text_io (spec)
ada.text_io (body)
ada.text_io.float_aux (spec)
ada.text_io.generic_aux (spec)
ada.text_io.generic_aux (body)
ada.text_io.integer_aux (spec)
system.val_int (spec)
gnat.sockets (body)
system.val_lli (spec)
ada.text_io.integer_aux (body)
system.val_llu (spec)
system.val_real (spec)
ada.text_io.float_aux (body)
system.val_uns (spec)
system.val_util (spec)
system.val_util (body)
system.val_uns (body)
system.val_real (body)
system.val_llu (body)
system.val_lli (body)
system.val_int (body)
text_io (spec)
csl_host (spec)
csl_host (body)
csl_level_exceptions (spec)
csl_system_numbers (spec)
csl_system_numbers (body)
csl_angle (spec)
csl_decibel (spec)
csl_fast_maths (spec)
csl_fast_maths (body)
csl_decibel (body)
csl_angle (body)
csl_length (spec)
csl_length (body)
csl_powers (spec)
csl_powers (body)
csl_statistical (spec)
csl_statistical (body)
csl_system_utils (spec)
csl_system_utils (body)
csl_time (spec)
csl_time (body)
csl_angle_rate (spec)
csl_angle_rate (body)
csl_database (spec)
csl_frequency (spec)
csl_frequency (body)
csl_real_time (spec)
csl_real_time (body)
csl_database (body)
csl_velocity (spec)
csl_velocity (body)
csl_volts (spec)
csl_volts (body)
csl_levels (spec)
csl_levels (body)
csl_paths (spec)
csl_paths (body)
csl_tonals (spec)
csl_tonals (body)
csl_image_utilities (spec)
current_exception (spec)
csl_image_utilities (body)
integer_io (spec)
integer_io (body)
radar_vdb_access (spec)
sm_model_radar_general_types (spec)
sm_model_radar_general_types (body)
sm_model_radar_kind (spec)
sm_model_radar_kind (body)
sm_model_sonar_general_types (spec)
sm_model_sonar_general_types (body)
sm_model_sonar_kind (spec)
sm_model_sonar_kind (body)
sm_model_vehicle_bb_flow_types (spec)
sm_model_vehicle_bb_machinery_types (spec)
sm_model_vehicle_bb_propeller_modulation_types (spec)
sm_model_vehicle_bb_propeller_types (spec)
sm_model_vehicle_enhanced_aural_types (spec)
sm_model_vehicle_enhanced_aural_types (body)
sm_model_vehicle_general_types (spec)
sm_model_vehicle_general_types (body)
sm_model_vehicle_general (spec)
sm_model_vehicle_kind (spec)
sm_model_vehicle_kind (body)
sm_model_vehicle_associated_fit_types (spec)
sm_model_vehicle_associated_fit_types (body)
sm_model_vehicle_nb_aux_int_types (spec)
sm_model_vehicle_nb_aux_int_types (body)
sm_model_vehicle_nb_bld_types (spec)
sm_model_vehicle_nb_common_types (spec)
sm_model_vehicle_nb_common_types (body)
sm_model_vehicle_bb_aural_types (spec)
sm_model_vehicle_bb_aural_types (body)
sm_model_vehicle_nb_fir_types (spec)
sm_model_vehicle_nb_mod_types (spec)
sm_model_vehicle_nb_spd_bld_types (spec)
sm_model_vehicle_nb_spd_types (spec)
sm_model_vehicle_physical_types (spec)
sm_model_vehicle_project_specific_types (spec)
sm_model_vehicle_project_specific (spec)
sm_model_vehicle_propulsion_mode_types (spec)
sm_model_vehicle_propulsion_mode_types (body)
sm_model_vehicle_associated_fit (spec)
sm_model_vehicle_bb_aural (spec)
sm_model_vehicle_bb_flow (spec)
sm_model_vehicle_bb_machinery (spec)
sm_model_vehicle_bb_propeller (spec)
sm_model_vehicle_bb_propeller_modulation (spec)
sm_model_vehicle_bb (spec)
sm_model_vehicle_enhanced_aural (spec)
sm_model_vehicle_nb_aux_int (spec)
sm_model_vehicle_nb_common (spec)
sm_model_vehicle_nb_fir (spec)
sm_model_vehicle_nb_mod (spec)
sm_model_vehicle_nb_spd_bld (spec)
sm_model_vehicle_nb_bld (spec)
sm_model_vehicle_nb_spd (spec)
sm_model_vehicle_nb (spec)
sm_model_vehicle_physical (spec)
sm_model_vehicle_propulsion_mode (spec)
sm_model_vehicle_speed_types (spec)
sm_model_vehicle_speed_types (body)
sm_model_vehicle_speed (spec)
sm_model_vehicle_turning_diving_types (spec)
sm_model_vehicle_turning_diving_types (body)
sm_model_vehicle_turning_diving (spec)
sm_model_vehicle_wb_types (spec)
sm_model_vehicle_wb_types (body)
sm_model_vehicle_wb (spec)
sm_model_vehicle (spec)
unsigned_types (spec)
csl_ids (spec)
csl_ids (body)
csl_config (spec)
csl_config (body)
sm_model_vehicle (body)
sm_model_vehicle_database (spec)
sm_model_vehicle_database (body)
radar_vdb_access (body)
   END ELABORATION ORDER */

/*  BEGIN Object file/option list
/build/jdyer/astute/ada/csl_host.o
/build/jdyer/astute/ada/csl_level_exceptions.o
/build/jdyer/astute/ada/csl_system_numbers.o
/build/jdyer/astute/ada/csl_fast_maths.o
/build/jdyer/astute/ada/csl_decibel.o
/build/jdyer/astute/ada/csl_angle.o
/build/jdyer/astute/ada/csl_length.o
/build/jdyer/astute/ada/csl_powers.o
/build/jdyer/astute/ada/csl_statistical.o
/build/jdyer/astute/ada/csl_system_utils.o
/build/jdyer/astute/ada/csl_time.o
/build/jdyer/astute/ada/csl_angle_rate.o
/build/jdyer/astute/ada/csl_frequency.o
/build/jdyer/astute/ada/csl_real_time.o
/build/jdyer/astute/ada/csl_database.o
/build/jdyer/astute/ada/csl_velocity.o
/build/jdyer/astute/ada/csl_volts.o
/build/jdyer/astute/ada/csl_levels.o
/build/jdyer/astute/ada/csl_paths.o
/build/jdyer/astute/ada/csl_tonals.o
/build/jdyer/astute/ada/current_exception.o
/build/jdyer/astute/ada/csl_image_utilities.o
/build/jdyer/astute/ada/integer_io.o
/build/jdyer/astute/ada/sm_model_radar_general_types.o
/build/jdyer/astute/ada/sm_model_radar_kind.o
/build/jdyer/astute/ada/sm_model_sonar_general_types.o
/build/jdyer/astute/ada/sm_model_sonar_kind.o
/build/jdyer/astute/ada/sm_model_vehicle_bb_flow_types.o
/build/jdyer/astute/ada/sm_model_vehicle_bb_machinery_types.o
/build/jdyer/astute/ada/sm_model_vehicle_bb_propeller_modulation_types.o
/build/jdyer/astute/ada/sm_model_vehicle_bb_propeller_types.o
/build/jdyer/astute/ada/sm_model_vehicle_enhanced_aural_types.o
/build/jdyer/astute/ada/sm_model_vehicle_general_types.o
/build/jdyer/astute/ada/sm_model_vehicle_general.o
/build/jdyer/astute/ada/sm_model_vehicle_kind.o
/build/jdyer/astute/ada/sm_model_vehicle_associated_fit_types.o
/build/jdyer/astute/ada/sm_model_vehicle_nb_aux_int_types.o
/build/jdyer/astute/ada/sm_model_vehicle_nb_bld_types.o
/build/jdyer/astute/ada/sm_model_vehicle_nb_common_types.o
/build/jdyer/astute/ada/sm_model_vehicle_bb_aural_types.o
/build/jdyer/astute/ada/sm_model_vehicle_nb_fir_types.o
/build/jdyer/astute/ada/sm_model_vehicle_nb_mod_types.o
/build/jdyer/astute/ada/sm_model_vehicle_nb_spd_bld_types.o
/build/jdyer/astute/ada/sm_model_vehicle_nb_spd_types.o
/build/jdyer/astute/ada/sm_model_vehicle_physical_types.o
/build/jdyer/astute/ada/sm_model_vehicle_project_specific_types.o
/build/jdyer/astute/ada/sm_model_vehicle_project_specific.o
/build/jdyer/astute/ada/sm_model_vehicle_propulsion_mode_types.o
/build/jdyer/astute/ada/sm_model_vehicle_associated_fit.o
/build/jdyer/astute/ada/sm_model_vehicle_bb_aural.o
/build/jdyer/astute/ada/sm_model_vehicle_bb_flow.o
/build/jdyer/astute/ada/sm_model_vehicle_bb_machinery.o
/build/jdyer/astute/ada/sm_model_vehicle_bb_propeller.o
/build/jdyer/astute/ada/sm_model_vehicle_bb_propeller_modulation.o
/build/jdyer/astute/ada/sm_model_vehicle_bb.o
/build/jdyer/astute/ada/sm_model_vehicle_enhanced_aural.o
/build/jdyer/astute/ada/sm_model_vehicle_nb_aux_int.o
/build/jdyer/astute/ada/sm_model_vehicle_nb_common.o
/build/jdyer/astute/ada/sm_model_vehicle_nb_fir.o
/build/jdyer/astute/ada/sm_model_vehicle_nb_mod.o
/build/jdyer/astute/ada/sm_model_vehicle_nb_spd_bld.o
/build/jdyer/astute/ada/sm_model_vehicle_nb_bld.o
/build/jdyer/astute/ada/sm_model_vehicle_nb_spd.o
/build/jdyer/astute/ada/sm_model_vehicle_nb.o
/build/jdyer/astute/ada/sm_model_vehicle_physical.o
/build/jdyer/astute/ada/sm_model_vehicle_propulsion_mode.o
/build/jdyer/astute/ada/sm_model_vehicle_speed_types.o
/build/jdyer/astute/ada/sm_model_vehicle_speed.o
/build/jdyer/astute/ada/sm_model_vehicle_turning_diving_types.o
/build/jdyer/astute/ada/sm_model_vehicle_turning_diving.o
/build/jdyer/astute/ada/sm_model_vehicle_wb_types.o
/build/jdyer/astute/ada/sm_model_vehicle_wb.o
/build/jdyer/astute/ada/unsigned_types.o
/build/jdyer/astute/ada/csl_ids.o
/build/jdyer/astute/ada/csl_config.o
/build/jdyer/astute/ada/sm_model_vehicle.o
/build/jdyer/astute/ada/sm_model_vehicle_database.o
./radar_vdb_access.o
-L./
-L/build/jdyer/astute/ada/
-L/build/jdyer/astute/
-L/usr/local/gcc-3.4.4/lib/gcc/i386-redhat-linux/3.4.4/adalib/
-static
-lgnat
    END Object file/option list */
