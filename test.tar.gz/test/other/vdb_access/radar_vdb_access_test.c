//  Subversion:         $Id: radar_vdb_access_test.c 11 2006-08-21 13:31:12Z rconnell $
//  Originator:         R W Norris
//
//  Quick test of Ada Radar Vehicle Database Access
//
// NB File PATH_PREFIX is required to reference the location of the vehicle DB. 
// It can be absolute or relative (to where the program runs from)
// Eg:
//
// echo /project/astute > PATH_PREFIX
//
// or should the user have there own version:
//
// echo /working/$USER/astute > PATH_PREFIX
//

#include <stdio.h>
#include <string.h>

#include "radar_vdb_access.h"

//
// Specifing any command line parameter triggers a pass of the whole DB.
//

int main( int argc, char **argv) {

  printf ("\nradar_vdb_access_test: C start...\n");

  Radar_Vdb_Access_Data_P myInfo_P;
  Radar_Vdb_Access_Data_T myInfo_T;

  printf ("\nradar_vdb_access_test: Ada starting...\n");
  adainit();
  printf ("\nradar_vdb_access_test: Ada started\n");

  // Fails
  printf ("\nradar_vdb_access_test: Expect Fail...\n");
  myInfo_P = Radar_Vdb_Access_Get_Data_P (1);
  memcpy (&myInfo_T, myInfo_P, sizeof (Radar_Vdb_Access_Data_T));
  printf ("radar_vdb_access_test: Fail Length=%f\n", myInfo_T.C200_Length);
  printf ("radar_vdb_access_test: Fail Height=%f\n", myInfo_T.C203_Height);
  printf ("radar_vdb_access_test: Fail Width=%f\n", myInfo_T.C215_Width);

  //
  // Now Initialise
  //
  Radar_Vdb_Access_Initialise ();

  // SUBTEST
  // 995 -> 995 * 2 + 1 = 1991
  // From DB:
  //        c200   Length                        ft |500.0       |            |            |
  //        c203   Vehicle Height                ft |100.0       |            |            |
  //        c215   Vehicle Width                 ft |42.0        |            |            |

  // Therefore:
  // Length =~ 150m
  // Height =~ 30m
  // Width =~ 13m

  printf ("\nradar_vdb_access_test: Expect Success Pointer Method... values roughly 150, 30, 13\n");
  myInfo_P = Radar_Vdb_Access_Get_Data_P ((995 * 2 + 1));
  memcpy (&myInfo_T, myInfo_P, sizeof (Radar_Vdb_Access_Data_T));
  printf ("radar_vdb_access_test: Subtest Length=%f\n", myInfo_T.C200_Length);
  printf ("radar_vdb_access_test: Subtest Height=%f\n", myInfo_T.C203_Height);
  printf ("radar_vdb_access_test: Subtest Width=%f\n", myInfo_T.C215_Width);

  printf ("\nradar_vdb_access_test: Expect Success - Structure Method... values <secret>\n");
  myInfo_T = Radar_Vdb_Access_Get_Data_T (7);
  printf ("radar_vdb_access_test: Echo II Length=%f\n", myInfo_T.C200_Length);
  printf ("radar_vdb_access_test: Echo II Height=%f\n", myInfo_T.C203_Height);
  printf ("radar_vdb_access_test: Echo II Width=%f\n", myInfo_T.C215_Width);

  if (argc > 1 ) {
    // Whole DB and then some   
    // Beware this can take over a minute - 2000 odd db accesses across the network!
    int i;
    for (i = 0; i < 2010; i++) {
      myInfo_P = Radar_Vdb_Access_Get_Data_P (i);
      //myInfo_T = Radar_Vdb_Access_Get_Data_T (i);
      memcpy (&myInfo_T, myInfo_P, sizeof (Radar_Vdb_Access_Data_T));
      printf ("radar_vdb_access_test: Vehicle %d: Length=%f, Height=%f, Width=%f\n", i, myInfo_T.C200_Length, myInfo_T.C203_Height, myInfo_T.C215_Width);
    }
  }

  adafinal();
  printf ("\nradar_vdb_access_test: Ada ended.\n");

  return 0;
}
