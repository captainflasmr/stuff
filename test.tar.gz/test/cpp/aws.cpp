#include <iostream>
//#include <stdexcept>
//#include <sys/select.h>
//#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

/*-----------------------------------------------------------------------------
 * Function    : main
 */
int  main( int argc, char **argv ) {

  if (argc != 1 && argc != 2) {
    return 1;
  }
  
  std::cout << "Enter name for federation to join (eg SCTTFederation):";
  char Federation[50];
  scanf ("%50s", Federation);
  return 0;
}
