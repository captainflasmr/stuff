# AGENTS.md — mild

Single-file Emacs Lisp package (Meld-Inspired Local Diff).

## Commands

```sh
# Run all tests
emacs --batch -l mild-tests.el

# Interactive usage
emacs -Q -L . -l mild.el --eval '(mild-diff "dir1" "dir2")'
```

## Structure

- `mild.el` — the package (676 lines), single entrypoint. `M-x mild-diff` (pick two dirs) or `M-x mild-diff-dwim` (guesses from Dired buffers).
- `mild-tests.el` — 2 `ert` tests. Loads `mild.el` via `(load-file "mild.el")` — run from repo root.
- No Makefile, no CI, no package manager config.

## Key conventions

- `lexical-binding: t` — be careful with closures in scan threads.
- Uses Emacs `make-thread` for async scanning — UI must update via `run-at-time` from main thread.
- `diff -q` for content comparison; set `mild-simple-comparison` for size-only (faster).
- Glob filter: `"*.elc"` matches filenames; `"tmp/*"` matches relative paths (contains `/`).
- `mild-node` struct stores the entire tree; properties attached via text-property `'mild-node`.
- Buffer-local vars (`mild-show-*`) must be `make-local-variable`'d in mode body.
- Node rendering uses standard Emacs `diff-*` faces for theming.

## Minimum Emacs version

Requires Emacs 27+ (uses `make-thread`, 4-arg `copy-directory`).
